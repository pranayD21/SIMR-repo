from enum import Enum
from typing import Optional
from pydantic import BaseModel


class AuthType(str, Enum):
    COGNITO = "cognito"
    GOOGLE = "google"
    APPLE = "apple"


class User(BaseModel):
    username: str  # email
    password: str


class SignupUser(BaseModel):
    username: str
    password: str
    email: str
    first_name: str
    last_name: str
    dob: str
    is_minor: bool
    parentname: str
    parentemail: str
    consentdate: str
    type: Optional[str] = "student"  # to set persona type
    auth_type: Optional[AuthType] = AuthType.COGNITO.value


class VerifyUser(BaseModel):
    username: str
    confirmation_code: str


class UserEmail(BaseModel):
    username: (
        str  # actually email but cognito_identity needs this to be called username
    )


class S3(BaseModel):
    id_token: str
    object_type: Optional[str] = "post"  # post/transcript. default is post.
    object_name: str
    expiration: int
    content_type: str = "application/octet-stream"
    content_len: int = 0
    content_disposition: str = "inline"


class ResetPassword(VerifyUser):
    new_password: str


class RefreshToken(BaseModel):
    refresh_token: str
    auth_token: str


class GoogleLogin(BaseModel):
    id_token: str


class GoogleSignup(GoogleLogin):
    dob: str
    parentname: str
    parentemail: str
    consentdate: str
    type: Optional[str] = "student"
