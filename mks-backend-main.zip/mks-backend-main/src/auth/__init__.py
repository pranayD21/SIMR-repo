import os
from pydantic_settings import BaseSettings
from pydantic.types import Any
from logger import log_trace, logging


class Settings(BaseSettings):
    check_expiration: bool = True
    jwt_header_prefix: str = "Bearer"
    jwt_header_name: str = "Authorization"
    app_name: str = os.environ.get("APP_NAME", "dabbl-app-mvp")
    region_name: str = os.environ.get("APP_REGION", "us-east-2")
    app_client_id: str = os.environ.get("APP_CLIENT_ID", "")
    app_client_secret: str = os.environ.get("APP_CLIENT_SECRET", "")
    user_pool_id: str = os.environ.get("APP_USER_POOL_ID", "")
    auth_type: str = "USER_PASSWORD_AUTH"
    auth_type_refresh_token: str = "REFRESH_TOKEN_AUTH"
    identity_pool_id: str = os.environ.get("IDENTITY_POOL_ID","")
    s3_bucket: str = os.environ.get("S3_BUCKET","")
    s3_private_bucket: str = os.environ.get("S3_PRIVATE_BUCKET","")
    user_pool_name: str = os.environ.get("APP_USER_POOL_NAME", "")
    google_sso_client_id: str = os.getenv("GOOGLE_CLIENT_ID", "")
    google_sso_client_secret: str = os.getenv("GOOGLE_CLIENT_SECRET", "")
    aws_access_key_id: str = os.getenv("AWS_ACCESS_KEY", "")
    aws_secret_access_key: str = os.getenv("AWS_SECRET_KEY", "")

    if (aws_access_key_id == "" or aws_secret_access_key == "" or app_client_id == "" or app_client_secret == "" or user_pool_id == "" or user_pool_name == "" or identity_pool_id == "" or s3_bucket == ""):
        log_trace(logging.INFO, "Missing env! Please set the following env variables: APP_CLIENT_ID, APP_CLIENT_SECRET, APP_USER_POOL_ID, APP_USER_POOL_NAME, IDENTITY_POOL_ID, S3_BUCKET")
    userpools: dict[str, dict[str, Any]] = {
        user_pool_name: {
            "region": region_name,
            "userpool_id": user_pool_id,
            "app_client_id": app_client_id
        }
    }
settings = Settings()
