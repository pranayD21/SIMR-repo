import os
from typing import Optional
import boto3
from logger import log_trace, logging

from . import settings
from . import schemas


def get_temporary_credentials(id_token, region_name):
    client = boto3.client('cognito-identity', region_name=region_name)
    response = client.get_id(
        IdentityPoolId=settings.identity_pool_id,
        Logins={
            'cognito-idp.' + region_name + '.amazonaws.com/' + settings.user_pool_id: id_token
        }
    )
    identity_id = response['IdentityId']
    response = client.get_credentials_for_identity(
        IdentityId=identity_id,
        Logins={
            'cognito-idp.' + region_name + '.amazonaws.com/' + settings.user_pool_id: id_token
        }
    )
    return response['Credentials']

def get_cognito_identity_id(identity_pool_id, login_token):
    cognito_client = boto3.client('cognito-identity',settings.region_name)
    response = cognito_client.get_id(
        IdentityPoolId=identity_pool_id,
        Logins={
            'cognito-idp.{0}.amazonaws.com/{1}'.format(settings.region_name,
                                                       settings.user_pool_id): login_token
        }
    )
    return response['IdentityId']

def get_presigned_url(s3_details: schemas.S3,
                      operation='get_object'):
    credentials = get_temporary_credentials(id_token=s3_details.id_token,
                                                  region_name=settings.region_name)
    identity_id = get_cognito_identity_id(settings.identity_pool_id,
                                           s3_details.id_token)
    key = "private-resources/"+identity_id+"/"+ s3_details.object_name
    s3_client = boto3.client('s3',
                             aws_access_key_id=credentials['AccessKeyId'],
                             aws_secret_access_key=credentials['SecretKey'],
                             aws_session_token=credentials['SessionToken'],
                             config = boto3.session.Config(signature_version='s3v4',
                             region_name=settings.region_name,
                             ),
                            )
    log_trace(logging.INFO, f"access key is {credentials['AccessKeyId']}")
    log_trace(logging.INFO, f"secret key is {credentials['SecretKey']}")
    log_trace(logging.INFO, f"session token is {credentials['SessionToken']}")

    if (operation == 'put_object'):
        assert s3_details.content_len != 0, "Content length must be provided for put_object operation"
        assert s3_details.content_type != '', "Content type must be provided for put_object operation"
        # If object_type == "post" (default), use the S3_BUCKET to generate the presigned url
        # If the object type == "transcript", use the S3_PRIVATE_BUCKET to generate the presigned url
        if s3_details.object_type == "post":
            bucket_name = os.environ.get("S3_BUCKET")
        elif s3_details.object_type == "essay_review" or s3_details.object_type == "lor":
            # TODO: change the bucket to private bucket, with only the user having access to it?
            bucket_name = os.environ.get("S3_BUCKET")
            key = "private-resources/" + s3_details.object_type + "s/" + identity_id + "/" + s3_details.object_name
        else:
            bucket_name = os.environ.get("S3_PRIVATE_BUCKET")

        url = s3_client.generate_presigned_url(operation,
                                               Params={'Bucket': bucket_name,
                                                        'Key': key,
                                                        'ContentType': s3_details.content_type,
                                                        'ContentLength': s3_details.content_len
                                                        },
                                               ExpiresIn=s3_details.expiration,
                                               )
        return [key, bucket_name, url]
    else:
        # We dont expect any other type of request for transcripts
        url = s3_client.generate_presigned_url(operation,
                                                Params={'Bucket': os.environ.get("S3_BUCKET"),
                                                        'Key': key,
                                                        },
                                                ExpiresIn=s3_details.expiration)
        return [key, bucket_name, url]
    
def delete_s3_file(filename: str, id_token: str, object_type: Optional[str] = "post"):
    s3_details = schemas.S3(id_token=id_token, object_name=filename, expiration=3600)
    try:
        credentials = get_temporary_credentials(id_token=s3_details.id_token,
                                                      region_name=settings.region_name)
        identity_id = get_cognito_identity_id(settings.identity_pool_id,
                                               s3_details.id_token)
    except Exception as e:
        log_trace(logging.ERROR, f"Error deleting file: {str(e)}")
        raise Exception("Failed to delete the file from the S3 bucket.")
        
    key = "private-resources/"+identity_id+"/"+ s3_details.object_name
    if object_type == "post":    
        bucket = os.environ.get("S3_BUCKET")
    elif object_type == "essay_review" or object_type == "lor":
        bucket = os.environ.get("S3_BUCKET")
        key = "private-resources/"+ object_type + "s/" + identity_id+"/"+ s3_details.object_name
    else:                    
        bucket = os.environ.get("S3_PRIVATE_BUCKET")
                             
    try:                     
        s3_client = boto3.client('s3',
                                 aws_access_key_id=credentials['AccessKeyId'],
                                 aws_secret_access_key=credentials['SecretKey'],
                                 aws_session_token=credentials['SessionToken'],
                                 config = boto3.session.Config(signature_version='s3v4',
                                        region_name=settings.region_name,
                                    ),
                                )

        log_trace(logging.INFO, f"Bucket: {bucket}, key: {key}")
        s3_client.delete_object(Bucket=bucket, Key=key)
    except Exception as e:
        log_trace(logging.ERROR, f"Error deleting file: {str(e)}")
        raise Exception("Failed to delete the file from the S3 bucket.")

    return True
