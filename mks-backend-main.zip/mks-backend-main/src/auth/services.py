from io import BytesIO
import os
import hmac
import shutil
import time
import httpx
import base64
import hashlib
import requests
import datetime
from fastapi import Depends, APIRouter, File, HTTPException, UploadFile, Request
from boto3.session import Session
from botocore.exceptions import ClientError
from fastapi_cognito import CognitoAuth, CognitoSettings, CognitoToken
from dateutil.parser import parse
from auth_jwt.jwt_token import JWKS, JWTAuthorizationCredentials, JWTBearer, fetch_jwks
from db import Constants, crud, schemas as dbschemas
from db.services import get_db
from auth import settings
from auth.s3_utils import get_presigned_url, delete_s3_file
from dotenv import load_dotenv, find_dotenv
from logger import log_trace, logging
from fastapi_sso.sso.google import GoogleSSO
from google.auth import jwt as google_jwt
from jose import jwt
from . import schemas
from reportlab.pdfgen import canvas
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph
from reportlab.lib.styles import getSampleStyleSheet
from utils import get_identity_token

_ = load_dotenv(find_dotenv())

router = APIRouter(
    prefix="/auth",
    tags=["auth"],
    # dependencies=[Depends(get_token_header)],
    responses={404: {"description": "Not found"}},
)

# Cognito identity pool service helps identify user access privs
COGNITO_IDENTITY_POOL_SVC = "cognito-idp"

cognito = CognitoAuth(
    settings=CognitoSettings.from_global_settings(settings),
    userpool_name=settings.user_pool_name)

# Needed for parsing the auth token in the request headers
jwks = JWKS.model_validate(fetch_jwks())
auth = JWTBearer(jwks)

# Configure Cognito
cognito_client = Session().client(
    COGNITO_IDENTITY_POOL_SVC,
    region_name=settings.region_name,
    aws_access_key_id=settings.aws_access_key_id,
    aws_secret_access_key=settings.aws_secret_access_key
)

google_sso = GoogleSSO(
    client_id=settings.google_sso_client_id,
    client_secret=settings.google_sso_client_secret,
)


def get_app_settings():
    return settings


def get_cognito():
    return cognito


def get_cognito_user(email: str):
    # Search for the user by email
    response = cognito_client.list_users(
        UserPoolId=settings.user_pool_id, Filter=f'email = "{email}"'
    )

    # Extract user information from the response
    users = response.get("Users", [])
    if users:
        user = users[0]
        attributes_dict = {}
        if user["Attributes"]:
            attributes_dict = {attr["Name"]: attr["Value"] for attr in user["Attributes"]}
        del user["Attributes"]
        user.update(attributes_dict)
        return user


def decode_google_id_token(token: str):
    try:
        id_info = google_jwt.decode(token, verify=False)
        return id_info
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid Google token")


def generate_secret_hash(info_to_hide: str):
    # Prepare the message to be hashed
    message = info_to_hide + settings.app_client_id

    # Create HMAC object
    hmac_obj = hmac.new(
        key=settings.app_client_secret.encode("utf-8"),
        msg=message.encode("utf-8"),
        digestmod=hashlib.sha256,
    )

    # Generate the digest and encode it in base64
    secret_hash = base64.b64encode(hmac_obj.digest()).decode("utf-8")

    return secret_hash


@router.get("/")
async def root(auth: CognitoToken = Depends(cognito.auth_required)):
    log_trace(logging.INFO, f"Token valid")
    return {"message": "Hello World"}

# Add user to cognito
# Send email to user with verification code
# Analytics hook
@router.post("/signup", dependencies=[Depends(get_app_settings)], name="signup")
async def user_signup(userinfo: schemas.SignupUser):
    return_code = 400
    try:
        secret_hash = generate_secret_hash(userinfo.email)

        updated_at = int(time.time())

        log_trace(logging.INFO, f"username: {userinfo.username}")
        log_trace(logging.INFO, f"password: {userinfo.password}")
        log_trace(logging.INFO, f"email: {userinfo.email}")
        log_trace(logging.INFO, f"first_name: {userinfo.first_name}")
        log_trace(logging.INFO, f"last_name: {userinfo.last_name}")
        log_trace(logging.INFO, f"is_minor: {userinfo.is_minor}")
        if userinfo.dob:
            log_trace(logging.INFO, f"dob: {userinfo.dob}")

        compute_is_minor = False
        # date of birth can be just the dummy date 1900-01-01
        # or the actual date of birth, in which case set is_minor to
        # True if dob is less than 18 years, and False otherwise
        if userinfo.dob is None or userinfo.dob == "":
            # is_minor should be set appropriately by UI so no need to calculate here
            userinfo.dob = Constants.DUMMY_BIRTHDATE_STR.value
        elif userinfo.dob != Constants.DUMMY_BIRTHDATE_STR.value:
            compute_is_minor = True
        date = datetime.datetime.strptime(userinfo.dob, '%m-%d-%Y')
        userinfo.dob = date.strftime('%m-%d-%Y')

        if compute_is_minor:
            # actual birthdate was received - check if minor
            # userinfo.dob is a string in the format 'mm-dd-yyyy'
            today = datetime.datetime.today()
            age = today.year - date.year - ((today.month, today.day) < (date.month, date.day))
            userinfo.is_minor = age < 18

        log_trace(logging.INFO, f"dob: {userinfo.dob}")
        log_trace(logging.INFO, f"is_minor: {userinfo.is_minor}")
        log_trace(logging.INFO, f"parentname: {userinfo.parentname}")
        log_trace(logging.INFO, f"parentemail: {userinfo.parentemail}")
        log_trace(logging.INFO, f"consentdate: {userinfo.consentdate}")
        log_trace(logging.INFO, f"updated_at: {updated_at}")
        # IMP: Cognito expects even integer custom attributes as string values  
        is_minor = "1" if userinfo.is_minor == True else "0"
        response = cognito_client.sign_up(
            ClientId=settings.app_client_id,
            Username=userinfo.email,
            Password=userinfo.password,
            SecretHash=secret_hash,
            UserAttributes=[
                {"Name": "email", "Value": userinfo.email},
                {"Name": "birthdate", "Value": userinfo.dob},
                {"Name": "given_name", "Value": userinfo.first_name},
                {"Name": "family_name", "Value": userinfo.last_name},
                {"Name": "updated_at", "Value": str(updated_at)},
                {"Name": "custom:parent_name", "Value": userinfo.parentname},
                {"Name": "custom:parent_email", "Value": userinfo.parentemail},
                {"Name": "custom:consent_date", "Value": userinfo.consentdate},
                {"Name": "custom:auth_type", "Value": userinfo.auth_type},
                {"Name": "custom:type", "Value": userinfo.type},
                {"Name": "custom:is_minor", "Value": is_minor},
            ],
        )
        log_trace(logging.INFO, f"cognito response {response}")
        return {
            "message": "User successfully signed up",
            "data": response,
            "code": 200
            }
    except ClientError as error:
        log_trace(logging.ERROR, f"cognito error {error.response['Error']['Message']}")
        error_code = error.response['Error']['Code']
        message = f"{error_code}: {error.response['Error']['Message']}"

        if error_code == 'UsernameExistsException':
            log_trace(logging.ERROR, f"User already exists.")
            #message = "User already exists."
        elif error_code == 'InvalidPasswordException':
            log_trace(logging.ERROR, f"Password does not conform to policy: it must contain special characters, numbers, etc.")
            #message = "Password does not conform to policy: it must contain special characters, numbers, etc."
            return_code = 428 # Precondition not met
        elif error_code == 'InvalidParameterException':
            log_trace(logging.ERROR, f"One or more parameters are incorrect.")
            #message = "One or more parameters are incorrect."
        elif error_code == 'TooManyRequestsException':
            log_trace(logging.ERROR, f"Too many requests: please try again later.")
            #message = "Too many requests: please try again later."
            return_code = 429 # Too many requests
        elif error_code == 'NotAuthorizedException':
            log_trace(logging.ERROR, f"Not authorized to perform this action.")
            #message = "Not authorized to perform this action."
        elif error_code == 'UserLambdaValidationException':
            log_trace(logging.ERROR, f"User Lambda validation exception.")
            #message = "User Lambda validation exception."
        elif error_code == 'InvalidLambdaResponseException':
            log_trace(logging.ERROR, f"Invalid Lambda response.")
            #message = "Invalid Lambda response."
        elif error_code == 'UnexpectedLambdaException':
            log_trace(logging.ERROR, f"Unexpected Lambda exception.")
            #message = "Unexpected Lambda exception."
        elif error_code == 'CodeDeliveryFailureException':
            log_trace(logging.ERROR, f"Failed to deliver the verification code.")
            #message = "Failed to deliver the verification code."
        elif error_code == 'LimitExceededException':
            log_trace(logging.ERROR, f"Operation limit exceeded.")
            #message = "Operation limit exceeded."
        # Add other specific error codes as needed
        else:
            log_trace(logging.ERROR, f"Unhandled error: {error_code}")
            #message = "Unhandled error. {error_code}"

    except Exception as e:
        # Catch any other exceptions that are not ClientErrors
        log_trace(logging.ERROR, f"An unexpected error occurred: {str(e)}")
        message = f"An unexpected error occurred: {str(e)}"
    
    return {
        "message": f"Error encountered in signup. {message}",
        "code": return_code
        }

# Login return:
# {status_code: 200/400, message: <msg>, data: <data>}
@router.post("/login", dependencies=[Depends(get_app_settings)], name="login")
async def login(user: schemas.User, db: Session = Depends(get_db)):
    return_code = 400
    response = None
    try:
        secret_hash = generate_secret_hash(user.username)

        response = cognito_client.initiate_auth(
            ClientId=settings.app_client_id,
            AuthFlow=settings.auth_type,
            AuthParameters={"USERNAME": user.username,
                            "PASSWORD": user.password,
                            "SECRET_HASH": secret_hash},
        )
        log_trace(logging.INFO, f"cognito response {response}")
    except ClientError as error:
        log_trace(logging.ERROR, f"cognito error {error.response['Error']['Message']}")
        error_code = error.response['Error']['Code']
        # Add error_code to message
        message = f"{error_code}: {error.response['Error']['Message']}"
        if error_code == 'UserNotConfirmedException':
            log_trace(logging.ERROR, f"User has not confirmed their email or phone number.")
            #message = "User has not confirmed their email or phone number."
            return_code = 428 # Precondition not met
        elif error_code == 'PasswordResetRequiredException':
            log_trace(logging.ERROR, f"Password reset is required for the user.")
            #message = "Password reset is required for the user."
            return_code = 428 # Precondition not met
        elif error_code == 'NotAuthorizedException':
            log_trace(logging.ERROR, f"Incorrect username or password.")
            #message = "Incorrect username or password."
        elif error_code == 'UserNotFoundException':
            log_trace(logging.ERROR, f"User does not exist.")
            #message = "User does not exist."
        elif error_code == 'TooManyRequestsException':
            log_trace(logging.ERROR, f"Too many requests: please try again later.")
            #message = "Too many requests: please try again later."
            return_code = 429 # Too many requests
        elif error_code == 'InvalidParameterException':
            log_trace(logging.ERROR, f"One or more parameters are incorrect.")
            #message = "One or more parameters are incorrect."
        elif error_code == 'InvalidPasswordException':
            log_trace(logging.ERROR, f"Password does not conform to policy: it must contain special characters, numbers, etc.")
            #message = "Password does not conform to policy: it must contain special characters, numbers, etc."
        elif error_code == 'UserLambdaValidationException':
            log_trace(logging.ERROR, f"User Lambda validation exception.")
            #message = "User Lambda validation exception."
        # Add other specific error codes as needed
        else:
            log_trace(logging.ERROR, f": {error_code}")
            message = f"{error_code}: {error.response['Error']['Message']}"
            #message = "Unhandled error. {error_code}"

        return {"message": f"Login failed: {message}", "code": return_code}

    except Exception as e:
        # Catch any other exceptions that are not ClientErrors
        log_trace(logging.ERROR, f"An unexpected error occurred: {str(e)}")
        message = f"An unexpected error occurred: {str(e)}"
        return {"message": f"Login failed: {message}", "code": 400}
    
    orig_response = response
    log_trace(logging.INFO, f"Response is {response}")

    # Here only on successful login
    try:
        if 'AuthenticationResult' not in response or 'AccessToken' not in response['AuthenticationResult']:
            log_trace(logging.ERROR, f"Login failed missing auth result in response")
            return {"message": "Login failed: missing auth result in response.", "code": 400}
        
        # MFA handling
        if "ChallengeName" in response:
            # Complete MFA
            log_trace(logging.ERROR, f"MFA required")
            return {"message": "MFA required", "challenge_name": response["ChallengeName"]}
        else:
            # Check if this is the first login - if so, get user info from cognito and add user record to db
            # Check if user exists in db
            # If not, add user to db
            db_user = crud.get_user_by_username_or_email(db,
                                                        username=None,
                                                        email=user.username)
            if db_user:
                # Check if user has been deleted, and if yes return an error to fail login
                if not db_user.is_active:
                    log_trace(logging.ERROR, f"Login failed user has been deleted")
                    return {"message": "Login failed: user has been deleted", "code": 400}
                
                if db_user.type == Constants.DB_USER_TYPE_STUDENT.value:
                    db_student = crud.get_student_by_uid(db, db_user.id)
                    if not db_student:
                        # For Backward Compatibility - users that dont have corresponding student accounts already
                        db_student = crud.create_student(db, student=dbschemas.StudentCreate(user_id=db_user.id))
                        if not db_student:
                            log_trace(logging.ERROR, f"Login failed unknown error creating student user")
                            return {"message": "Login failed: unknown error creating student user", "code": 400}
                elif db_user.type == Constants.DB_USER_TYPE_COUNSELOR.value:
                    db_counselor = crud.get_counselor_by_uid(db, db_user.id)
                    if not db_counselor:
                        db_counselor = crud.create_counselor(db, counselor=dbschemas.CounselorCreate(user_id=db_user.id))
                        if not db_counselor:
                            log_trace(logging.ERROR, f"Login failed unknown error creating counselor user")
                            return {"message": "Login failed: unknown error creating counselor user", "code": 400}
                else:
                    log_trace(logging.ERROR, f"Login failed unknown user persona selected")
                    return {"message": "Login failed: unknown user persona selected", "code": 400}
            elif not db_user:
                # Get user info from cognito
                response = cognito_client.get_user(AccessToken=response["AuthenticationResult"]["AccessToken"])
                log_trace(logging.INFO, f"cognito user response {response}")

                user_attributes = {attr['Name']: attr['Value'] for attr in response['UserAttributes']}
                log_trace(logging.INFO, f"{user_attributes}")

                if 'custom:parent_name' in user_attributes:
                    parent_name = user_attributes['custom:parent_name']
                    parent_email = user_attributes['custom:parent_email']
                else:
                    parent_name = ''
                    parent_email = ''
                
                cognito_user = {
                    'username': user_attributes['given_name'] + ' ' + user_attributes['family_name'],
                    'uid': user_attributes['sub'], # 'sub
                    'email': user_attributes['email'],
                    'given_name': user_attributes['given_name'],
                    'family_name': user_attributes['family_name'],
                    'dob': parse(user_attributes['birthdate']), # 'custom:dob
                    'parent_name': parent_name,
                    'parent_email': parent_email,
                    'consent_date': parse(user_attributes['custom:consent_date']),
                    'is_online': False,
                    'is_minor': True if user_attributes['custom:is_minor'] == "1" else False,
                    'fcm_token': '',
                    'website': '',
                    'personal_statement': '',
                    'connections': [],
                    'profile_pic_url': '',
                    'show_sensitive_info': False,
                    'type': user_attributes['custom:type']
                }

                # Add user to db
                cuser = dbschemas.UserCreate(
                    username=cognito_user['username'],
                    uid=cognito_user['uid'],
                    email=cognito_user['email'],
                    first_name=cognito_user['given_name'],
                    last_name=cognito_user['family_name'],
                    parent_name=cognito_user['parent_name'] if 'parent_name' in cognito_user else '',
                    parent_email=cognito_user['parent_email'] if 'parent_email' in cognito_user else '',
                    birthdate=cognito_user['dob'],
                    consentdate=cognito_user['consent_date'],
                    followers=[],
                    following=[],
                    counselor_connections=[],
                    type=cognito_user['type'],
                    website=cognito_user['website'],
                    personal_statement=cognito_user['personal_statement'],
                    connections=cognito_user['connections'],
                    profile_pic_url=cognito_user['profile_pic_url'],
                    is_online=cognito_user['is_online'],
                    is_minor=cognito_user['is_minor'],
                    fcm_token=cognito_user['fcm_token'],
                    show_sensitive_info=cognito_user['show_sensitive_info'],
                    is_active=True,
                    date_deleted=None
                )

                try:
                    db_user = crud.create_user(db=db, user=cuser)
                    if db_user.type == Constants.DB_USER_TYPE_STUDENT.value:
                        db_student = crud.get_student_by_uid(db, db_user.id)
                    else:
                        db_counselor = crud.get_counselor_by_uid(db, uid=db_user.id)
                    
                except Exception as db_err:
                    log_trace(logging.ERROR, f"error adding user to db {str(db_err)}")
                    return {"message": "Login failed: Internal server error", "code": 400}

            # IMPORTANT: Add user and student ids to response
            # TEMP HACK: Use two keys: "id" and "user_id" to store the user id
            # and "student_id" to store the student id in the response
            # Once the frontend is updated, we can remove the "id" key
            if db_user.type == Constants.DB_USER_TYPE_STUDENT.value:
                orig_response.update({"id": db_user.id,
                                      "user_id": db_user.id,
                                      "student_id": db_student.id})
            else:
                orig_response.update({"id": db_user.id,
                                      "user_id": db_user.id,
                                      "counselor_id": db_counselor.id})
            
            return {"message": "User successfully signed in ", "data": orig_response, "code": 200}

    except Exception as error:
        log_trace(logging.ERROR, f"{str(error)}")
        message = f"Login failed. An error occurred while processing your request: {str(error)}"
        return {"message": message, "code": 400}

@router.post("/refresh-auth-token", dependencies=[Depends(get_app_settings)])
def refresh_token(refreshtoken: schemas.RefreshToken): # = Depends(auth)):
    try:
        decoded_token = jwt.get_unverified_claims(refreshtoken.auth_token)
        log_trace(logging.INFO, f"decoded_token {decoded_token}")
        cognito_username = decoded_token['username']
        secret_hash = generate_secret_hash(cognito_username)
    
        response = cognito_client.initiate_auth(
            ClientId=settings.app_client_id,
            AuthFlow=settings.auth_type_refresh_token,
            AuthParameters={"REFRESH_TOKEN": refreshtoken.refresh_token,
                            "SECRET_HASH": secret_hash},
        )
        log_trace(logging.INFO, f"refresh token response {response}")
        
        return {"message": "Token successfully refreshed", "data": response, "code": 200}
    except cognito_client.exceptions.NotAuthorizedException as e:
        log_trace(logging.ERROR, f"Not authorized to refresh token {str(e)}")
    except cognito_client.exceptions.ResourceNotFoundException as e:
        log_trace(logging.ERROR, f"Resource not found {str(e)}")
    except Exception as e:
        log_trace(logging.ERROR, f"Error refreshing token {str(e)}")

# delete file from s3
@router.post("/delete_file/", dependencies=[Depends(get_app_settings)])
async def delete_file(filename: str, 
                      credentials: JWTAuthorizationCredentials = Depends(auth)):
    s3_details = schemas.S3(id_token=credentials.jwt_token, object_name=filename, expiration=3600)
    # key = ''
    # url = ''
    # try:
    #     [key, url] = get_presigned_url(s3_details, operation='delete_object')
    # except ClientError as error:
    #     log_trace(logging.ERROR, f"S3 Signed URL Failed {error.response['Error']['Message']}")
    #     return {"message": f"S3 Signed URL Failed: {error.response['Error']['Message']}", "code": 400}
    # # Delete the file
    # response = requests.delete(url)

    response = delete_s3_file(filename, credentials.jwt_token)
    if response:
        return {"message": "File successfully deleted", "code": 200}
    
    return {"message": "File deletion failed", "code": 400}
    
# Upload a pdf file to s3
@router.post("/upload_pdf_file/", dependencies=[Depends(get_app_settings)])
async def upload_pdf(file: UploadFile = File(...),
                     object_type: str = "essay_review",
                     credentials: JWTAuthorizationCredentials = Depends(auth),
                     identity_token: str = Depends(get_identity_token)
                    ):
    try:
        log_trace(logging.INFO, f"file name {file.filename}")

        pdf_buffer = BytesIO()
        shutil.copyfileobj(file.file, pdf_buffer)

        # Reset buffer position
        pdf_buffer.seek(0)
        pdf_buffer_length = len(pdf_buffer.getbuffer())
        # Set the name for the PDF file - remove old extension, add .pdf
        pdf_buffer.name = file.filename

        log_trace(logging.INFO, f"pdf_buffer name {pdf_buffer.name}")
        s3_details = schemas.S3(id_token=identity_token,
                                object_type=object_type,
                                object_name=pdf_buffer.name,
                                content_len=pdf_buffer_length,
                                content_type="application/pdf",
                                expiration=3600)
        [key, bucket_name, url] = get_presigned_url(s3_details=s3_details, operation='put_object')
        log_trace(logging.INFO, f"Presigned url {url}")

        # Upload to s3
        headers = {
            "x-amz-content-sha256": "UNSIGNED-PAYLOAD",
            "Content-Type": "application/pdf",
            "Content-Len": str(pdf_buffer_length),                                                                 
            "Content-Disposition": "inline"
        }
        response = requests.put(url, headers=headers, data=pdf_buffer)
        if response.status_code == 200:
            # Construct the url to the file
            url = f"https://{bucket_name}.s3.{settings.region_name}.amazonaws.com/{key}"
            return {"data": url, "message": "File successfully uploaded to S3", "status_code": 200}
        else:
            log_trace(logging.INFO, f"response code {response.status_code}; error {response.text}")
            return {"message": "File upload failed.", "status_code": 400}
    except ClientError as error:
        log_trace(logging.ERROR, f"S3 error {error.response['Error']['Message']}")
        return {"message": f"S3 Signed URL Failed: {error.response['Error']['Message']}", "status_code": 400}
    
# upload file to s3
@router.post("/upload_file/", dependencies=[Depends(get_app_settings)])
async def upload_file(file: UploadFile = File(...),
                            credentials: JWTAuthorizationCredentials = Depends(auth),
                            ):
    try:
        contents = file.file        
        s3_details = schemas.S3(id_token=credentials.jwt_token, object_name=file.filename, expiration=3600)

        [key, bucket_name, url] = get_presigned_url(s3_details.id_token, object_name=s3_details.object_name,
                                operation='put_object', expiration=s3_details.expiration) #, credentials=tmp_credentials)
        log_trace(logging.INFO, f"Presigned url {url}")
        # Upload to s3
        headers = {
            "x-amz-content-sha256": "UNSIGNED-PAYLOAD",
        }
        response = requests.put(url, headers=headers, data=contents)
        if response.status_code == 200:
            # Construct the url to the file
            url = f"https://{bucket_name}.s3.{settings.region_name}.amazonaws.com/{key}"
            return {"data": url, "message": "File successfully uploaded to S3", "status_code": 200}
        else:
            log_trace(logging.INFO, f"response code {response.status_code}; error {response.text}")
            return {"message": "File upload failed.", "status_code": 400}
    except ClientError as error:
        log_trace(logging.ERROR, f"S3 error {error.response['Error']['Message']}")
        return {"message": f"S3 Signed URL Failed: {error.response['Error']['Message']}", "status_code": 400}


# get file from s3
@router.post("/presigned_url/get", dependencies=[Depends(get_app_settings)])
async def get_s3_url(s3_details:schemas.S3,
                            db: Session = Depends(get_db),
                            credentials: JWTAuthorizationCredentials = Depends(auth),
                            ):
    key = ''
    url = ''
    try:
        log_trace(logging.INFO, f"s3_details are {s3_details}")
        [key, bucket_name, url] = get_presigned_url(s3_details, operation='get_object')
    except ClientError as error:
        log_trace(logging.ERROR, f"S3 Signed URL Failed {error.response['Error']['Message']}")
        return {"message": f"S3 Signed URL Failed: {error.response['Error']['Message']}", "code": 400}
    output = {
        "message": "Presigned URL successfully generated",
        "data": {
            "url": url,
            "key": key
        },
        "code": 200
    }
    return output

# put file from s3
@router.post("/presigned_url/put", dependencies=[Depends(get_app_settings)])
async def get_s3_url(s3_details:schemas.S3,
                     credentials: JWTAuthorizationCredentials = Depends(auth),
                    ):
    key = ''
    url = ''
    try:
        [key, bucket_name, url] = get_presigned_url(s3_details, operation='put_object')
        log_trace(logging.INFO, f"presigned url is {url} AND key is {key}")
    except ClientError as error:
        log_trace(logging.ERROR, f"S3 Signed URL Failed {error.response['Error']['Message']}")
        return {"message": f"S3 Signed URL Failed: {error.response['Error']['Message']}", "code": 400}
    
    output = {
        "message": "Presigned URL successfully generated",
        "data": {
            "url": url,
            "key": key,
        },
        "code": 200
    }
    return output

# delete file from s3
@router.post("/presigned_url/delete", dependencies=[Depends(get_app_settings)])
async def get_s3_url(s3_details:schemas.S3,
                            db: Session = Depends(get_db),
                            credentials: JWTAuthorizationCredentials = Depends(auth),
                            ):
    key = ''
    url = ''
    try:
        [key, bucket_name, url] = get_presigned_url(s3_details, operation='delete_object')
    except ClientError as error:
        log_trace(logging.ERROR, f"S3 Signed URL Failed {error.response['Error']['Message']}")
        return {"message": f"S3 Signed URL Failed: {error.response['Error']['Message']}", "code": 400}
    output = {
        "message": "Presigned URL successfully generated",
        "data": {
            "url": url,
            "key": key
        },
        "code": 200
    }
    return output

# Define the /logout endpoint
@router.post("/logout", dependencies=[Depends(get_app_settings)])
async def logout_user(credentials: JWTAuthorizationCredentials = Depends(auth)):
    try:
        access_token = credentials.jwt_token
        response = cognito_client.global_sign_out(AccessToken=access_token)
        log_trace(logging.INFO, f"")
        return {"message": "Logout successful", "status_code": 200}
    except Exception as e:
        log_trace(logging.ERROR, f"logout failed {str(e)}")
        # Handle errors gracefully
        return {"message": f"Logout failed: {str(e)}", "status_code": 400}

# Resend confirmation code endpoint
@router.post("/resend-confirmation-code", dependencies=[Depends(get_app_settings)])
async def resend_confirmation_code(user: schemas.UserEmail):
    try:
        secret_hash = generate_secret_hash(user.username)
        response = cognito_client.resend_confirmation_code(
            ClientId=settings.app_client_id,
            Username=user.username,
            SecretHash=secret_hash,
        )
        log_trace(logging.INFO, "resend_confirmation_code: Confirmation code successfully resent")
        return {"message": "Confirmation code successfully resent", "data": response, "status_code": 200}
    except ClientError as error:
        log_trace(logging.ERROR, f"Confirmation code resend failed {error.response['Error']['Message']}")
        return {"message": f"Confirmation code resend failed: {error.response['Error']['Message']}", "status_code": 400}

@router.post("/verify-email", dependencies=[Depends(get_app_settings)])
async def verify(verify_user: schemas.VerifyUser):
    try:
        secret_hash = generate_secret_hash(verify_user.username)

        response = cognito_client.confirm_sign_up(
            ClientId=settings.app_client_id,
            Username=verify_user.username,
            ConfirmationCode=verify_user.confirmation_code,
            SecretHash=secret_hash,
        )
        log_trace(logging.INFO, f"User email verified cognito data {response}")
        return {"message": "User email successfully verified", "data": response, "status_code": 200}
    except ClientError as error:
        log_trace(logging.ERROR, f"Email verification failed: {error.response['Error']['Message']}")
        return {"message": f"Email verification failed: {error.response['Error']['Message']}", "status_code": 400}


@router.post("/forgot-password", dependencies=[Depends(get_app_settings)])
async def forgot_password(fpuser: schemas.UserEmail):  # username: str):
    try:
        secret_hash = generate_secret_hash(fpuser.username)
        existing_user = get_cognito_user(email=fpuser.username)

        if (
            existing_user and existing_user.get("custom:auth_type")
            and existing_user["custom:auth_type"]
            != schemas.AuthType.COGNITO.value
        ):
            message = f"Update password is prohibited for user registered through {existing_user['custom:auth_type']}"
            log_trace(logging.INFO, message)
            raise HTTPException(status_code=400, detail=message)

        response = cognito_client.forgot_password(
            ClientId=settings.app_client_id,
            Username=fpuser.username,
            SecretHash=secret_hash,
        )
        log_trace(
            logging.INFO, f"password reset request sent, cognito response {response}"
        )
        return {
            "message": "User password reset request received",
            "data": response,
            "status_code": 200,
        }
    except ClientError as error:
        message = f"Password reset failed: {error.response['Error']['Message']}"
        log_trace(logging.ERROR, message)
        return {"message": message, "status_code": 400}


# Reset password
@router.post("/reset-password", dependencies=[Depends(get_app_settings)])
async def reset_password(reset_password: schemas.ResetPassword):
    try:
        secret_hash = generate_secret_hash(reset_password.username)

        response = cognito_client.confirm_forgot_password(
            ClientId=settings.app_client_id,
            Username=reset_password.username,
            ConfirmationCode=reset_password.confirmation_code,
            Password=reset_password.new_password,
            SecretHash=secret_hash,
        )
        log_trace(logging.INFO, f"password successfully reset, cognito response {response}")
        return {"message": "User password successfully reset", "data": response, "code": 200}
    except ClientError as error:
        log_trace(logging.INFO, f"Password reset failed: {error.response['Error']['Message']}")
        return {"message": f"Password reset failed: {error.response['Error']['Message']}", "code": 400}


@router.get("/google/auth")
async def get_google_auth(request: Request):
    redirect_uri = str(request.url_for("google_user_details"))
    return await google_sso.get_login_redirect(redirect_uri=redirect_uri)


@router.get("/google/user", name="google_user_details")
async def get_google_user_details(request: Request):
    user_info = await google_sso.verify_and_process(request)
    user = dict(user_info)
    user["id_token"] = google_sso.id_token
    return user


@router.post("/google/login")
async def google_login(request: Request, user_info: schemas.GoogleLogin):
    google_user_details = decode_google_id_token(user_info.id_token)
    password = generate_secret_hash(google_user_details["sub"])

    login_cred = schemas.User(username=google_user_details["email"], password=password)
    login_uri = str(request.url_for("login"))

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(login_uri, json=login_cred.model_dump())

        response = response.json()
    except httpx.HTTPStatusError as http_exc:
        message = f"Error response {http_exc.response.status_code} while requesting {http_exc.request.url!r}, Error {http_exc}"
        log_trace(logging.ERROR, message)
        raise HTTPException(status_code=http_exc.response.status_code, detail=message)
    except httpx.RequestError as req_exc:
        message = f"An error occurred while requesting {req_exc.request.url!r}, Error {req_exc}"
        log_trace(logging.ERROR, message)
        raise HTTPException(status_code=500, detail=message)
    except Exception as exc:
        message = f"An unexpected error occurred: {exc}"
        log_trace(logging.ERROR, message)
        raise HTTPException(status_code=500, detail=message)

    if not response.get("data"):
        response["google_user_info"] = {
            "name": google_user_details["name"],
            "email": google_user_details["email"],
            "picture": google_user_details["picture"],
            "given_name": google_user_details["given_name"],
            "family_name": google_user_details["family_name"],
        }
    return response


@router.post("/google/signup")
async def google_signup(request: Request, user_info: schemas.GoogleSignup):
    google_user_details = decode_google_id_token(user_info.id_token)
    password = generate_secret_hash(google_user_details["sub"])

    signup_cred = schemas.SignupUser(
        username=google_user_details["email"],
        password=password,
        email=google_user_details["email"],
        first_name=google_user_details["given_name"],
        last_name=google_user_details["family_name"],
        dob=user_info.dob,
        parentname=user_info.parentname,
        parentemail=user_info.parentemail,
        consentdate=user_info.consentdate,
        type=user_info.type,
        auth_type=schemas.AuthType.GOOGLE.value
    )
    signup_uri = str(request.url_for("signup"))
    # Try to sign up the user in Cognito
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(signup_uri, json=signup_cred.model_dump())

        return response.json()
    except httpx.HTTPStatusError as http_exc:
        message = f"Error response {http_exc.response.status_code} while requesting {http_exc.request.url!r}, Error {http_exc}"
        log_trace(logging.ERROR, message)
        raise HTTPException(status_code=http_exc.response.status_code, detail=message)
    except httpx.RequestError as req_exc:
        message = f"An error occurred while requesting {req_exc.request.url!r}, Error {req_exc}"
        log_trace(logging.ERROR, message)
        raise HTTPException(status_code=500, detail=message)
    except Exception as exc:
        message = f"An unexpected error occurred: {exc}"
        log_trace(logging.ERROR, message)
        raise HTTPException(status_code=500, detail=message)
