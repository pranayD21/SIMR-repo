from pydantic import BaseModel
from typing import Optional, Dict, Any, List
from datetime import datetime
from .analytics_constants import EventType

class EventData(BaseModel):
    event_type: EventType
    unique_id: str
    timestamp: datetime
    attributes: Optional[Dict[str, Any]] = None

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat(),
            EventType: lambda v: v.value
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'EventData':
        if isinstance(data.get('event_type'), int):
            data['event_type'] = EventType(data['event_type'])
        elif isinstance(data.get('event_type'), str):
            data['event_type'] = EventType[data['event_type'].upper()]
        
        if isinstance(data.get('timestamp'), str):
            data['timestamp'] = datetime.fromisoformat(data['timestamp'])
        
        return cls(**data)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "event_type": self.event_type.value,
            "unique_id": self.unique_id,
            "timestamp": self.timestamp.isoformat(),
            "attributes": self.attributes
        }


class StudentRecommendationResponse(BaseModel):
    unique_id: int
    recommended_colleges: List[str]
    saved_colleges: List[str]
    total_recommended_colleges: int = 0
    total_saved_colleges: int = 0
    last_recommendation_time: datetime
    last_saved_time: datetime
