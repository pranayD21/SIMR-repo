import json
import os
import logging
from enum import Enum, auto
from datetime import datetime, timezone
from typing import Optional, Dict, Any
from pydantic import BaseModel, Field

# Analytic Database  URL and CLient Token details 
BASE_URL = os.environ.get("SERVER_URL")
timeout = int(os.getenv("REQUEST_TIMEOUT"))

def generate_auth_header():
    """
    Generates the authentication header for the analytics service.

    Returns:
        dict: The authentication header.
    """
    #auth_token = os.environ.get("ANALYTIC_AUTH_TOKEN")
    #if auth_token is None:
    #    raise ValueError("ANALYTIC_AUTH_TOKEN is not set")
    #TODO : Comment the authorization requirement for internal services
    return {
        # "Authorization": f"Bearer {auth_token}",
        "Content-Type": 'application/json'
    }

class EventType(Enum):
    """
    Enumeration of all the analytics event types.

    Attributes:
        USER_SIGNUP (EventType): Event triggered when a user signs up.
        USER_DELETE (EventType): Event triggered when a user is deleted.
        USER_DISABLE_ACCOUNT (EventType): Event triggered when a user disables their account.
        USER_RESTORE_ACCOUNT (EventType): Event triggered when a user restores their account.
        RECOMMENDATION_CAREER (EventType): Event triggered when a career recommendation is generated.
        RECOMMENDATION_SAVED_CAREER (EventType): Event triggered when a career recommendation is saved.
        RECOMMENDATION_DELETE_CAREER (EventType): Event triggered when a career recommendation is deleted.
        RECOMMENDATION_COLLEGE (EventType): Event triggered when a college recommendation is generated.
        RECOMMENDATION_SAVED_COLLEGE (EventType): Event triggered when a college recommendation is saved.
        RECOMMENDATION_DELETE_COLLEGE (EventType): Event triggered when a college recommendation is deleted.
        RECOMMENDATION_THUMBS_DOWN (EventType): Event triggered when a user clicks the thumbs-down button on a recommendation.
        AGGREGATE_COLLEGE_RECOMMENDATIONS (EventType): Event triggered after post processing the data to aggregate and send college recommendation data to the collector.

      Events that are triggered to indicate user profile updates
              USER_PROFILE_UPDATE (EventType): Event triggered when a user updates their account. ( Added achool, GPA )
    """
    # User Activity Events
    USER_SIGNUP = auto()    
    USER_DELETE = auto()
    USER_DISABLE_ACCOUNT = auto()
    USER_RESTORE_ACCOUNT = auto()
    USER_PROFILE_UPDATE = auto()
    
    # Recommendation Events
    RECOMMENDATION_CAREER = auto()
    RECOMMENDATION_SAVED_CAREER = auto()
    RECOMMENDATION_DELETE_CAREER = auto()
    RECOMMENDATION_COLLEGE = auto()
    RECOMMENDATION_SAVED_COLLEGE = auto()
    RECOMMENDATION_DELETE_COLLEGE = auto()
    RECOMMENDATION_THUMBS_DOWN = auto()

    #List of Events  that are triggeredby the analytics Framework on post processing the data 
    # Mostly invovles aggregation of data and sending it to the collector with unique id set to 'system'
    AGGREGATE_COLLEGE_RECOMMENDATIONS = auto()
    
    # List only Events that should trigger a User profile update
    @classmethod
    def user_activity_events(cls):
        """
        Returns a set of all user activity event types.
        """
        return frozenset({
            cls.USER_SIGNUP,          # not triggered  on backend code
            cls.USER_PROFILE_UPDATE,
        })
    
    @classmethod
    def college_recommendation_events(cls):
        """
        Returns a set of all college recommendation event types.
        """
        return frozenset({
            cls.RECOMMENDATION_COLLEGE,
            cls.RECOMMENDATION_SAVED_COLLEGE,
            cls.RECOMMENDATION_DELETE_COLLEGE
        })
    
    @classmethod
    def career_recommendation_events(cls):
        """
        Returns a set of all career recommendation event types.
        """
        return frozenset({
            cls.RECOMMENDATION_CAREER,
            cls.RECOMMENDATION_SAVED_CAREER
        })
    
    @staticmethod
    def from_str(label: str) -> 'EventType':
        """
        Returns the corresponding EventType for the given label.

        Raises a ValueError if the label is unknown.

        Args:
            label (str): The label of the EventType.

        Returns:
            EventType: The corresponding EventType.

        Raises:
            ValueError: If the label is unknown.
        """
        try:
            return EventType[label.upper()]
        except KeyError:
            raise ValueError(f"Unknown EventType: {label}")

    def __str__(self) -> str:
        """
        Returns the string representation of the event type.

        Returns:
            str: The string representation of the event type.
        """
        return self.name.lower()

class AnalyticsEvent(BaseModel):
    """
    Represents an analytics event.

    Attributes:
        event_type (EventType): The type of the event.
        unique_id (int): The ID of the user or session that event is triggered by
        timestamp (Optional[datetime]): The timestamp of the event. Defaults to the current UTC datetime.
        attributes (Optional[Dict[str, Any]]): Additional attributes of the event.
    """
    event_type: EventType
    unique_id: str
    timestamp: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    attributes: Optional[Dict[str, Any]] = None

    model_config = {
        "json_encoders": {
            datetime: lambda v: v.isoformat(),
            EventType: lambda v: v.name,
        }
    }
    def serialize_value(self, value: Any) -> Any:
        """
        Recursively serialize a value, handling various types.
        """
        if isinstance(value, datetime):
            return value.isoformat()
        elif isinstance(value, Enum):
            return value.value
        elif isinstance(value, dict):
            return {k: self.serialize_value(v) for k, v in value.items()}
        elif isinstance(value, list):
            return [self.serialize_value(item) for item in value]
        elif isinstance(value, (int, float, str, bool, type(None))):
            return value
        else:
            # For any other types, convert to string
            return str(value)

    def to_dict(self) -> Dict[str, Any]:
        """
        Converts the event to a dictionary, ensuring all values are serializable.
        """
        return {
            "event_type": self.event_type.value,
            "unique_id": self.unique_id,
            "timestamp": self.timestamp.isoformat(),
            "attributes": self.serialize_value(self.attributes)
        }

    def to_json(self, **kwargs) -> str:
        """
        Converts the event to a JSON string.

        Returns:
            str: The event as a JSON string.
        """
        return json.dumps(self.to_dict(), **kwargs)
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'AnalyticsEvent':
        """
        Creates an AnalyticsEvent instance from a dictionary.

        Args:
            data (Dict[str, Any]): The dictionary containing the event data.

        Returns:
            AnalyticsEvent: The created event instance.
        """
        logging.info(f"Creating AnalyticsEvent from {data}")
        return cls(
            event_type=data["event_type"],
            unique_id=data["unique_id"],
            timestamp=datetime.fromisoformat(data["timestamp"]),
            attributes=data.get("attributes", {})
        )

if __name__ == "__main__":
    # Example usage:
    event = AnalyticsEvent(
        unique_id=123,
        event_type=EventType.USER_SIGNUP,
        attributes={"usersSignedUp": 10, "loginFrequency": 5}
    )

    print(event.to_json())

