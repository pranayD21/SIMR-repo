# Analytics Framework
Requirement:
The Generic Analytics  Data  pipeline for collecting and analyzing data from various events and supports a wide range of data sources and analytics engines.
1)  Business objectives to be met by the analytics ? 
2)  What Data are we interested to collect and purpose?   
   -  user activity data 
         - Users signed up,  How often are users logging in and using the tool , Users who havent logged in for a while, Account update
   - Recommendation Effectiveness - Accuracy and relevance
      - How many careers were recommended and were saved by the user
      - User clicked on thumbsup for the recommendation to highlight the relevance 
   - Trends /Data that end customers would be able to use. Example school admins
      - Users distribution filtered on schools
      - Users distribution , school  filtered on interests trend
      - Users students colleges , Future data
 - Data to support Marketing and other external teams    
      - When users log in do we ask how they got introduced to the app ?
      - Explicit ask users on the  satisfaction rating ?
2) Source  for the Data , is it form UI & User interaction,  DB CRUD events, other feature usage like transcript uploaded
3) Integrating the  analytics tool that is best for the purpose


## Example of Data Reports that can  be generated
--------------------------------
Product Usage -User Engagement

1. New Users who have successfully logged in (weekly/monthly)
2. New users who have been unsuccessful  (Monthly)
3. Popular feature  - Users spend their time most on what screens (Careers ? Colleges? Roadmaps)
4. Trends
   - Where is the most traction ?  Is it from Mobile or web   (Group users based on platforms)
   - How diverse are the users w.r.t to Geo location (Group successfully logged in users based on country , states , schools , GPA)

Recommendation Effectiveness

1. Users spending most of their time in AI explore - Recommendation Careers or Recommendation  colleges ,   Saved Careers /Saved colleges
2. Diversity in Recommendation - What is the spread of colleges being recommended.  Are we seeing any Bias ?

## Type of Events (To be Updated)

Events represent any user activity and is defined by 
- Event type 
- Unique-ID    (ID of the user or the session the event was triggered)
- Timestamp  (The timestamp of the event)
- Attributes   (Additional Data of the event)

| Event Type | Description | Examples |
|------------|-------------|-----------|
| USER_DELETE | Unique ID, Delete Date | Delete account forever |
| USER_DISABLE_ACCOUNT | Unique ID | Soft-delete , still possible to restore the account |
| USER_RESTORE_ACCOUNT | Unique ID | Restore the account |
| RECOMMENDATION_COLLEGE | Unique ID,  Unique List of colleges recommended by AI, timestamp | College recommendation data from AI |
| RECOMMENDATION_SAVED_COLLEGE | Unique ID ,  Unique list of colleges saved by the user, timestamp | College recommendation data saved by the User |
| RECOMMENDATION_DELETE_COLLEGE | Unique ID ,  Unique list of colleges deleted by the user | College recommendation data deleted by the User |
## Usage

Execution:
 Define environment variable MIXPANEL_KEY which is the project token provided on Mixpanel projects

Integrating a module to Analytic service
1) Refer file db/analytic_data.py as reference implementation
2) Update analytics/analytics_constants.py with new events and additional shared data.

## Testing
cd  mks-backend/src/test
bash test_anaytics.sh  --> Update this shell script to  trigger new events.


## Design Guideline -Best Practice
Do we report data from frontend or Backend ?
  The frontend can impact the load, increase data usage, and affect battery consumption of users. If the data is available only on front end then leverage reporting from frontend else by default send data from Backend.
