"""
Analytics module.

This module provides the AnalyticsManager class which is used to track events with
different analytics services.

The AnalyticsManager class provides the following methods:

- __init__: Initialize the analytics manager.
- track_event_async: Track an event asynchronously with all services.
- post_process_and_run_analytics: Run the college recommendation analytics asynchronously and send as an aggregate event.

The AnalyticsManager class uses the following services:

- LocalDatabaseAnalyticsService: A service that stores events in a local database.  ( Commented code for writing to DB as the analytics DB is not well defined)
- MixpanelService: A service that tracks events with Mixpanel.

The AnalyticsManager class provides the following events:

- AnalyticsEvent: An event that can be tracked.
"""

import os
import asyncio
from typing import Union, Coroutine, Any
from abc import ABC, abstractmethod
from logger import logging, log_trace
from dotenv import load_dotenv
# import required modules from mixpanel
import mixpanel
from mixpanel_async import AsyncBufferedConsumer
from datetime import datetime
from .analytics_constants import EventType, AnalyticsEvent
from . import events_database as database

# Load the .env file
load_dotenv()

class AnalyticsService(ABC):
    """
    Abstract base class for analytics services.

    This class defines the abstract method: `track_event_async`.
    These methods must be implemented by any child class that inherits from this class.

    The `track_event_async` method is used to track an event asynchronously.
    It takes an `AnalyticsEvent` object as an argument and returns a coroutine object.
    """

    @abstractmethod
    async def track_event_async(self, event: AnalyticsEvent):
        """
        Track an event asynchronously.

        Args:
            event (AnalyticsEvent): The event to be tracked.

        Returns:
            Coroutine: A coroutine object representing the asynchronous task.
        """
        pass

class MixpanelService(AnalyticsService):
    """
    Mixpanel analytics service.

    This class is used to track events with Mixpanel.
    """

    def __init__(self, api_key: str):
        """
        Initialize the Mixpanel service.

        Args:
            api_key (str): Mixpanel API key.
        """
        self.mixpanel = mixpanel.Mixpanel(api_key,  consumer=AsyncBufferedConsumer())
        log_trace(logging.INFO, f"MixPanel service initialized successfully with API key")


    async def track_event_async(self, event: AnalyticsEvent):
        """
        Track an event asynchronously with Mixpanel.

        Args:
            event (AnalyticsEvent): The event to be tracked.

        Returns:
            dict: The result of the Mixpanel tracking request.

        Raises:
            Exception: If there was an error tracking the event.
        """
        try:
            event.attributes["User ID"] = event.unique_id
            if event.event_type  in EventType.user_activity_events():
                 self.mixpanel.people_set(event.unique_id, event.attributes)
                 return
            log_trace(logging.INFO, f"event {event.event_type} for user {event.unique_id} in mixpanel with attributes {event.attributes}")
            self.mixpanel.track(event.unique_id, event.event_type.name, event.attributes)
        except Exception as e:
            log_trace(logging.ERROR, f"Error tracking Mixpanel event asynchronously: {e}")
            raise

class LocalDatabaseAnalyticsService(AnalyticsService):
    """
    Local database analytics service.

    This class is used to track events in a local database.
    """
    def __init__(self):
        """
        Initialize the local database analytics service.
        """
        pass


    async def track_event_async(self, event: AnalyticsEvent):
        """
        Track an event asynchronously in the local database.

        Args:
            event (AnalyticsEvent): The event to be tracked.
        """
        try:
            log_trace(logging.INFO, f"DB Analytics service Starting to track event: {event.event_type}")

            def write_event_database(event: AnalyticsEvent) -> Any:
                try:
                    # Skip writing events to DB
                    # database.write_event(event)
    
                    if event.event_type in EventType.user_activity_events():
                        database.update_user_profile(event)
                        log_trace(logging.INFO, "DB User profile updated")
                    
                    if event.event_type in EventType.college_recommendation_events():
                        database.write_student_college_recommendations(event)
                        log_trace(logging.INFO, "DB Student college recommendations written")
                except Exception as e:
                    log_trace(logging.ERROR, f"Error in write_event: {e}")
                    raise

            # Track the event in the local database in a separate thread
            result = await asyncio.to_thread(write_event_database, event)
            log_trace(logging.INFO, f"Event tracking completed: {result}")

            # Call read_events after the write operation
            #result = await asyncio.to_thread(self.read_events)
            #log_trace(logging.INFO, "Read events completed")

        except Exception as e:
            log_trace(logging.ERROR, f"Error tracking event {event.event_type}: {e}")
            # Optionally, re-raise the exception if you want it to propagate
            raise


    def read_events(self, all=False):
        # Read all events
        if all:
            events = database.read_all_events()
            log_trace(logging.INFO, f"Total events in database: {len(events)}")
        else:
            events = database.read_recent_events()
        
        # Print details of each event
        for event in events:
            log_trace(logging.INFO, f"Event Type: {event.event_type}")
            log_trace(logging.INFO, f"Unique ID: {event.unique_id}")
            log_trace(logging.INFO, f"Timestamp: {event.timestamp}")
            log_trace(logging.INFO, f"Attributes: {event.attributes}")
            log_trace(logging.INFO, "---")

class AnalyticsManager:
    """
    Analytics manager.

    This class manages the tracking of events with different analytics services.

    TODO: Commented code for writing to DB as the analytics DB is not well defined.
    """

    def __init__(self, services: list = None):
        """
        Initialize the analytics manager.

        Args:
            services (list): A list of analytics services to use. By default, the Mixpanel service is added.
        """
        #self.db = LocalDatabaseAnalyticsService()
        self.services = services if services is not None else []
        self.services.append(MixpanelService(os.getenv('MIXPANEL_KEY')))
        self.last_analytics_run = None

    async def post_process_and_run_analytics(self):
        """
        Run the college recommendation analytics asynchronously and send as an aggregate event.
        Comment for now.
        """
        # To be implemented
        return
        #try:
        #     if event.event_type in [EventType.RECOMMENDATION_SAVED_COLLEGE]:
        #        analytics_result = await database.get_college_recommendation_analytics()
        #        log_trace(logging.INFO, f"College recommendation analytics: {analytics_result}")
        #        self.last_analytics_run = datetime.now()

        #        # Create an aggregate event
        #        event = AnalyticsEvent(
        #            event_type=EventType.AGGREGATE_COLLEGE_RECOMMENDATIONS,
        #            unique_id="system",  # or some other identifier for system-generated events
        #            attributes=analytics_result
        #        )

        #        # Send the aggregate event to only Analytics DB services. SKip external devices 
        #        try:
        #            await self.db.track_event_async(event)
        #        except Exception as e:
        #            log_trace(logging.ERROR, f"Error tracking college recommendation event {event.event_type} for user {event.unique_id}: {e}")
        #except Exception as e:
        #    log_trace(logging.ERROR, f"Error running college recommendation analytics: {e}")

    def preprocess_event(self, event: AnalyticsEvent):
        """
        Preprocess and send an event to all services.

        Args:
            event (AnalyticsEvent): The event to be processed and sent.
        """
        #log_trace(logging.INFO, f"AnalyticsManager : Preprocessing and sending event {event.event_type} for user {event.unique_id}")
        #if event.event_type == EventType.RECOMMENDATION_SAVED_COLLEGE:
        #   event =  database.get_student_college_recommendation_analytics(event.unique_id, event)

        return event

    async def track_event_async(self, event: AnalyticsEvent):
        """
        Track an event asynchronously with all services.

        Args:
            event (AnalyticsEvent): The event to be tracked.

        Returns:
            Coroutine: A coroutine representing the asynchronous task.
        """
        # By default  store the data in the local database
        #try:
        #    await self.db.track_event_async(event)
        #except Exception as e:
        #    log_trace(logging.ERROR, f"AnalyticsManager : Error tracking event {event.event_type} for user {event.unique_id}: {e}")

        # Preprocess and  send to external services as required 
        event = self.preprocess_event(event)

        for service in self.services:
            try:
                await service.track_event_async(event)
            except Exception as e:
                log_trace(logging.ERROR, f"Error tracking event {event.event_type} for user {event.unique_id}: {e}")

        await self.post_process_and_run_analytics()


    def track_event(self, event: AnalyticsEvent) -> Union[None, Coroutine]:
        """
        Track an event with all services.

        Args:
            event (AnalyticsEvent): The event to be tracked.

        Returns:
            None or Coroutine: If there's no running event loop, the synchronous version is returned.
            Otherwise, the asynchronous version is returned.
        """
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError as e:
             log_trace(logging.ERROR, f" Error invoking async operation {event.event_type} for user {event.unique_id}: {e}")
        else:
            # If there's a running event loop, return the asynchronous version
            return asyncio.create_task(self.track_event_async(event))

