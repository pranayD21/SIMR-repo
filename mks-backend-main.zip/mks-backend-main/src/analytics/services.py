from fastapi import APIRouter, HTTPException, Depends
from auth_jwt.jwt_token import JWKS, JWTAuthorizationCredentials, JWTBearer, fetch_jwks
import requests
import json
from pydantic import BaseModel
from datetime import datetime
from typing import Optional, Dict, Any
from .analytics import AnalyticsManager
from .analytics_constants import EventType, AnalyticsEvent
from .schemas import EventData, StudentRecommendationResponse
from . import events_database as database
from logger import logging, log_trace
# from .. import 
__package__ = "src.analytics"


router = APIRouter(
    prefix="/analytics",
    tags=["analytics"],
    responses={404: {"description": "Not found"}},
)

# Needed for parsing the auth token in the request headers
jwks = JWKS.model_validate(fetch_jwks())
auth = JWTBearer(jwks)

def check_response_status(response: requests.Response):
    if response.status_code == 200:
        return response.json()

    try:
        error_detail = response.json()
    except requests.exceptions.JSONDecodeError:
        error_detail = response.text

    status_code = response.status_code
    if status_code == 400:
        detail = error_detail.get('detail', 'Bad Request')
    elif status_code == 401:
        detail = error_detail.get('detail', 'Unauthorized')
    elif status_code == 403:
        detail = error_detail.get('detail', 'Forbidden')
    elif status_code == 404:
        detail = error_detail.get('detail', 'Not Found')
    elif status_code == 500:
        detail = error_detail.get('detail', 'Internal Server Error')
    else:
        detail = error_detail

    raise HTTPException(status_code=status_code, detail=detail)



@router.post("/event")
async def post_event(event_input: EventData): # credentials: JWTAuthorizationCredentials = Depends(auth)): #Commenting auth interaction between services
    log_trace(logging.INFO, f"Received Event data - {event_input}")
    analytics_event = AnalyticsEvent(
        event_type=event_input.event_type,
        unique_id=event_input.unique_id,
        attributes=event_input.attributes
    ) 
    analytics_manager = AnalyticsManager()
    result = analytics_manager.track_event(analytics_event)
    log_trace(logging.INFO, f"Server: Event tracked - {result}")
    return {"status": "success", "message": "Event logged successfully"}


#--------------------------   TODO Service endpoints triggered by external user -----------------------------
# @router.get("/student-college-recommendations/{user_id}", response_model=StudentRecommendationResponse)
# def get_student_college_recommendations(user_id: int, credentials: JWTAuthorizationCredentials = Depends(auth)):
#     try:
#         student_data = database.get_student_college_recommendation_analytics(str(user_id))
#         if student_data is None:
#             raise HTTPException(status_code=404, detail="Student not found")
#         return student_data
#     except Exception as e:
#         raise HTTPException(status_code=500,detail=f"An error occurred: {str(e)}")

# @router.get("/college-recommendation-analytics", response_model=Dict[str, Any])
# async def college_recommendation_analytics(credentials: JWTAuthorizationCredentials = Depends(auth)):
#     try:
#         analytics_result = await database.get_college_recommendation_analytics()
#         return analytics_result
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=f"An error occurred: {str(e)}")
    

# For testing purposes
if __name__ == "__main__":
    import uvicorn
    uvicorn.run(router, host="0.0.0.0", port=8000)



