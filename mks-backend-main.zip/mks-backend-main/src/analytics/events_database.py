import os
import json
from typing import List
from contextlib import contextmanager
from datetime import datetime, timezone
from sqlalchemy import create_engine, desc
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.exc import NoResultFound
from collections import Counter
from .models import EventsData,UserProfileData,  Base,  StudentCollegeRecommendationData
from .analytics_constants import AnalyticsEvent, EventType
from logger import log_trace, logging

# Database setup
DB_URL = os.environ['DB_URL']
engine = create_engine(DB_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# Dependency
@contextmanager
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def update_user_profile(event: AnalyticsEvent):
    """
    Updates the user profile based on the provided AnalyticsEvent.

    Args:
        event (AnalyticsEvent): The event containing information to update the user profile.

    Returns:
        UserProfileData: The updated user profile after the changes.
    """
    with get_db() as db:
        user_profile = db.query(UserProfileData).filter(UserProfileData.unique_id == event.unique_id).first()
        
        if not user_profile:
            # Create new user profile if it doesn't exist
            user_profile = UserProfileData(unique_id=event.unique_id)
            user_profile.created_timestamp = event.timestamp
            db.add(user_profile)
        
        # Update user profile fields
        if event.attributes:
            for key, value in event.attributes.items():
                if hasattr(UserProfileData, key):
                    setattr(user_profile, key, value)
        
        # Commit changes
        db.commit()
        db.refresh(user_profile)
        log_trace(logging.INFO, f"User profile: {user_profile}")
    
    return user_profile

def delete_user_profile(event: AnalyticsEvent):
    """
    Deletes a user profile from the database based on the unique ID of the event.

    Args:
        event (AnalyticsEvent): The event containing the unique ID of the user profile to be deleted.

    Returns:
        None
    """
    #TODO currently profiles are not deleted. We need to figure how to handle it 
    log_trace(logging.INFO, f"Deleting user profile {event.unique_id}")
    with get_db() as db:
        db.query(UserProfileData).filter(UserProfileData.unique_id == event.unique_id).delete()
        db.commit() 

def write_student_college_recommendations(event: AnalyticsEvent):
    """
    Writes student college recommendations to the database based on the provided event.

    Args:
        event (AnalyticsEvent): The event containing the unique ID and event type of the student.

    Returns:
        StudentCollegeRecommendationData: The updated student college recommendation data.
    """
    with get_db() as db:
        try:
            recommendation = db.query(StudentCollegeRecommendationData).filter(
                StudentCollegeRecommendationData.unique_id == event.unique_id
            ).one()
        except NoResultFound:
            recommendation = StudentCollegeRecommendationData(
                unique_id=event.unique_id,
                recommended_colleges=[],
                saved_colleges=[]
            )
            db.add(recommendation)
            log_trace(logging.INFO, f"Created student college recommendation data for {event.unique_id}")

        if event.event_type == EventType.RECOMMENDATION_COLLEGE:
            college_names = event.attributes.get('college_names', [])
            if isinstance(college_names, str):
                college_names = [college_names]
            
            # Convert existing recommended_colleges to a set, update it, and convert back to a list
            current_recommended = set(recommendation.recommended_colleges or [])
            current_recommended.update(college_names)
            recommendation.recommended_colleges = list(current_recommended)
            recommendation.total_recommendations = len(recommendation.recommended_colleges) 
            recommendation.last_recommendation_time = event.timestamp

            log_trace(logging.INFO, f"Updated recommended colleges for {event.unique_id}: {college_names}")

        elif event.event_type == EventType.RECOMMENDATION_SAVED_COLLEGE:
            college_name = event.attributes.get('college_name')
            if college_name:
                # Convert existing saved_colleges to a set, update it, and convert back to a list
                current_saved = set(recommendation.saved_colleges or [])
                current_saved.add(college_name)
                recommendation.saved_colleges = list(current_saved)
                recommendation.total_saved = len(recommendation.saved_colleges)
                recommendation.last_saved_time = event.timestamp

                log_trace(logging.INFO, f"Updated saved colleges for {event.unique_id}: {college_name}")

        elif event.event_type == EventType.RECOMMENDATION_DELETE_COLLEGE:
            college_name = event.attributes.get('college_name')
            if college_name:
                # Remove the college from saved_colleges if it exists
                current_saved = set(recommendation.saved_colleges or [])
                current_saved.discard(college_name)  # discard() doesn't raise an error if the item doesn't exist
                recommendation.saved_colleges = list(current_saved)
                log_trace(logging.INFO, f"Deleted saved college {college_name} for {event.unique_id}")
 
        db.commit()
        db.refresh(recommendation)
    
    return recommendation

# Post operations
def write_event(event: AnalyticsEvent) -> EventsData:
    """
    Writes an AnalyticsEvent to the database.

    Args:
        event (AnalyticsEvent): The event to be written to the database.

    Returns:
        EventsData: The newly created EventsData object representing the written event.
    """
    with get_db() as db:
        log_trace(logging.INFO, f"Writing event: {event}")
        new_event = EventsData(
            event_type=event.event_type,
            unique_id=event.unique_id,
            timestamp=event.timestamp,
            attributes=json.dumps(event.attributes) if event.attributes else None
        )
        db.add(new_event)
        db.commit()
        db.refresh(new_event)
        return new_event

def read_all_events() -> List[AnalyticsEvent]:
    with get_db() as db:
        events = db.query(EventsData).all()
        return [convert_to_analytics_event(event) for event in events]
    

def read_recent_events(limit: int = 1) -> List[AnalyticsEvent]:
    with get_db() as db:
        recent_events = db.query(EventsData).order_by(desc(EventsData.timestamp)).limit(limit).all()
        return [convert_to_analytics_event(event) for event in recent_events]
    
# Function to convert EventsData back to AnalyticsEvent
def convert_to_analytics_event(event_data: EventsData) -> AnalyticsEvent:
    return AnalyticsEvent(
        event_type=event_data.event_type,
        unique_id=event_data.unique_id,
        timestamp=event_data.timestamp,
        attributes=json.loads(event_data.attributes) if event_data.attributes else {}
    ) 

#-----------------------------------   Post processing of the  data - Corelate, Aggregate Data ------------------------------


def get_student_college_recommendation_analytics(unique_id: str, event: AnalyticsEvent = None):
    """
    Retrieve college recommendation analytics for a given unique ID.

    This function retrieves the student college recommendation data from the database
    based on the provided unique ID and computes various analytics.

    Args:
        unique_id (str): The unique ID of the student.

    Returns:
        dict: Analytics results.
            - unique_id (str): The unique ID of the student.
            - total_recommended_colleges (int): Total number of recommended colleges.
            - total_saved_colleges (int): Total number of saved colleges.
            - save_rate (float): The percentage of recommended colleges that are saved.
            - recommended_colleges (list): List of recommended colleges.
            - saved_colleges (list): List of saved colleges.
            - last_recommendation_time (str): The timestamp of the last recommendation.
            - last_saved_time (str): The timestamp of the last save.
    """
    with get_db() as db:
        try:
            student = db.query(StudentCollegeRecommendationData).filter(
                StudentCollegeRecommendationData.unique_id == unique_id
            ).one()
        except NoResultFound:
            log_trace(logging.INFO, f"Student not found: {unique_id}")
            return {"error": "Student not found"}

        recommended = student.recommended_colleges or []
        saved = student.saved_colleges or []

        analytics = {
            "unique_id": student.unique_id,
            "total_recommended_colleges": len(recommended),
            "total_saved_colleges": len(saved),
            "save_rate": (len(saved) / len(recommended) * 100) if recommended else 0,
            "recommended_colleges": recommended,
            "saved_colleges": saved,
            "last_recommendation_time": student.last_recommendation_time.isoformat() if student.last_recommendation_time else None,
            "last_saved_time": student.last_saved_time.isoformat() if student.last_saved_time else None
        }
        if event:
            event.attributes = analytics
            return event
        log_trace(logging.INFO, f"Analytics for {unique_id}: {analytics}")
        return analytics

async def get_college_recommendation_analytics():
    """
    Compute analytics on college recommendations.

    This function retrieves all student college recommendation data from the database,
    computes various analytics, and returns the results as a dictionary.

    Returns:
        dict: Analytics results.
            - total_students (int): Total number of students.
            - total_recommended_colleges (int): Total number of recommended Colleges.
            - total_saved_colleges (int): Total number of saved Colleges.
            - average_recommended_per_student (float): Average number of recommended Colleges per student.
            - average_saved_per_student (float): Average number of saved Colleges per student.
            - top_5_recommended_colleges (list): List of top 5 recommended Colleges and their counts.
            - top_5_saved_colleges (list): List of top 5 saved Colleges and their counts.
            - save_rate_percentage (float): Percentage of recommended Colleges that are saved.
            - save_engagement_rate_percentage (float): Percentage of students who saved at least one recommended college.
    """
    with get_db() as db:
        # Retrieve all student college recommendation data
        recommendations = db.query(StudentCollegeRecommendationData).all()
        
        total_students = len(recommendations)
        total_recommended = 0
        total_saved = 0
        all_recommended = []
        all_saved = []
        
        # Compute various analytics
        for rec in recommendations:
            recommended = rec.recommended_colleges or []
            saved = rec.saved_colleges or []
            
            total_recommended += len(recommended)
            total_saved += len(saved)
            all_recommended.extend(recommended)
            all_saved.extend(saved)
        
        recommended_counter = Counter(all_recommended)
        saved_counter = Counter(all_saved)
        
        top_recommended = recommended_counter.most_common(5)
        top_saved = saved_counter.most_common(5)
        
        overlap = set(all_recommended) & set(all_saved)
        overlap_count = len(overlap)
        
        avg_recommended = total_recommended / total_students if total_students > 0 else 0
        avg_saved = total_saved / total_students if total_students > 0 else 0
        
        save_rate = (overlap_count / total_recommended * 100) if total_recommended > 0 else 0
        
        students_with_saves = sum(1 for rec in recommendations if set(rec.recommended_colleges or []) & set(rec.saved_colleges or []))
        save_engagement_rate = (students_with_saves / total_students * 100) if total_students > 0 else 0
        
        analytics_result = {
            "total_students": total_students,
            "total_recommended_colleges": total_recommended,
            "total_saved_colleges": total_saved,
            "average_recommended_per_student": round(avg_recommended, 2),
            "average_saved_per_student": round(avg_saved, 2),
            "top_5_recommended_colleges": top_recommended,
            "top_5_saved_colleges": top_saved,
            "save_rate_percentage": round(save_rate, 2),
            "save_engagement_rate_percentage": round(save_engagement_rate, 2)
        }
    
        log_trace(logging.INFO, f"Analytics result: {analytics_result}")
    
        return analytics_result



# Test code
if __name__ == "__main__":
    # Create tables
    Base.metadata.create_all(bind=engine)
    
    # Create a test event
    test_event = AnalyticsEvent(
        event_type=EventType.USER_SIGNUP,
        unique_id="test_user_123",
        timestamp=datetime.now(timezone.utc),
        attributes={"key": "value"}
    )
    
    # Write the event to the database
    with SessionLocal() as db:
        result = write_event(test_event, db)
    
    # Check if the event was written correctly
    assert result.event_type == test_event.event_type.value  # Compare with enum value
    assert result.unique_id == test_event.unique_id
    assert result.timestamp == test_event.timestamp
    assert json.loads(result.attributes) == test_event.attributes
    
    print("Test passed successfully!")
    # Usage
    analytics_result = get_recommendation_analytics()
    print(analytics_result)