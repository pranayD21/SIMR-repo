import os
from sqlalchemy import Column, Integer, String, DateTime, create_engine, Enum, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from sqlalchemy.sql import func
from sqlalchemy import JSON
from dotenv import load_dotenv, find_dotenv
from .analytics_constants import EventType

_ = load_dotenv(find_dotenv()) 
Base = declarative_base()


class UserProfileData(Base):
    __tablename__ = "user_profile_data"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True)
    unique_id = Column(String(255), nullable=False, index=True)
    created_timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    # school demographics
    school_name = Column(String)
    school_state = Column(String)
    school_city = Column(String)
    # academic Profile
    gpa = Column(String)
    deleted_timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)


class EventsData(Base):
    __tablename__ = "events_main"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True)
    event_type = Column(Enum(EventType), nullable=False)  # Use SQLAlchemy's Enum type
    unique_id = Column(String(255), nullable=False, index=True)
    attributes = Column(String)
    timestamp = Column(DateTime(timezone=True), server_default=func.now(), nullable=False)
    counselor_connections = Column(ARRAY(Integer), default=[])  # List of counselor ids for counselors the user is connected to
    mentor_connections = Column(ARRAY(Integer), default=[]) # List of mentor ids for mentors the user is connected to


class StudentCollegeRecommendationData(Base):
    __tablename__ = 'student_college_recommendation_data'
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, autoincrement=True)
    unique_id = Column(String(255), nullable=False, index=True)
    recommended_colleges = Column(JSON, nullable=False)
    saved_colleges = Column(JSON, nullable=False)
    total_recommendations = Column(Integer, default=0)
    total_saved = Column(Integer, default=0)
    last_recommendation_time =  Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
    last_saved_time =  Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


# Create all tables in the database
# Get base server url from env
DB_URL = os.environ['DB_URL']
engine = create_engine(DB_URL)
Base.metadata.create_all(bind=engine)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)