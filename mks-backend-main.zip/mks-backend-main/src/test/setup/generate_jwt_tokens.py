import json
from jose import jwk, jwt
from jose.utils import base64url_encode
from datetime import datetime, timedelta
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa

# Generate RSA Key
key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
private_key_pem = key.private_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PrivateFormat.PKCS8,
    encryption_algorithm=serialization.NoEncryption()
)
public_key_pem = key.public_key().public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)

# Load keys to be used in jose
private_key = serialization.load_pem_private_key(private_key_pem, password=None)
public_key = serialization.load_pem_public_key(public_key_pem)

# JWKS data
public_numbers = public_key.public_numbers()
jwks = {
    "keys": [
        {
            "kty": "RSA",
            "use": "sig",
            "kid": "mock-key-id",
            "alg": "RS256",
            "n": base64url_encode(public_numbers.n.to_bytes((public_numbers.n.bit_length() + 7) // 8, byteorder='big')).decode('utf-8'),
            "e": base64url_encode(public_numbers.e.to_bytes((public_numbers.e.bit_length() + 7) // 8, byteorder='big')).decode('utf-8')
        }
    ]
}

# Save JWKS to a file
with open("jwks.json", "w") as f:
    json.dump(jwks, f)

# Create a token
payload = {
    "sub": "1234567890",
    "name": "John Doe",
    "iat": datetime.utcnow(),
    "exp": datetime.utcnow() + timedelta(minutes=30)
}
token = jwt.encode(payload, private_key_pem, algorithm='RS256', headers={"kid": "mock-key-id"})
#DONT ALTER THE SCRIPT TO PRINT ANYTHING ELSE.  Fails in the CI pipeline
print(token)
