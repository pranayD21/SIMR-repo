
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))
import time
import subprocess
from sqlalchemy import create_engine, text
from sqlalchemy.exc import OperationalError
from src.logger import log_trace, logging


def install_postgresql():
    distribution = os.popen("cat /etc/*release | grep '^ID=' | cut -d= -f2").read().strip()
    if distribution == "debian" or distribution == "ubuntu":
        os.system("sudo apt update && sudo apt install -y postgresql")
    elif distribution == "centos" or distribution == "rhel":
        os.system("sudo yum install -y postgresql-server")
    elif distribution == "fedora":
        os.system("sudo dnf install -y postgresql-server")
    elif distribution == "alpine":
        os.system("sudo apk add postgresql")
    else:
        log_trace(logging.INFO, "Unsupported distribution.")
        
def run_command(command):
    """Run a shell command and check for errors."""
    result = subprocess.run(command, shell=True, text=True, check=True, capture_output=True)
    log_trace(logging.INFO, result.stdout)
    if result.returncode != 0:
        log_trace(logging.INFO, result.stderr)
        raise Exception(f"Command failed: {command}")


# Find the location of the PostgreSQL binaries directory using pg_config
def find_pg_bindir():
    try:
        pg_config_path = subprocess.check_output(["which", "pg_config"]).decode().strip()
        pg_bindir = subprocess.check_output([pg_config_path, "--bindir"]).decode().strip()
        log_trace(logging.INFO, f"PostgreSQL binaries directory: {pg_bindir}")
        return pg_bindir
    except subprocess.CalledProcessError:
        log_trace(logging.INFO, "Error: pg_config not found or PostgreSQL not installed.")
        return None


def find_psql_version():
    try:
        version = subprocess.check_output(['psql', '--version']).decode('utf-8').splitlines()[0].split()[2].split('(')[0]
        return version
    except FileNotFoundError:
        return "psql command not found"


def find_pg_conf():
    version = find_psql_version()
    version = version.split(".")[0]
    log_trace(logging.INFO, f"PostgreSQL version: {version}")
    path1 = f"/etc/postgresql/{version}/main/pg_hba.conf"
    path2 = f"/var/lib/pgsql/<version>/data/pg_hba.conf"
    path3 = f"/usr/local/var/postgresql@{version}/pg_hba.conf"
    if os.path.exists(path1):
        log_trace(logging.INFO, f"pg_hba.conf found at: {path1}")
        return  os.path.dirname(path1)
    if os.path.exists(path2):
        log_trace(logging.INFO, f"pg_hba.conf found at: {path2}")
        return  os.path.dirname(path2)
    if os.path.exists(path3):
        log_trace(logging.INFO, f"pg_hba.conf found at: {path3}")
        return  os.path.dirname(path3)

      
def configure_postgresql():
    """Configure PostgreSQL to accept local connections."""
    log_trace(logging.INFO, "Configuring PostgreSQL...")
    sysconfdir = find_pg_conf()
    pg_hba_conf = os.path.join(sysconfdir, "pg_hba.conf")
    postgresql_conf = os.path.join(sysconfdir, "postgresql.conf")

    # Modify pg_hba.conf to allow local connections
    #run_command(f"sudo sed -i 's/^#\\(.*local.*all.*all.*\\)$/\\1/' {pg_hba_conf}")
    #run_command(f"sudo sed -i 's/^#\\(.*host.*all.*all.*127.0.0.1\/32.*\\)$/\\1/' {pg_hba_conf}")
    #run_command(f"sudo sed -i 's/^#\\(.*host.*all.*all.*::1\/128.*\\)$/\\1/' {pg_hba_conf}")
    
    # Ensure PostgreSQL listens on localhost
    #run_command(f"sudo sed -i \"s/^#listen_addresses = 'localhost'/listen_addresses = 'localhost'/\" {postgresql_conf}")
    
    #log_trace(logging.INFO, "PostgreSQL configured to accept local connections.")

    # Check PostgreSQL server status
    status = os.system("sudo -H service postgresql status")
    if status != 0:
        log_trace(logging.INFO, "PostgreSQL server is not running. Starting the server...")
        os.system("sudo service postgresql start")

    # Edit postgresql.conf to listen on all addresses
    os.system("sudo -H chmod 644 "+postgresql_conf)
    with open(postgresql_conf, "r+") as f:
        lines = f.readlines()
        for i, line in enumerate(lines):
            if line.startswith("listen_addresses"):
                lines[i] = "listen_addresses = '*'\n"
        f.seek(0)
        f.writelines(lines)
        f.truncate()

    # Edit pg_hba.conf to allow connections from all IPv4 addresses
    os.system("sudo -H chmod 644 "+pg_hba_conf)
    with open(pg_hba_conf, "r+") as f:
        lines = f.readlines()
        for i, line in enumerate(lines):
            if line.startswith("host all all 127.0.0.1/32"):
                lines[i] = "host all all 0.0.0.0/0 md5\n"
        f.seek(0)
        f.writelines(lines)
        f.truncate()

    # Restart PostgreSQL service
    os.system("sudo -H service postgresql restart")
    

def validate_postgresql_connection(host, port, database, user, password):
    """
    Validates the connection to a PostgreSQL database.

    Args:
        host (str): The host address of the database.
        port (int): The port number on which the database is running.
        database (str): The name of the database.
        user (str): The username for the database connection.
        password (str): The password for the database connection.

    Returns:
        bool: True if the connection is successful, False otherwise.
    """
    try:
        # Construct database URL
        db_url = f"postgresql://{user}:{password}@{host}:{port}/{database}"

        # Create engine to connect to the database
        engine = create_engine(db_url)

        # Connect to the database
        connection = engine.connect()

        # Execute a simple query to validate connection
        query = text("SELECT version();")
        result = connection.execute(query)

        # Fetch the result
        db_version = result.fetchone()[0]

        # Print the version of the database
        log_trace(logging.INFO, "PostgreSQL database version:", db_version)

        query = text("CREATE EXTENSION IF NOT EXISTS pg_trgm;")
        connection.execute(query)
        connection.commit()
        
        # Close connection
        connection.close()

        return True  # Connection successful

    except OperationalError as e:
        # Print the error message if the connection fails
        log_trace(logging.INFO, f"Error: {e}")
        return False  # Connection failed



def create_postgres_user():
    try:
        # Check if the PostgreSQL user already exists
        subprocess.run(['id', 'postgres'], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        log_trace(logging.INFO, "PostgreSQL user already exists.")
    except subprocess.CalledProcessError:
        # Create the PostgreSQL user
        log_trace(logging.INFO, "Creating PostgreSQL user...")
        try:
            subprocess.run(['sudo', 'adduser', 'postgres'], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            log_trace(logging.INFO, "PostgreSQL user created successfully.")
        except subprocess.CalledProcessError as e:
            log_trace(logging.INFO, f"Error creating PostgreSQL user: {e}")
            return

# Start PostgreSQL service
def start_postgresql_service(data_dir, pg_bindir):
    try:
        subprocess.run(["sudo -u postgres", pg_bindir + "/pg_ctl", "-D", data_dir, "start"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        log_trace(logging.INFO, "PostgreSQL service started.")
    except subprocess.CalledProcessError as e:
        log_trace(logging.INFO, f"Error starting PostgreSQL service: {e}")

def switch_to_postgres_user(pg_bindir):
    try:
        # Switch to the PostgreSQL user
        log_trace(logging.INFO, "Switching to the PostgreSQL user...")
        postgres_shell = subprocess.Popen(['su', '-', 'postgres', '-c', '/bin/bash'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)

        # Create the data directory and initialize the PostgreSQL database
        data_dir = os.path.expanduser("./dabbl_data/db1")
        os.makedirs(data_dir, exist_ok=True)
        log_trace(logging.INFO, f"Creating data directory: {data_dir}")
        subprocess.run(['sudo', 'chown', '-R', 'postgres:postgres', './dabbl_data/db1'], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        subprocess.run(["sudo", "-u", "postgres", pg_bindir + "/initdb", "-D", data_dir], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        log_trace(logging.INFO, "Initializing PostgreSQL database...")
        postgres_shell.stdin.write(f"{pg_bindir}/initdb  {data_dir}\n")
        postgres_shell.stdin.write("exit\n")
        output, error = postgres_shell.communicate()
        log_trace(logging.INFO, output)
        if error:
            log_trace(logging.INFO, "Error: PostgreSQL initialization failed.")
            log_trace(logging.INFO, f"Error: {error}")

        # Start the PostgreSQL server
        log_trace(logging.INFO, "Starting PostgreSQL server...")
        start_postgresql_service(data_dir, pg_bindir)

    except subprocess.CalledProcessError as e:
        log_trace(logging.INFO, f"Error switching to the PostgreSQL user: {e}")


# Execute the script --------------------------------------------------------------------------------------------------------
# Check if PostgreSQL is installed, install it if not
try:
   find_psql_version()
except subprocess.CalledProcessError:
    log_trace(logging.INFO, "PostgreSQL is not installed. Installing...")
    install_postgresql()

# Find the path to the PostgreSQL binaries
pg_bindir = find_pg_bindir()
if pg_bindir is None:
   log_trace(logging.INFO, "Error: pg_config not found or PostgreSQL not installed.")

# Stop PostgreSQL service if it's running
try:
    subprocess.run([pg_bindir + "/pg_ctl", "status"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    log_trace(logging.INFO, "PostgreSQL service is running. Stopping...")
    os.system(pg_bindir + "/pg_ctl" + " stop")
except subprocess.CalledProcessError:
    pass

# Configure PostgreSQL to accept local connections
configure_postgresql()

# Get PostgreSQL version
pg_version = subprocess.run(["psql", "--version"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE).stdout.decode().split("\n")[0].split(" ")[2]
log_trace(logging.INFO, f"PostgreSQL version: {pg_version}")

# Switch to the postgres user
log_trace(logging.INFO, "Switching to the PostgreSQL user and start the DB server...")
create_postgres_user()
switch_to_postgres_user(pg_bindir)

# Set up DB_URL
db_user = "postgres"
db_password = ""  # Assuming no password is set for the default user 'postgres'
db_host = "localhost"
db_port = "5432"
db_name = "postgres"

db_url = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
log_trace(logging.INFO, f"Database URL: {db_url}")

# Validate PostgreSQL connection
log_trace(logging.INFO, "Validating PostgreSQL connection...")
max_attempts = 3
attempt = 1
while attempt <= max_attempts:
    if validate_postgresql_connection(db_host, db_port, db_name, db_user, db_password):
            log_trace(logging.INFO, "Connection to PostgreSQL database successful.")
            log_trace(logging.INFO, "PostgreSQL is ready for connection.")
            break
    log_trace(logging.INFO, f"Connection attempt {attempt}/{max_attempts} failed. Retrying in 3 seconds...")
    attempt += 1
    time.sleep(3)
else:
    log_trace(logging.INFO, "Failed to connect to PostgreSQL after multiple attempts.")


# Add Mock Data to DB
subprocess.run(["python", "mock_test_data.py"])
