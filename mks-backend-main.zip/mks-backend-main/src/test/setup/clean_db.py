# Create a new SQLite database (or connect to an existing one)
import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))
from sqlalchemy import MetaData
from src.db.database import engine
from src.logger import log_trace, logging


log_trace(logging.INFO, "Drop All Tables ")
# Create a metadata object
metadata = MetaData()

# Reflect the tables
metadata.reflect(bind=engine)

# Drop all tables
metadata.drop_all(bind=engine, checkfirst=True)