# Example script to generate mock test data for the database
# This script should be run from the root of the project
#cd /.../dabbl/mks-backend
#python -m src.db.mock_test_data

import sys, os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..')))
import random
from faker import Faker
from sqlalchemy.orm import sessionmaker
from sqlalchemy import MetaData, inspect, text

dabbl_home = os.getenv("DABBL_HOME")
if dabbl_home is None:
    print("DABBL_HOME environment variable is not set")
else:
    print(f"DABBL_HOME is set to: {dabbl_home}")
    sys.path.insert(0, f"{dabbl_home}/..")
    sys.path.insert(0, dabbl_home)

from src.db.models import (
    Base, School, User, Student, StudentStrengthsWeakness, StudentSchool,
    StudentStandardizedTests, StudentWorkExperience, StudentProjects, Course,
    Activity, StudentCourse, StudentActivity, Careers, StudentCareers,
    StudentTargetSchools, TargetSchools, Post, Comment, UserProfileAIUpdates
)
from src.db.database import engine, SessionLocal, Base
from src.logger import log_trace, logging
from src.utils import normalize_email


# Initialize Faker
fake = Faker()

# Create a new SQLite database (or connect to an existing one)
log_trace(logging.INFO, "Drop All Tables ")
# Create a metadata object
metadata = MetaData()

# Reflect the tables
metadata.reflect(bind=engine)

# Drop all tables
metadata.drop_all(bind=engine, checkfirst=True)

log_trace(logging.INFO, "Create All Tables ")
Base.metadata.create_all(engine)
# Create a sessionmaker
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
session = SessionLocal()

# Enable similarity checks
with engine.begin() as connection:
    connection.execute(text("CREATE EXTENSION IF NOT EXISTS pg_trgm;"))

# Helper functions
def random_date(start, end):
    return fake.date_between(start_date=start, end_date=end)

def random_bool():
    return bool(random.getrandbits(1))

def clear_database():
    try:
        # Get the list of table names
        table_names = inspect(engine).get_table_names()

        # Drop all tables
        for table_name in table_names:
            if table_name != "alembic_version":  # Exclude the alembic version table
                table = Base.metadata.tables[table_name]
                session.execute(table.delete())

        # Commit the transaction
        session.commit()
        log_trace(logging.INFO, "Database cleared successfully!")

    except Exception as e:
        session.rollback()
        log_trace(logging.INFO, f"Error clearing database: {e}")


# Clear the database
clear_database()  

records = 10  # Assuming you want to create 10 entries across all tables
# Generate Schools
school_ids = []
states = ["California", "New York", "Texas", "Florida", "Illinois", "Pennsylvania", "Ohio", "Georgia", "North Carolina", "Michigan"]
cities_by_state = {
    "California": ["Los Angeles", "San Francisco", "San Diego", "Sacramento", "San Jose"],
    "New York": ["New York City", "Buffalo", "Rochester", "Albany", "Syracuse"],
    "Texas": ["Houston", "Dallas", "Austin", "San Antonio", "Fort Worth"],
    "Florida": ["Miami", "Orlando", "Tampa", "Jacksonville", "Fort Lauderdale"],
    "Illinois": ["Chicago", "Aurora", "Rockford", "Joliet", "Naperville"],
    "Pennsylvania": ["Philadelphia", "Pittsburgh", "Allentown", "Erie", "Reading"],
    "Ohio": ["Columbus", "Cleveland", "Cincinnati", "Toledo", "Akron"],
    "Georgia": ["Atlanta", "Augusta", "Savannah", "Columbus", "Macon"],
    "North Carolina": ["Charlotte", "Raleigh", "Greensboro", "Durham", "Winston-Salem"],
    "Michigan": ["Detroit", "Grand Rapids", "Warren", "Sterling Heights", "Lansing"]
}

for state in states:
    cities = cities_by_state[state]
    for city in cities:
        for _ in range(5):  # Generate 5 schools per city
            school = School(
                name=fake.company(),
                city=city,
                state=state,
                zip=fake.zipcode(),
                country="United States",
                type="High School"
            )
            session.add(school)
            session.commit()
            school_ids.append(school.id)

# For testing purposes (always ensures there is an entry with 'S')
california_cities = cities_by_state.get('California', [])
city = random.choice(california_cities)
school = School(
    name="Sample High School",
    city=city,
    state='California',
    zip=fake.zipcode(),
    country="United States",
    type="High School"
)
session.add(school)
session.commit()
school_ids.append(school.id)
            
# Generate Students and Users
student_ids = []
user_ids = []
for _ in range(records):  
    user = User(
        username=fake.user_name(),
        uid=str(fake.uuid4()),
        email=fake.email(),
        first_name=fake.first_name(),
        last_name=fake.last_name(),
        type="Student",
        birthdate=fake.date_of_birth(minimum_age=14, maximum_age=18),
        parent_name=fake.name(),
        parent_email=fake.email(),
        consentdate=fake.date_this_decade(),
        followers=[],
        following=[],
        website=fake.url(),
        personal_statement=fake.text(),
        connections=[],
        profile_pic_url=fake.image_url(),
        is_online=fake.boolean(),
        fcm_token=str(fake.uuid4()),
        show_sensitive_info=fake.boolean(),
        is_active=True,
        delete_date=None)
    
    user.normalized_email = normalize_email(user.email)
    session.add(user)
    session.commit()
    user_ids.append(user.id)

    student = Student(
        user_id=user.id
    )
    session.add(student)
    session.commit()
    student_ids.append(student.id)
log_trace(logging.INFO, f"Students and Users created! user_ids: {user_ids}, student_ids: {student_ids}")

# Generate Student Schools
schools_ids = []
for _ in range(records):
    for user_id in user_ids:
        # Check if the user already has a student school
        existing_student_school = session.query(StudentSchool).filter_by(user_id=user_id).first()
        if not existing_student_school:
            # If not, create a new student school entry
            student_school = StudentSchool(
                student_id=random.choice(student_ids),
                school_id=random.choice(school_ids),
                user_id=user_id,
                start_date=fake.date_between(start_date='-4y', end_date='today'),
                end_date=fake.date_between(start_date='today', end_date='+4y'),
                currently_enrolled=fake.boolean(),
                gpa=round(random.uniform(2.0, 4.0), 2),
                w_gpa=round(random.uniform(2.0, 5.0), 2),
                current_grade=random.choice(['9','10','11','12']),
                is_primary=True,
                graduation_year=fake.date_between(start_date='+1y', end_date='+4y')
            )
            session.add(student_school)

# Generate Student Strengths and Weaknesses
for student in student_ids:
    strengths_weakness = StudentStrengthsWeakness(
        student_id=student,
        strengths=random.choice(['Leadership', 'Communication', 'Critical Thinking', 'Problem Solving']),
        weakness=random.choice(['Public speaking', 'Fear of failure', 'poor organizational skills', 'Self-doubt']) 
    )
    session.add(strengths_weakness)


# Generate Standardized Tests
for student in student_ids:
    standardized_test = StudentStandardizedTests(
        student_id=student,
        date_taken=random_date(start='-3y', end='today'),
        test_type=random.choice(['sat', 'act']),
        total_score=random.randint(800, 1600),
        english_score=random.uniform(200, 800),
        math_score=random.uniform(200, 800),
        reading_score=random.uniform(200, 800),
        science_score=random.uniform(200, 800)
    )
    session.add(standardized_test)

# Generate Work Experience
for student in student_ids:
    work_experience = StudentWorkExperience(
        student_id=student,
        job_title=fake.job(),
        company_name=fake.company(),
        job_description=fake.text(),
        start_date=random_date(start='-3y', end='today'),
        end_date=random_date(start='-2y', end='today'),
        employment_type=random.choice(['Internship', 'Part-time', 'Full-time']),
        active=random_bool()
    )
    session.add(work_experience)

# Generate Projects
for student in student_ids:
    project = StudentProjects(
        student_id=student,
        project_title=fake.sentence(),
        project_description=fake.text(),
        rewards_recognition=fake.sentence(),
        start_date=random_date(start='-3y', end='today'),
        end_date=random_date(start='-2y', end='today'),
        is_complete=random_bool(),
        skills=fake.word()
    )
    session.add(project)


# Generate Courses
course_names = ['Biology', 'Chemistry', 'Math', 'Physics', 'Computer Science', 'English', 'History', 'Geography', 'Music', 'Art','spanish','psycology','philosophy']
courses_ids = []
for course_name in course_names:
        course = Course(course_name=course_name)
        session.add(course)
        session.commit()
        courses_ids.append(course.id)

# Generate Activities
activity_ids = []
activity_names = ["swimming", "running", "hiking",  "Research", "Writing","Track & Field", "Soccer", "Football", "Volleyball", "Badminton", "sculpture", "chess"]  # Keep track of generated activity names to avoid duplicates
for activity_name in activity_names:
        activity = Activity( activity_name=activity_name )
        session.add(activity)
        session.commit()
        activity_ids.append(activity.id)
    

# Generate Student Courses
for student in student_ids:
    student_course = StudentCourse(
        student_id=student,
        course_id=random.choice(courses_ids),
        school_id=random.choice(school_ids),
        credits=random.randint(1, 5),
        grade=random.choice(['A', 'B', 'C', 'D']),
        grade_year=fake.year(),
        difficulty_level=random.choice(['Easy', 'Medium', 'Hard']),
        feedback=fake.sentence()
    )
    session.add(student_course)

# Generate Student Activities
for student in student_ids:
    student_activity = StudentActivity(
        student_id=student,
        activity_id=random.choice(activity_ids),
        hours_committed_per_week=random.uniform(1.0, 10.0),
        type=fake.word(),
        activity_description=random.choice(['swimming', 'running', 'hiking',  'Research', 'Writing', 'Track & Field', 'Soccer', 'Football', 'Volleyball', 'Badminton', 'sculpture', 'chess']),
        achievements=random.choice(['Excellent', 'Good', 'Average', 'Poor'])
    )
    session.add(student_activity)

# Generate Careers
careers_ids =[]
for _ in range(records):
    career = Careers(
        career_name=fake.job(),
        career_description=fake.text(),
        career_outlook=fake.sentence(),
        job_duties=fake.text(),
        skills=fake.word(),
        median_salary=fake.random_number(digits=5),
        majors=fake.word()
    )
    session.add(career)
    session.commit()
    careers_ids.append(career.id)

# Generate Student Careers
for student in student_ids:
    student_career = StudentCareers(
        student_id=student,
        career_id=random.choice(careers_ids),
        rank=random.randint(1, 10)
    )
    session.add(student_career)

# Generate Target Schools
college_names = [
    {
        'name': 'Stanford University',
        'url': "https://dabbl-college-images.s3.amazonaws.com/private-resources/Stanford University/1FniFIxy1jXzXgq4OenEGWLexml5UMDLy.jpg"
    },
    {
        'name': 'University of Massachusetts',
        'url':"https://dabbl-college-images.s3.amazonaws.com/private-resources/Massachusetts Institute of Technology/1F4D0HI_nBWaF0SN_erD01dxmL5pdFxIE.jpg"
    },
    {
        'name': 'Cornell University',
        'url': "https://dabbl-college-images.s3.amazonaws.com/private-resources/Cornell University/18a34pzV2KPzJYSUi9kcbEFc65JwQvZHd.jpg"
    },
    {
        'name':'Harvard University',
        'url':"https://dabbl-college-images.s3.amazonaws.com/private-resources/Harvard University/1J3X9-rT-GrKgnOnIfSoajvNQ-LPJe7Tf.jpg"
    }
]

college_ids = []
for college_record in college_names:
        college = TargetSchools(college_name=college_record['name'], college_pic_url=college_record['url'])
        session.add(college)
        session.commit()
        college_ids.append(college.id)
        college_record['id'] = college.id

college_count = len(college_names)
c_idx = 0
# Generate Student Target Schools
for student in student_ids:
    c_idx = c_idx % college_count
    college_record = college_names[c_idx]
    target_school = StudentTargetSchools(
        student_id=student,
        career_id=random.choice(careers_ids),
        college_name=college_record["name"],
        #college_name=fake.company(),
        college_id = college_record['id'],
        tution_fees=str(fake.random_number(digits=5)),
        probability_of_admission=fake.word(),
        positives=[fake.word() for _ in range(3)],
        negatives=[fake.word() for _ in range(3)],
        rank=random.randint(1, 10)
    )
    session.add(target_school)
    c_idx = c_idx + 1

# Generate Posts
post_ids = []
for user in user_ids:
    post = Post(
        user_id=user,
        post_title=fake.sentence(),
        post_content=fake.text(),
        profile_pic_url=fake.image_url(),
        likes=[random.randint(1, 20) for _ in range(random.randint(0, 10))],
        date_published=fake.date_time_this_year(),
        post_content_url=fake.url()
    )
    session.add(post)
    post_ids.append(post.id)

# Generate Comments
for _ in range(50):
    comment = Comment(
        user_id=random.choice(user_ids),
        post_id=random.choice(post_ids),
        content=fake.text(),
        likes=[random.randint(1, 20) for _ in range(random.randint(0, 10))],
        date_published=fake.date_time_this_year(),
        content_url=fake.url(),
        profile_pic_url=fake.image_url()
    )
    session.add(comment)

# Generate User Profile AI Updates
for user in user_ids:
    profile_ai_update = UserProfileAIUpdates(
        user_id=user,
        profile_last_update=fake.date_time_this_year(),
        ai_last_update=fake.date_time_this_year()
    )
    session.add(profile_ai_update)

# Commit the session to the database
session.commit()
session.close()
log_trace(logging.INFO, "Database populated with mock data!")
