import os
import sys
import uuid
import boto3
import pytest
import random
import string
import datetime
from src.main import app
from faker import Faker
from logger import log_trace, logging
from src.db import Constants, schemas
from fastapi.testclient import TestClient
import random
from dotenv import load_dotenv, find_dotenv
from webhooks import ses_utils
from src.db import Constants, schemas
from src.main import app

# Load environment variables
_ = load_dotenv(find_dotenv())

# Add the project root directory to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

from src.db import Constants, schemas
from src.main import app
from utils import normalize_email

# AWS Cognito configuration

def config_cognito():
    REGION = os.getenv("AWS_REGION", "us-east-2")
    USER_POOL_ID = os.getenv("COGNITO_USER_POOL_ID")
    CLIENT_ID = os.getenv("COGNITO_CLIENT_ID")
    REGION = os.getenv("AWS_REGION", "us-east-2")
    log_trace(logging.INFO, f"Pool ID: {USER_POOL_ID}")
    log_trace(logging.INFO, f"Client ID: {CLIENT_ID}")

    sts_client = boto3.client('sts',
                            aws_access_key_id=os.getenv("AWS_ACCESS_KEY"),
                            aws_secret_access_key=os.getenv("AWS_SECRET_KEY"),
                            region_name=REGION)
    response = sts_client.get_session_token(
        DurationSeconds=3600
    )
    credentials = response['Credentials']
    log_trace(logging.INFO, f"Access Key: {credentials['AccessKeyId']}")
    log_trace(logging.INFO, f"Secret Key: {credentials['SecretAccessKey']}")
    log_trace(logging.INFO, f"Session Token: {credentials['SessionToken']}")

    cognito_client = boto3.client('cognito-idp', 
                                  aws_access_key_id=credentials['AccessKeyId'],
                                  aws_secret_access_key=credentials['SecretAccessKey'],
                                  aws_session_token=credentials['SessionToken'],
                                  region_name=REGION)

    #cognito_client = boto3.client('cognito-idp',
    #                               aws_access_key_id=os.getenv("AWS_ACCESS_KEY"),
    #                               aws_secret_access_key=os.getenv("AWS_SECRET_KEY"),
    #                               region_name=REGION)

    return cognito_client

def generate_unique_username():
    import uuid
    return f"testuser_{uuid.uuid4().hex[:8]}"

# Test client for db services
db_client = TestClient(app)  # Initialize TestClient with your FastAPI app

# Fixture to generate an authentication token
@pytest.fixture(scope="session")
def auth_token():
    # Generate or fetch the authentication token here
    return os.environ.get("TEST_AUTH_TOKEN")  # Return the authentication token

def generate_auth_header(auth_token):
    headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    return headers


def create_user_helper(user_type: str = "student"):
    name = (
        f"{user_type}123"
        + random.choice(string.ascii_letters)
        + str(random.choice(range(1, 100)))
    )
    email = name + "@test.com"
    uid = name + "123"
    user_data = schemas.UserCreate(
        username=name,
        email=email,
        first_name="Test",
        last_name="User123",
        birthdate="1990-03-01",
        type=user_type,
        parent_email=name + "parent@test.com",
        parent_name="",
        consentdate="2024-02-01",
        uid=uid,
        followers=[],
        following=[],
        counselor_connections=[],
        website="go-dabbl.ai",
        personal_statement="own whats next",
        connections=[],
        profile_pic_url="",
        is_online=False,
        fcm_token="",
        show_sensitive_info=False,
        is_active=True,
        is_minor=False,
        delete_date=None,
    )
    user_data_dict = user_data.__dict__
    user_data_dict["birthdate"] = user_data_dict["birthdate"].isoformat()
    user_data_dict["consentdate"] = user_data_dict["consentdate"].isoformat()
    return user_data_dict

# Create user helper function with the new is_minor field set instead of the birthdate
def create_user_helper_new(user_type: str = "student"):
    name = (
        f"{user_type}123"
        + random.choice(string.ascii_letters)
        + str(random.choice(range(1, 100)))
    )
    email = name + "@test.com"
    uid = name + "123"
    user_data = schemas.UserCreate(
        username=name,
        email=email,
        first_name="Test",
        last_name="User123",
        birthdate="1900-01-01",
        type=user_type,
        parent_email=name + "parent@test.com",
        parent_name="",
        consentdate="2024-02-01",
        uid=uid,
        followers=[],
        following=[],
        counselor_connections=[],
        website="go-dabbl.ai",
        personal_statement="own whats next",
        connections=[],
        profile_pic_url="",
        is_online=False,
        is_minor=True,
        fcm_token="",
        show_sensitive_info=False,
        is_active=True,
        delete_date=None,
    )
    user_data_dict = user_data.__dict__
    user_data_dict["birthdate"] = user_data_dict["birthdate"].isoformat()
    user_data_dict["consentdate"] = user_data_dict["consentdate"].isoformat()
    return user_data_dict

def create_student_user(headers):
    # Add a student user whos not a minor
    user_data_dict = create_user_helper()
    assert(user_data_dict["is_minor"] == False)
    log_trace(logging.INFO, user_data_dict)
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    
    output = response.json()
    log_trace(logging.INFO, f"Message is {output['message']}")

    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name
    assert user["is_minor"] == False  # Validate user has been marked a minor

    # get student id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/students/get/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_id = output["id"]
    uid = output["user_id"]
    assert(uid == user_id)
    log_trace(logging.INFO, f"Student id is {student_id}")
    return {"user_id": user_id, "student_id": student_id }

def test_create_user_function(auth_token):
    headers = generate_auth_header(auth_token)
    create_student_user(headers=headers)

def get_user_id(headers):
    response = db_client.get(f"/db/users/get?skip=0&limit=100",headers=headers)
    output = response.json()
    user_id = output['data'][1]['id']
    log_trace(logging.INFO, user_id)
    return user_id

def get_user_info(headers):
    response = db_client.get(f"/db/users/get?skip=0&limit=100",headers=headers)
    
    output = response.json()
    user= output['data'][1]
    log_trace(logging.INFO, user)
    return user



def get_all_student_user_ids(headers):
    response = db_client.get(f"/db/users/get?skip=0&limit=100",headers=headers)
    output = response.json()
    log_trace(logging.INFO, "num of users is " + str(len(output['data'])))
    user_ids = []
    for user in output['data']:
        if user['type'] == "Student":
          user_ids.append(user['id'])
    log_trace(logging.INFO, user_ids)
    return user_ids

# Return following
def get_user_following(userid, headers):
    log_trace(logging.INFO, f"userid is {userid}")
    url = f"/db/users/get/user_id/{userid}"
    log_trace(logging.INFO, f"url is {url}")

    response = db_client.get(f"/db/users/get/user_id/{userid}",headers=headers)
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    check_error_code(output,
                          success_message="Get user by id succeeded",
                          error_message="Get user by id failed")
    user= output['data']
    log_trace(logging.INFO, user)
    return user["following"]

# Return followers
def get_user_followers(userid, headers):
    log_trace(logging.INFO, f"userid is {userid}")
    url = f"/db/users/get/user_id/{userid}"
    log_trace(logging.INFO, f"url is {url}")

    response = db_client.get(f"/db/users/get/user_id/{userid}",headers=headers)
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    check_error_code(output,
                          success_message="Get user by id succeeded",
                          error_message="Get user by id failed")
    user= output['data']
    log_trace(logging.INFO, user)
    return user["followers"]

def check_response_status(response, expected_status_code=200, success_message=None, error_message=None):
    assert response.status_code == expected_status_code, error_message or \
            f"Failed with status code: {response.status_code}. Response: {response.text}"
    log_trace(logging.INFO, success_message)

def check_error_code(output, expected_code=200, success_message=None, error_message=None):
    assert output['code'] == expected_code, error_message or \
            f"Failed with status code: {output['code']}. Response: {output['message']}"
    log_trace(logging.INFO, success_message)

def get_user_by_email(user_email, headers):
    response = db_client.get(f"/db/users/get/email/{user_email}", headers=headers)
    check_response_status(response,
                          success_message="Get user by email successful for a deleted User",
                          error_message="Get user by email not successful for a deleted User")
    return response

def test_delete_restore_user_function(auth_token):
    headers = generate_auth_header(auth_token)
    test_user = get_user_info(headers)
    user_id = test_user['id']
    user_email = test_user['email']
    user_name = test_user['username']

    response = db_client.delete(f"/db/users/delete/id/{user_id}", headers=headers)
    check_response_status(response, success_message="User deleted successfully", error_message="Error deleting user")
    response = db_client.get(f"/db/users/get/user_id/{user_id}", headers=headers)
    # Response to this API is wrapped within message, data, code and error
    log_trace(logging.INFO, f"Response is {response}")
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    check_error_code(output, expected_code=404,
                          success_message="Get user by id failed as expected for a deleted User",
                          error_message="Get user by id did not fail as expected for a deleted User")

    response = db_client.get(f"/db/users/get/email/{user_email}", headers=headers)
    check_response_status(response,
                          success_message="Get user by email successful for a deleted User",
                          error_message="Get user by email not successful for a deleted User")

    response = db_client.get(f"/db/users/get/username/{user_name}", headers=headers)
    check_response_status(response,
                          success_message="Get user by username successful for a deleted User",
                          error_message="Get user by username not successful for a deleted User")

    response = db_client.post(f"/db/users/restore-account/?user_email={user_email}", headers=headers)
    check_response_status(response,
                          success_message="Restored deleted user successfully",
                          error_message="Restored deleted user failed")
    response = db_client.get(f"/db/users/get/user_id/{user_id}", headers=headers)
    check_error_code(output, expected_code=404,
                    success_message="Get user by id failed as expected for a deleted User",
                    error_message="Get user by id did not fail as expected for a deleted User")


def test_get_user_by_id_function(auth_token):
    headers = generate_auth_header(auth_token)
    user_id = get_user_id(headers)
    response = db_client.get(f"/db/users/get/user_id/{user_id}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200    
    output = response.json()
    assert output["message"] == "User Fetched!"  # Validate message
    assert "data" in output  # Check if data is present in the response

    assert output["data"]["id"] == user_id  # Validate user ID
    if output["error"]:
        assert output["code"] == 500  # Check status code for error
        assert "error" in output  # Validate error information
    else:
        assert output["code"] == 200  # Check status code for success


def test_search_user_by_name_function(auth_token):
    name = "Test"  #  user name - present in database
    headers = generate_auth_header(auth_token)
    response = db_client.get(f"/db/users/get/search/{name}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    
    if output["error"]:
        assert output["statusCode"] == 500
        assert "error" in output
    else:
        assert output["statusCode"] == 200
        lower_name = name.lower()
        for item in output["data"]["result"]:
            fname = item["first_name"].lower()
            lname = item["last_name"].lower()
            assert lower_name in fname or lower_name in lname  # Validate message

    name = "szygy"  # Mock user name - not present in the database
    response = db_client.get(f"/db/users/get/search/{name}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    output = response.json()
    if output["error"]:
        assert output["statusCode"] == 200 # No users found
        assert "error" in output
    else:
        assert output["statusCode"] == 200
        lower_name = name.lower()
        for item in output["data"]["result"]:
            fname = item["first_name"].lower()
            lname = item["last_name"].lower()
            assert lower_name in fname or lower_name in lname  # Validate message

def test_search_user_by_email_function(auth_token):
    headers = generate_auth_header(auth_token)

    user_data_dict = create_user_helper()
    user_data_dict["email"] = user_data_dict["email"].upper()
    saved_email = normalize_email(user_data_dict["email"])
    log_trace(logging.INFO, f"User email is {user_data_dict['email']}")
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message

    email = user_data_dict["email"]
    log_trace(logging.INFO, f"Searching for user with email: {email}")
    response = db_client.get(f"/db/users/get/search_by_email/{email}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    
    error = output["error"]
    log_trace(logging.INFO, f"Output is {output}, Error is {error}")

    if output["error"]:
        assert output["code"] == 500
        assert "error" in output
    else:
        assert output["code"] == 200
        item = output["data"]
        assert saved_email == item["normalized_email"] # Validate user email
        log_trace(logging.INFO, f"Normalized email is {item['normalized_email']}")

    email = user_data_dict["email"].lower()
    log_trace(logging.INFO, f"Searching for user with email: {email}")
    response = db_client.get(f"/db/users/get/search_by_email/{email}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    
    error = output["error"]
    log_trace(logging.INFO, f"Output is {output}, Error is {error}")

    if output["error"]:
        assert output["code"] == 500
        assert "error" in output
    else:
        assert output["code"] == 200
        item = output["data"]
        assert saved_email == item["normalized_email"] # Validate user email

    email = "szygy@syz.com"  # Mock user name - not present in the database
    response = db_client.get(f"/db/users/get/search_by_email/{email}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert output["data"] is None
    assert output["message"] == "No matching users found!"

# Tests for student activities
def test_create_student_activity_function(auth_token):
    headers = generate_auth_header(auth_token)
    activity_data = schemas.StudentActivityCreate(student_id=1,
                                                  activity_name="Test Activity",
                                                  activity_description="Test Description",
                                                  #activity_start_date="2021-01-01",
                                                  #activity_end_date="2021-12-31",
                                                  type="Test Type",
                                                  #activity_role="Test Role",
                                                  #activity_hours=100
                                                )  # Mock activity data
    activity_data_dict = activity_data.__dict__
    #activity_data_dict["activity_start_date"] = activity_data_dict["activity_start_date"].isoformat()
    #activity_data_dict["activity_end_date"] = activity_data_dict["activity_end_date"].isoformat()

    user_id = get_user_id(headers)
    response = db_client.post(f"/db/users/students/activities/add/{user_id}", json=activity_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    # Get activity
    response = db_client.get(f"/db/users/students/activities/get/user_id/{user_id}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    found_record = False
    for elem in output:
        if elem["activity_description"] == "Test Description":
            # Validate message
            found_record = True
            break

    assert found_record == True

    # Add another activity with the same name, but different description
    activity_data = schemas.StudentActivityCreate(student_id=1,
                                                  activity_name="Test Activity",
                                                  activity_description="Test Description Modified and Added again",
                                                  #activity_start_date="2021-01-01",
                                                  #activity_end_date="2021-12-31",
                                                  type="Test Type",
                                                  #activity_role="Test Role",
                                                  #activity_hours=100
                                                )  # Mock activity data
    activity_data_dict = activity_data.__dict__
    #activity_data_dict["activity_start_date"] = activity_data_dict["activity_start_date"].isoformat()
    #activity_data_dict["activity_end_date"] = activity_data_dict["activity_end_date"].isoformat()
    user_id = get_user_id(headers)
    response = db_client.post(f"/db/users/students/activities/add/{user_id}",
                              json=activity_data_dict,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

     # Get activity
    response = db_client.get(f"/db/users/students/activities/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    found_record = False
    for elem in output:
        if elem["activity_description"] == "Test Description Modified and Added again":
            assert elem["activity_name"] == "Test Activity"
            # Validate message
            found_record = True
            break
        
    assert found_record == True

def test_get_student_activity_function(auth_token):
    headers = generate_auth_header(auth_token)
    user_id = get_user_id(headers)
    response = db_client.get(f"/db/users/students/activities/get/user_id/{user_id}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    # assert "data" in output  # Check if data is present in the response
    assert len(output) > 0  # Check if data is present in the response

# Test for adding list of activities
def test_create_student_activity_list_function(auth_token):
    headers = generate_auth_header(auth_token)
    activity_data = [
        {
            "student_id": 1,
            "activity_name": "Test Activity 1",
            "activity_description": "Test Description 1",
            "type": "Test Type 1"
        },
        {
            "student_id": 1,
            "activity_name": "Test Activity 2",
            "activity_description": "Test Description 2",
            "type": "Test Type 2"
        }
    ]
    user_id = get_user_id(headers)
    response = db_client.post(f"/db/users/students/activities/addlist/{user_id}",
                              json=activity_data,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    # Get activity
    response = db_client.get(f"/db/users/students/activities/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    found_record = False
    for elem in output:
        if elem["activity_description"] == "Test Description 1":
            # Validate message
            found_record = True
            break

    assert found_record == True

    found_record = False
    for elem in output:
        if elem["activity_description"] == "Test Description 2":
            # Validate message
            found_record = True
            break

    assert found_record == True

# Generate tests for standardized tests add, update, get
def test_create_student_standardized_test_function(auth_token):
   
    headers = generate_auth_header(auth_token)
    user_id = get_user_id(headers)
    # Get student id for the user
    response = db_client.get(f"/db/users/students/get/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    student_id = output["id"]

    test_data = schemas.StudentStandardizedTestCreate(
                                                     student_id=student_id,
                                                     date_taken="2021-01-01",
                                                     test_type=Constants.STD_TEST_TYPE_SAT.value,
                                                     total_score=1000,
                                                     english_score=500,
                                                     math_score=500,
                                                     reading_score=0,
                                                     science_score=0
                                                    )  # Mock test data
    test_data_dict = test_data.__dict__
    test_data_dict["date_taken"] = test_data_dict["date_taken"].isoformat()

    user_id = get_user_id(headers)
    response = db_client.post(f"/db/users/students/standardizedtests/add/user_id/{user_id}",
                              json=test_data_dict,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    # Get test
    response = db_client.get(f"/db/users/students/standardizedtests/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    found_record = False
    for elem in output:
        if elem["total_score"] == 1000 and elem["test_type"] == Constants.STD_TEST_TYPE_SAT.value:
            # Validate message
            found_record = True
            break

    assert found_record == True

    # Add another test with the same date, but different test type
    test_data = schemas.StudentStandardizedTestCreate(
                                                     student_id=student_id,
                                                     date_taken="2021-01-01",
                                                     test_type=Constants.STD_TEST_TYPE_ACT.value,
                                                     total_score=35,
                                                     english_score=35,
                                                     math_score=36,
                                                     reading_score=35,
                                                     science_score=35
                                                    )  # Mock test data
    test_data_dict = test_data.__dict__
    test_data_dict["date_taken"] = test_data_dict["date_taken"].isoformat()

    user_id = get_user_id(headers)
    response = db_client.post(f"/db/users/students/standardizedtests/add/user_id/{user_id}",
                              json=test_data_dict,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    # Get test
    response = db_client.get(f"/db/users/students/standardizedtests/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    found_record = False
    for elem in output:
        if elem["total_score"] == 35 and elem["test_type"] == Constants.STD_TEST_TYPE_ACT.value:
            # Validate message
            found_record = True
            break
    
    assert found_record == True

def test_get_student_standardized_test_function(auth_token):
    headers = generate_auth_header(auth_token)
    user_id = get_user_id(headers)
    response = db_client.get(f"/db/users/students/standardizedtests/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    # assert "data" in output  # Check if data is present in the response
    assert len(output) > 0  # Check if data is present in the response

def test_update_student_standardized_test_function(auth_token):
    headers = generate_auth_header(auth_token)
    # Get the standardized test first and then update it
    user_id = get_user_id(headers)
    response = db_client.get(f"/db/users/students/standardizedtests/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    
    std_test_to_update = output[0]
    std_test_id = std_test_to_update["id"]

    test_data = schemas.StudentStandardizedTestCreate(
                                                     student_id=std_test_to_update["student_id"],
                                                     date_taken="2021-01-01",
                                                     test_type=Constants.STD_TEST_TYPE_ACT.value,
                                                     total_score=36,
                                                     english_score=36,
                                                     math_score=36,
                                                     reading_score=36,
                                                     science_score=36
                                                    )  # Mock test data
    test_data_dict = test_data.__dict__
    test_data_dict["date_taken"] = test_data_dict["date_taken"].isoformat()

    response = db_client.put(f"/db/users/students/standardizedtests/update/{std_test_id}",
                             json=test_data_dict,
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    # Get test
    response = db_client.get(f"/db/users/students/standardizedtests/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    found_record = False
    for elem in output:
        if elem["total_score"] == 36 and elem["test_type"] == Constants.STD_TEST_TYPE_ACT.value and elem["id"] == std_test_id:
            # Validate message
            found_record = True
            break

    assert found_record == True

def test_search_user_by_name_paginated_function(auth_token):
    headers = generate_auth_header(auth_token)
    name = "Test"  # User name to search
    page_num = 1  # Page number
    limit = 10  # Limit per page

    response = db_client.get(f"/db/users/get/paginated/search/{name}?page_num={page_num}&limit={limit}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    assert output["message"] == "Users Fetched!"  # Validate message
    assert "data" in output  # Check if data is present in the response

    data = output["data"]
    users = data["result"]
    assert len(users) > 0  # Check if users are returned

    for user in users:
        assert user["username"] is not None  # Validate username
        assert user["email"] is not None  # Validate email
        assert user["first_name"] is not None  # Validate first name
        assert user["last_name"] is not None  # Validate last name
        assert user["birthdate"] is not None  # Validate birthdate
        assert user["type"] is not None  # Validate type
        assert user["parent_name"] is not None  # Validate parent name
        assert user["parent_email"] is not None  # Validate parent email
        assert user["consentdate"] is not None  # Validate consent date
        assert user["uid"] is not None  # Validate UID
        assert user["followers"] is not None  # Validate followers
        assert user["following"] is not None  # Validate following
        assert user["website"] is not None  # Validate website
        assert user["personal_statement"] is not None  # Validate personal statement
        assert user["connections"] is not None  # Validate connections
        assert user["counselor_connections"] is not None  # Validate counselor connections
        assert user["profile_pic_url"] is not None  # Validate profile picture URL
        assert user["id"] is not None  # Validate ID
        assert user["is_online"] is not None  # Validate online status
        assert user["fcm_token"] is not None  # Validate FCM token
        assert user["show_sensitive_info"] is not None  # Validate show sensitive info

    assert "limit" in data  # Check if limit is present in the response
    assert "pageNo" in data  # Check if page number is present in the response
    assert "totalData" in data  # Check if total count is present in the responsedef test_get_post_by_uid_paginated_function():

    user_id = get_user_id(headers)  # User ID to fetch posts
    page_num = 1  # Page number
    limit = 10  # Limit per page
    
    # Create a post
    test_datetime = datetime.datetime(2024, 3, 15, 10, 30, 0)
    post_data = schemas.PostCreate(post_title="Pytest Post",
                                   post_content="Pytest Content",
                                   date_published=test_datetime,
                                   user_id=user_id,
                                   likes=[],
                                   post_content_url="")  # Mock post data
    post_data_dict = post_data.__dict__
    post_data_dict["date_published"] = post_data_dict["date_published"].isoformat()

    response = db_client.post("/db/users/posts/create", json=post_data_dict,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    response = db_client.get(f"/db/users/posts/get_paginated/user_id/{user_id}?page_num={page_num}&limit={limit}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    output = response.json()
    assert output["message"] == "Posts Fetched!"  # Validate message
    assert "data" in output  # Check if data is present in the response

    data = output["data"]
    result = data["result"]
    assert len(result) > 0  # Check if posts are returned

    for post in result:
        assert post["id"] is not None  # Validate post ID
        assert post["type"] == Constants.POST_TYPE_REGULAR.value # Validate its a regular post
        assert post["post_title"] is not None  # Validate post title
        assert post["post_content"] is not None  # Validate post content
        assert post["date_published"] is not None  # Validate date published
        assert post["user_id"] is not None  # Validate user ID
        assert post["profile_pic_url"] is not None  # Validate profile picture URL
        assert post["likes"] is not None  # Validate likes
        assert post["post_content_url"] is not None  # Validate post content URL
        assert post["username"] is not None  # Validate username

    assert "pageNo" in data  # Check if page number is present in the response
    assert "limit" in data  # Check if limit is present in the response
    assert "totalData" in data  # Check if total data count is present in the response
    assert "statusCode" in output  # Check if status code is present in the response
    page_num = 1  # Page number
    limit = 10  # Limit per page

    response = db_client.get(f"/db/users/posts/get_paginated?page_num={page_num}&limit={limit}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200

    output = response.json()
    assert output["message"] == "Posts Fetched!"  # Validate message
    assert "data" in output  # Check if data is present in the response

    result = output["data"]["result"]
    assert len(result) > 0  # Check if posts are returned

    for post in result:
        assert post["id"] is not None  # Validate post ID
        assert post["type"] == Constants.POST_TYPE_REGULAR.value # Validate its a regular post
        assert post["post_title"] is not None  # Validate post title
        assert post["post_content"] is not None  # Validate post content
        assert post["date_published"] is not None  # Validate date published
        assert post["user_id"] is not None  # Validate user ID
        assert post["profile_pic_url"] is not None  # Validate profile picture URL
        assert post["likes"] is not None  # Validate likes
        assert post["post_content_url"] is not None  # Validate post content URL
        assert post["username"] is not None  # Validate username
        assert post["comment_count"] is not None  # Validate comment count

    assert "pageNo" in output["data"]  # Check if page number is present in the response
    assert "limit" in output["data"]  # Check if limit is present in the response
    assert "totalData" in output["data"]  # Check if total data count is present in the response
    assert "statusCode" in output  # Check if status code is present in the response


def test_search_user_by_name_and_type_paginated_function(auth_token):
    headers = generate_auth_header(auth_token)
    name = "Test"  # User name to search
    type = "student"
    page_num = 1  # Page number
    limit = 10  # Limit per page

    response = db_client.get(f"/db/users/get/paginated/search?name={name}&user_type={type}&page_num={page_num}&limit={limit}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    assert output["message"] == "Users Fetched!"  # Validate message
    assert "data" in output  # Check if data is present in the response

    data = output["data"]
    users = data["result"]
    assert len(users) > 0  # Check if users are returned

    for user in users:
        assert user["username"] is not None  # Validate username
        assert user["email"] is not None  # Validate email
        assert user["first_name"] is not None  # Validate first name
        assert user["last_name"] is not None  # Validate last name
        assert user["birthdate"] is not None  # Validate birthdate
        assert user["type"] == type  # Validate type
        assert user["parent_name"] is not None  # Validate parent name
        assert user["parent_email"] is not None  # Validate parent email
        assert user["consentdate"] is not None  # Validate consent date
        assert user["uid"] is not None  # Validate UID
        assert user["followers"] is not None  # Validate followers
        assert user["following"] is not None  # Validate following
        assert user["website"] is not None  # Validate website
        assert user["personal_statement"] is not None  # Validate personal statement
        assert user["connections"] is not None  # Validate connections
        assert user["counselor_connections"] is not None  # Validate counselor connections
        assert user["profile_pic_url"] is not None  # Validate profile picture URL
        assert user["id"] is not None  # Validate ID
        assert user["is_online"] is not None  # Validate online status
        assert user["fcm_token"] is not None  # Validate FCM token
        assert user["show_sensitive_info"] is not None  # Validate show sensitive info

    assert "limit" in data  # Check if limit is present in the response
    assert "pageNo" in data  # Check if page number is present in the response
    assert "totalData" in data  # Check if total count is present in the responsedef

    # Invalid user_type
    type = "user"
    response = db_client.get(f"/db/users/get/paginated/search?name={name}&user_type={type}&page_num={page_num}&limit={limit}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    assert output["message"] == "No matching users found!"  # Validate message
    assert "data" in output  # Check if data is present in the response

    data = output["data"]
    results = data["result"]
    assert len(results) == 0  # Check if users are returned


def test_student_schools(auth_token):
    headers = generate_auth_header(auth_token)
    # User ID to fetch posts
    user_id = get_user_id(headers)
    # Returns a list of schools for the user
    response = db_client.get(f"/db/users/students/schools/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Response Data is {output}")
    #assert "data" in output  # Check if data is present in the response
    assert len(output) > 0  # Check if data is present in the response
    log_trace(logging.INFO, f"Output is {output}")
    assert output[0]["id"] is not None  # Validate ID
    student_school_id = output[0]["id"]
    student_id = output[0]["student_id"]
    school_id = output[0]["school_id"]

    # Returns only one record not a list
    response = db_client.get(f"/db/users/students/schools/get/id/{student_id}/{school_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    #assert "data" in output  # Check if data is present in the response
    assert len(output) > 0  # Check if data is present in the response
    log_trace(logging.INFO, f"Output is {output}")
    assert output["id"] is not None  # Validate ID
    assert output["student_id"] == student_id  # Validate student ID
    assert output["school_id"] == school_id  # Validate school ID
    assert output["id"] == student_school_id  # Validate student school ID
    
    # Returns only one record not a list
    response = db_client.get(f"/db/users/students/schools/get/student_school/{student_school_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    #assert "data" in output  # Check if data is present in the response
    assert len(output) > 0  # Check if data is present in the response
    log_trace(logging.INFO, f"Output is {output}")
    assert output["id"] == student_school_id  # Validate ID

    response = db_client.get(f"/db/users/students/schools/get/student_school/100000",
                             headers=headers)  # Simulate a request to your endpoint
    log_trace(logging.INFO, f"Response is {response}")
    assert response.status_code == 200
    output = response.json()
    #assert "data" in output  # Check if data is present in the response
    assert output is None or len(output) == 0  # Check if data is present in the response
    #assert output[0]["id"] is None  # Validate ID - there should be no record

    school_data = schemas.StudentSchoolCreate(
        student_id=0,
        school_id=0,
        current_grade="12",
        gpa=3.5,
        w_gpa=3.8,
        start_date="2019-09-01",
        end_date="2023-06-01",
        graduation_year="2027-06-01",
        currently_enrolled=True,
        is_primary=True,
        user_id=user_id,
        name="Test School",
        city="Test City",
        state="Test State",
        zip="12345",
        country="United States"
    )
    school_data_dict = school_data.__dict__
    school_data_dict["start_date"] = school_data_dict["start_date"].isoformat()
    school_data_dict["end_date"] = school_data_dict["end_date"].isoformat()
    school_data_dict["graduation_year"] = school_data_dict["graduation_year"].isoformat()

    response = db_client.post(f"/db/users/students/schools/add/",
                              json=school_data_dict,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    #assert "data" in output  # Check if data is present in the response
    assert output["id"] is not None  # Validate ID
    assert output["user_id"] == user_id  # Validate user ID
    assert output["name"] == school_data_dict["name"]  # Validate school ID
    assert output["start_date"] == school_data_dict["start_date"]  # Validate start date
    assert output["end_date"] == school_data_dict["end_date"]  # Validate end date
    assert output["currently_enrolled"] == True  # Validate currently enrolled
    assert output["gpa"] == 3.5  # Validate GPA
    assert output["w_gpa"] == 3.8  # Validate weighted GPA
    assert output["current_grade"] == "12"  # Validate current grade
    #assert output["is_primary"] == school_data_dict["is_primary"]  # Validate is primary
    assert output["graduation_year"] == school_data_dict["graduation_year"]  # Validate graduation year
    student_school_id = output["id"]

    # Update the school record
    school_data = schemas.StudentSchoolUpdate(
        student_id=output["student_id"],
        school_id=output["school_id"],
        current_grade="12",
        gpa=3.5,
        w_gpa=3.8,
        start_date="2019-09-01",
        end_date="2023-06-01",
        graduation_year="2028-06-01", # change from 2027 to 2028
        currently_enrolled=True,
        is_primary=True,
        user_id=user_id,
        name="Test High School",  # change from Test School to Test High School
        city="Test City",
        state="Test State",
        zip="12345",
        country="United States"
    )
    school_data_dict = school_data.__dict__
    school_data_dict["start_date"] = school_data_dict["start_date"].isoformat()
    school_data_dict["end_date"] = school_data_dict["end_date"].isoformat()
    school_data_dict["graduation_year"] = school_data_dict["graduation_year"].isoformat()

    response = db_client.put(f"/db/users/students/schools/update/student_school_id/{student_school_id}",
                             json=school_data_dict,
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    log_trace(logging.INFO, f"School data dict is {school_data_dict}")
    assert output["id"] == student_school_id  # Validate ID
    assert output["user_id"] == user_id  # Validate user ID
    assert output["name"] == school_data_dict["name"]  # Validate school ID
    assert output["start_date"] == school_data_dict["start_date"]  # Validate start date
    assert output["end_date"] == school_data_dict["end_date"]  # Validate end date
    assert output["currently_enrolled"] == school_data_dict["currently_enrolled"]  # Validate currently enrolled
    assert output["gpa"] == school_data_dict["gpa"]  # Validate GPA
    assert output["w_gpa"] == school_data_dict["w_gpa"]  # Validate weighted GPA
    assert output["current_grade"] == school_data_dict["current_grade"]  # Validate current grade
    assert output["graduation_year"] == school_data_dict["graduation_year"]  # Validate graduation year

def get_student_id(user_id, auth_token):
    headers = generate_auth_header(auth_token)
    response = db_client.get(f"/db/users/students/get/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_id = output["id"]
    return student_id

def test_college_recommendation(auth_token):
    headers = generate_auth_header(auth_token)

    # add a few target schools for this studen
    college_names = ["University of Utah","University of Wyoming","University of Cincinnati","University of Akron","University of Arkansas",
                     "Penn State Altoona","Indiana University of Pennsylvania","California University of Pennsylvania",
                     "Slippery Rock University of Pennsylvania","Bloomsburg University of Pennsylvania",
                     "University of Pittsburgh at Bradford","Mansfield University of Pennsylvania","Lock Haven University",
                     "East Stroudsburg University of Pennsylvania","West Chester University of Pennsylvania",
                     "Temple University","Millersville University of Pennsylvania","Shippensburg University of Pennsylvania",
                     "Kutztown University of Pennsylvania","Edinboro University of Pennsylvania","University of Pittsburgh",
                     "Carnegie Mellon University","University of Pennsylvania"]
    user_ids = get_all_student_user_ids(headers)
    for  cn in  college_names:
        print("college name is ",cn)
        user_id = random.choice(user_ids)
        target_school_data = schemas.StudentTargetSchoolCreate(student_id=get_student_id(user_id, auth_token),
                              career_id= 1,
                               college_name=cn ,
                              tution_fees= "20000",
                   probability_of_admission= "0.8",
            positives= ["good location", "good program"],
            why_this_recommendation ="Test Data",
          negatives= ["high tution fees", "far from home"],
          classification = random.choice(["Safety", "Target", "Reach", "Extreme Reach"]),
          acceptance_rate = random.choice( ["high", "moderate", "medium", "low"])
         )
        target_school_data_dict = target_school_data.__dict__
        response = db_client.post("/db/users/students/targetschools/add/", json=target_school_data_dict, headers=headers)
        #assert response.status_code == 200
        output = response.json()
        print("Output is ", output)

def test_student_courses(auth_token):
    headers = generate_auth_header(auth_token)
    user_id = get_user_id(headers)
    # Returns a list of courses for the user
    response = db_client.get(f"/db/users/students/courses/get/user_id/{user_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert len(output) > 0  # Check if data is present in the response
    log_trace(logging.INFO, f"Output is {output}")
    assert output[0]["id"] is not None  # Validate ID
    student_course_id = output[0]["id"]
    student_id = output[0]["student_id"]
    #course_id = output[0]["course_id"]
    school_id = output[0]["school_id"]
    addlist_student_course1_id = 0
    addlist_student_course2_id = 0
    for record in output:
        if record["course_name"] == "Test AddList Course 1":
            addlist_student_course1_id = record["id"]
        elif record["course_name"] == "Test AddList Course 2":
            addlist_student_course2_id = record["id"]

    if addlist_student_course1_id != 0:
        log_trace(logging.INFO, f"Deleting student course id {addlist_student_course1_id}")
        response = db_client.delete(f"/db/users/students/courses/delete/{addlist_student_course1_id}",
                                    headers=headers)  # Simulate a request to your endpoint
        assert response.status_code == 200
        output = response.json()
        log_trace(logging.INFO, f"Output is {output}")

    if addlist_student_course2_id != 0:
        log_trace(logging.INFO, f"Deleting student course id {addlist_student_course2_id}")
        response = db_client.delete(f"/db/users/students/courses/delete/{addlist_student_course2_id}",
                                    headers=headers)  # Simulate a request to your endpoint
        assert response.status_code == 200
        output = response.json()
        log_trace(logging.INFO, f"Output is {output}")

    # Returns a list of courses taken at that school by the student
    response = db_client.get(f"/db/users/students/courses/get/student_school_id/{student_id}/{school_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    #assert "data" in output  # Check if data is present in the response
    assert len(output) > 0  # Check if data is present in the response
    log_trace(logging.INFO, f"Output is {output}")
    assert output[0]["id"] is not None  # Validate ID
    assert output[0]["student_id"] == student_id  # Validate student ID
    assert output[0]["school_id"] == school_id  # Validate course ID
    student_course_id = output[0]["id"]

    # Returns a list of courses taken by the student
    response = db_client.get(f"/db/users/students/courses/get/student_id/{student_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert len(output) > 0  # Check if data is present in the response
    log_trace(logging.INFO, f"Output is {output}")
    student_course_id = output[0]["id"]
    student_record = output[0]
    for record in output:
        assert record["student_id"] == student_id  # Validate ID

    # Delete the course record
    log_trace(logging.INFO, f"Deleting student course id {student_course_id}")
    response = db_client.delete(f"/db/users/students/courses/delete/{student_course_id}",
                                headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
        
    course_data = schemas.StudentCourseCreate(
        student_id=student_id,
        school_id=school_id,
        grade="A",
        course_name=student_record["course_name"], # To make sure the request succeeds, add a deleted course
        credits=4,
        term='T1', # course term: Term1/Sem1/Fall/etc
        grade_year="10",
        difficulty_level="Hard",
        feedback="Good"
    )
    course_data_dict = course_data.__dict__
    log_trace(logging.INFO, f"Course data dict is {course_data_dict}")
    response = db_client.post(f"/db/users/students/courses/add/",
                              json=course_data_dict,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    assert output["id"] is not None  # Validate ID
    assert output["student_id"] == student_id  # Validate student ID
    assert output["school_id"] == school_id  # Validate school ID
    assert output["course_name"] == course_data_dict["course_name"]  # Validate course name
    assert output["term"] == course_data_dict["term"] # Validate term
    assert output["grade"] == course_data_dict["grade"]  # Validate grade
    assert output["grade_year"] == course_data_dict["grade_year"]  # Validate grade year
    assert output["difficulty_level"] == course_data_dict["difficulty_level"]  # Validate difficulty level
    assert output["feedback"] == course_data_dict["feedback"]  # Validate feedback
    student_course_id = output["id"]

    # Update the course record
    course_data = schemas.StudentCourseCreate(
        student_id=student_id,
        school_id=school_id,
        course_id=0,
        grade="A+",
        course_name="Test Update Course",
        credits=4,
        term="T2",  # course term: Term1/Sem1/Fall/etc
        grade_year="10",
        difficulty_level="Hard",
        feedback="Good"
    )
    course_data_dict = course_data.__dict__
    response = db_client.post(f"/db/users/students/courses/update/{student_course_id}",
                             json=course_data_dict,
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    assert output["id"] == student_course_id  # Validate ID
    assert output["student_id"] == student_id  # Validate student ID
    assert output["school_id"] == school_id  # Validate school ID
    assert output["course_name"] == course_data_dict["course_name"]  # Validate course name
    assert output["term"] == course_data_dict["term"]  # course term: Term1/Sem1/Fall/etc
    assert output["grade"] == course_data_dict["grade"]  # Validate grade
    assert output["grade_year"] == course_data_dict["grade_year"]  # Validate grade year
    assert output["difficulty_level"] == course_data_dict["difficulty_level"]  # Validate difficulty level
    assert output["feedback"] == course_data_dict["feedback"]  # Validate feedback

    # Add list of courses
    course_data = [
        {
            "student_id": student_id,
            "school_id": school_id,
            "course_id": 0,
            "grade": "A",
            "course_name": "Test AddList Course 1",
            "credits": 4,
            "term": "T1", # course term: Term1/Sem1/Fall/etc
            "grade_year": "10",
            "difficulty_level": "Hard",
            "feedback": "Good"
        },
        {
            "student_id": student_id,
            "school_id": school_id,
            "course_id": 0,
            "grade": "A+",
            "course_name": "Test AddList Course 2",
            "credits": 4,
            "term": "T1", # course term: Term1/Sem1/Fall/etc
            "grade_year": "10",
            "difficulty_level": "Hard",
            "feedback": "Good"
        }
    ]
    response = db_client.post(f"/db/users/students/courses/addlist/",
                              json=course_data,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    assert len(output) > 0  # Check if data is present in the response
    for record in output:
        assert record["student_id"] == student_id  # Validate ID
        assert record["school_id"] == school_id  # Validate school ID

    # Get the list of courses
    response = db_client.get(f"/db/users/students/courses/get/student_id/{student_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    found_course_1 = False
    found_course_2 = False
    assert len(output) > 0  # Check if data is present in the response
    for record in output:
        assert record["student_id"] == student_id  # Validate ID
        assert record["school_id"] == school_id  # Validate school ID
        if record["course_name"] == "Test AddList Course 1":
            assert record["grade"] == "A"
            found_course_1 = True
        if record["course_name"] == "Test AddList Course 2":
            assert record["grade"] == "A+"
            found_course_2 = True

    assert found_course_1 == True
    assert found_course_2 == True

    # Try adding the same course, but with a different term
    course_data = [
        {
            "student_id": student_id,
            "school_id": school_id,
            "course_id": 0,
            "grade": "A",
            "course_name": "Test AddList Course 1",
            "credits": 4,
            "term": "T2", # course term: Term1/Sem1/Fall/etc
            "grade_year": "10",
            "difficulty_level": "Hard",
            "feedback": "Good"
        }
    ]
    response = db_client.post(f"/db/users/students/courses/addlist/",
                              json=course_data,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    assert len(output) > 0  # Check if data is present in the response
    for record in output:
        assert record["student_id"] == student_id  # Validate ID
        assert record["school_id"] == school_id  # Validate school ID

    # Get the list of courses
    response = db_client.get(f"/db/users/students/courses/get/student_id/{student_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    found_course_1_t2 = False
    assert len(output) > 0  # Check if data is present in the response
    for record in output:
        assert record["student_id"] == student_id  # Validate ID
        assert record["school_id"] == school_id  # Validate school ID
        if record["course_name"] == "Test AddList Course 1":
            if record["term"] == "T2":
                log_trace(logging.INFO, record)
                found_course_1_t2 = True

    assert found_course_1_t2 == True

    # Try adding the same course again with the exact same term - should be a NOP with listadd
    course_data = [
        {
            "student_id": student_id,
            "school_id": school_id,
            "course_id": 0,
            "grade": "C", # CHANGED THE GRADE HERE - SHOULD NOT REFLECT!
            "course_name": "Test AddList Course 1",
            "credits": 4,
            "term": "T2", # course term: Term1/Sem1/Fall/etc
            "grade_year": "10",
            "difficulty_level": "Hard",
            "feedback": "Good"
        }
    ]
    response = db_client.post(f"/db/users/students/courses/addlist/",
                              json=course_data,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    assert len(output) == 0  # Nothing added, so nothing returned. Check if data is present in the response
    # for record in output:
    #     assert record["student_id"] == student_id  # Validate ID
    #     assert record["school_id"] == school_id  # Validate school ID
    # assert output[0]["grade"] == "A"

    # Get the list of courses
    response = db_client.get(f"/db/users/students/courses/get/student_id/{student_id}",
                             headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    found_course_1_t2 = False
    assert len(output) > 0  # Check if data is present in the response
    for record in output:
        assert record["student_id"] == student_id  # Validate ID
        assert record["school_id"] == school_id  # Validate school ID
        if record["course_name"] == "Test AddList Course 1":
            if record["term"] == "T2": # course term: Term1/Sem1/Fall/etc
                # assert record["grade"] == "A" # SHOULD SHOW THE ADDLIST WAS NOP WHEN COURSE WAS ADDED FOR SAME TERM
                found_course_1_t2 = True

    assert found_course_1_t2 == True

    # ADD THE SAME COURSE FOR THE SAME YEAR AND TERM - SHOULD RETURN AN EXCEPTION
    course_data = schemas.StudentCourseCreate(
        student_id=student_id,
        school_id=school_id,
        grade="A",
        course_name="Test AddList Course 1", # Adding the same course
        credits=4,
        term='T2', # course term: Term1/Sem1/Fall/etc
        grade_year="10",
        difficulty_level="Hard",
        feedback="Good"
    )
    course_data_dict = course_data.__dict__
    log_trace(logging.INFO, f"Course data dict is {course_data_dict}")
    response = db_client.post(f"/db/users/students/courses/add/",
                              json=course_data_dict,
                              headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 400


# Test get states endpoint
def test_get_states(auth_token):
    """Test retrieving all states"""
    headers = generate_auth_header(auth_token)
    response = db_client.get("/db/get-states/", headers=headers)
    assert response.status_code == 200
    states = response.json()
    assert isinstance(states, list)
    assert len(states) > 0
    assert len(states) == len(set(states))  # Ensure no duplicates
    assert all(isinstance(state, str) for state in states)

# Test get cities by state endpoint
def test_get_cities_by_state(auth_token):
    """Test retrieving all cities for a given state"""
    headers = generate_auth_header(auth_token)
    state = "California"  # Example state
    response = db_client.get(f"/db/get-cities-by-state/?state={state}", headers=headers)
    assert response.status_code == 200
    cities = response.json()
    assert isinstance(cities, list)
    assert len(cities) > 0
    assert len(cities) == len(set(cities))  # Ensure no duplicates
    assert all(isinstance(city, str) for city in cities)

# Test get schools by state with pagination and filtering by name start
def test_get_schools_by_state(auth_token):
    """Test retrieving schools by state with pagination and optional name filtering"""
    headers = generate_auth_header(auth_token)
    state = "California"  # Example state
    starts_with = "S"  # Example starts_with value
    page = 1  # Example page number
    per_page = 10  # Example number of schools per page

    response = db_client.get(
        f"/db/get-schools-state/?state={state}&starts_with={starts_with}&page={page}&per_page={per_page}",
        headers=headers
    )

    assert response.status_code == 200
    data = response.json()
    assert isinstance(data, list)
    assert len(data) > 0
    assert all(isinstance(school, dict) for school in data)
    assert all(school["state"] == state for school in data)

    # Check pagination
    assert len(data) <= per_page  # Number of schools should be less than or equal to per_page
    # Check if the correct page of data is returned
    expected_page_data = data[(page - 1) * per_page:page * per_page]
    assert expected_page_data == data  # Assuming the response returns the entire page's data

# Test get all schools by city and state
def test_get_all_schools_city_state(auth_token):
    """Test retrieving all schools by city and state"""
    headers = generate_auth_header(auth_token)
    city = "Los Angeles"  # Example city
    state = "California"  # Example state
    response = db_client.get(f"/db/get-all-schools-city-state/?city={city}&state={state}", headers=headers)
    assert response.status_code == 200
    schools = response.json()
    assert isinstance(schools, list)
    assert len(schools) > 0
    assert all(isinstance(school, dict) for school in schools)
    assert all(school["city"] == city and school["state"] == state for school in schools)
    log_trace(logging.INFO, schools)

# Test the news endpoints

def test_create_news(auth_token):
    headers = generate_auth_header(auth_token)
    news_data = schemas.NewsCreate(
        news_title = "Test News123",
        news_content_url = "https://www.testnews.com",
        news_published_date= "2021-01-01T00:00:00",
        news_keywords = ["test", "news"],
        likes = [],
    )

    news_data_dict = news_data.__dict__

    news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()

    response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
    log_trace(logging.INFO, f"Response is {response}")
    assert response.status_code == 200
    output = response.json()
    assert output["news_title"] == news_data_dict["news_title"]
    assert output["news_content_url"] == news_data_dict["news_content_url"]

    log_trace(logging.INFO, output)

def test_get_news(auth_token):
    headers = generate_auth_header(auth_token)

    title = "Test News123"    
    response = db_client.get(f"/db/news/get/{title}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    assert output["news_title"] == title
    log_trace(logging.INFO, output)
    id = output["id"]
    response = db_client.get(f"/db/news/get/id/{id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    assert output["news_title"] == title
    log_trace(logging.INFO, output)

def test_delete_news(auth_token):
    headers = generate_auth_header(auth_token)

    # Create a news
    news_data = schemas.NewsCreate(
        news_title="Test News Delete1",
        news_content_url="https://www.testnews.com",
        news_published_date="2021-01-01T00:00:00",
        news_keywords=["test", "news"],
        likes=[],
    )

    news_data_dict = news_data.__dict__
    news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
    response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, output)
    news_title = output["news_title"]

    # Delete the news using title

    response = db_client.delete(f"/db/news/delete/{news_title}", headers=headers)
    assert response.status_code == 200
    output = response.json()

def test_delete_outdated_news(auth_token):

    #procedure: get the number of news in system.
    # set the threshold date to today

    # get the number of news in system
    # note the numeber that are outdated

    # delete the outdated news
    # get the number of news in system

    # assert that the number of news in system is the same as the number of news that are not outdated

    headers = generate_auth_header(auth_token)
    response = db_client.get("/db/news/get_news_paginated/?page_num=1&limit=100", headers=headers)
    assert response.status_code == 200
    output = response.json()
    num_news = len(output["data"]["result"])
    log_trace(logging.INFO, f"Number of news in system: {num_news}")
    threshold_date = datetime.datetime.now()
    formatted_datetime = threshold_date.strftime("%Y-%m-%dT%H:%M:%S")
    log_trace(logging.INFO, f"Threshold date: {formatted_datetime}")

    for i in range(1, 21):
        k = 40 - 2*i
        news_data = schemas.NewsCreate(
            news_title=f"Test News Paginated {i}",
            news_content_url="https://www.testnews.com",
            news_published_date= f"20{k:02d}-01-01T00:00:00",
            news_keywords=["test", "news"],
            likes=[],
        )

        news_data_dict = news_data.__dict__
        news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
        response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
        assert response.status_code == 200

    response = db_client.get("/db/news/get_news_paginated/?page_num=1&limit=20", headers=headers)
    assert response.status_code == 200
    output = response.json()
    num_news = len(output["data"]["result"])
    log_trace(logging.INFO, f"Number of news in system: {num_news}")
    # count the number of news that are outdated
    # Do this by parsing the date published and comparing it to the threshold date
    num_outdated = 0

    for news in output["data"]["result"]:
        if news["news_published_date"] < formatted_datetime:
            num_outdated += 1
            log_trace(logging.INFO, f"Outdated news: {news['news_published_date']}")

    log_trace(logging.INFO, f"Number of outdated news: {num_outdated}")

    # now delete the outdated news
    response = db_client.delete(f"/db/news/delete_outdated/{formatted_datetime}", headers=headers)
    assert response.status_code == 200
    response = db_client.get("/db/news/get_news_paginated/?page_num=1&limit=20", headers=headers)
    assert response.status_code == 200
    output = response.json()
    num_news = len(output["data"]["result"])
    log_trace(logging.INFO, f"Number of news in system after purge: {num_news}")
    # delete all the news we created

    for i in range(1, 20):
        response = db_client.delete(f"/db/news/delete/Test News Paginated {i}", headers=headers)
        assert response.status_code == 200
    assert num_news == 20 - num_outdated


def test_news_post_like_unlike(auth_token):
    headers = generate_auth_header(auth_token)

    # create dummy news data
    news_data = schemas.NewsCreate(
        news_title=f"Test News Like_Unlike",
        news_content_url="https://www.testnews.com",
        news_published_date= f"2024-01-01T00:00:00",
        news_keywords=["test", "news"],
    )

    news_data_dict = news_data.__dict__
    news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
    response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
    assert response.status_code == 200
    news_data = response.json()

    payload = {
        "user_id": get_user_id(headers),
        "news_id": news_data["id"]
    }

    # Test news like
    response = db_client.put(f'/db/news/like_unlike/{news_data["id"]}', json=payload, headers=headers)
    assert response.status_code == 200

    response_json = response.json()
    assert response_json["likes"][0]["user_id"] == payload["user_id"]
    assert response_json["likes"][0]["post_id"] == payload["news_id"]

    # Test news unlike
    response = db_client.put(f'/db/news/like_unlike/{news_data["id"]}', json=payload, headers=headers)
    assert response.status_code == 200

    response_json = response.json()
    assert len(response_json["likes"]) == 0
    log_trace(logging.INFO, news_data)

    # now delete the news
    response = db_client.delete(f"/db/news/delete/{news_data['news_title']}", headers=headers)
    assert response.status_code == 200


def test_get_news_paginated(auth_token):
    headers = generate_auth_header(auth_token)

    # first create a bunch of news
    # make the date random
    for i in range(1, 20):
        k = 40 - i
        news_data = schemas.NewsCreate(
            news_title=f"Test News Paginated {i}",
            news_content_url="https://www.testnews.com",
            news_published_date= f"20{k:02d}-01-01T00:00:00",
            news_keywords=["test", "news"],
            likes=[],
        )

        news_data_dict = news_data.__dict__
        news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
        response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
        assert response.status_code == 200

    response = db_client.get("/db/news/get_news_paginated/?page_num=1&limit=10", headers=headers)
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, output)

    # The smaller the i value, the more recent the news
    for i in range(1, 6):
        assert output["data"]["result"][i-1]["news_title"] == f"Test News Paginated {i}"

    # Also add a test for getting news and posts
    response = db_client.get("/db/feed/get_news_and_posts_paginated/?page_num=1&limit=10", headers=headers)
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, output)
    regular_post = 0
    news_post = 0
    for post in output["data"]["result"]:
        if post["type"] == Constants.POST_TYPE_REGULAR.value:
            regular_post = regular_post + 1
        elif post["type"] == Constants.POST_TYPE_NEWS.value:
            news_post = news_post + 1
    assert news_post > 0
    assert regular_post > 0

    # now delete all the news we created
    for i in range(1, 20):
        response = db_client.delete(f"/db/news/delete/Test News Paginated {i}", headers=headers)
        assert response.status_code == 200

def test_create_news_comment(auth_token):
    headers = generate_auth_header(auth_token)

    # create a news
    news_data = schemas.NewsCreate(
        news_title="Test News Comment",
        news_content_url="https://www.testnews.com",
        news_published_date="2021-01-01T00:00:00",
        news_keywords=["test", "news"],
    )

    news_data_dict = news_data.__dict__
    news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
    response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
    assert response.status_code == 200
    output = response.json()
    news_title = output["news_title"]
    # use title to get id
    response = db_client.get(f"/db/news/get/{news_title}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    news_id = output["id"]
    user_id = get_user_id(headers)

    log_trace(logging.INFO, f"News ID is {news_id}")
    log_trace(logging.INFO, f"User ID is {user_id}")

    # create a comment
    comment_data = schemas.NewsCommentCreate(
        user_id=user_id,
        news_id=news_id,
        content="This is a test comment",
        date_published="2021-01-01T00:00:00"
    )

    comment_data_dict = comment_data.__dict__
    log_trace(logging.INFO, f"Comment data dict is {comment_data_dict}")
    comment_data_dict["date_published"] = comment_data_dict["date_published"].isoformat()
    response = db_client.post("/db/news/create_comment", json=comment_data_dict, headers=headers)
    log_trace(logging.INFO, response)
    assert response.status_code == 200
    output = response.json()
    assert output["content"] == comment_data_dict["content"]
    # now delete the news
    response = db_client.delete(f"/db/news/delete/{news_title}", headers=headers)
    assert response.status_code == 200

def test_get_news_comments(auth_token):
    headers = generate_auth_header(auth_token)

    # create a news
    news_data = schemas.NewsCreate(
        news_title="Test News Comment",
        news_content_url="https://www.testnews.com",
        news_published_date="2021-01-01T00:00:00",
        news_keywords=["test", "news"],
    )

    news_data_dict = news_data.__dict__
    news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
    response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
    assert response.status_code == 200
    output = response.json()
    news_title = output["news_title"]

    # use title to get id
    response = db_client.get(f"/db/news/get/{news_title}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    news_id = output["id"]
    user_id = get_user_id(headers)

    log_trace(logging.INFO, f"News ID is {news_id}")
    log_trace(logging.INFO, f"User ID is {user_id}")

    # create a comment
    comment_data = schemas.NewsCommentCreate(
        user_id=user_id,
        news_id=news_id,
        content="This is a test comment",
        date_published="2021-01-01T00:00:00"
    )

    comment_data_dict = comment_data.__dict__
    log_trace(logging.INFO, f"Comment data dict is {comment_data_dict}")
    comment_data_dict["date_published"] = comment_data_dict["date_published"].isoformat()
    response = db_client.post("/db/news/create_comment", json=comment_data_dict, headers=headers)
    log_trace(logging.INFO, response)
    assert response.status_code == 200
    output = response.json()
    assert output["content"] == comment_data_dict["content"]

    # get the comments
    response = db_client.get(f"/db/news/get_comments/{news_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, output)

    # delete the comment
    response = db_client.delete(f"/db/news/delete_comment/{output[0]['id']}", headers=headers)
    # now delete the news
    response = db_client.delete(f"/db/news/delete/{news_title}", headers=headers)
    assert response.status_code == 200

def test_get_multiple_news_comments(auth_token):
    headers = generate_auth_header(auth_token)

    # create a news
    news_data = schemas.NewsCreate(
        news_title="Test News Comment",
        news_content_url="https://www.testnews.com",
        news_published_date="2021-01-01T00:00:00",
        news_keywords=["test", "news"],
    )

    news_data_dict = news_data.__dict__
    news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
    response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
    assert response.status_code == 200
    output = response.json()
    news_title = output["news_title"]

    # use title to get id
    response = db_client.get(f"/db/news/get/{news_title}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    news_id = output["id"]
    user_id = get_user_id(headers)

    log_trace(logging.INFO, f"News ID is {news_id}")
    log_trace(logging.INFO, f"User ID is {user_id}")

    # create a comment
    comment_data = schemas.NewsCommentCreate(
        user_id=user_id,
        news_id=news_id,
        content="This is a test comment",
        date_published="2021-01-01T00:00:00"
    )

    comment_data_dict = comment_data.__dict__
    log_trace(logging.INFO, f"Comment data dict is {comment_data_dict}")
    comment_data_dict["date_published"] = comment_data_dict["date_published"].isoformat()
    response = db_client.post("/db/news/create_comment", json=comment_data_dict, headers=headers)
    log_trace(logging.INFO, response)
    assert response.status_code == 200
    output = response.json()
    assert output["content"] == comment_data_dict["content"]

    # create another comment
    comment_data = schemas.NewsCommentCreate(
        user_id=user_id,
        news_id=news_id,
        content="This is a test comment 2",
        date_published="2021-02-01T00:00:00"
    )

    comment_data_dict = comment_data.__dict__
    log_trace(logging.INFO, f"Comment data dict is {comment_data_dict}")
    comment_data_dict["date_published"] = comment_data_dict["date_published"].isoformat()
    response = db_client.post("/db/news/create_comment", json=comment_data_dict, headers=headers)
    log_trace(logging.INFO, response)
    assert response.status_code == 200
    output = response.json()
    assert output["content"] == comment_data_dict["content"]

    # get the comments
    response = db_client.get(f"/db/news/get_comments/{news_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()

    # format output to log_trace logging.INFO, only the content and the date published

    for comment in output:
        log_trace(logging.INFO, f"Comment: {comment['content']}")
        log_trace(logging.INFO, f"Date Published: {comment['date_published']}")

    # verify that the comments are in the correct order
    assert output[0]["content"] == "This is a test comment 2"
    # delete the comments
    response = db_client.delete(f"/db/news/delete_comment/{output[0]['id']}", headers=headers)
    # delete the news
    response = db_client.delete(f"/db/news/delete/{news_title}", headers=headers)


def test_news_comment_like_unlike(auth_token):
    headers = generate_auth_header(auth_token)

    # create dummy news data
    news_data = schemas.NewsCreate(
        news_title=f"Test News Like_Unlike",
        news_content_url="https://www.testnews.com",
        news_published_date= f"2024-01-01T00:00:00",
        news_keywords=["test", "news"],
    )

    news_data_dict = news_data.__dict__
    news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
    response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
    assert response.status_code == 200
    news_data = response.json()

    user_id = get_user_id(headers)

    # create dummy news data
    comment_data = schemas.NewsCommentCreate(
        user_id=user_id,
        news_id=news_data["id"],
        content="This is a test comment",
        date_published="2021-01-01T00:00:00"
    )

    comment_data_dict = comment_data.__dict__
    log_trace(logging.INFO, f"Comment data dict is {comment_data_dict}")
    comment_data_dict["date_published"] = comment_data_dict["date_published"].isoformat()
    response = db_client.post("/db/news/create_comment", json=comment_data_dict, headers=headers)
    log_trace(logging.INFO, response)
    assert response.status_code == 200
    news_comment = response.json()

    payload = {
        "user_id": user_id,
        "comment_id": news_comment["id"]
    }

    # Test news comment like
    response = db_client.put(f'/db/news/comments/like_unlike', json=payload, headers=headers)
    assert response.status_code == 200

    response_json = response.json()
    assert response_json["likes"][0]["user_id"] == payload["user_id"]
    assert response_json["likes"][0]["comment_id"] == payload["comment_id"]

    # Test news comment unlike
    response = db_client.put(f'/db/news/comments/like_unlike', json=payload, headers=headers)
    assert response.status_code == 200

    response_json = response.json()
    assert len(response_json["likes"]) == 0
    log_trace(logging.INFO, news_comment)

    # now delete the news
    response = db_client.delete(f"/db/news/delete/{news_data['news_title']}", headers=headers)
    assert response.status_code == 200


def test_no_comments(auth_token):
    headers = generate_auth_header(auth_token)
    # create a news
    news_data = schemas.NewsCreate(
        news_title="Test News Comment Empty",
        news_content_url="https://www.testnews.com",
        news_published_date="2021-01-01T00:00:00",
        news_keywords=["test", "news"],
        likes=[],
    )

    news_data_dict = news_data.__dict__
    news_data_dict["news_published_date"] = news_data_dict["news_published_date"].isoformat()
    response = db_client.post("/db/news/create", json=news_data_dict, headers=headers)
    assert response.status_code == 200
    output = response.json()
    news_title = output["news_title"]
    # use title to get id
    response = db_client.get(f"/db/news/get/{news_title}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    news_id = output["id"]

    # get the comments
    response = db_client.get(f"/db/news/get_comments/{news_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    assert len(output) == 0
    log_trace(logging.INFO, output)

    # delete the news
    response = db_client.delete(f"/db/news/delete/{news_title}", headers=headers)
    assert response.status_code == 200

def test_num_of_news_posts(auth_token):
    headers = generate_auth_header(auth_token)
    # Get the number of news in the system
    response = db_client.get("/db/news/get_num_news_posts", headers=headers)
    output = response.json()
    log_trace(logging.INFO, output)


def test_get_user_followers(auth_token):
    """Test getting user followers by deleting one of the followers and making sure the uid doesnt show after delete"""

    headers = generate_auth_header(auth_token)
    user_data_dict = create_user_helper()
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message  

    # Setup 2nd user
    user_data_dict2 = create_user_helper()
    response = db_client.post("/db/users/create", json=user_data_dict2, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message

    # Setup 3rd user
    user_data_dict3 = create_user_helper()
    response = db_client.post("/db/users/create", json=user_data_dict3, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message

    # Get users
    response = get_user_by_email(user_data_dict['email'], headers=headers)
    log_trace(logging.INFO, f"response is {response}")
    output = response.json()
    log_trace(logging.INFO, f"output is {output}")
    user1 = output['data']

    response = get_user_by_email(user_data_dict2['email'], headers=headers)
    log_trace(logging.INFO, f"response is {response}")
    output = response.json()
    log_trace(logging.INFO, f"output is {output}")
    user2 = output['data']

    response = get_user_by_email(user_data_dict3['email'], headers=headers)
    log_trace(logging.INFO, f"response is {response}")
    output = response.json()
    log_trace(logging.INFO, f"output is {output}")
    user3 = output['data']
    # Setup follower relation
    follow = {
                "user_id": user1['id'],
                "follow_id": user2['id']
            }
    response = db_client.post("/db/users/follow_user/user_id/{user1['id']}", json=follow, headers=headers)
    assert response.status_code == 200
    follow = {
                "user_id": user1['id'],
                "follow_id": user3['id']
            }
    response = db_client.post("/db/users/follow_user/user_id/{user1['id']}", json=follow, headers=headers)
    assert response.status_code == 200
    following = get_user_following(userid=user1['id'], headers=headers)
    assert user2['id'] in following and user3['id'] in following

    # delete user2
    response = db_client.delete(f"/db/users/delete/id/{user2['id']}", headers=headers)
    check_response_status(response, success_message="User deleted successfully", error_message="Error deleting user")
    response = db_client.get(f"/db/users/get/user_id/{user2['id']}", headers=headers)
    # Response to this API is wrapped within message, data, code and error
    output = response.json()
    check_error_code(output, expected_code=404,
                     success_message="Get user by id failed as expected for a deleted User",
                     error_message="Get user by id did not fail as expected for a deleted User")
    
    following = get_user_following(userid=user1['id'], headers=headers)
    assert user2['id'] not in following and user3['id'] in following

    # Directly use the API to get user records of users user1 is following and validate that only one user still follows user1
    response = db_client.get(f"/db/users/get/following/user_id/{user1['id']}", headers=headers)
    check_response_status(response, success_message="Got user following successfully", error_message="Error getting user following")
    output = response.json()
    log_trace(logging.INFO, f"Response is {response}")
    log_trace(logging.INFO, f"Output is {output}")
    followers = output['data']
    assert len(followers) == 1
    follows = followers[0]['followers']
    # Make sure this is user id for user3 we added, and that the followers list for this user includes user1['id']
    assert user1['id'] in follows and user3['id'] == followers[0]['id']

###############################################################################
# Counselor API tests
###############################################################################

def test_create_counselor_function(auth_token):
    headers = generate_auth_header(auth_token)
    # Create a dummy user
    user_data_dict = create_user_helper(user_type="counselor")
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    
    output = response.json()
    #log_trace(logging.INFO, f"Message is output['message']")

    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name

    # get counselor id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/counselors/get/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"output is {output}")

    counselor_id = output["id"]
    uid = output["user_id"]
    assert(uid == user_id)
    log_trace(logging.INFO, f"Counselor id is {counselor_id}")

    # Get counselor
    response = db_client.get(f"/db/users/counselors/get/id/{counselor_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"output is {output}")
    assert(counselor_id == output["id"])
    log_trace(logging.INFO, f"Counselor students is {output['students']}")


def test_counselor_connect_with_students(auth_token):
    """Test counselor connection with students"""
    headers = generate_auth_header(auth_token=auth_token)

    # Create Counselor
    user_data_dict = create_user_helper(user_type="counselor")
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)
    assert response.status_code == 200
    output = response.json()
    user = output["data"]

    response = db_client.get(f"/db/users/counselors/get/{user['id']}", headers=headers)
    assert response.status_code == 200
    counselor = response.json()

    # Test Student Accept request
    student_1_details = create_student_user(headers=headers)
    response = db_client.get(f"/db/users/get/user_id/{student_1_details['user_id']}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_1 = output["data"]

    payload_1 = {
        "counselor_id": counselor["id"],
        "student_details": [
            {
                "student_name": student_1["first_name"],
                "student_email": student_1["email"],
                "parent_email": student_1["parent_email"],
            }
        ]
    }
    response = db_client.post("/db/counselor/connect-with-students", json=payload_1, headers=headers)
    assert response.status_code == 200

    payload_1 = {"counselor_id": counselor["id"], "student_email": student_1["email"]}
    response = db_client.get("/db/counselor/get-connect-with-student-status", params=payload_1, headers=headers)
    assert response.status_code == 200
    conn_req = response.json()

    encoded_str = ses_utils.create_encoded_string(
        conn_req["counselor_id"],
        conn_req["counselor_name"],
        conn_req["counselor_email"],
        conn_req["student_name"],
        conn_req["student_email"],
        conn_req["parent_email"],
        str(uuid.uuid4()),
    )

    payload_1 = {
        "token": conn_req["token"],
        "val": encoded_str,
        "approved": True
    }
    response = db_client.get("/webhooks/approve_request", params=payload_1, headers=headers)
    assert response.status_code == 200

    # Test Student Reject request
    student_2_details = create_student_user(headers=headers)
    response = db_client.get(f"/db/users/get/user_id/{student_2_details['user_id']}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_2 = output["data"]

    payload_2 = {
        "counselor_id": counselor["id"],
        "student_details": [
            {
                "student_name": student_2["first_name"],
                "student_email": student_2["email"],
                "parent_email": student_2["parent_email"]
            }
        ]
    }
    response = db_client.post("/db/counselor/connect-with-students", json=payload_2, headers=headers)
    assert response.status_code == 200

    payload_2 = {"counselor_id": counselor["id"], "student_email": student_2["email"]}
    response = db_client.get("/db/counselor/get-connect-with-student-status", params=payload_2, headers=headers)
    assert response.status_code == 200
    conn_req = response.json()

    encoded_str = ses_utils.create_encoded_string(
        conn_req["counselor_id"],
        conn_req["counselor_name"],
        conn_req["counselor_email"],
        conn_req["student_name"],
        conn_req["student_email"],
        conn_req["parent_email"],
        str(uuid.uuid4()),
    )

    payload_2 = {
        "token": conn_req["token"],
        "val": encoded_str,
        "approved": True
    }
    response = db_client.get("/webhooks/approve_request", params=payload_2, headers=headers)
    assert response.status_code == 200


def add_dummy_career(headers):
    career = schemas.CareersCreate(career_name="Career 1",
                                   career_description = "Doing career 1",
                                   career_outlook = "Great",
                                   job_duties = "Doing whatever is needed",
                                   skills = "Math, patience",
                                   median_salary = "85,000",
                                   majors = "Computer Science")

    response = db_client.post("/db/careers/get_create_or_update/",
                              json=career.__dict__, headers=headers)
    assert response.status_code == 200
    output = response.json()
    return output["id"]


def test_student_career_comment(auth_token):
    headers = generate_auth_header(auth_token=auth_token)

    # Create users
    student_info = create_student_user(headers=headers)
    user_id = student_info["user_id"]
    student_id = student_info["student_id"]

    # Create dummy career
    career_id = add_dummy_career(headers=headers)

    # Create student career
    student_career_data = {
        "student_id": student_id,
        "career_id": career_id
    }
    response = db_client.post("/db/users/students/careers/add/", json=student_career_data, headers=headers)
    assert response.status_code == 200
    student_career = response.json()
    log_trace(logging.INFO, student_career)
    assert student_career["career"]["id"] == career_id
    assert student_career["student_id"] == student_id

    # create student career comment
    student_career_comment_data = {
        "user_id": user_id,
        "student_career_id": student_career["id"],
        "content": "Test Comment",
        "date_published": "2024-07-26T05:48:00.774Z"
    }
    response = db_client.post("/db/users/students/careers/comment/create", json=student_career_comment_data, headers=headers)
    assert response.status_code == 200
    created_comment = response.json()
    assert created_comment["user_id"] == user_id
    assert created_comment["student_career_id"] == student_career["id"]

    # Get student career comment
    response = db_client.get(f"/db/users/students/careers/comments/{student_career['id']}", headers=headers)
    assert response.status_code == 200
    fetched_comment = response.json()
    assert len(fetched_comment) > 0
    assert fetched_comment[0]["student_career_id"] == student_career["id"]


# Add tests for saving colleges
def test_save_college(auth_token):
    """Test saving colleges and making sure we get the right college back on search"""
    headers = generate_auth_header(auth_token=auth_token)

    # Create users
    student_info = create_student_user(headers=headers)
    user_id = student_info["user_id"]
    student_id = student_info["student_id"]

    # Create dummy career
    career_id = add_dummy_career(headers=headers)

    # Create a dummy college and save it
    college_name_1 = "College123" + random.choice(string.ascii_letters)
    user_data = schemas.StudentTargetSchoolCreate(
                                    student_id=student_id,
                                    career_id=career_id,
                                    college_name=college_name_1,
                                    tution_fees="10000",
                                    probability_of_admission="low",
                                    positives=["pos1", "pos2"],
                                    negatives=["neg1", "neg2", "neg3"],
                                    classification='Safety',
                                    acceptance_rate='66.6',
                                    why_this_recommendation="Blah blah blah")
    user_data_dict = user_data.__dict__
    log_trace(logging.INFO, user_data_dict)
    response = db_client.post("/db/users/students/targetschools/add/", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    # Make sure the output is returning info about college_name_1
    assert output["college_name"] == college_name_1
    
    # Create another dummy college and save it
    college_name_2 = "College456" + random.choice(string.ascii_letters)
    user_data = schemas.StudentTargetSchoolCreate(
                                    student_id=student_id,
                                    career_id=career_id,
                                    college_name=college_name_2,
                                    tution_fees="10000",
                                    probability_of_admission="low",
                                    positives=["pos1", "pos2"],
                                    negatives=["neg1", "neg2", "neg3"],
                                    classification='Safety',
                                    acceptance_rate='66.6',
                                    why_this_recommendation="Blah blah blah")
    user_data_dict = user_data.__dict__
    log_trace(logging.INFO, user_data_dict)
    response = db_client.post("/db/users/students/targetschools/add/", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    # Make sure the output is returning info about college_name_1
    assert output["college_name"] == college_name_2

    # Get the colleges for the student, and we should see 2 records
    response = db_client.get(f"/db/users/students/targetschools/student_id/{student_id}", headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert len(output) == 2
    assert(output[0]["college_name"] == college_name_1)
    assert(output[1]["college_name"] == college_name_2)

def test_student_signup(auth_token):
    """Test user signup"""
    headers = generate_auth_header(auth_token=auth_token)
    USER_POOL_ID = os.getenv("COGNITO_USER_POOL_ID")
    log_trace(logging.INFO, f"Pool ID: {USER_POOL_ID}")
    fake = Faker()
    # Sign up a student user
    username = generate_unique_username()
    user = schemas.UserSignup(username=username,
                              password="abc123",
                              email=f"{username}@example.com",
                              first_name="dummy",
                              last_name="user",
                              dob="07-21-2008", # parsed_date,
                              is_minor=False,
                              parentname="Dummy parent",
                              parentemail=fake.email(),
                              consentdate=datetime.date.today().strftime('%m-%d-%Y'), # consent_date,
                              type=Constants.DB_USER_TYPE_STUDENT.value)
    user_dict = user.__dict__
    log_trace(logging.INFO, user_dict)
    #log_trace(logging.INFO, f"Client ID: {CLIENT_ID}")

    response = db_client.post("/auth/signup/", json=user_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()

    # Verify the user through admin API - we cannot get the confirmation code without using selenium
    cognito_client = config_cognito()

    response = cognito_client.admin_confirm_sign_up(UserPoolId=USER_POOL_ID, Username=user.email)
    log_trace(logging.INFO, response)

    # If verification succeeded, login
    login = schemas.UserLogin(username=user.email, password=user.password)
    login_dict = login.__dict__
    response = db_client.post("/auth/login", json=login_dict, headers=headers)
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Output is {output}")
    data = output["data"]
    id_value = None
    for key, value in data.items():
        if key == "student_id":
            found_student = True
            id_value = value
        elif key == "counselor_id":
            found_counselor = True
            id_value = value
    # If student, verify we got the student id
    if user.type == Constants.DB_USER_TYPE_STUDENT.value:
        assert found_student == True
        log_trace(logging.INFO, f"Student id is {id_value}")
    elif user.type == Constants.DB_USER_TYPE_COUNSELOR.value:
        assert found_counselor == True
        log_trace(logging.INFO, f"Counselor id is {id_value}")


def test_student_target_school_comment(auth_token):
    headers = generate_auth_header(auth_token=auth_token)

    # Create users
    student_info = create_student_user(headers=headers)
    user_id = student_info["user_id"]
    student_id = student_info["student_id"]

    # Create dummy career
    career_id = add_dummy_career(headers=headers)

    # Create a dummy college and save it
    college_name_1 = "College123" + random.choice(string.ascii_letters)
    user_data = schemas.StudentTargetSchoolCreate(
        student_id=student_id,
        career_id=career_id,
        college_name=college_name_1,
        tution_fees="10000",
        probability_of_admission="low",
        positives=["pos1", "pos2"],
        negatives=["neg1", "neg2", "neg3"],
        classification='Safety',
        acceptance_rate='66.6',
        why_this_recommendation="Blah blah blah")
    user_data_dict = user_data.__dict__
    print(user_data_dict)
    response = db_client.post("/db/users/students/targetschools/add/", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    student_target_school = response.json()

    # create student career comment
    student_targeted_school_comment_data = {
        "user_id": user_id,
        "target_school_id": student_target_school["id"],
        "content": "Test Comment",
        "date_published": "2024-07-26T05:48:00.774Z"
    }
    response = db_client.post("/db/users/students/targetschools/comment/create", json=student_targeted_school_comment_data, headers=headers)
    assert response.status_code == 200
    created_comment = response.json()
    assert created_comment["user_id"] == user_id
    assert created_comment["target_school_id"] == student_target_school["id"]

    # Get student career comment
    response = db_client.get(f"/db/users/students/targetschools/comments/{student_target_school['id']}", headers=headers)
    assert response.status_code == 200
    fetched_comment = response.json()
    assert len(fetched_comment) > 0
    assert fetched_comment[0]["target_school_id"] == student_target_school["id"]


####### JOBS TESTS ################

def create_job_helper(title=None, organization=None):
    fake = Faker()
    job_data = schemas.JobCreate(
        title=title if title else fake.job(),
        organization=organization if organization else fake.company(),
        deadline=fake.date(),
        area=[fake.word() for _ in range(3)],
        age=[str(fake.random_int(min=18, max=65)) for _ in range(3)],
        season=["Summer"],
        eligibility=[fake.sentence()],
        description=fake.text(),
        requirements=fake.text(),
        mode=["Remote"],
        location=[fake.city()],
        address=fake.address(),
        salary=str(fake.random_int(min=50000, max=150000)),
        program_fee=str(fake.random_int(min=0, max=10000)),
        keywords=fake.words(nb=5),
        link=fake.url(),
        listing_type=["Full-time"],
        is_priority=False
    )
    return job_data

def test_create_job(auth_token):
    headers = generate_auth_header(auth_token)
    job_data = create_job_helper()
    response = db_client.post("/db/jobs/create", json=job_data.model_dump(), headers=headers)
    assert response.status_code == 200
    output = response.json()
    assert "id" in output; assert output["title"] == job_data.title; assert output["organization"] == job_data.organization
    assert output["deadline"] == job_data.deadline; assert output["area"] == job_data.area; assert output["age"] == job_data.age
    assert output["season"] == job_data.season; assert output["eligibility"] == job_data.eligibility; assert output["description"] == job_data.description
    assert output["requirements"] == job_data.requirements; assert output["mode"] == job_data.mode; assert output["location"] == job_data.location
    assert output["address"] == job_data.address; assert output["salary"] == job_data.salary; assert output["program_fee"] == job_data.program_fee
    assert output["keywords"] == job_data.keywords; assert output["link"] == job_data.link; assert output["listing_type"] == job_data.listing_type

def test_get_jobs(auth_token):
    headers = generate_auth_header(auth_token)
    response = db_client.get("/db/jobs/get?page_num=1&limit=10", headers=headers)
    if response.status_code != 200:
        print(response.json())
    assert response.status_code == 200
    
    output = response.json()
    
    # Check that the output has the expected structure
    assert "message" in output
    assert "data" in output
    assert "statusCode" in output
    assert "error" in output

    data = output["data"]
    assert "result" in data
    assert "pageNo" in data
    assert "limit" in data
    assert "totalData" in data

    # Check that result is a list
    assert isinstance(data["result"], list)
    
    # Check that the number of jobs in the result does not exceed the limit
    assert len(data["result"]) <= 10
    
    # Check the fields of each job in the result
    for job in data["result"]:
        assert "id" in job
        assert "title" in job
        assert "organization" in job
        assert "deadline" in job
        assert "area" in job
        assert "age" in job
        assert "season" in job
        assert "eligibility" in job
        assert "description" in job
        assert "requirements" in job
        assert "mode" in job
        assert "location" in job
        assert "address" in job
        assert "salary" in job
        assert "program_fee" in job
        assert "keywords" in job
        assert "link" in job
        assert "listing_type" in job


def test_delete_job(auth_token):
    headers = generate_auth_header(auth_token)
    
    # Create a job first
    job_data = create_job_helper()
    response = db_client.post("/db/jobs/create", json=job_data.model_dump(), headers=headers)
    assert response.status_code == 200, f"Job creation failed: {response.text}"
    created_job = response.json()
    job_id = created_job.get("id")
    assert job_id is not None, "Job ID is None after creation"

    # Delete the job
    response = db_client.delete(f"/db/jobs/delete/{job_id}", headers=headers)
    assert response.status_code == 200, f"Job deletion failed: {response.text}"
    deleted_job = response.json()
    assert deleted_job["id"] == job_id, f"Deleted job ID mismatch: {deleted_job['id']} != {job_id}"

    # Verify the job is deleted by getting the job list
    response = db_client.get("/db/jobs/get?page_num=1&limit=10", headers=headers)
    assert response.status_code == 200, f"Failed to get jobs: {response.text}"
    jobs = response.json()["data"]["result"]

    found_job = None
    for job in jobs:
        if job["id"] == job_id:
            found_job = job
            break

    assert found_job is None, f"Deleted job found in job list: {jobs}"

def test_update_job(auth_token):
    headers = generate_auth_header(auth_token)
    
    # Create a job
    job_data = create_job_helper()
    response = db_client.post("/db/jobs/create", json=job_data.model_dump(), headers=headers)
    assert response.status_code == 200, f"Job creation failed: {response.text}"
    created_job = response.json()
    job_id = created_job.get("id")
    
    # Update two fields
    update_data = {
        "title": "Updated Job Title",
        "organization": "Updated Organization"
    }

    response = db_client.put(f"/db/jobs/update/{job_id}", json=update_data, headers=headers)
    assert response.status_code == 200, f"Job update failed: {response.text}"
    updated_job = response.json()
    assert updated_job["title"] == update_data["title"], f"Job title was not updated: {updated_job}"
    assert updated_job["organization"] == update_data["organization"], f"Job organization was not updated: {updated_job}"

def test_search_jobs(auth_token):
    headers = generate_auth_header(auth_token)

    # Create jobs to search
    job_data_1 = create_job_helper(title="Software Engineer", organization="Tech Corp")
    job_data_2 = create_job_helper(title="Data Scientist", organization="Data Inc")
    response = db_client.post("/db/jobs/create", json=job_data_1.model_dump(), headers=headers)
    assert response.status_code == 200, f"Job creation failed: {response.text}"
    response = db_client.post("/db/jobs/create", json=job_data_2.model_dump(), headers=headers)
    assert response.status_code == 200, f"Job creation failed: {response.text}"

    # Search for jobs by title
    response = db_client.get("/db/jobs/search?filter_by=title&query=Software Engineer&page_num=1&limit=10", headers=headers)
    assert response.status_code == 200, f"Job search failed: {response.text}"
    search_results = response.json()
    assert len(search_results) > 0, "No jobs found for the search query"
    assert search_results[0]["title"] == "Software Engineer", f"Expected title 'Software Engineer', but got {search_results[0]['title']}"

    # Search for jobs by organization
    response = db_client.get("/db/jobs/search?filter_by=organization&query=Data Inc&page_num=1&limit=10", headers=headers)
    assert response.status_code == 200, f"Job search failed: {response.text}"
    search_results = response.json()
    assert len(search_results) > 0, "No jobs found for the search query"
    assert search_results[0]["organization"] == "Data Inc", f"Expected organization 'Data Inc', but got {search_results[0]['organization']}"

def test_bookmark_and_remove_job(auth_token):
    headers = generate_auth_header(auth_token)
    
    # Create a job 
    job_data = create_job_helper()
    response = db_client.post("/db/jobs/create", json=job_data.model_dump(), headers=headers)
    assert response.status_code == 200, f"Job creation failed: {response.text}"
    created_job = response.json()
    job_id = created_job.get("id")
    assert job_id is not None, "Job ID is None after creation"

    # Bookmark the job
    bookmark_data = {
        "user_id": 1, 
        "job_id": job_id
    }
    response = db_client.post("/db/jobs/bookmark", json=bookmark_data, headers=headers)
    assert response.status_code == 200, f"Job bookmarking failed: {response.text}"
    bookmarked_job = response.json()
    assert bookmarked_job["job_id"] == job_id, f"Bookmarked job ID mismatch: {bookmarked_job['job_id']} != {job_id}"

    # Get bookmarked jobs for user_id 1
    response = db_client.get("/db/users/1/bookmarks?page_num=1&limit=10", headers=headers)
    assert response.status_code == 200, f"Get bookmarked jobs failed: {response.text}"
    bookmarked_jobs = response.json()
    assert len(bookmarked_jobs) > 0, "No bookmarked jobs found"
    assert "id" in bookmarked_jobs["data"]["result"][0], "Job ID missing in bookmarked job"

    # Remove the bookmark
    response = db_client.delete(f"/db/jobs/bookmark?user_id=1&job_id={job_id}", headers=headers)
    assert response.status_code == 200, f"Job bookmark removal failed: {response.text}"
    removed_bookmark = response.json()
    assert removed_bookmark["job_id"] == job_id, f"Removed bookmark job ID mismatch: {removed_bookmark['job_id']} != {job_id}"

    # Verify the bookmark is removed
    response = db_client.get("/db/users/1/bookmarks?page_num=1&limit=10", headers=headers)
    assert response.status_code == 200, f"Get bookmarked jobs failed: {response.text}"
    bookmarked_jobs = response.json()
    assert all(job["id"] != job_id for job in bookmarked_jobs["data"]["result"]), "Job ID found in bookmarks after removal"


# Add new tests for counselor-student connections
# Add a test for testing the endpoint to add a counselor
def test_counselor_add(auth_token):
    headers = generate_auth_header(auth_token)
    # Create a dummy user
    user_data_dict = create_user_helper(user_type="counselor")
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name

    # get counselor id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/counselors/get/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    assert output["user_id"] == user_id

    # now delete the counselor
    response = db_client.delete(f"/db/users/delete/id/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    assert "User Deleted" in output["message"]  # Validate message

    # now try to get the counselor again
    response = db_client.get(f"/db/users/counselors/get/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    assert output == None


# Test counselor connect with student
def test_counselor_connect_with_student(auth_token):
    headers = generate_auth_header(auth_token)
    # Create a dummy user
    user_data_dict = create_user_helper(user_type="counselor")
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name

    # get counselor id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/counselors/get/{user_id}", headers=headers)
    assert response.status_code == 200
    counselor = response.json()

    # Test Student Accept request
    student_1_details = create_student_user(headers=headers)
    response = db_client.get(f"/db/users/get/user_id/{student_1_details['user_id']}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_1 = output["data"]

    payload_1 = {
        "counselor_id": counselor["id"],
        "student_details": [
            {
                "student_name": student_1["first_name"],
                "student_email": student_1["email"],
                "parent_email": student_1["parent_email"],
            }
        ]
    }
    response = db_client.post("/db/counselor/connect-with-students", json=payload_1, headers=headers)
    assert response.status_code == 200

    payload_1 = {"counselor_id": counselor["id"], "student_email": student_1["email"]}
    response = db_client.get("/db/counselor/get-connect-with-student-status", params=payload_1, headers=headers)
    assert response.status_code == 200
    conn_req = response.json()

    encoded_str = ses_utils.create_encoded_string(
        conn_req["counselor_id"],
        conn_req["counselor_name"],
        conn_req["counselor_email"],
        conn_req["student_name"],
        conn_req["student_email"],
        conn_req["parent_email"],
        str(uuid.uuid4()),
    )

    payload_1 = {
        "token": conn_req["token"],
        "val": encoded_str,
        "approved": True
    }
    response = db_client.get("/webhooks/approve_request", params=payload_1, headers=headers)
    assert response.status_code == 200

    # Test Student Reject request
    student_2_details = create_student_user(headers=headers)
    response = db_client.get(f"/db/users/get/user_id/{student_2_details['user_id']}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_2 = output["data"]

    payload_2 = {
        "counselor_id": counselor["id"],
        "student_details": [
            {
                "student_name": student_2["first_name"],
                "student_email": student_2["email"],
                "parent_email": student_2["parent_email"]
            }
        ]
    }
    response = db_client.post("/db/counselor/connect-with-students", json=payload_2, headers=headers)
    assert response.status_code == 200

    payload_2 = {"counselor_id": counselor["id"], "student_email": student_2["email"]}
    response = db_client.get("/db/counselor/get-connect-with-student-status", params=payload_2, headers=headers)
    assert response.status_code == 200
    conn_req = response.json()

    encoded_str = ses_utils.create_encoded_string(
        conn_req["counselor_id"],
        conn_req["counselor_name"],
        conn_req["counselor_email"],
        conn_req["student_name"],
        conn_req["student_email"],
        conn_req["parent_email"],
        str(uuid.uuid4()),
    )

    payload_2 = {
        "token": conn_req["token"],
        "val": encoded_str,
        "approved": True
    }
    response = db_client.get("/webhooks/approve_request", params=payload_2, headers=headers)
    assert response.status_code == 200

def test_counselor_get_students(auth_token):
    headers = generate_auth_header(auth_token)
    # Create a dummy user
    user_data_dict = create_user_helper(user_type="counselor")
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name

    # get counselor id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/counselors/get/{user_id}", headers=headers)
    assert response.status_code == 200
    counselor = response.json()

    # Test Student Accept request
    student_1_details = create_student_user(headers=headers)
    response = db_client.get(f"/db/users/get/user_id/{student_1_details['user_id']}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_1 = output["data"]

    payload_1 = {
        "counselor_id": counselor["id"],
        "student_details": [
            {
                "student_name": student_1["first_name"],
                "student_email": student_1["email"],
                "parent_email": student_1["parent_email"],
            }
        ]
    }
    response = db_client.post("/db/counselor/connect-with-students", json=payload_1, headers=headers)
    assert response.status_code == 200

    payload_1 = {"counselor_id": counselor["id"], "student_email": student_1["email"]}
    response = db_client.get("/db/counselor/get-connect-with-student-status", params=payload_1, headers=headers)
    assert response.status_code == 200
    conn_req = response.json()

    encoded_str = ses_utils.create_encoded_string(
        conn_req["counselor_id"],
        conn_req["counselor_name"],
        conn_req["counselor_email"],
        conn_req["student_name"],
        conn_req["student_email"],
        conn_req["parent_email"],
        str(uuid.uuid4()),
    )

    payload_1 ={
        "token": conn_req["token"],
        "val": encoded_str,
        "approved": True
    }
    response = db_client.get("/webhooks/approve_request", params=payload_1, headers=headers)
    assert response.status_code == 200

    # Get students for this counselor
    response = db_client.get(f"/db/counselor/get-student-users/cid/{counselor['id']}", headers=headers)
    assert response.status_code == 200
    students = response.json()
    assert len(students) == 1
    assert students[0]["first_name"] == student_1["first_name"]
    assert students[0]["email"] == student_1["email"]
    assert students[0]["parent_email"] == student_1["parent_email"]

def test_counselor_remove_student(auth_token):
    headers = generate_auth_header(auth_token)
    # Create a dummy user
    user_data_dict = create_user_helper(user_type="counselor")
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name

    # get counselor id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/counselors/get/{user_id}", headers=headers)
    assert response.status_code == 200
    counselor = response.json()

    # Test Student Accept request
    student_1_details = create_student_user(headers=headers)
    response = db_client.get(f"/db/users/get/user_id/{student_1_details['user_id']}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_1 = output["data"]

    payload_1 = {
        "counselor_id": counselor["id"],
        "student_details": [
            {
                "student_name": student_1["first_name"],
                "student_email": student_1["email"],
                "parent_email": student_1["parent_email"],
            }
        ]
    }
    response = db_client.post("/db/counselor/connect-with-students", json=payload_1, headers=headers)
    assert response.status_code == 200

    payload_1 = {"counselor_id": counselor["id"], "student_email": student_1["email"]}
    response = db_client.get("/db/counselor/get-connect-with-student-status", params=payload_1, headers=headers)
    assert response.status_code == 200
    conn_req = response.json()

    encoded_str = ses_utils.create_encoded_string(
        conn_req["counselor_id"],
        conn_req["counselor_name"],
        conn_req["counselor_email"],
        conn_req["student_name"],
        conn_req["student_email"],
        conn_req["parent_email"],
        str(uuid.uuid4()),
    )

    payload_1 = {
        "token": conn_req["token"],
        "val": encoded_str,
        "approved": True
    }
    response = db_client.get("/webhooks/approve_request", params=payload_1, headers=headers)
    assert response.status_code == 200

    # Get students for this counselor
    response = db_client.get(f"/db/counselor/get-student-users/cid/{counselor['id']}", headers=headers)
    assert response.status_code == 200
    students = response.json()
    assert len(students) == 1
    assert students[0]["first_name"] == student_1["first_name"]
    assert students[0]["email"] == student_1["email"]
    
    # Get student id from user id
    response = db_client.get(f"/db/users/students/get/{student_1['id']}", headers=headers)
    assert response.status_code == 200
    student = response.json()
    id = student["id"]

    # Remove student
    response = db_client.delete(f"/db/counselor/remove-student/cid/{counselor['id']}/student-id/{id}", headers=headers)
    assert response.status_code == 200

    # Get students for this counselor
    response = db_client.get(f"/db/counselor/get-student-users/cid/{counselor['id']}", headers=headers)
    assert response.status_code == 200
    students = response.json()
    assert len(students) == 0

def test_counselor_get_student_requests(auth_token):
    headers = generate_auth_header(auth_token)
    # Create a dummy user
    user_data_dict = create_user_helper(user_type="counselor")
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name

    # get counselor id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/counselors/get/{user_id}", headers=headers)
    assert response.status_code == 200
    counselor = response.json()

    # Test Student Accept request
    student_1_details = create_student_user(headers=headers)
    response = db_client.get(f"/db/users/get/user_id/{student_1_details['user_id']}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_1 = output["data"]

    payload_1 = {
        "counselor_id": counselor["id"],
        "student_details": [
            {
                "student_name": student_1["first_name"],
                "student_email": student_1["email"],
                "parent_email": student_1["parent_email"],
            }
        ]
    }
    response = db_client.post("/db/counselor/connect-with-students", json=payload_1, headers=headers)
    assert response.status_code == 200

    payload_1 = {"counselor_id": counselor["id"], "student_email": student_1["email"]}
    response = db_client.get("/db/counselor/get-connect-with-student-status", params=payload_1, headers=headers)
    assert response.status_code == 200
    conn_req = response.json()
    log_trace(logging.INFO, conn_req)
    assert conn_req["first_name"] == student_1["first_name"]
    assert conn_req["email"] == student_1["email"]
    assert conn_req["status"] == "Pending"

    encoded_str = ses_utils.create_encoded_string(
        conn_req["counselor_id"],
        conn_req["counselor_name"],
        conn_req["counselor_email"],
        conn_req["student_name"],
        conn_req["student_email"],
        conn_req["parent_email"],
        str(uuid.uuid4()),
    )

    payload_1 = {
        "token": conn_req["token"],
        "val": encoded_str,
        "approved": True
    }

    response = db_client.get("/webhooks/approve_request", params=payload_1, headers=headers)
    assert response.status_code == 200

    # Get student requests for this counselor
    response = db_client.get(f"/db/counselor/get-connect-with-students-status/{counselor['id']}", headers=headers)
    assert response.status_code == 200
    requests = response.json()
    assert len(requests) == 1
    assert requests[0]["first_name"] == student_1["first_name"]
    assert requests[0]["email"] == student_1["email"]
    assert requests[0]["status"] == "Connected"

def test_user_create_is_minor(auth_token):
    headers = generate_auth_header(auth_token)
    # Add a student user whos a minor
    user_data_dict = create_user_helper()
    assert(user_data_dict["is_minor"] == False)
    user_data_dict["birthdate"] = "2008-01-01"
    log_trace(logging.INFO, user_data_dict)
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Message is {output['message']}")

    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name
    assert user["is_minor"] == False  # Validate user has been marked a minor

    # get student id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/students/get/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_id = output["id"]
    uid = output["user_id"]
    assert(uid == user_id)
    log_trace(logging.INFO, f"Student id is {student_id}")

    ##############################################################
    # Redo the same test but with the newer form of user info data
    ##############################################################
    user_data_dict = create_user_helper_new()
    assert(user_data_dict["is_minor"] == True)
    log_trace(logging.INFO, user_data_dict)
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    
    output = response.json()
    log_trace(logging.INFO, f"Message is {output['message']}")

    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name
    assert user["is_minor"] == True  # Validate user has been marked a minor

    # get student id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/students/get/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_id = output["id"]
    uid = output["user_id"]
    assert(uid == user_id)
    log_trace(logging.INFO, f"Student id is {student_id}")

    # Redo the same test but with the newer form of user info data
    user_data_dict = create_user_helper_new()
    user_data_dict["is_minor"] = False
    log_trace(logging.INFO, user_data_dict)
    response = db_client.post("/db/users/create", json=user_data_dict, headers=headers)  # Simulate a request to your endpoint
    assert response.status_code == 200
    
    output = response.json()
    log_trace(logging.INFO, f"Message is {output['message']}")

    assert "created successfully" in output["message"]  # Validate message
    assert "data" in output  # Check if data is present in the response
    user = output["data"]
    assert user["first_name"] == user_data_dict["first_name"]  # Validate user name
    assert user["is_minor"] == False  # Validate user is still marked as not a minor

    # get student id for this new user
    user_id = user["id"]
    response = db_client.get(f"/db/users/students/get/{user_id}", headers=headers)
    assert response.status_code == 200
    output = response.json()
    student_id = output["id"]
    uid = output["user_id"]
    assert(uid == user_id)
    log_trace(logging.INFO, f"Student id is {student_id}")


if __name__ == "__main__":
    auth_token = os.environ.get("TEST_AUTH_TOKEN")
    if auth_token is None or auth_token == "":
        log_trace(logging.INFO, "Please set the TEST_AUTH_TOKEN environment variable to a valid auth token. Exiting.")
        exit(1)

    pytest.main()
