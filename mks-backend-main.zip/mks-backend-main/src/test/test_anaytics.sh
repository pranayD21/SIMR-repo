#!/bin/bash

# Function to run pytest with common arguments
run_pytest() {
    pytest --cache-clear "$1" -v -s
}



# Function to comment out all models except "groq"
comment_out_models() {
    echo "Commenting out all models except 'groq'..."
    sed -i 's/models = \[.*\]/models = ["groq"] #, "openai", "google", "pplx"]/' test_ai_services.py
}

# Run tests
echo "Running tests..."

run_pytest "test_db_services.py::test_create_user_function"
run_pytest "test_db_services.py::test_student_schools"
echo "Testing AI colleges with only 'groq' model..."
run_pytest "test_ai_services.py::test_ai_colleges"
run_pytest "test_ai_services.py::test_ai_colleges"
run_pytest "test_ai_services.py::test_ai_colleges"
run_pytest "test_db_services.py::test_college_recommendation"
run_pytest "test_db_services.py::test_delete_restore_user_function"

# Test student schools in all places where schools are updated
echo "Testing student schools in all update locations..."
run_pytest "test_db_services.py::test_student_schools"
# Add more test functions here for other places where schools are updated
# For example:
# run_pytest "test_db_services.py::test_update_student_schools"
# run_pytest "test_db_services.py::test_transfer_student_schools"

# Comment out all models except "groq"
comment_out_models()


echo "All tests completed."
