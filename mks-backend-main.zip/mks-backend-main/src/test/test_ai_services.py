import os
import sys
import pytest
from src.main import app
import random 
from src.db import schemas
from logger import log_trace, logging
from fastapi.testclient import TestClient

# Add the project root directory to the Python path
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))

# Test client for db services
# Added tests for the below endpoints:
# /ai/careers/{model} - refresh_results=true
# /ai/careers/{model} - refresh_results=false
# /ai/colleges/{model} - refresh_results=true
# /ai/colleges/{model} - refresh_results=false

# Fixture to generate an authentication token
@pytest.fixture(scope="session")
def auth_token():
    # Generate or fetch the authentication token here
    return os.environ.get("TEST_AUTH_TOKEN")  # Return the authentication token

def generate_auth_header(auth_token):
    headers = {
        "Authorization": f"Bearer {auth_token}"
    }
    return headers

# Test client for db services
ai_client = TestClient(app)  # Initialize TestClient with your FastAPI app
models = ["groq", "openai"] # "google", "pplx"]   #Commented Gemini and PPLX for now



def get_user_id(headers):
    response = ai_client.get(f"/db/users/get?skip=0&limit=100",headers=headers)
    output = response.json()
    # If we have users in the response, select a random one
    if output['data']:
        while True:
            random_user = random.choice(output['data'])
            if random_user['type'] == 'student':
                break

        if not random_user:
            log_trace(logging.INFO,"No students found")
            return None
        
        user_id = random_user['id']
        log_trace(logging.INFO,f"Randomly selected user ID: {user_id}")
        return user_id
    else:
        log_trace(logging.INFO,"No users found")
        return None


@pytest.mark.parametrize("model", models)
def test_ai_careers(auth_token, model):
    headers = generate_auth_header(auth_token)
  
    user_id = get_user_id(headers=headers)
    log_trace(logging.INFO, user_id)
    response = ai_client.post(f"/ai/careers/{model}?user_id={user_id}&refresh_results=true",
                              headers=headers)
    assert response.status_code == 200
    output = response.json()
    log_trace(logging.INFO, f"Error code {output['error']}")
    assert output["message"] == "Possible Careers Generated!"
    assert output["statusCode"] == 200

    # Parse results, save one career to the database
    careers = output["data"]
    career = careers[0]
    career_id = career["career_id"]
    career_name = career["career_name"]
    career_description = career["career_description"]
    career_outlook = career["career_outlook"]
    job_duties = career["job_duties"]
    skills = career["skills"]
    median_salary = career["median_salary"]
    majors = career["majors"]
    assert career_id is not None
    assert career_name is not None
    assert career_description is not None
    assert career_outlook is not None
    assert job_duties is not None
    assert skills is not None
    assert median_salary is not None
    assert majors is not None

    # Get student id for user
    response = ai_client.get(f"/db/users/students/get/{user_id}", headers=headers)
    assert response.status_code == 200
    student = response.json()
    assert student["user_id"] == user_id
    student_id = student["id"]
    assert student_id is not None

    # Save the career to the database
    # Create a studentcareercreate record
    student_career = schemas.StudentCareerCreate(
        student_id=student_id,
        career_id=career_id
    )
    response = ai_client.post("/db/users/students/careers/add/",
                              json=student_career.__dict__, headers=headers)
    assert response.status_code == 200
    #output = response.json()
    #assert output["message"] == "Student Career Added"
    #assert output["statusCode"] == 200

    # Get the student career
    response = ai_client.get(f"/db/users/students/careers/student_id/{student_id}", headers=headers)
    assert response.status_code == 200
    student_careers = response.json()
    assert len(student_careers) >= 1
    found_career = False
    for student_career in student_careers:
        #assert student_career["student_id"] == 1
        if student_career["career_id"] == career_id:
            found_career = True
    assert found_career

    # Get careers without refreshing results
    response = ai_client.post(f"/ai/careers/{model}?user_id={user_id}&refresh_results=false",
                              headers=headers)
    # ai/colleges/groq?user_id=1&career_id=4&num_colleges=5&tution_budget_per_year=10000&refresh_results=true'
    assert response.status_code == 200
    careers = response.json()
    #assert output["message"] == "Possible Careers Generated!"
    #assert output["statusCode"] == 200
    #careers = output["data"]
    
    log_trace(logging.INFO, f"Careers are: {careers}")
    found_career = False
    for career in careers:
        log_trace(logging.INFO, f"Career is {career}")
        if career["career_id"] == career_id:
            found_career = True
    assert found_career

@pytest.mark.parametrize("model", models)
def test_ai_colleges(auth_token, model):
     headers = generate_auth_header(auth_token)
     user_id = get_user_id(headers=headers)
     #TODO : query career dynamically form DB
     response = ai_client.post(
            f"/ai/colleges/{model}?user_id={user_id}&career_id=1&num_colleges=5&tution_budget_per_year=50000&refresh_results=true",
        headers=generate_auth_header(auth_token))
     assert response.status_code == 200


if __name__ == "__main__":
    auth_token = os.environ.get("TEST_AUTH_TOKEN")
    if auth_token is None or auth_token == "":
        log_trace(logging.INFO, "Please set the TEST_AUTH_TOKEN environment variable to a valid auth token. Exiting.")
        exit(1)
        
    pytest.main()
