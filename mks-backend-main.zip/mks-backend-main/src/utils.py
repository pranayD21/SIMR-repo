# Utility functions shared across modules
import logging
import re
import io
import os
from typing import Optional
import json
from fastapi import HTTPException, Header
from logger import log_trace
from reportlab.lib import colors
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, Image
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from pathlib import Path

# Assuming DABBL_HOME is an environment variable
DABBL_HOME = os.environ.get('DABBL_HOME')
if DABBL_HOME is None:
    DABBL_HOME = '/home/ubuntu/buddybot-server/mks-backend/src'
ASSETS_PATH = Path(DABBL_HOME) / 'assets'

def wrap_response(data=None, message="Success", code=200, error=None,page_num=None, limit=None, total_count=None):
    if not page_num:
        return {
        "message": message,
        "data": data,
        "code": code,
        "error": error
    }
    else:
        return {
            "message": message,
            "data":{
        "result": data,
        "pageNo":page_num,
        "limit": limit,
        "totalData":total_count
            },
        "code": code,
        "error": error,
        
        }

# Remove trailing and leading whitespaces, besides bullet points from an AI generated college name.
def clean_college_name(name):
    # Remove numbering at the start (e.g., "1. ")
    name = re.sub(r'^\d+\.\s*"', '', name)
    # Remove any leading and trailing quotation marks or whitespaces
    name = re.sub(r'^[\s"]+|[\s"]+$', '', name)
    return name

# Email addresses need to be normalized before we check for pre-existence.
def normalize_email(email: str):
    local_part, domain = email.lower().split('@')
    if domain == 'gmail.com':
        local_part = local_part.replace('.', '')
    return f"{local_part}@{domain}"

def preprocess_college_name(name:str):
    words_to_remove = ['university', 'college', 'institute', 'of', 'the', 'at', 'in']
    # Create a regex pattern with word boundaries
    pattern = r'\b(?:' + '|'.join(re.escape(word) for word in words_to_remove) + r')\b'
    log_trace(logging.INFO, "Input college name: {name}")
    # Remove the words and any surrounding whitespace
    name = re.sub(pattern, '', name, flags=re.IGNORECASE)
    
    # Remove any commas
    name = name.replace(',', '')
    # Remove extra whitespace
    name = re.sub(r'\s+', ' ', name).strip()
    log_trace(logging.INFO, "Output college name: {name}")
    return name

# To save essay review to the database, we need both the auth token and the identity token
# We pass the auth token in the header as a Bearer token, and the identity token in the header as a X-Identity-Token
async def get_identity_token(x_identity_token: Optional[str] = Header(None)):
    if x_identity_token is None:
        raise HTTPException(status_code=400, detail="X-Identity-Token header is missing")
    return x_identity_token

def get_fun_score(score):
    score = float(score)
    fun_scores = {
        range(0, 3): ('meh.png', 'Meh'),
        range(3, 6): ('not-bad.png', 'Not bad'),
        range(6, 9): ('awesome.png', 'Awesome'),
        range(9, 11): ('superstar.png', 'Superstar!')
    }
    
    def create_img_tag(img_name, text):
        img_path = ASSETS_PATH / img_name
        return f'<para><img src="{img_path}" width="10" height="10"/> {text}</para>'
    
    for score_range, (img_name, text) in fun_scores.items():
        if score in score_range:
            return create_img_tag(img_name, text)    
    return create_img_tag('off-the-charts.png', 'Off the charts!')

def create_formatted_pdf(prompt, essay, json_data):
    log_trace(logging.INFO, f"Creating formatted PDF, data: {json_data}")

    # Parse JSON data
    data = json.loads(json_data)

    # Create a buffer to store the PDF
    buffer = io.BytesIO()

    # Create PDF document
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []

    # Styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(name='CenteredTitle', parent=styles['Heading1'], alignment=TA_CENTER)
    header_style = styles['Heading2']
    normal_style = styles['Normal']
    styles['Normal'].fontName = 'Helvetica'

    # Add logo
    logo_path = ASSETS_PATH / 'logo.png'
    try:
        logo = Image(logo_path, width=80, height=80)  # Adjust width and height as needed
        elements.append(logo)
        elements.append(Spacer(1, 12))
    except Exception as e:
        log_trace(logging.ERROR, f"Error adding logo: {e}")

    # Add title
    elements.append(Paragraph("Essay Feedback", title_style))
    elements.append(Spacer(1, 12))

    elements.append(Paragraph("Prompt:", header_style))
    elements.append(Paragraph(prompt, normal_style))
    elements.append(Spacer(1, 12))

    # Add Essay subheading and value
    # Handle essay_value as either string or buffer
    if isinstance(essay, io.IOBase):
        essay_text = essay.getvalue().decode('utf-8')
    else:
        essay_text = essay
    elements.append(Paragraph("Essay:", header_style))
    elements.append(Paragraph(essay_text, normal_style))
    elements.append(Spacer(1, 12))

    # Create a table for each criterion
    for item in data:
        elements.append(Paragraph(item['criterion'], header_style))
        elements.append(Spacer(1, 6))
        fun_score = get_fun_score(int(item['score']))
        log_trace(logging.INFO, f"Fun score: {fun_score}")
        table_data = [
            ['Feedback', Paragraph(item['feedback'], styles['Normal'])],
            ['Score', Paragraph(fun_score, styles['Normal'])],
            ['Suggestions', Paragraph(item['suggestions'], styles['Normal'])]
        ]

        table = Table(table_data, colWidths=[100, 400])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), 0x98EECA),
            ('BACKGROUND', (0, 1), (0, -1), 0xFFDEAB),
            ('BACKGROUND', (0, 2), (0, -1), 0xFAA2E8),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 12),
            ('BOX', (0, 0), (-1, -1), 1, colors.black),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
        ]))

        elements.append(table)
        elements.append(Spacer(1, 12))

    # Add summary
    elements.append(Paragraph("Summary of Feedback", header_style))
    elements.append(Spacer(1, 6))

    summary = "Overall, the essay "
    total_score = sum(float(item['score']) for item in data)
    avg_score = total_score / len(data)
    log_trace(logging.INFO, f"Average score: {avg_score}")

    if avg_score >= 8:
        summary += "is excellent. "
    elif avg_score >= 6:
        summary += "is good but has room for improvement. "
    else:
        summary += "needs significant improvement. "

    summary += f"The average score is {avg_score:.1f} out of 10. "
    summary += "Key areas for improvement include: "
    summary += ", ".join(item['suggestions'] for item in data if item['suggestions'] != "N/A")

    elements.append(Paragraph(summary, normal_style))

    # Build PDF
    doc.build(elements)
    # Reset buffer position to the beginning
    buffer.seek(0)
    
    return buffer

def create_lor_formatted_pdf(student_name, school, college, json_data):
    log_trace(logging.INFO, f"Creating formatted PDF, data: {json_data}")

    # Parse JSON data
    data = json.loads(json_data)
    # Create a buffer to store the PDF
    buffer = io.BytesIO()
    # Create PDF document
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    elements = []

    # Styles
    styles = getSampleStyleSheet()
    title_style = ParagraphStyle(name='CenteredTitle', parent=styles['Heading1'], alignment=TA_CENTER)
    header_style = styles['Heading2']
    normal_style = styles['Normal']
    styles['Normal'].fontName = 'Helvetica'

    # Add logo
    logo_path = ASSETS_PATH / 'logo.png'
    try:
        logo = Image(logo_path, width=60, height=60)  # Adjust width and height as needed
        elements.append(logo)
        elements.append(Spacer(1, 12))
    except Exception as e:
        log_trace(logging.ERROR, f"Error adding logo: {e}")

    log_trace(logging.INFO, f"Student name: {student_name}")

    # Add title
    elements.append(Paragraph("Letter of recommendation", title_style))
    elements.append(Spacer(1, 12))

    elements.append(Paragraph("Confidential Counselor Letter of Recommendation", header_style))
    elements.append(Paragraph("Student:", header_style))
    elements.append(Paragraph(student_name, normal_style))
    elements.append(Spacer(1, 12))

    log_trace(logging.INFO, f"Adding school to PDF: {school}")
    # Add School subheading
    elements.append(Paragraph("High School:", header_style))
    elements.append(Paragraph(school, normal_style))
    elements.append(Spacer(1, 12))

    log_trace(logging.INFO, f"Adding college to PDF: {college}")
    # Add college subheading
    elements.append(Paragraph("College or University:", header_style))
    elements.append(Paragraph(college, normal_style))
    elements.append(Spacer(1, 12))

    # Set strengths to '' if data['strengths'] is missing
    log_trace(logging.INFO, f"Adding data to PDF: {data}")

    personality = data['personality'] if data['personality'] else ''
    log_trace(logging.INFO, f"Personality: {personality}")
    # Concatenate strengths and areas_of_improvement to a single string
    if isinstance(personality, str):
        personality_str = personality
    else:
        personality_str = ', '.join(personality)
    log_trace(logging.INFO, f"Personality: {personality_str}")

    academic_strengths = data['academic strengths'] if data['academic strengths'] else ''
    log_trace(logging.INFO, f"Strengths: {academic_strengths}")
    # Concatenate strengths and areas_of_improvement to a single string
    if isinstance(academic_strengths, str):
        strengths_str = academic_strengths
    else:
        strengths_str = ', '.join(academic_strengths)
    log_trace(logging.INFO, f"Strengths: {strengths_str}")

    areas_of_improvement = data['areas of improvement'] if data['areas of improvement'] else ''
    if isinstance(areas_of_improvement, str):
        areas_of_improvement_str = areas_of_improvement
    else:
        areas_of_improvement_str = ', '.join(areas_of_improvement)
    log_trace(logging.INFO, f"Areas of improvement: {areas_of_improvement_str}")

    summary = data['summary'] if data['summary'] else ''
    if isinstance(summary, str):
        summary_str = summary
    else:
        summary_str = ', '.join(summary)
    log_trace(logging.INFO, f"Summary: {summary_str}")

    log_trace(logging.INFO, f"Adding data to PDF: {personality_str}")
    elements.append(Paragraph("Personality:", header_style))
    elements.append(Paragraph(personality_str, normal_style))
    elements.append(Spacer(1, 12))

    log_trace(logging.INFO, f"Adding data to PDF: {strengths_str}")
    elements.append(Paragraph("Strengths:", header_style))
    elements.append(Paragraph(strengths_str, normal_style))
    elements.append(Spacer(1, 12))

    log_trace(logging.INFO, f"Adding data to PDF: {areas_of_improvement_str}")
    elements.append(Paragraph("Areas of Improvement:", header_style))
    elements.append(Paragraph(areas_of_improvement_str, normal_style))
    elements.append(Spacer(1, 12))

    log_trace(logging.INFO, f"Adding data to PDF: {summary_str}")
    elements.append(Paragraph("Summary:", header_style))
    elements.append(Paragraph(summary_str, normal_style))
    elements.append(Spacer(1, 12))

    # Build PDF
    doc.build(elements)
    # Reset buffer position to the beginning
    buffer.seek(0)
    return buffer
