import base64
import json
import boto3
import os
from dotenv import load_dotenv, find_dotenv
from webhooks import schemas

_ = load_dotenv(find_dotenv())

def init_ses_client():
    ses_client = boto3.client('ses',
                            aws_access_key_id=os.environ['AWS_ACCESS_KEY'],
                            aws_secret_access_key=os.environ['AWS_SECRET_KEY'],
                            region_name=os.environ['APP_REGION'])
    return ses_client

def create_encoded_string(counselor_id: str,
                          counselor_name: str,
                          counselor_email: str,
                          student_name: str, 
                          student_email: str,
                          parent_email: str,
                          request_id: str):
    data = {
        "counselor_id": counselor_id,
        "counselor_name": counselor_name,
        "counselor_email": counselor_email,
        "student_name": student_name,
        "student_email": student_email,
        "parent_email": parent_email,
        "request_id": request_id
    }
    json_data = json.dumps(data)
    encoded_string = base64.urlsafe_b64encode(json_data.encode()).decode()
    return encoded_string

def decode_encoded_string(encoded_string: str):
    # Decode the data
    try:
        json_data = base64.urlsafe_b64decode(encoded_string).decode()
        decoded_data = json.loads(json_data)
    except (ValueError, json.JSONDecodeError):
        print("Error decoding the string")
        return None

    req_data = schemas.RequestData(
        counselor_id = decoded_data.get('counselor_id'),
        counselor_name = decoded_data.get('counselor_name'),
        counselor_email = decoded_data.get('counselor_email'),
        student_name = decoded_data.get('student_name'),
        student_email = decoded_data.get('student_email'),
        parent_email = decoded_data.get('parent_email'),
        request_id = decoded_data.get('request_id')
    )
    return req_data

ses_client = init_ses_client()