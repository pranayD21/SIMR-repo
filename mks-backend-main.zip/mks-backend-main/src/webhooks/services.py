import secrets
from aiohttp import ClientError
from fastapi.responses import JSONResponse
from fastapi import Depends, HTTPException, APIRouter, Request
from sqlalchemy.orm import Session
from db import Constants, crud as dbcrud, schemas as dbschemas
from db.database import SessionLocal
from logger import log_trace, logging
from webhooks.ses_utils import ses_client
from db.notification_handler import NotificationHandler
from . import schemas
from . import ses_utils
from datetime import datetime, timezone


__package__ = "src.webhooks"

router = APIRouter(
    prefix="/webhooks",
    tags=["webhooks"],
    # dependencies=[Depends(get_token_header)],
    responses={404: {"description": "Not found"}},
)


# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def send_approval_request_email(url: str, recipient_email: str):
    # Send email with webhook link using AWS SES
    response = ""
    log_trace(logging.INFO, "Sending approval request")
    try:
        # Define the HTML and plain text versions of the email
        html_content = Constants.PARENT_APPROVAL_HTML_CONTENT.value.format(logo_url=Constants.DABBL_LOGO_NEW.value, url=url)
        plain_text_content = Constants.PARENT_APPROVAL_TEXT_CONTENT.value.format(url=url)
        log_trace(logging.INFO, f"html content: {html_content}")
        response = ses_client.send_email(
            Source="hello@go-dabbl.ai",  # approval_request.counselor_email,
            Destination={
                "ToAddresses": [recipient_email],
                "CcAddresses": [],
                "BccAddresses": [],
            },
            Message={
                'Subject': {
                    'Data': 'Parental Approval Request',
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': plain_text_content,
                        'Charset': 'UTF-8'
                    },
                    'Html': {
                        'Data': html_content,
                        'Charset': 'UTF-8'
                    }
                }
            }
        )
    except ClientError as e:
        log_trace(logging.ERROR, e.response["Error"]["Message"])
        return JSONResponse(status_code=500, content={"message": "Error sending email"})

    log_trace(logging.INFO, f"Response is {response}")
    return response


async def reconcile_approval_response(db: Session, response: schemas.ApprovalRequest):
    # Decode the string and then process the response
    req_data = ses_utils.decode_encoded_string(response.request_data)

    counselor = dbcrud.get_counselor_by_id(db, req_data.counselor_id)
    counselor_user = dbcrud.get_user(db, counselor["user_id"])
    student = dbcrud.get_user_by_username_or_email(db, email=req_data.student_email, username=None)

    # Update database or perform other actions based on the response
    log_trace(
        logging.INFO,
        f"Reconciled response: {req_data.request_id} - {response.approved} - {req_data.student_email}",
    )

    # Validate token
    is_valid = dbcrud.validate_approval_response_token(db, response.token)
    if not is_valid:
        log_trace(logging.ERROR, f"Token {response.token} is invalid")
        raise HTTPException(
            status_code=400, detail="Counselor connect request to student failed"
        )

    if response.approved:
        log_trace(logging.INFO, f"Approving request")

        result = dbcrud.update_counselor_connection_request(
            db, req_data.counselor_id, response.token, response.approved
        )
        if not result:
            raise HTTPException(
                status_code=400, detail="Counselor connect request to student failed"
            )

        notification_handler = NotificationHandler()
        notification_handler.create_notification(
                db=db,
                notification=dbschemas.NotificationCreate(
                    user_id=counselor["user_id"],
                    title="Connection Request Accepted",
                    message=f"{student.username} accepted your connection request",
                    send_time=datetime.now(timezone.utc),
                    type="connection_accepted",
                    data=None
                    )
            )
        notification_handler.create_notification(
                db=db,
                notification=dbschemas.NotificationCreate(
                    user_id=student.id,
                    title="New Connection",
                    message=f"You are now connected with {counselor_user.username}",
                    type="connection_accepted",
                    send_time=datetime.now(timezone.utc),
                    data=None
                    )
            )

        return JSONResponse(
            status_code=200,
            content={"message": "Counselor connected with student successfully"},
        )

    # reject connection request
    log_trace(logging.INFO, f"Rejecting request")

    result = dbcrud.update_counselor_connection_request(
        db, req_data.counselor_id, response.token, response.approved
    )
    if not result:
        raise HTTPException(
            status_code=400, detail="Counselor connect request to student failed"
        )

    return JSONResponse(
        status_code=200,
        content={
            "message": "Student rejected counselor connection request successfully"
        },
    )


@router.get("/approve_request/")
async def webhook(token: str, val: str, approved: bool, db: Session = Depends(get_db)):
    # Handle webhook callback
    response = schemas.ApprovalRequest(token=token, request_data=val, approved=approved)
    await reconcile_approval_response(db, response)
    return JSONResponse(status_code=200, content={"message": "Webhook received"})
