from pydantic import BaseModel


class ApprovalRequest(BaseModel):
    token: str
    request_data: str
    approved: bool


class RequestData(BaseModel):
    counselor_id: int
    counselor_name: str
    counselor_email: str
    student_name: str
    student_email: str
    parent_email: str
    request_id: str
