# app-ai-services
A fast API based python service to connect and interact with OpenAI

To install the App (python>=3.8), run
```pip install -r requirements.txt```

Either add the OPENAI_API_KEY in a .env file for local dev/testing or have the key available in the environment that you are running the serivce.
Set the env for DB_URL - setup postgres, pgadmin tool on local machine. Start the db. Set DB_URL to the db server.

Run the below command to start the app

```uvicorn main:app --reload --port 8001```

Backend Setup Instructions:

AWS Cognito commands:

$> aws configure (for setting up cli)

$> aws cognito-idp admin-set-user-password --user-pool-id <userpool id> --username <user>   --password "<password>" --region us-east-2

Install/upgrade python to 3.10+. https://www.freecodecamp.org/news/pip-upgrade-and-how-to-update-pip-and-python/
$> python3 –version

Should show the version is > 3.10.


Backend setup

Get the repo
$> git clone <http location to git repo for app-ai-services>

This will create a directory: app-ai-services in the current directory.

Change directory to the repo head.
$> cd app-ai-services

Create a virtual env for backend, call it dabbl-be-env:
$> python -m venv dabbl-be-env 

This creates a directory called dabbl-be-env in the current directory.

Source this venv:
$> source dabbl-be-env/bin/activate

Now your prompt should show the virtual environment name in it:
(dabbl-be-env) user@system app-ai-services % 

Now install the required packages in this venv.

$> pip3 install -r requirements.txt

This will install the packages listed in requirements.txt.


# ENVIRONMENT VARIABLES
# ====================

- export DB_URL="postgresql://postgres:postgres@localhost:5432/postgres"
- export DB_SERVER_URL="http://localhost:8001/db"
- export OPENAI_API_KEY="<openai api key>"
- export GOOGLE_API_KEY="<google vertex ai api>"
- export APP_CLIENT_ID="<aws app client id>"
- export APP_CLIENT_SECRET="<aws app client secret>"
- export APP_USER_POOL_NAME="<aws user pool name>"
- export APP_USER_POOL_ID="<aws user pool id>"
- export GROQ_API_KEY="<GROQ API KEY>"

- export FCM_SERVER_KEY_DEV=""
- export FCM_SERVER_KEY_PROD=""
- export FCM_SERVER_KEY_UAT=""
- export AWS_SERVER_BASE_URL_DEV=""
- export AWS_SERVER_BASE_URL_UAT=""
- export AWS_SERVER_BASE_URL_PROD=""
- export IDP_SERVER="https://cognito-idp.us-east-2.amazonaws.com/"

- export AWS_SERVER_PORT_DEV=xxxx
- export AWS_SERVER_PORT_PROD=xxxx
- export AWS_SERVER_PORT_UAT=xxxx
- export MIXPANEL_TOKEN="ade7d6a4c1c7dcf30ad23f86987c960"
- export AWS_S3_BUCKET_NAME=""
- export DABBL_ADMIN_EMAIL="dabbl@go-dabbl.ai"

- export APP_REGION=""
- export AWS_ACCESS_KEY=""
- export AWS_SECRET_KEY=""
- export S3_COLLEGE_DATA_KEY=""
- export S3_COLLEGE_PICS_BUCKET=""
- export DABBL_HOME=""

#  Test Environment Variables
- export REQUEST_TIMEOUT=30
- export TEST_AUTH_TOKEN=""
- export USE_MOCK_JWKS="true"



You can the values for the above from one of us: Sirisha or Madhu.

FOR POSTGRESQL SETUP
====================

1. Install postgresql
2. Create a postgres user on your system
3. Switch to the postgres user using "su - postgres"
4. Create the data directory to a dabbl dir. E.g. ~/dabbl_data/db1
   a) mkdir -p ~/dabbl_data/db1
   b) cd ~/dabbl_data/
   c) initdb db1
5. Start postgres now: pg_ctl -D ~/dabbl_data/db1 start

Make sure you have edited the config files for postgres (to accept only local connections etc).

Uvicorn Logging
===================
View/Change settings in ```src/logging.yaml```

Start uvicorn server with ```uvicorn main:app --reload --log-config=logging.yaml  --port 8002```

Steps for Testing Dev Changes
===============================================================

SERVER_PORT=8000

1. Define a `.env` file with the following variables:

    - `DB_URL="postgresql://postgres:@localhost:5432/postgres"`
    - `DB_SERVER_URL="http://localhost:<SERVER_PORT>/db"`
    - `REQUEST_TIMEOUT=30`
    - `TEST_AUTH_TOKEN = ??`
    - `USE_MOCK_JWKS="true"`
    - `OPENAI_API_KEY="<openai api key>"`
    - `GROQ_API_KEY="<GROQ API KEY>"`

2. Execute the scripts in `src/test/setup` folder:
    - `deploy_db.py` (Deploy Postgres database and populate with Mock data 
      (test/setup/mock_test_data.py can be executed independently to populate mock data))
    - `generate_jwt_token` (Copy the printed test token and assign to the `TEST_AUTH_TOKEN` environment variable)

3. Execute the Application server: `uvicorn main:app --reload --port <SERVER_PORT>`

4. Execute the following tests:
    - `pytest --cache-clear test_db_services.py -v -s` in the `src/test` folder for DB tests
    - `pytest --cache-clear test_ai_services.py -v -s` in the `src/test` folder for AI tests# app-ai-services
