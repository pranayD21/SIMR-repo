from typing import Dict, Any
from cognitojwt import CognitoJWTException, decode_async as cognito_jwt_decode
from fastapi.exceptions import HTTPException
from jose import JWTError
from pydantic_settings import BaseSettings
from starlette.requests import Request

token="eyJraWQiOiJpRW5oUUlFeUFZTVFyZUNEN2JOb1BzN0dLMU9DS3ZXeUo3XC9ZTnhnQ1haUT0iLCJhbGciOiJSUzI1NiJ9.eyJzdWIiOiI4ZGQ5OThkNS04Y2M5LTRhOWQtODFhMi04ZDk2NTdkMmJjNTAiLCJpc3MiOiJodHRwczpcL1wvY29nbml0by1pZHAudXMtZWFzdC0yLmFtYXpvbmF3cy5jb21cL3VzLWVhc3QtMl9hZXA5bEc2clgiLCJjbGllbnRfaWQiOiI2MmNzczI3Z2VpdGo0cmdnMTc3MWRlMDQ0bSIsIm9yaWdpbl9qdGkiOiIyMWU1OWI4NC05OWFhLTQwYjQtYTJkMC03NDEwOWU1Y2EzOTMiLCJldmVudF9pZCI6ImZhMTM3ZWM3LWJmMzQtNDVhMi1iZjJiLWYwMTcwM2NhOTNkOCIsInRva2VuX3VzZSI6ImFjY2VzcyIsInNjb3BlIjoiYXdzLmNvZ25pdG8uc2lnbmluLnVzZXIuYWRtaW4iLCJhdXRoX3RpbWUiOjE3MDQ0MjAxMzUsImV4cCI6MTcwNDQyMzczNSwiaWF0IjoxNzA0NDIwMTM1LCJqdGkiOiI2ZGMxZmEzNy00ZTY5LTQ1Y2YtODc1ZC1hNmYzYWE3ZTA1NDkiLCJ1c2VybmFtZSI6InNrYWlwYSJ9.W6RHeYG5Hf2a-E8jI7EpG8eZuLl7IMka0ODKvJjKZZrly4prXbRkLAsi5J6fjC-M9BZV89lUUpgkOqhUfA4yurQFxLNfU1Z0t-YjW14AZr4iHgxLD712FlGHTmRs7gea0NL3As9XSvJziAoSsCP35klVXqFtSBQjxQzHv-1xVnHhIvAYBYgZGbJxodp6B2xnpnMiOKXjoAIndi99xX5Pji8L16MquE1sHmhvfnJywB-R3MHQDxlkD0aCswOcG5kNCd7D_7rBvqi81_St-Dbhad4dMxed_l57dMQSvRJVduZYF0ESFImtJxZgTGptwRe8zXdpvWqqdh584CXb-NnFeA"

region = "us-east-2"
id = "us-east-2_aep9lG6rX"
app_id="62css27geitj4rgg1771de044m"

async def test_func():
  try:
    await cognito_jwt_decode(
                token=token,
                region=region,
                userpool_id=id,
                app_client_id=app_id,
                testmode=True
            )
  except TypeError:
     raise HTTPException(
                status_code=401,
                detail="Unable to get userpool key,"
                       " your userpool_id config might be incorrect."
            )
  except (ValueError, JWTError):
    raise HTTPException(
                status_code=401,
                detail="Malformed authentication token"
            )

test_func()
