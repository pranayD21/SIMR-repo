import requests
import pandas as pd
import os
from dotenv import find_dotenv, load_dotenv
import csv
import time
from cds_scraper import scrape_college_data


# Load environment variables
_ = load_dotenv(find_dotenv())


# Define the endpoint and parameters
endpoint = "https://api.data.gov/ed/collegescorecard/v1/schools"
api_key = os.environ["DATA_GOV_API_KEY"]  # You need to sign up for an API key at https://api.data.gov/signup/
PER_PAGE = 100
MAX_PAGE = 3
MAX_HOURS = 21

for hour in range(0, MAX_HOURS):
    # Define parameters
    start_page = hour * 3
    end_page = start_page + 3
    all_data = []

    params = {
    "api_key": api_key,
    "fields": "id,school.name,school.school_url,school.degrees_awarded.predominant,school.ownership,school.minority_serving.historically_black,school.locale",
    "per_page": PER_PAGE,  # Number of results per page (max is 100)
    "page": start_page  # Page number
    }


# Function to fetch data from API
    def fetch_data(params):
        response = requests.get(endpoint, params=params)
        if response.status_code == 200:
            return response.json()
        else:
            response.raise_for_status()


    # Initialize list to hold all data


    # Fetch data from multiple pages
    for page in range(start_page, end_page):  # Adjust range as needed
        #print(start_page)
        print(f"Fetching data from page {page}")
        params["page"] = page
        data = fetch_data(params)
        all_data.extend(data["results"])
        if len(data["results"]) < params["per_page"]:
            break


    # Convert to DataFrame
    df = pd.DataFrame(all_data)


    # Filter out rows where URL is missing
    df = df[df['school.school_url'].notnull()]

    # Filter out rows
        # 0: Not classified
        # 1: Predominantly certificate-degree granting
        # 2: Predominantly associate's-degree granting --> 2 year
        # 3: Predominantly bachelor's-degree granting --> 4 year
        # 4: Entirely graduate-degree granting
    df = df[df['school.degrees_awarded.predominant'].notnull()]

    # School ownership numbers meanings
        # 1: Public
        # 2: Private nonprofit
        # 3: Private for-profit
    df = df[df['school.ownership'].notnull()]

    # HBCU meanings
        # 1: Yes, the institution is a Historically Black College or University (HBCU).
        # 0: No, the institution is not a Historically Black College or University (HBCU).
    df = df[df['school.minority_serving.historically_black'].notnull()]

    # School.locale meanings
    '''
    11	City: Large (population of 250,000 or more)
    12	City: Midsize (population of at least 100,000 but less than 250,000)
    13	City: Small (population less than 100,000)
    21	Suburb: Large (outside principal city, in urbanized area with population of 250,000 or more)
    22	Suburb: Midsize (outside principal city, in urbanized area with population of at least 100,000 but less than 250,000)
    23	Suburb: Small (outside principal city, in urbanized area with population less than 100,000)
    31	Town: Fringe (in urban cluster up to 10 miles from an urbanized area)
    32	Town: Distant (in urban cluster more than 10 miles and up to 35 miles from an urbanized area)
    33	Town: Remote (in urban cluster more than 35 miles from an urbanized area)
    41	Rural: Fringe (rural territory up to 5 miles from an urbanized area or up to 2.5 miles from an urban cluster)
    42	Rural: Distant (rural territory more than 5 miles but up to 25 miles from an urbanized area or more than 2.5 and up to 10 miles from an urban cluster)
    43	Rural: Remote (rural territory more than 25 miles from an urbanized area and more than 10 miles from an urban cluster)'''
    df = df[df['school.locale'].notnull()]

    # Save to CSV

    df.to_csv(f"college_general_information_{page}.csv", index=False)
    print(page)
    print(df.head())

    unique_ids = df['id'].dropna().unique()
    unique_names = df['school.name'].dropna().unique()
    unique_names_df = pd.DataFrame(unique_names, columns=['school_name'])
    unique_names_df.to_csv(f"unique_college_names_{page}.csv", index=False)

    school_and_majors = []
    for school_name in unique_names:
        # print('School Name:', school_name)
        params = {
            "api_key": api_key,
            "fields": "id,school.name,programs.cip_4_digit.title",
            "per_page": PER_PAGE,  # Increase the number of results per page
            "school.name": school_name
        }
        response = requests.get(endpoint, params=params)
        
        # print(f"Response Status Code: {response.status_code}")
        if response.status_code == 200:
            data = response.json()
            # print(f"Full Response Data: {data}")
            if 'results' in data and len(data['results']) > 0:
                majors = []
                school_id = data['results'][0]['id']
                for school in data['results']:
                    if 'latest.programs.cip_4_digit' in school:
                        for program in school['latest.programs.cip_4_digit']:
                            # print('Program Title:', program['title'])
                            if program['title'] not in majors:
                                majors.append(program['title'])
                
                school_and_majors.append([school_id, school_name, majors])
            else:
                print("No results found for this school.")
        else:
            print(f"Error: {response.status_code}")
            print(response.json())

    with open(f'college_majors_{page}.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['id', 'CollegeName', 'Major'])
        
        for item in school_and_majors:
            college_id = item[0]
            college_name = item[1]
            for major in majors:
                writer.writerow([college_id, college_name, major])

    def get_campuses(school_id):
        '''
        For school.main campus: 
            1: Yes, the insittution is the main campus
            0: No, it is not the main campus
        
        For school.branch
            1: Yes, it is a branch campus
            0: No, it is not a branch campus
        '''

        params = {
            "api_key": api_key,
            "id": school_id,
            "fields": "id,school.name,school.main_campus,school.branch"
        }
        response = requests.get(endpoint, params=params)
        
        if response.status_code == 200:
            data = response.json()
            # print('Full Response Data', data)
            if 'results' in data and len(data['results']) > 0:
                return data['results']
        return []

    college_campuses_dict = {}

    for school_id in unique_ids:
        campuses = get_campuses(school_id)
        if campuses:
            college_campuses_dict[school_id] = campuses

    with open(f'college_campuses_{page}.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['id', 'CollegeName', 'MainCampus', 'Branch'])
        
        for school_id, campuses in college_campuses_dict.items():
            for campus in campuses:
                writer.writerow([school_id, campus['school.name'], campus['school.main_campus'], campus['school.branches']])

    def get_student_profiles(school_id):
        params = {
            "api_key": api_key,
            "id": school_id,
            "fields": "id,school.name,latest.admissions.admission_rate.overall,"
                        "latest.student.size,"
                    "latest.admissions.sat_scores.25th_percentile.critical_reading,"
                    "latest.admissions.sat_scores.75th_percentile.critical_reading,"
                    "latest.admissions.act_scores.25th_percentile.cumulative,"
                    "latest.admissions.act_scores.75th_percentile.cumulative,"
                    "latest.student.demographics.race_ethnicity.white,"
                    "latest.student.demographics.race_ethnicity.black,"
                    'latest.student.demographics.race_ethnicity.hispanic,'
                        'latest.student.demographics.race_ethnicity.asian,'
                        'latest.student.demographics.race_ethnicity.aian,'
                        'latest.student.demographics.race_ethnicity.nhpi,'
                        'latest.student.demographics.race_ethnicity.two_or_more,'
                        'latest.student.demographics.race_ethnicity.non_resident_alien,'
                        'latest.student.demographics.race_ethnicity.unknown,'
                    "latest.admissions.sat_scores.75th_percentile.math,"
                    "latest.admissions.sat_scores.75th_percentile.writing,"
                    "latest.admissions.sat_scores.midpoint.math,"
                    "latest.admissions.act_scores.25th_percentile.english,"
                    "latest.admissions.act_scores.25th_percentile.math,"
                    "latest.admissions.act_scores.25th_percentile.writing,"
                    "latest.admissions.act_scores.midpoint.cumulative,"
                    "latest.admissions.act_scores.midpoint.math,"
                    "latest.admissions.sat_scores.average.overall,"
                    "latest.academics.program_percentage.agriculture,"
                        'latest.academics.program_percentage.architecture,'
                        'latest.academics.program_percentage.communication,'
                        'latest.academics.program_percentage.computer,'
                        'latest.academics.program_percentage.education,'
                        'latest.academics.program_percentage.engineering_technology,'
                        'latest.academics.program_percentage.family_consumer_science,'
                        'latest.academics.program_percentage.english,'
                        'latest.academics.program_percentage.library,'
                        'latest.academics.program_percentage.mathematics,'
                        'latest.academics.program_percentage.multidiscipline,'
                        'latest.academics.program_percentage.philosophy_religious,'
                        'latest.academics.program_percentage.physical_science,'
                        'latest.academics.program_percentage.psychology,'
                        'latest.academics.program_percentage.public_administration_social_service,'
                        'latest.academics.program_percentage.construction,'
                        'latest.academics.program_percentage.precision_production,'
                        'latest.academics.program_percentage.visual_performing,'
                        'latest.academics.program_percentage.business_marketing,'
                        'latest.cost.attendance.academic_year,'
                        'latest.cost.tuition.in_state,'
                        'latest.completion.completion_rate_4yr_100nt,'
                        'latest.completion.completion_rate_less_than_4yr_100nt'
        }
        response = requests.get(endpoint, params=params)
        
        if response.status_code == 200:
            data = response.json()
            if 'results' in data and len(data['results']) > 0:
                return data['results']
        return []

# Save student profiles
    with open(f'college_demographics_{page}.csv', 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(['id', 'school.name', 'school.admissions_rate', 
                        "all_degree_seeking_undergrads",
                        'sat_scores_25th_percentile.critical_reading', 
                        'sat_scores_75th_percentile.critical_reading', 
                        'act_scores.25th_percentile.cumulative', 
                        'act_scores.75th_percentile.cumulative', 
                        'student.demographics.race_ethnicity.white',
                        'student.demographics.race_ethnicity.black',
                        'student.demographics.race_ethnicity.hispanic',
                        'student.demographics.race_ethnicity.asian',
                        'student.demographics.race_ethnicity.aian',
                        'student.demographics.race_ethnicity.nhpi',
                        'student.demographics.race_ethnicity.two_or_more',
                        'student.demographics.race_ethnicity.non_resident_alien',
                        'student.demographics.race_ethnicity.unknown',
                        'sat_scores.75th_percentile.math', 
                        'sat_scores.75th_percentile.writing', 
                        'sat_scores.midpoint.math', 
                        'act_scores.25th_percentile.english', 
                        'act_scores.25th_percentile.math', 
                        'act_scores.25th_percentile.writing', 
                        'act_scores.midpoint.cumulative', 
                        'act_scores.midpoint.math', 
                        'sat_scores.average.overall',
                        "latest.academics.program_percentage.agriculture",
                        'latest.academics.program_percentage.architecture',
                        'latest.academics.program_percentage.communication',
                        'latest.academics.program_percentage.computer',
                        'latest.academics.program_percentage.education',
                        'latest.academics.program_percentage.engineering_technology',
                        'latest.academics.program_percentage.family_consumer_science',
                        'latest.academics.program_percentage.english',
                        'latest.academics.program_percentage.library',
                        'latest.academics.program_percentage.mathematics',
                        'latest.academics.program_percentage.multidiscipline',
                        'latest.academics.program_percentage.philosophy_religious,',
                        'latest.academics.program_percentage.physical_science',
                        'latest.academics.program_percentage.psychology',
                        'latest.academics.program_percentage.public_administration_social_service',
                        'latest.academics.program_percentage.construction',
                        'latest.academics.program_percentage.precision_production',
                        'latest.academics.program_percentage.visual_performing',
                        'latest.academics.program_percentage.business_marketing',
                        'latest.cost.attendance.academic_year',
                        'latest.cost.tuition.in_state',
                        "Completion rate for first-time, full-time bachelor's-degree-seeking students at four-year institutions ",
                        "Completion rate for first-time, full-time students at less-than-four-year institutions"])
        for school_id in unique_ids:
            profiles = get_student_profiles(school_id)
            if profiles:
                for school in profiles:
                    writer.writerow([school_id, school['school.name'], 
                                    school.get("latest.student.size"),
                                    school.get('latest.admissions.admission_rate.overall'), 
                                    school.get('latest.admissions.sat_scores.25th_percentile.critical_reading'), 
                                    school.get('latest.admissions.sat_scores.75th_percentile.critical_reading'), 
                                    school.get('latest.admissions.act_scores.25th_percentile.cumulative'), 
                                    school.get('latest.admissions.act_scores.75th_percentile.cumulative'), 
                                    school.get('latest.student.demographics.race_ethnicity.white'), 
                                    school.get('latest.student.demographics.race_ethnicity.black'),
                                    school.get('latest.student.demographics.race_ethnicity.hispanic'),
                                    school.get('latest.student.demographics.race_ethnicity.asian'),
                                    school.get('latest.student.demographics.race_ethnicity.aian'),
                                    school.get('student.demographics.race_ethnicity.nhpi'),
                                    school.get('latest.student.demographics.race_ethnicity.two_or_more'),
                                    school.get('latest.student.demographics.race_ethnicity.non_resident_alien'),
                                    school.get('latest.student.demographics.race_ethnicity.unknown'),
                                    school.get('latest.admissions.sat_scores.75th_percentile.math'), 
                                    school.get('latest.admissions.sat_scores.75th_percentile.writing'), 
                                    school.get('latest.admissions.sat_scores.midpoint.math'), 
                                    school.get('latest.admissions.act_scores.25th_percentile.english'),
                                    school.get('latest.admissions.act_scores.25th_percentile.math'), 
                                    school.get('latest.admissions.act_scores.25th_percentile.writing'), 
                                    school.get('latest.admissions.act_scores.midpoint.cumulative'), 
                                    school.get('latest.admissions.act_scores.midpoint.math'),
                                    school.get('latest.admissions.sat_scores.average.overall'),
                                    school.get("latest.academics.program_percentage.agriculture"),
                        school.get('latest.academics.program_percentage.architecture'),
                        school.get('latest.academics.program_percentage.communication'),
                        school.get('latest.academics.program_percentage.computer'),
                        school.get('latest.academics.program_percentage.education'),
                        school.get('latest.academics.program_percentage.engineering_technology'),
                        school.get('latest.academics.program_percentage.family_consumer_science'),
                        school.get('latest.academics.program_percentage.english'),
                        school.get('latest.academics.program_percentage.library'),
                        school.get('latest.academics.program_percentage.mathematics'),
                        school.get('latest.academics.program_percentage.multidiscipline'),
                        school.get('latest.academics.program_percentage.philosophy_religious'),
                        school.get('latest.academics.program_percentage.physical_science'),
                        school.get('latest.academics.program_percentage.psychology'),
                        school.get('latest.academics.program_percentage.public_administration_social_service'),
                        school.get('latest.academics.program_percentage.construction'),
                        school.get('latest.academics.program_percentage.precision_production'),
                        school.get('latest.academics.program_percentage.visual_performing'),
                        school.get('latest.academics.program_percentage.business_marketing'),
                        school.get('latest.cost.attendance.academic_year'),
                        school.get('latest.cost.tuition.in_state'),
                        school.get('latest.completion.completion_rate_4yr_100nt'),
                        school.get('latest.completion.completion_rate_less_than_4yr_100nt')])

    dff = pd.read_csv(f'college_demographics_{page}.csv')
    dff.dropna()


    # Extract URLs and filter for uniqueness
    unique_urls = df['school.school_url'].dropna().unique()


    # Save to CSV
    unique_urls_df = pd.DataFrame(unique_urls, columns=['school_url'])
    unique_urls_df.to_csv(f"unique_college_urls_{page}.csv", index=False)

    print(unique_urls_df.head())

    scrape_college_data(list(unique_names), page)
    print('YOU NOW HAVE 50 MINUTES TO UPDATE THE GOOGLE SHEET')
    time.sleep(3600)