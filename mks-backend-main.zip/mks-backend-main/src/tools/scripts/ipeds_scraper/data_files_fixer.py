import csv
import pandas as pd
from collections import defaultdict

root_path = '/Users/shreyanakum/Downloads/dabbl/'

## -- Fixing IPEDS data --
def get_csv_files_for_data(data_type: str) -> list:
    '''
    :param: data_type college_campuses, college_data, college_demographics, college_general_information, college_majors
    '''
    return [f'{root_path}{data_type}_2.csv',
             f'{root_path}{data_type}_5.csv',
             f'{root_path}{data_type}_8.csv',
             f'{root_path}{data_type}_11.csv',
             f'{root_path}{data_type}_14.csv',
             f'{root_path}{data_type}_17.csv',
             f'{root_path}{data_type}_20.csv',
             f'{root_path}{data_type}_23.csv',
             f'{root_path}{data_type}_26.csv',
             f'{root_path}{data_type}_29.csv',
             f'{root_path}{data_type}_32.csv',
             f'{root_path}{data_type}_35.csv',
             f'{root_path}{data_type}_38.csv',
             f'{root_path}{data_type}_41.csv',
             f'{root_path}{data_type}_44.csv',
             f'{root_path}{data_type}_47.csv',
             f'{root_path}{data_type}_50.csv',
             f'{root_path}{data_type}_53.csv',
             f'{root_path}{data_type}_56.csv',
             f'{root_path}{data_type}_59.csv',
             f'{root_path}{data_type}_62.csv',]

def transform_same_headers(data_type: str) -> None:
    '''
    :param: data_type 'college_campuses', 'college_data', 'college_demographics', 'college_general_information'
    
    Puts all college data for a specific data_type into one csv file.
    '''
    csv_files = get_csv_files_for_data(data_type)
    df_append = pd.DataFrame()

    for file in csv_files:
        df_temp = pd.read_csv(file)
        df_append = df_append._append(df_temp, ignore_index = True)
    
    df_append.to_csv(f'{data_type}_combined.csv')

def mapping_college_name_to_id() -> dict:
    college_ids = dict()

    with open(f'{root_path}college_general_information_combined.csv', mode = 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)
        for row in reader:
            rownum, college_name, url, degree, ownership, hbcu, locale, college_id = row
            college_ids[college_name] = college_id
    
    return college_ids

def transform_college_majors() -> None:
    '''
    Combines majors into a list for each college and then puts 
    all college-majorlist pairs into one csv file
    '''
    csv_files = get_csv_files_for_data('college_majors')
    
    # Create college and major list pairs csv file
    output_file = 'college_majors_combined.csv'

    college_majors = defaultdict(list)

    for file in csv_files:
        with open(file, mode='r', newline='', encoding='utf-8') as csvfile:
            reader = csv.reader(csvfile)
            next(reader)
            for row in reader:
                id, college, major = row
                college_majors[college].append(f'"{major}"')
        
    for value in college_majors.values():
        value[0] = f'[{value[0]}'
        value[-1] = f'{value[-1]}]'
        
    with open(output_file, mode='w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['id', 'CollegeName', 'Majors'])

        college_ids = mapping_college_name_to_id()

        for college, majors in college_majors.items():
            writer.writerow([college_ids.get(college, 'ID not found'), college, ', '.join(majors)])

## -- Fixing Scraped data --

## GPA
RAW_SCRAPED_DATA = f'{root_path}college_data_combined.csv'
# RAW_SCRAPED_DATA = f'{root_path}college_data_1247.csv'

def transforming_GPA_information() -> None:
    '''
    Changes the GPA information column to a be split up into 5 columns based on 
    GPA distribution. Updates that into a new csv file.
    '''
    college_gpa_information = dict() # Key: College Name & Value: list of dictionaries of the GPA breakdown
    
    with open(RAW_SCRAPED_DATA, mode='r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)
        for row in reader:
            rownum, college_name, gpa_information, activities, rotc, housing, aid, scorecard, units = row
            for item in gpa_information.split('\n'):
                if 'Percent who had GPA between' in item:
                    if '%' in item:
                        breakdown = item.split('Percent who had GPA between')[1].split(' ')
                        if college_name not in college_gpa_information:
                            college_gpa_information[college_name] = [{' '.join(breakdown[1:4]): breakdown[-1]}]
                        else:
                            college_gpa_information[college_name].append({' '.join(breakdown[1:4]): breakdown[-1]})
                    else:
                        pass
                        # if college_gpa_information[college_name] == []:
                        #     college_gpa_information[college_name].append({' '.join(breakdown[1:4]): 'N/A'})
                elif 'Percent who had GPA of' in item:
                    if '%' in item:
                        breakdown = item.split('Percent who had GPA of')[1].split(' ')
                        if college_name not in college_gpa_information:
                            college_gpa_information[college_name] = [{' '.join(breakdown[1:2]): breakdown[-1]}]
                        else:
                            college_gpa_information[college_name].append({' '.join(breakdown[1:2]): breakdown[-1]})
                    else:
                        pass
                elif 'Percent who had GPA below' in item:
                    if '%' in item:
                        breakdown = item.split('Percent who had GPA below')[1].split(' ')
                        if college_name not in college_gpa_information:
                            college_gpa_information[college_name] = [{' '.join(breakdown[1:2]): breakdown[-1]}]
                        else:
                            college_gpa_information[college_name].append({' '.join(breakdown[1:2]): breakdown[-1]})
                    else:
                        pass
                else:
                    pass
    
    with open('gpa_information_scraped.csv', mode='w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['id', 'CollegeName', 'Percent who had GPA of 4.0', 'Percent who had GPA between 3.75 and 3.99', 'Percent who had GPA between 3.50 and 3.74', 
                         'Percent who had GPA between 3.25 and 3.49', 'Percent who had GPA between 3.00 and 3.24', 'Percent who had GPA between 2.50 and 2.99', 
                         'Percent who had GPA between 2.0 and 2.49', 'Percent who had GPA between 1.0 and 1.99', 'Percent who had GPA below 1.0'])

        college_ids = mapping_college_name_to_id()

        for college in college_gpa_information:
            row = [college_ids.get(college, 'ID not found'), college, 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'N/A']
            breakdowns = college_gpa_information[college]
            for breakdown in breakdowns:
                for gpa, percent in breakdown.items():
                    if gpa == '4.0':
                        row[2] = percent
                    elif '3.75' in gpa:
                        row[3] = percent
                    elif '3.50' in gpa:
                        row[4] = percent
                    elif '3.25' in gpa:
                        row[5] = percent
                    elif '3.00' in gpa:
                        row[6] = percent
                    elif '2.50' in gpa:
                        row[7] = percent
                    elif '2.0' in gpa:
                        row[8] = percent
                    elif '1.99' in gpa:
                        row[9] = percent
                    elif '1.0' in gpa:
                        row[10] = percent
            writer.writerow(row)

## Activities, ROTC, and Housing
def populate_dictionaries(item: str, offered_activities: dict, offered_housing: dict, offered_rotc: dict) -> None:
    '''Given the string of text that was scraped, all the dictionaries of data are populated'''
    if item.split(' ')[0] == 'X':
        if item.split('X')[1].strip() in offered_activities:
            offered_activities[item.split('X')[1].strip()] = True
        elif item.split('X')[1].strip() in offered_housing:
            offered_housing[item.split('X')[1].strip()] = True
    elif 'ROTC' in item:
        if 'X' in item and 'Army' in item:
            offered_rotc['Army ROTC'] = True
        elif 'X' in item and 'Naval' in item:
            offered_rotc['Naval ROTC'] = True
        elif 'X' in item and 'Air Force' in item:
            offered_rotc['Air Force ROTC'] = True
    else:
        pass

def get_offered_activites_rotc_housing() -> dict:
    '''
    Returns dictionaries of activities, rotc, and housing offered at the university 
    '''
    college_activities_rotc_housing_information = dict()

    with open(RAW_SCRAPED_DATA, mode='r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)
        for row in reader:
            rownum, college_name, gpa_information, activities, rotc, housing, aid, scorecard, units = row
            if activities == 'URL Not Found' or rotc == 'URL Not Found' or housing == 'URL Not Found':
                pass
            else:
                offered_activities = {'Campus Ministries': False, 'Choral groups': False, 'Concert band': False,
                          'Dance': False, 'Drama/theater': False, 'International Student Organization': False,
                          'Jazz band': False, 'Literary magazine': False, 'Marching band': False,
                          'Model UN': False, 'Music ensembles': False, 'Musical theater': False,
                          'Opera': False, 'Pep band': False, 'Radio station': False,
                          'Student government': False, 'Student newspaper': False, 
                          'Student-run film society': False, 'Symphony orchestra': False,
                          'Television station': False, 'Yearbook': False} 
                    # Key: Activities & Value: boolean indicating activity offered (True) or not (False)

                offered_rotc = {'Army ROTC': False, 'Naval ROTC': False, 'Air Force ROTC': False}
                    # Key: Type of Rotc & Value: boolean indicating if that ROTC is offered (True) or not (False)

                offered_housing = {'Coed dorms': False, "Men's dorms": False, "Women's dorms": False,
                                "Apartments for married students": False, "Apartments for single students": False,
                                "Special housing for disabled students": False, 
                                "Special housing for international students": False, 
                                "Fraternity/sorority housing": False,
                                "Cooperative housing": False,
                                "Theme housing": False, 'Wellness housing': False, 'Living Learning Communities': False,
                                'Other housing options': False}
                    # Key: Type of housing & Value: boolean indicating if that housing is offered (True) or not (False)
                for item in activities.split('\n'):
                    populate_dictionaries(item, offered_activities, offered_housing, offered_rotc)
                for item in rotc.split('\n'):
                    populate_dictionaries(item, offered_activities, offered_housing, offered_rotc)
                for item in housing.split('\n'):
                    populate_dictionaries(item, offered_activities, offered_housing, offered_rotc)
                
                college_activities_rotc_housing_information[college_name] = [offered_activities, offered_housing, offered_rotc]
                if (list(offered_activities.values()) == [False, False, False, False, False, False, False, False, False, False, False, False, False]):
                    college_activities_rotc_housing_information[college_name][0] = {'N/A': 'N/A'}
                if (list(offered_housing.values()) == [False, False, False, False, False, False, False, False, False, False, False, False, False]):
                    college_activities_rotc_housing_information[college_name][1] = {'N/A': 'N/A'}
                if (list(offered_rotc.values()) == [False, False, False, False, False, False, False, False, False, False, False, False, False]):
                    college_activities_rotc_housing_information[college_name][2] = {'N/A': 'N/A'}

    return college_activities_rotc_housing_information

def transform_activities_rotc_housing(college_activities_rotc_housing_information: dict) -> None:
    '''
    Writes the activities, rotc, and housing into csv files for each college.
    '''
    college_ids = mapping_college_name_to_id()
    with open('college_activities_combined.csv', mode='w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['id', 'CollegeName', 'Campus Ministries', 'Choral groups', 'Concert band', 'Dance', 'Drama/theater', 'International Student Organization', 'Jazz band', 'Literary magazine', 'Marching band', 'Model UN', 'Music ensembles', 'Musical theater', 'Opera', 'Pep band', 'Radio station', 'Student government', 'Student newspaper', 'Student-run film society', 'Symphony orchestra', 'Television station', 'Yearbook'])
        for college in college_activities_rotc_housing_information:
            row = [college_ids.get(college, 'ID not found'), college]
            activities = college_activities_rotc_housing_information[college][0]
            for offerance in activities.values():
                row.append(offerance)
            writer.writerow(row)
    
    with open('college_housing_combined.csv', mode='w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['id', 'CollegeName', 'Coed dorms', "Men's dorms", "Women's dorms", 'Apartments for married students', 'Apartments for single students', 'Special housing for disabled students', 'Special housing for international students', 'Fraternity/sorority housing', 'Cooperative housing', 'Theme housing', 'Wellness housing', 'Living Learning Communities', 'Other housing options'])
        for college in college_activities_rotc_housing_information:
            row = [college_ids.get(college, 'ID not found'), college]
            housing = college_activities_rotc_housing_information[college][1]
            for offerance in housing.values():
                row.append(offerance)
            writer.writerow(row)
    
    with open('college_rotc_combined.csv', mode='w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['id', 'CollegeName', 'Army ROTC', 'Naval ROTC', 'Air Force ROTC'])
        for college in college_activities_rotc_housing_information:
            row = [college_ids.get(college, 'ID not found'), college]
            rotc = college_activities_rotc_housing_information[college][2]
            # print(rotc)
            for offerance in rotc.values():
                row.append(offerance)
            # print(row)
            writer.writerow(row)

## Scorecard/Ranking (C7)
def get_valid_scorecards() -> dict:
    scorecards = dict()
    with open(RAW_SCRAPED_DATA, mode='r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)
        for row in reader:
            rownum, college_name, gpa_information, activities, rotc, housing, aid, scorecard, units = row
            if scorecard == 'URL Not Found':
                pass
            else:
                scorecards[college_name] = scorecard
    return scorecards

def transform_scorecards(scorecards_info: dict) -> None:
    college_ids = mapping_college_name_to_id()

    with open('college_scorecard_combined.csv', mode='w', newline='', encoding='utf-8') as csvfile:
        writer = csv.writer(csvfile)
        writer.writerow(['id', 'CollegeName', 'CollegeScorecard'])
        for college in scorecards_info:
            writer.writerow([college_ids[college], college, scorecards_info[college]])

## -- Combine all data into one CSV file

## -- The Main Function --
def transform_all_csv_files() -> None:
    '''
    Transforms all IPEDS data and scraped data.
    '''
    transform_same_headers('college_campuses')
    transform_same_headers('college_data')
    transform_same_headers('college_demographics')
    transform_same_headers('college_general_information')
    transform_college_majors()
    transforming_GPA_information()
    transform_activities_rotc_housing(get_offered_activites_rotc_housing())
    transform_scorecards(get_valid_scorecards())

def combine_into_one_csv() -> None:
    # transform_all_csv_files()
    transform_scorecards(get_valid_scorecards())
    general_information = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_general_information_combined.csv')
    activities = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_activities_combined.csv')
    campuses = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_campuses_combined.csv')
    demographics = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_demographics_combined.csv')
    housing = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_housing_combined.csv')
    majors = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_majors_combined.csv')
    rotc = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_rotc_combined.csv')
    scorecard = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_scorecard_combined.csv')
    gpa = pd.read_csv('/Users/shreyanakum/Downloads/dabbl/gpa_information_scraped.csv')

    # df = general_information.merge(activities, on="id", how='left')#.merge(campuses, on="id", how='left')#.merge(demographics, on="id").merge(housing, on="id").merge(majors, on="id").merge(rotc, on="id").merge(scorecard, on="id").merge(gpa, on="id")
    df = pd.merge(general_information, activities[['Campus Ministries', 'Choral groups', 'Concert band',
       'Dance', 'Drama/theater', 'International Student Organization',
       'Jazz band', 'Literary magazine', 'Marching band', 'Model UN',
       'Music ensembles', 'Musical theater', 'Opera', 'Pep band',
       'Radio station', 'Student government', 'Student newspaper',
       'Student-run film society', 'Symphony orchestra', 'Television station',
       'Yearbook', 'id']], on='id', how='outer')
    # df.to_csv('all_college_information.csv')
    # print(df)
    # print(campuses)
    cols_to_use = campuses.columns.difference(df.columns)
    df2 = pd.merge(df, campuses[['Branch', 'MainCampus','id']], on='id', how='left')
    
    cols_to_use = demographics.columns.difference(df2.columns)
    df3 = pd.merge(df2, demographics[["Completion rate for first-time, full-time bachelor's-degree-seeking students at four-year institutions ",
       'Completion rate for first-time, full-time students at less-than-four-year institutions',
       'act_scores.25th_percentile.cumulative',
       'act_scores.25th_percentile.english', 'act_scores.25th_percentile.math',
       'act_scores.25th_percentile.writing',
       'act_scores.75th_percentile.cumulative',
       'act_scores.midpoint.cumulative', 'act_scores.midpoint.math',
       'all_degree_seeking_undergrads',
       'latest.academics.program_percentage.agriculture',
       'latest.academics.program_percentage.architecture',
       'latest.academics.program_percentage.business_marketing',
       'latest.academics.program_percentage.communication',
       'latest.academics.program_percentage.computer',
       'latest.academics.program_percentage.construction',
       'latest.academics.program_percentage.education',
       'latest.academics.program_percentage.engineering_technology',
       'latest.academics.program_percentage.english',
       'latest.academics.program_percentage.family_consumer_science',
       'latest.academics.program_percentage.library',
       'latest.academics.program_percentage.mathematics',
       'latest.academics.program_percentage.multidiscipline',
       'latest.academics.program_percentage.philosophy_religious,',
       'latest.academics.program_percentage.physical_science',
       'latest.academics.program_percentage.precision_production',
       'latest.academics.program_percentage.psychology',
       'latest.academics.program_percentage.public_administration_social_service',
       'latest.academics.program_percentage.visual_performing',
       'latest.cost.attendance.academic_year', 'latest.cost.tuition.in_state',
       'sat_scores.75th_percentile.math', 'sat_scores.75th_percentile.writing',
       'sat_scores.average.overall', 'sat_scores.midpoint.math',
       'sat_scores_25th_percentile.critical_reading',
       'sat_scores_75th_percentile.critical_reading', 'school.admissions_rate',
       'student.demographics.race_ethnicity.aian',
       'student.demographics.race_ethnicity.asian',
       'student.demographics.race_ethnicity.black',
       'student.demographics.race_ethnicity.hispanic',
       'student.demographics.race_ethnicity.nhpi',
       'student.demographics.race_ethnicity.non_resident_alien',
       'student.demographics.race_ethnicity.two_or_more',
       'student.demographics.race_ethnicity.unknown',
       'student.demographics.race_ethnicity.white', 'id']], how='left', on='id')
    
    cols_to_use = housing.columns.difference(df3.columns)
    df4 = pd.merge(df3, housing[['Apartments for married students', 'Apartments for single students',
       'Coed dorms', 'Cooperative housing', 'Fraternity/sorority housing',
       'Living Learning Communities', "Men's dorms", 'Other housing options',
       'Special housing for disabled students',
       'Special housing for international students', 'Theme housing',
       'Wellness housing', "Women's dorms", 'id']], how='left', on='id')
    
    cols_to_use = majors.columns.difference(df4.columns)
    df5 = pd.merge(df4, majors[['Majors', 'id']], how='left', on='id')
    
    cols_to_use = rotc.columns.difference(df5.columns)
    df6 = pd.merge(df5, rotc[['Air Force ROTC', 'Army ROTC', 'CollegeName', 'Naval ROTC', 'id']], how='left', on='id')
    
    cols_to_use = scorecard.columns.difference(df6.columns)
    df7 = pd.merge(df6, scorecard[['CollegeScorecard', 'id']], how='left', on='id')
    
    cols_to_use = gpa.columns.difference(df7.columns)
    df8 = pd.merge(df7, gpa[['Percent who had GPA below 1.0',
       'Percent who had GPA between 1.0 and 1.99',
       'Percent who had GPA between 2.0 and 2.49',
       'Percent who had GPA between 2.50 and 2.99',
       'Percent who had GPA between 3.00 and 3.24',
       'Percent who had GPA between 3.25 and 3.49',
       'Percent who had GPA between 3.50 and 3.74',
       'Percent who had GPA between 3.75 and 3.99',
       'Percent who had GPA of 4.0', 'id']], how='left', on='id')
    
    df8.drop_duplicates()
    df8.to_csv('all_college_information.csv')

if __name__ == '__main__':
    # combine_into_one_csv()
    # transform_all_csv_files()
    print(mapping_college_name_to_id())
