import requests
from bs4 import BeautifulSoup
import pdfplumber
import csv
import re
# from ipeds_api import unique_names


def google_search(query, college_name, abbreviation):
   headers = {"User-Agent": "Mozilla/5.0"}
   response = requests.get(f"https://www.google.com/search?q={query}", headers=headers)
   soup = BeautifulSoup(response.text, "html.parser")
   college_words = college_name.lower().split()
   for link in soup.find_all("a"):
       url = link.get("href")
       if url.startswith("/url?q="):
           real_url = url.split("/url?q=")[1].split("&sa=U")[0]
           words_in_url = sum(word in real_url.lower() for word in college_words)
           if (
               ("cds" in real_url.lower() or "common" in real_url.lower()) and
               ".edu" in real_url and
               "2023" in real_url and
               (abbreviation.lower() in real_url.lower() or words_in_url >= 1)
           ):
               print(f"Found URL: {real_url}")
               return real_url
   return None


def get_abbreviation(college_name):
   return ''.join(word[0] for word in college_name.split())


def is_pdf_url(url):
   return url.lower().endswith('.pdf')


def check_404(url):
   response = requests.head(url)
   return response.status_code == 404


def is_valid_pdf(file_path):
   try:
       with pdfplumber.open(file_path) as pdf:
           return True
   except:
       return False


def extract_gpa_activities_from_pdf(pdf_url):
   print(f"Reading PDF: {pdf_url}")
   response = requests.get(pdf_url)
   with open("temp.pdf", "wb") as f:
       f.write(response.content)
  
   if not is_valid_pdf("temp.pdf"):
       print(f"Invalid PDF: {pdf_url}")
       return None, None, None, None, None, None, None
   get_ranking = ['Very Important', 'Important', 'Considered', 'Not Considered/Not']
   gpa_info = None
   activities_info = None
   rotc_info = None
   housing_info = None
   aid_info = None
   units_required_info = None
   scorecard_info = {"Rigor of secondary school record": None, 
                                 "Class rank": None,
                                 "Academic Grade Point Average (GPA)": None, 
                                 "Recommendations": None,
                                 "Standardized test scores": None,
                                 "Application essay": None,
                                 "Interview": None,
                                 "Extracurriculuar activities": None,
                                 "Talent/ability": None,
                                 "Character/personal qualities": None,
                                 "First generation": None,
                                 "Alumni/ae relation": None,
                                 "Geographical residence": None,
                                 "State residency": None,
                                 "Religious affilitation/commitment": None,
                                 "Volunteer work": None,
                                 "Work experience": None,
                                 "Level of applicant's interest": None}
  
   with pdfplumber.open("temp.pdf") as pdf:
       print('inside pdf plumber')
       for page in pdf.pages:
           text = page.extract_text()
           if "C11" in text: # GPA
               gpa_info = extract_gpa_table(text, "C11")
           if "F2" in text: # Activities
               activities_info = extract_section(text, "F2")
           if "F3" in text: # ROTC
               rotc_info = extract_section(text, "F3")
           if "F4" in text: # Housing
               housing_info = extract_section(text, "F4")
           if "Which needs-analysis methodology does your institution use in awarding institutional aid?" in text: # Which needs-analysis methodology does your institution use in awarding institutional aid?
               aid_info = extract_section(text, "Which needs-analysis methodology does your institution use in awarding institutional aid?")
           if "C7" in text or (("C8" in text)): # Scorecard
               # ------------------
               print('with extract_table')
               tables = (page.extract_table(table_settings=
                                                {"vertical_strategy": "lines", 
                                               "horizontal_strategy": "text", 
                                               "snap_tolerance": 4,}))
               for table in tables:
                   print('table: ', table)
                   if 'Rigor of secondary school record' in table and 'X' in table:
                       scorecard_info['Rigor of secondary school record'] = get_ranking[table.index('X')-1]
                   elif 'Class rank' in table and 'X' in table:
                       scorecard_info['Class rank'] = get_ranking[table.index('X')-1]
                   elif 'Academic GPA' in table and 'X' in table:
                       scorecard_info['Academic GPA'] = get_ranking[table.index('X')-1]
                   elif 'Standardized test scores' in table and 'X' in table:
                       scorecard_info['Standardized test scores'] = get_ranking[table.index('X')-1]
                   elif 'Application Essay' in table and 'X' in table:
                       scorecard_info['Application Essay'] = get_ranking[table.index('X')-1]
                   elif ('Recommendation(s)' in table or 'Recommendations' in table) and 'X' in table:
                       scorecard_info['Recommendations'] = get_ranking[table.index('X')-1]
                   elif ('Interview') in table and 'X' in table:
                       scorecard_info['Interview'] = get_ranking[table.index('X')-1]
                   elif ('Extracurricular activities') in table and 'X' in table:
                       scorecard_info['Extracurricular activities'] = get_ranking[table.index('X')-1]
                   elif ('Talent/ability') in table and 'X' in table:
                       scorecard_info['Talent/ability'] = get_ranking[table.index('X')-1]
                   elif ('Character/personal qualities') in table and 'X' in table:
                       scorecard_info['Character/personal qualities'] = get_ranking[table.index('X')-1]
                   elif ('First generation') in table and 'X' in table:
                       scorecard_info['First generation'] = get_ranking[table.index('X')-1]
                   elif ('Alumni/ae relation') in table and 'X' in table:
                       scorecard_info['Alumni/ae relation'] = get_ranking[table.index('X')-1]
                   elif ('Geographical residence') in table and 'X' in table:
                       scorecard_info['Geographical residence'] = get_ranking[table.index('X')-1]
                   elif ('State residency') in table and 'X' in table:
                       scorecard_info['State residency'] = get_ranking[table.index('X')-1]
                   elif ('Religious affilitation/commitment') in table and 'X' in table:
                       scorecard_info['Religious affilitation/commitment'] = get_ranking[table.index('X')-1]
                   elif ('Volunteer work') in table and 'X' in table:
                       scorecard_info['Volunteer work'] = get_ranking[table.index('X')-1]
                   elif ('Work experience') in table and 'X' in table:
                       scorecard_info['Work experience'] = get_ranking[table.index('X')-1]
                   elif ("Level of applicant's interest") in table and 'X' in table:
                       scorecard_info["Level of applicant's interest"] = get_ranking[table.index('X')-1]
                   else:
                        # -------------------
                        print('\n')
                        print('\n')
                        page.crop((200, 300, 400, 450))
                        tables = page.find_tables(table_settings=
                                                            {"vertical_strategy": "lines", 
                                                        "horizontal_strategy": "text", 
                                                        "snap_tolerance": 4,})
                        for table in tables:
                            table_info = table.extract(x_tolerance=3, y_tolerance=3)
                            print('with extract_tables', table_info)
                            for item in table_info:
                                if 'Considered' in item or 'Not Considered' in item or 'Important' in item or 'Very Important' in item:
                                    scorecard_info[list(scorecard_info.keys())[list(scorecard_info.values()).index(None)]] = item[0]
                                elif 'Rigor of secondary school record' in item and 'X' in item:
                                    scorecard_info['Rigor of secondary school record'] = get_ranking[item.index('X')-1]
                                elif 'Class rank' in item and 'X' in item:
                                    scorecard_info['Class rank'] = get_ranking[item.index('X')-1]
                                elif 'Academic GPA' in item and 'X' in item:
                                    scorecard_info['Academic GPA'] = get_ranking[item.index('X')-1]
                                elif 'Standardized test scores' in item and 'X' in item:
                                    scorecard_info['Standardized test scores'] = get_ranking[item.index('X')-1]
                                elif 'Application Essay' in item and 'X' in item:
                                    scorecard_info['Application Essay'] = get_ranking[item.index('X')-1]
                                elif ('Recommendation(s)' in item or 'Recommendations' in item) and 'X' in item:
                                    scorecard_info['Recommendations'] = get_ranking[item.index('X')-1]
                                elif ('Interview') in item and 'X' in item:
                                    scorecard_info['Interview'] = get_ranking[item.index('X')-1]
                                elif ('Extracurricular activities') in item and 'X' in item:
                                    scorecard_info['Extracurricular activities'] = get_ranking[item.index('X')-1]
                                elif ('Talent/ability') in item and 'X' in item:
                                    scorecard_info['Talent/ability'] = get_ranking[item.index('X')-1]
                                elif ('Character/personal qualities') in item and 'X' in item:
                                    scorecard_info['Character/personal qualities'] = get_ranking[item.index('X')-1]
                                elif ('First generation') in item and 'X' in item:
                                    scorecard_info['First generation'] = get_ranking[item.index('X')-1]
                                elif ('Alumni/ae relation') in item and 'X' in item:
                                    scorecard_info['Alumni/ae relation'] = get_ranking[item.index('X')-1]
                                elif ('Geographical residence') in item and 'X' in item:
                                    scorecard_info['Geographical residence'] = get_ranking[item.index('X')-1]
                                elif ('State residency') in item and 'X' in item:
                                    scorecard_info['State residency'] = get_ranking[item.index('X')-1]
                                elif ('Religious affilitation/commitment') in item and 'X' in item:
                                    scorecard_info['Religious affilitation/commitment'] = get_ranking[item.index('X')-1]
                                elif ('Volunteer work') in item and 'X' in item:
                                    scorecard_info['Volunteer work'] = get_ranking[item.index('X')-1]
                                elif ('Work experience') in item and 'X' in item:
                                    scorecard_info['Work experience'] = get_ranking[item.index('X')-1]
                                elif ("Level of applicant's interest") in item and 'X' in item:
                                    scorecard_info["Level of applicant's interest"] = get_ranking[item.index('X')-1]
                        print('\n')
                        print('\n')
                        break
           if "C5" in text: # Units
               units_required_info = extract_section(text, "C5")
              
   return gpa_info, activities_info, rotc_info, housing_info, aid_info, scorecard_info, units_required_info


def extract_gpa_table(text, section): # Some colleges like MIT don't disclose GPAs
   gpa_info = ""
   lines = text.split('\n')
   start_collecting = False
   for line in lines:
       if section in line:
           start_collecting = True
       elif start_collecting and not line.strip():
           break
       elif start_collecting:
           gpa_info += line + "\n"
   return gpa_info.strip()

def extract_scorecard_table(text: list, section):
   pass


def extract_section(text, section):
   info = ""
   lines = text.split('\n')
   start_collecting = False
   for line in lines:
       if section in line:
           start_collecting = True
       elif start_collecting and not line.strip():
           break
       elif start_collecting:
           info += line + "\n"
   return info.strip()


def extract_gpa_activities_from_html(html_url):
   print(f"Reading site: {html_url}")


   if check_404(html_url):
       print(f"404 error for URL: {html_url}")
       return None, None, None, None


   response = requests.get(html_url)
   soup = BeautifulSoup(response.content, "html.parser")
  
   gpa_info = None
   activities_info = None
   rotc_info = None
   housing_info = None
   aid_info = None
   scorecard_info = None
   units_required_info = None
  
   # GPA info (C11)
   gpa_table = soup.find(string=re.compile("C11"))
   if gpa_table:
       gpa_info = gpa_table.find_parent("table").get_text(separator="\n", strip=True) if gpa_table.find_parent("table") else "Table not found"
  
   # Activities, ROTC, Housing (F2, F3, F4)
   activities_section = soup.find(string=re.compile("F2"))
   if activities_section:
       activities_info = activities_section.find_parent().get_text(separator="\n", strip=True) if activities_section.find_parent() else "Section not found"


   rotc_section = soup.find(string=re.compile("F3"))
   if rotc_section:
       rotc_info = rotc_section.find_parent().get_text(separator="\n", strip=True) if rotc_section.find_parent() else "Section not found"


   housing_section = soup.find(string=re.compile("F4"))
   if housing_section:
       housing_info = housing_section.find_parent().get_text(separator="\n", strip=True) if housing_section.find_parent() else "Section not found"
    
   aid_section = soup.find(string=re.compile("Which needs-analysis methodology does your institution use in awarding institutional aid?")) # replace w 
   if aid_section:
       aid_info = aid_section.find_parent().get_text(separator="\n", strip=True) if aid_section.find_parent() else "Section not found"

   scorecard_section = soup.find(string=re.compile("C7"))
   if scorecard_section:
       scorecard_info = scorecard_section.find_parent().get_text(separator="\n", strip=True) if scorecard_section.find_parent() else "Table not found"

   units_section = soup.find(string=re.compile("C5"))
   if units_section:
       units_required_info = units_section.find_parent().get_text(separator="\n", strip=True) if units_section.find_parent() else "Section not found"
      
   return gpa_info, activities_info, rotc_info, housing_info, aid_info, scorecard_info, units_required_info

def mapping_college_name_to_id() -> dict:
    college_ids = dict()

    with open('/Users/shreyanakum/Downloads/dabbl/college_general_information_combined.csv', mode = 'r', newline='', encoding='utf-8') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)
        for row in reader:
            rownum, college_name, url, degree, ownership, hbcu, locale, college_id = row
            college_ids[college_name] = college_id
    
    return college_ids

def scrape_college_data(colleges, pages):
   college_ids = mapping_college_name_to_id()
   uc_urls = {"University of Alabama in Huntsville": "https://www.uah.edu/images/administrative/provost/oir/CDS/cds_2023_2024.pdf", "University of California-Berkeley": "https://docs.google.com/spreadsheets/d/1CfCS76GVbnoWUkERd-mMtJT2EsIN2eVq/edit?gid=810727591#gid=810727591", "University of California-Davis": "https://aggiedata.ucdavis.edu/sites/g/files/dgvnsk1841/files/media/documents/CDS%202023-24%20UCD.pdf", "University of California-Irvine": "https://ucirvine.sharepoint.com/:b:/r/sites/IRAPWebsite-SPO/Shared%20Documents/Institutional%20Research/Common%20Data%20Sets/CDS_UNL2_2023_2024.pdf?csf=1&web=1&e=GJQVBp", "University of California-Los Angeles": "https://apb.ucla.edu/file/c4517b9b-1554-4daa-9194-dbc445d269e3", "University of California-Riverside": "https://ir.ucr.edu/sites/default/files/2024-03/cds-2023-2024.pdf","University of California-San Diego": "https://ir.ucsd.edu/stats/undergrad/CDS_UCSD_2023_20241.pdf", "University of California-Santa Barbara": "https://drive.google.com/file/d/1ehjlUgc7vxtgmqtTNS8KWUN3iMfM7YyJ/view?usp=sharing", "University of California-Santa Cruz": "https://mediafiles.ucsc.edu/iraps/common-data-set/common-data-set-2023-24.pdf", 'Alabama State University': "https://www.alasu.edu/_qa/2020%20CDS.2019-2020_2.pdf",
       'South University-Montgomery': "https://www.montgomerycollege.edu/_documents/offices/institutional-research-and-effectiveness/special-reports/common-data-set-2019-2020.pdf",
       'Jacksonville State University': "https://www.jsu.edu/ire/research/CDS/CDS_2022-2023.pdf",}
   with open(f"college_data_{pages}.csv", mode="w", newline="") as file:
       writer = csv.writer(file)
       writer.writerow(["id", "College Name", "GPA Information", "Activities Information", "ROTC Information", "Housing Information", "Aid Information", "College Scorecard", "Units Required"])
       for college in colleges:
       # for college in uc_urls:
       # for college in cds_urls:
           try:
               abbreviation = get_abbreviation(college)
               query = f"{college} Common Data Set"
               if college in uc_urls:
                url = uc_urls[college]
               else:
                url = google_search(query, college, abbreviation)
              
               if url:
                   if is_pdf_url(url):
                       # print(extract_gpa_activities_from_pdf(url))
                       gpa_info, activities_info, rotc_info, housing_info, aid_info, scorecard_info, units_info = extract_gpa_activities_from_pdf(url)
                   else:
                       gpa_info, activities_info, rotc_info, housing_info, aid_info, scorecard_info, units_info = extract_gpa_activities_from_html(url)
                  
                   if gpa_info is not None:
                       writer.writerow([college_ids[college], college, gpa_info, activities_info, rotc_info, housing_info, aid_info, scorecard_info, units_info])
                       print(f"{college} data written to CSV")
                   else:
                       writer.writerow([college_ids[college], college, "Data not found", "Data not found", "Data not found", "Data not found", "Data not found", "Data not found", "Data not found"])
                       print(f"Data extraction failed for {college}")
               else:
                   writer.writerow([college_ids[college], college, "URL Not Found", "URL Not Found", "URL Not Found", "URL Not Found", "URL Not Found", "URL Not Found", "URL Not Found"])
                   print(f"URL not found for {college}")
           except Exception as e:
               print(e)
               continue


if __name__ == '__main__':
   import pandas as pd
   college_names = list(pd.read_csv('/Users/shreyanakum/Downloads/dabbl/college_general_information_combined.csv')['school.name'])
   # college_names = ['']
   scrape_college_data(college_names, 6000)
   #scrape_college_data(['University of Alabama in Huntsville', 'South University-Montgomery', 'Jacksonville State University', 'Troy University'], 47)