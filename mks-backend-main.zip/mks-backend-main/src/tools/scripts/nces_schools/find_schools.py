import requests
import pandas as pd
import os
from dotenv import find_dotenv, load_dotenv

# Load environment variables
_ = load_dotenv(find_dotenv())

# Define the endpoint and parameters
endpoint = "https://api.data.gov/ed/collegescorecard/v1/pss"
api_key = os.environ["DATA_GOV_API_KEY"]  # You need to sign up for an API key at https://api.data.gov/signup/

# Define parameters
params = {
    "api_key": api_key,
    "fields": "id,pss.inst",
    "per_page": 100,  # Number of results per page (max is 100)
    "page": 0  # Page number
}

# Function to fetch data from API
def fetch_data(params):
    response = requests.get(endpoint, params=params)
    if response.status_code == 200:
        return response.json()
    else:
        response.raise_for_status()

# Initialize list to hold all data
all_data = []

# Fetch data from multiple pages
for page in range(0, 100):  # Adjust range as needed
    params["page"] = page
    data = fetch_data(params)
    all_data.extend(data["results"])
    if len(data["results"]) < params["per_page"]:
        break

# Convert to DataFrame
df = pd.DataFrame(all_data)

# # Filter out rows where URL is missing
# df = df[df['school.school_url'].notnull()]

# Save to CSV
df.to_csv("private_schools.csv", index=False)
print(df.head())

# unique_names = df['school.name'].dropna().unique()
# unique_names_df = pd.DataFrame(unique_names, columns=['school_name'])
# unique_names_df.to_csv("unique_college_names.csv", index=False)

# # Extract URLs and filter for uniqueness
# unique_urls = df['school.school_url'].dropna().unique()

# # Save to CSV
# unique_urls_df = pd.DataFrame(unique_urls, columns=['school_url'])
# unique_urls_df.to_csv("unique_college_urls.csv", index=False)

# print(unique_urls_df.head())