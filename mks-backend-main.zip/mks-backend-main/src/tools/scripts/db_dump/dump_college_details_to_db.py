import pandas as pd
import sys, os
from sqlalchemy import create_engine

# Add the project root directory to the Python path
home_dir = os.environ['DABBL_HOME']
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), home_dir)))

from db.database import SessionLocal, engine

# Load CSV data into a DataFrame
df = pd.read_csv('../findcollegesnew/findcolleges/majors.csv')

# Current columns in csv are:
# University,Major,Cost,Address,Phone,Website,Type
# Rename them to:
# source_url,major,cost,address,phone,website,type
df.rename(columns={
    'University': 'source_url',
    'Major': 'major',
    'Cost': 'cost',
    'Address': 'address',
    'Phone': 'phone',
    'Website': 'website',
    'Type': 'type'
}, inplace=True)

for column_name in ['source_url', 'major', 'address', 'phone', 'website', 'type']:
    print(column_name)
    df[column_name] = df[column_name].apply(lambda x: x.encode('utf-8').decode('utf-8'))

print("Finished encoding all columns")
DB_URL = os.environ['DB_URL'] + "?client_encoding=utf8"

engine = create_engine(DB_URL)

# Write the DataFrame to a PostgreSQL table
nrows = df.to_sql('college_details', engine, if_exists='replace', index=False)

if nrows > 0:
    print("CSV data successfully written to PostgreSQL table. Num rows: ", nrows)
else:
    print("No data was written to the table.")