import pandas as pd
import logging
import sys, os
from sqlalchemy import create_engine
from sshtunnel import SSHTunnelForwarder
from dotenv import load_dotenv, find_dotenv

_ = load_dotenv(find_dotenv())

# Add the project root directory to the Python path
home_dir = os.environ['DABBL_HOME']
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), home_dir)))

from db.database import SessionLocal, engine

# Configuration parameters
bastion_host = os.environ["BASTION_HOST"]
bastion_port = os.environ["BASTION_PORT"]
bastion_user = os.environ["BASTION_USER"]
bastion_key = os.environ["BASTION_ID_FILE"]

# get env
db_host = os.environ["DB_HOST"]
db_port = os.environ["DB_PORT"]
db_user = os.environ["DB_USER"]
db_password = os.environ["DB_PASSWORD"]
db_name = os.environ["DB_NAME"]

local_port = 5433

# Load CSV data into a DataFrame
df = pd.read_csv('./schools3.csv')

# Current columns in csv are:
# University,Major,Cost,Address,Phone,Website,Type
# Rename them to:
# source_url,major,cost,address,phone,website,type
df.rename(columns={
    'School Name': 'name',
    'Street Address': 'address',
    'City': 'city',
    'State': 'state',
    'ZIP': 'zip',
}, inplace=True)

df['type'] = 'High School'

for column_name in ['name', 'address', 'city', 'state', 'type']:
    print(column_name)
    df[column_name] = df[column_name].apply(lambda x: x.encode('utf-8').decode('utf-8'))

print("Finished encoding all columns")
DB_URL = os.environ['DB_URL'] + "?client_encoding=utf8"
print(DB_URL)

DB_URL = f"postgresql://{db_user}:{db_password}@localhost:{local_port}/{db_name}"
print(DB_URL)

# Configure logging
logging.basicConfig(level=logging.DEBUG)
# Configure logging for SQLAlchemy
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)
logger = logging.getLogger('sshtunnel')
logger.setLevel(logging.DEBUG)

print(df.head())

try:
    with SSHTunnelForwarder(
        (bastion_host, bastion_port),
        ssh_username=bastion_user,
        ssh_pkey=bastion_key,
        remote_bind_address=(db_host, db_port),
        local_bind_address=('localhost', local_port)
    ) as tunnel:
        tunnel.start()
        engine = create_engine(DB_URL)

        # Write the DataFrame to a PostgreSQL table
        nrows = df.to_sql('public.schools_master', engine, if_exists='replace', index=False)

        if nrows > 0:
            print("CSV data successfully written to PostgreSQL table. Num rows: ", nrows)
        else:
            print("No data was written to the table.")
except Exception as e:
    print(f"An error occurred: {e}")