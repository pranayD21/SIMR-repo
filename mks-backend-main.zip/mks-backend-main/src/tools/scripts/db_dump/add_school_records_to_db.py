import pandas as pd
import logging
import sys, os
import argparse
from sqlalchemy import MetaData, Table, create_engine
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sshtunnel import SSHTunnelForwarder
from dotenv import load_dotenv, find_dotenv

##############################################################################
################################ README ######################################
##############################################################################
# This script is to update the AWS RDS with data from a csv file.
# It is intended to be run from a different host (e.g. your own laptop). That
# is why it expects env variables for the BASTION HOST etc.
# 

def title_case(text):
    return ' '.join(word.capitalize() for word in text.split())

def upper_case(text):
    return ' '.join(word.upper() for word in str(text).split())

state_mapping = {
    'AL': 'Alabama', 'AK': 'Alaska', 'AZ': 'Arizona', 'AR': 'Arkansas',
    'CA': 'California', 'CO': 'Colorado', 'CT': 'Connecticut', 'DE': 'Delaware',
    'FL': 'Florida', 'GA': 'Georgia', 'HI': 'Hawaii', 'ID': 'Idaho',
    'IL': 'Illinois', 'IN': 'Indiana', 'IA': 'Iowa', 'KS': 'Kansas',
    'KY': 'Kentucky', 'LA': 'Louisiana', 'ME': 'Maine', 'MD': 'Maryland',
    'MA': 'Massachusetts', 'MI': 'Michigan', 'MN': 'Minnesota', 'MS': 'Mississippi',
    'MO': 'Missouri', 'MT': 'Montana', 'NE': 'Nebraska', 'NV': 'Nevada',
    'NH': 'New Hampshire', 'NJ': 'New Jersey', 'NM': 'New Mexico', 'NY': 'New York',
    'NC': 'North Carolina', 'ND': 'North Dakota', 'OH': 'Ohio', 'OK': 'Oklahoma',
    'OR': 'Oregon', 'PA': 'Pennsylvania', 'RI': 'Rhode Island', 'SC': 'South Carolina',
    'SD': 'South Dakota', 'TN': 'Tennessee', 'TX': 'Texas', 'UT': 'Utah',
    'VT': 'Vermont', 'VA': 'Virginia', 'WA': 'Washington', 'WV': 'West Virginia',
    'WI': 'Wisconsin', 'WY': 'Wyoming'
}

def convert_state(state):
    state = str(state).strip().upper()  # Remove whitespace and convert to uppercase
    if len(state) == 2:
        if state in state_mapping:
            return state_mapping[state].title()
        else:
            return state
    else:
        return state.title()

def get_flavor():
    # Set up the argument parser
    parser = argparse.ArgumentParser(description="An argument is needed to indicate which DB to update")
    parser.add_argument('--flavor', choices=['dev', 'prod'], required=True,
                    help='Specify the DB to update: dev or prod')

    try:
        # Parse the arguments
        args = parser.parse_args()
    except SystemExit:
        # This exception is raised when the parser encounters an error
        print("Error: The --flavor argument is required. Use either 'dev' or 'prod'.")
        sys.exit(1)

    # Parse the arguments
    args = parser.parse_args()
    env_filename = ''

    # Use the flavor in your script
    if args.flavor == 'dev':
        print("Running in development mode")
        env_filename = ".env_dev"
    elif args.flavor == 'prod':
        print("Running in production mode")
        env_filename = ".env_prod"
    else:
        # This exception is raised when the parser encounters an error
        print("Error: The --flavor argument is required. Use either 'dev' or 'prod'.")
        sys.exit(1)

    return env_filename

###########
# IMP: CHANGE THE ENV FILE DEPENDING ON WHICH DB TO UPDATE
###########
env_filename = get_flavor()
_ = load_dotenv(find_dotenv(filename=env_filename))

# Add the project root directory to the Python path
home_dir = os.environ['DABBL_HOME']
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), home_dir)))

from db.database import engine
    
# Configuration parameters
bastion_host = os.environ["BASTION_HOST"]
bastion_port = int(os.environ["BASTION_PORT"])
bastion_user = os.environ["BASTION_USER"]
bastion_key = os.environ["BASTION_ID_FILE"]

# get env
db_host = os.environ["DB_HOST"]
db_port = int(os.environ["DB_PORT"])
db_user = os.environ["DB_USER"]
db_password = os.environ["DB_PASSWORD"]
db_name = os.environ["DB_NAME"]

if not bastion_host or not bastion_port or not bastion_key or not bastion_user \
   or not db_host or not db_port or not db_user or not db_password or not db_user:
    print("Required environment variables are not set. Exiting...")
    print("Env variables needed to run this script:")
    print("BASTION_HOST, BASTION_PORT, BASTION_KEY, BASTION_USER")
    print("DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD")
    sys.exit(1)

local_port = 5433

# Load CSV data into a DataFrame
df = pd.read_csv('./High Schools - Public Schools.csv')

# Current columns in csv are:
# University,Major,Cost,Address,Phone,Website,Type
# Rename them to:
# source_url,major,cost,address,phone,website,type
df.rename(columns={
    'School Name': 'name',
    'Street Address': 'address',
    'City': 'city',
    'State': 'state',
    'ZIP': 'zip',
}, inplace=True)

df['type'] = 'High School'

for column_name in ['name', 'address', 'city']:
    print(column_name)
    df[column_name] = df[column_name].apply(lambda x: upper_case(x))
    df[column_name] = df[column_name].apply(lambda x: x.encode('utf-8').decode('utf-8'))

df['type'] = 'High School'
df['zip'] = df['zip'].apply(lambda x: str(x)) # convert to text

print("Before conversion ###############################")
print(df['state'])
df['state'] = df['state'].apply(lambda x: convert_state(x))

print("After conversion ###############################")
print(df['state'])

print("Finished encoding all columns")
DB_URL = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
print(DB_URL)

# Configure logging
logging.basicConfig(level=logging.DEBUG)
# Configure logging for SQLAlchemy
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)
logger = logging.getLogger('sshtunnel')
logger.setLevel(logging.DEBUG)

print(df.head())

try:
    with SSHTunnelForwarder(
        (bastion_host, bastion_port),
        ssh_username=bastion_user,
        ssh_pkey=bastion_key,
        remote_bind_address=(db_host, db_port)
        #local_bind_address=('localhost', local_port)
    ) as tunnel:
        tunnel.start()
        engine_url = f'postgresql://{db_user}:{db_password}@127.0.0.1:{tunnel.local_bind_port}/{db_name}'
        print("Engine url is ", engine_url)

        engine = create_engine(engine_url)

        # Write the DataFrame to a PostgreSQL table - works only if this is a new table being written to
        # nrows = df.to_sql('schools_main_new', engine, if_exists='append', index=False)

        # Create a connection
        with engine.connect() as connection:
            # Get the table metadata
            metadata = MetaData()
            schools_table = Table('schools_master', metadata, autoload_with=engine)

            # Convert DataFrame to list of dictionaries
            data = df.to_dict(orient='records')

            # Create the insert statement
            stmt = pg_insert(schools_table).values(data)

            input("Press Enter to continue...")

            # Add the ON CONFLICT DO NOTHING clause
            stmt = stmt.on_conflict_do_nothing(
                index_elements=['name', 'city', 'state']  # Replace with your unique column(s)
            )

            # Execute the statement
            result = connection.execute(stmt)
            connection.commit()

        nrows = result.rowcount

        if nrows > 0:
            print("CSV data successfully written to PostgreSQL table. Num rows: ", nrows)
        else:
            print("No data was written to the table.")
except Exception as e:
    print(f"An error occurred: {e}")