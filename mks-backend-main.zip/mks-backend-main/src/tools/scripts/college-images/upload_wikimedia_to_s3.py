import re
import uuid
import pandas as pd
import pywikibot
from pywikibot import pagegenerators
import requests
import csv
import boto3
from io import BytesIO
import os
from dotenv import load_dotenv
load_dotenv()

# Initialize S3 client
s3_client = boto3.client('s3',
    aws_access_key_id=os.environ.get("AWS_ACCESS_KEY"),
    aws_secret_access_key=os.environ.get("AWS_SECRET_KEY"),
    region_name=os.environ.get("APP_REGION")
)
bucket_name = os.environ.get("S3_COLLEGE_PICS_BUCKET")
# List of acceptable licenses
acceptable_licenses = [
    'public domain', 'cc-by-sa-4.0', 'cc-by-4.0', 'cc0', 'cc-by-sa-3.0', 'cc-by-3.0'
]
college_images = pd.DataFrame(columns=['college_name', 'image_path', 'file_id', 'source', 'license', 'author']) # list of college name, image path
num_recs = 0
csv_filename = ""

# Set up Pywikibot
site = pywikibot.Site("commons", "commons")  # Wikimedia Commons

def read_colleges_from_csv(file_path):
    colleges = []
    with open(file_path, mode='r', newline='', encoding='utf-8') as file:
        reader = csv.reader(file)
        for row in reader:
            colleges.append(row[0])
    return colleges

def search_images(college):
    url = "https://commons.wikimedia.org/w/api.php"
    params = {
        "action": "query",
        "format": "json",
        "list": "search",
        "srsearch": f"{college} filetype:bitmap",
        "srlimit": 20,
        "srnamespace": 6  # File namespace
    }
    response = requests.get(url, params=params)
    data = response.json()
    return data['query']['search']

def get_image_info(title):
    url = "https://commons.wikimedia.org/w/api.php"
    params = {
        "action": "query",
        "format": "json",
        "prop": "imageinfo|categories",
        "titles": title,
        "iiprop": "url|user|timestamp|size|mime",
        "cllimit": "max"
    }
    response = requests.get(url, params=params)
    data = response.json()
    pages = data['query']['pages']
    for page in pages.values():
        if 'imageinfo' in page:
            return page
    return None


def get_image_url(title):
    url = "https://commons.wikimedia.org/w/api.php"
    params = {
        "action": "query",
        "format": "json",
        "prop": "imageinfo",
        "titles": title,
        "iiprop": "url"
    }
    response = requests.get(url, params=params)
    data = response.json()
    pages = data['query']['pages']
    for page_id, page in pages.items():
        if 'imageinfo' in page:
            return page['imageinfo'][0]['url']
    return None

def download_and_upload_image(image_url, college, attributes):
    try:
        headers = {
            'User-Agent': 'dabbL/1.0 (dabbl@go-dabbl.ai) Python/3.8 requests/2.25.1'
        }
        response = requests.get(image_url, headers=headers)
        response.raise_for_status()  # Check if the request was successful
    
        image_content = response.content
        image_name = image_url.split('/')[-1]
        file_id = uuid.uuid4()
        s3_path = f"private-resources/{college}/{file_id}.jpg"  # Customize your S3 path as needed
        print(f"file: {file_id}; s3_path: {s3_path}")
        url = ''

        try:
            s3_client.upload_fileobj(
                BytesIO(image_content),
                bucket_name,
                s3_path,
                ExtraArgs={'Metadata': attributes,
                        'ContentDisposition': 'inline',
                        'ContentType': response.headers.get('Content-Type', '')}
            )
            # Generate a direct URL for the uploaded object
            url = f"https://{bucket_name}.s3.amazonaws.com/{s3_path}"

            print(f"Successfully uploaded to {url}")
            result = {
                'college': college,
                's3_path': s3_path,
                'url': url,
                'status': 'success',
                'error': ''
            }
            print(f"Successfully uploaded {s3_path} to S3")
        except Exception as e:
            print(f"Failed to upload {s3_path} to S3: {str(e)}")
            result = {
                    'college': college,
                    's3_path': s3_path,
                    'url': '',
                    'status': 'failed',
                    'error': str(e)
                }
        college_images.loc[len(college_images)] = [college,
                                                s3_path,
                                                url, # url in s3 
                                                attributes['source'], # source of image
                                                attributes['license'],
                                                attributes['author']]
    except Exception as e:
        print(f"Error downloading image: {e}")

# Function to check if the image has an acceptable license
def is_acceptable_license(page):
    categories = page.categories()
    for category in categories:
        category_title = category.title()
        for license in acceptable_licenses:
            if license in category_title.lower():
                return True
    return False

def get_license_from_categories(categories):
    for category in categories:
        category_title = category['title'].lower()
        for license in acceptable_licenses:
            if license in category_title:
                return license.upper()
    return "Unknown"

def ascii_encode_dict(data):
    ascii_dict = {}
    for key, value in data.items():
        if isinstance(value, str):
            ascii_dict[key] = value.encode('ascii', 'ignore').decode('ascii')
        else:
            ascii_dict[key] = str(value).encode('ascii', 'ignore').decode('ascii')
    return ascii_dict

def truncate_metadata(value, max_length=1024):
    return value[:max_length]

def sanitize_metadata(value):
    # Remove non-ASCII characters and replace newlines with spaces
    newvalue = re.sub(r'[^\x00-\x7F]+', '', value).replace('\n', ' ')
    return truncate_metadata(newvalue)

def get_image_attributes(image_page):
    latest_file_info = image_page.latest_file_info
    attributes = {
        'title': sanitize_metadata(image_page.title()),
        'source': image_page.get_file_url(),
        'description': sanitize_metadata(image_page.text),
        'author': sanitize_metadata(latest_file_info.user) if hasattr(latest_file_info, 'user') else 'Unknown',
        'mime': latest_file_info.mime if hasattr(latest_file_info, 'mime') else 'Unknown',
        'license': 'Unknown'  # You'll need to parse this from the description or use a specific method if available
    }
    
    # Try to extract license information from the file description
    if '{{cc-by-sa' in image_page.text.lower():
        attributes['license'] = 'CC-BY-SA'
    elif '{{cc-by' in image_page.text.lower():
        attributes['license'] = 'CC-BY'
    elif '{{pd' in image_page.text.lower():
        attributes['license'] = 'Public Domain'
    
    return attributes


def main():
    filename = "colleges5-5"
    csv_filename = f"{filename}_images_upload_results.csv"
    colleges = read_colleges_from_csv(f'{filename}.csv')
    for college in colleges:
        search_query = f"{college}"
        generator = pagegenerators.SearchPageGenerator(search_query, namespaces=[6], total=20, site=site)
        image_cnt = 0
        # Download full-resolution images
        for page in generator:
            if page.namespace() == 6:  # File namespace (images)
                image_title = page.title()
                #print(f"Checking image: {image_title}")
                image_page = pywikibot.FilePage(site, image_title)
                if is_acceptable_license(image_page):
                    #location = path
                    attributes = get_image_attributes(image_page)
                    ascii_attributes = ascii_encode_dict(attributes)
                    image_cnt += 1
                    image_file_url = image_page.get_file_url()
                    if image_file_url:
                        download_and_upload_image(image_file_url, college, ascii_attributes)

    # Check if the file exists
    file_exists = os.path.isfile(csv_filename)
    college_images.to_csv(csv_filename, mode='a',  # Append mode
                          header=not file_exists,  # Write header only if file doesn't exist
                          index=False)

if __name__ == "__main__":
    main()