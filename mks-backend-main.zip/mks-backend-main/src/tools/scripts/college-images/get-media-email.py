import re
from googleapiclient.discovery import build
from bs4 import BeautifulSoup
import pandas as pd
import requests
import os
from dotenv import load_dotenv, find_dotenv

_ = load_dotenv(find_dotenv())

universities = []
with open("../nces_colleges/unique_college_names.csv", "r") as f:
    universities = f.readlines()

media_info = pd.DataFrame(columns=['university', 'media_contact'])
def search_google(query):
    service = build("customsearch", "v1", developerKey=os.environ["GOOGLE_CUSTOM_SEARCH_KEY"])
    result = service.cse().list(q=query, cx=os.environ["GOOGLE_CUSTOM_SEARCH_CONTEXT"]).execute()
    return result.get("items", [])

def extract_email(html):
    soup = BeautifulSoup(html, 'html.parser')
    email = soup.find('a', text=re.compile(r'media contact|email'))
    if email:
        return email.text
    else:
        return None

for university in universities:
    query = f"{university} media contact"
    try:
        results = search_google(query)
        for result in results:
            url = result.get("link", "")
            html = requests.get(url).text
            email = extract_email(html)

            if email:
                print(f"{university}: {email}")
                media_info.loc[len(media_info)] = [university, email]            
    except Exception as e:
        print(f"Error searching for {university}: {str(e)}")

media_info.to_csv("media_contacts.csv", index=False)

