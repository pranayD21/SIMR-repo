import os
import re
import boto3
from typing import List
import os, sys
import requests
import pandas as pd
from io import BytesIO
from PIL import Image

from dotenv import load_dotenv, find_dotenv
_ = load_dotenv(find_dotenv(filename=".env"))

# Add the project root directory to the Python path
home_dir = os.environ['DABBL_HOME']
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), home_dir)))

from db.database import SessionLocal, engine

# Initialize the S3 client
s3_client = boto3.client('s3',
                         aws_access_key_id=os.environ["AWS_ACCESS_KEY"],
                         aws_secret_access_key=os.environ["AWS_SECRET_KEY"],
                         region_name=os.environ["APP_REGION"])

def download_image(url):
    try:
        # Send a GET request to the Google Drive link
        response = requests.get(url, allow_redirects=True)
        response.raise_for_status()

        # Check if we've been redirected to a Google Drive download page
        if 'drive.google.com' in response.url:
            # Extract the file ID from the URL
            file_id = url.split('/')[-2]
            # Construct the direct download link
            direct_url = f"https://drive.google.com/uc?export=download&id={file_id}"
            # Send another GET request to the direct download link
            response = requests.get(direct_url, allow_redirects=True)
            response.raise_for_status()
            
        # Open the image using Pillow
        img = Image.open(BytesIO(response.content))
        
        # Convert to RGB mode if it's not already (this handles PNG with transparency)
        if img.mode != 'RGB':
            img = img.convert('RGB')
        
        # Save as JPEG to a BytesIO object
        jpeg_io = BytesIO()
        img.save(jpeg_io, format='JPEG', quality=85)
        jpeg_io.seek(0)
        
        print(f"Successfully downloaded and converted image from {url}")
        return jpeg_io, 'image/jpeg'
    
    except Exception as e:
        print(f"Failed to download or process image from {url}: {str(e)}")
        return None, None
    
        # content = response.content
        # kind = filetype.guess(content)
        # file_type = kind.mime if kind else 'application/octet-stream'
        # return BytesIO(content), file_type
        # else:
        #     print(f"Failed to download {url}")
        #     return None, None

def upload_to_s3(file_obj, bucket_name, s3_path, file_type):
    try:
        content_type = file_type
        # if content_type is None:
        #     content_type = 'application/octet-stream'

        print(f"content type is {content_type}")
        # Set the Content-Disposition header for inline display
        extra_args = {
            'ContentDisposition': 'inline',
            'ContentType': content_type  # Adjust this based on your image type
            #'ACL': 'public-read'  # Make the object publicly readable
        }

        s3_client.upload_fileobj(
            file_obj, 
            bucket_name, 
            s3_path,
            ExtraArgs=extra_args
        )

        # Generate a direct URL for the uploaded object
        url = f"https://{bucket_name}.s3.amazonaws.com/{s3_path}"

        print(f"Successfully uploaded to {url}")
        return url

    except Exception as e:
        print(f"Error uploading to S3: {str(e)}")
        return None

    # try:
    #     s3_client.upload_fileobj(file_obj, bucket_name, s3_path)
    #     print(f"Successfully uploaded to {bucket_name}/{s3_path}")
    #     s3_url = f"s3://{bucket_name}/{s3_path}"
    #     return s3_url
    # except Exception as e:
    #     print(f"Error uploading to S3: {str(e)}")
    #     return None

def extract_file_id(link):
    file_id_match = re.search(r'/d/([a-zA-Z0-9_-]+)', link)
    if file_id_match:
        return file_id_match.group(1)
    return None

def process_images(df, bucket_name):
    results = []
    for index, row in df.iterrows():
        college_name = row['University']
        link = row['Google Drive Picture link']
        file_id = extract_file_id(link)
        if file_id:
            file_obj, file_type = download_image(link)
            if file_obj and file_type:
                s3_path = f"private-resources/{college_name}/{file_id}.jpg"  # Customize your S3 path as needed
                print(f"file: {file_id}; s3_path: {s3_path}")

                print(f"Uploading file {file_id}")
                s3_url = upload_to_s3(file_obj, bucket_name, s3_path, file_type)
                if s3_url:
                    results.append({
                        "College Name": college_name,
                        "Original Link": link,
                        "S3 Path": s3_url
                    })
                else:
                    print(f"Index: {index}; College: {college_name}; Failed to upload image")

    return results

# Your S3 bucket name
bucket_name = os.environ["S3_COLLEGE_PICS_BUCKET"]

df = pd.read_csv("./college-links.csv")

# Process the images and get the results
results = process_images(df, bucket_name)

# Convert results to a DataFrame and save to a CSV file
df = pd.DataFrame(results)
df.to_csv('uploaded_images.csv', index=False)

print("All images processed and results saved to uploaded_images.csv")

# def upload_files(
#     local_directory: str,
# ):
#     # Your S3 client setup
#     # s3_client = boto3.client('s3',
#     #                          aws_access_key_id=os.environ["AWS_ACCESS_KEY"],
#     #                          aws_secret_access_key=os.environ["AWS_SECRET_KEY"],
#     #                          region_name=os.environ["AWS_REGION"])

#     bucket_name = os.environ["S3_COLLEGE_PICS_BUCKET"]

#     # def upload_file_to_s3(local_path, filename):
#     #     try:
#     #         s3_client.upload_file(local_path, bucket_name, filename)
#     #         return f"Successfully uploaded {filename}"
#     #     except Exception as e:
#     #         return f"Error uploading {filename}: {str(e)}"

#     results = []
#     for root, dirs, files in os.walk(local_directory):
#         for file in files:
#             local_path = os.path.join(root, file)
            
#             # Get the relative path of the file
#             relative_path = os.path.relpath(local_path, local_directory)
        
#             # Get the directory part of the relative path
#             relative_dir = os.path.dirname(relative_path)
        
#             # If you want an empty string instead of '.' for files in the root directory
#             if relative_dir == '.':
#                 relative_dir = ''

#             key = "private-resources/" + relative_dir + "/" + file
#             # result = upload_file_to_s3(local_path, key)
#             # results.append(result)
#             print("Local path is: ", local_path, "; Bucket name: ", bucket_name, "; key is: ", key)

#     return {"results": results}

# upload_files("/Users/sirishakaipa/Downloads/dump/")