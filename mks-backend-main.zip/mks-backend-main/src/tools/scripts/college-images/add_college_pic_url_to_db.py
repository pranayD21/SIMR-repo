import re
import pandas as pd
import logging
import sys, os
import argparse
from sqlalchemy import MetaData, Table, create_engine, update
from sqlalchemy.dialects.postgresql import insert as pg_insert
from sshtunnel import SSHTunnelForwarder
from dotenv import load_dotenv, find_dotenv

##############################################################################
################################ README ######################################
##############################################################################
# This script is to update the AWS RDS with data from a csv file.
# It is intended to be run from a different host (e.g. your own laptop). That
# is why it expects env variables for the BASTION HOST etc.
# 

def clean_college_name(name):
    # Remove numbering at the start (e.g., "1. ")
    name = re.sub(r'^\d+\.\s*"', '', name)
    # Remove any leading and trailing quotation marks or whitespaces
    name = re.sub(r'^[\s"]+|[\s"]+$', '', name)
    return name

def get_flavor():
    # Set up the argument parser
    parser = argparse.ArgumentParser(description="An argument is needed to indicate which DB to update")
    parser.add_argument('--flavor', choices=['dev', 'prod'], required=True,
                    help='Specify the DB to update: dev or prod')

    try:
        # Parse the arguments
        args = parser.parse_args()
    except SystemExit:
        # This exception is raised when the parser encounters an error
        print("Error: The --flavor argument is required. Use either 'dev' or 'prod'.")
        sys.exit(1)

    # Parse the arguments
    args = parser.parse_args()
    env_filename = ''

    # Use the flavor in your script
    if args.flavor == 'dev':
        print("Running in development mode")
        env_filename = ".env_dev"
    elif args.flavor == 'prod':
        print("Running in production mode")
        env_filename = ".env_prod"
    else:
        # This exception is raised when the parser encounters an error
        print("Error: The --flavor argument is required. Use either 'dev' or 'prod'.")
        sys.exit(1)

    return env_filename

###########
# IMP: CHANGE THE ENV FILE DEPENDING ON WHICH DB TO UPDATE
###########
env_filename = get_flavor()
_ = load_dotenv(find_dotenv(filename=env_filename))

# Add the project root directory to the Python path
home_dir = os.environ['DABBL_HOME']
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), home_dir)))

from db.database import engine
    
# Configuration parameters
bastion_host = os.environ["BASTION_HOST"]
bastion_port = int(os.environ["BASTION_PORT"])
bastion_user = os.environ["BASTION_USER"]
bastion_key = os.environ["BASTION_ID_FILE"]

# get env
db_host = os.environ["DB_HOST"]
db_port = int(os.environ["DB_PORT"])
db_user = os.environ["DB_USER"]
db_password = os.environ["DB_PASSWORD"]
db_name = os.environ["DB_NAME"]

if not bastion_host or not bastion_port or not bastion_key or not bastion_user \
   or not db_host or not db_port or not db_user or not db_password or not db_user:
    print("Required environment variables are not set. Exiting...")
    print("Env variables needed to run this script:")
    print("BASTION_HOST, BASTION_PORT, BASTION_KEY, BASTION_USER")
    print("DB_HOST, DB_PORT, DB_NAME, DB_USER, DB_PASSWORD")
    sys.exit(1)

local_port = 5433

# Load CSV data into a DataFrame
df = pd.read_csv('./uploaded_images.csv')

# Current columns in csv are:
# College Name,Original Link,S3 Path
df.rename(columns={
    'College Name': 'college_name',
    'S3 Path': 'college_pic_url'
}, inplace=True)

df['college_name'] = df['college_name'].apply(lambda x: clean_college_name(x))
df.drop('Original Link', axis=1, inplace=True)
DB_URL = f"postgresql://{db_user}:{db_password}@{db_host}:{db_port}/{db_name}"
print(DB_URL)

# Configure logging
logging.basicConfig(level=logging.DEBUG)
# Configure logging for SQLAlchemy
logging.getLogger('sqlalchemy.engine').setLevel(logging.INFO)
logger = logging.getLogger('sshtunnel')
logger.setLevel(logging.DEBUG)

print(df.head())
try:
    with SSHTunnelForwarder(
        (bastion_host, bastion_port),
        ssh_username=bastion_user,
        ssh_pkey=bastion_key,
        remote_bind_address=(db_host, db_port)
        #local_bind_address=('localhost', local_port)
    ) as tunnel:
        tunnel.start()
        engine_url = f'postgresql://{db_user}:{db_password}@127.0.0.1:{tunnel.local_bind_port}/{db_name}'
        print("Engine url is ", engine_url)

        engine = create_engine(engine_url)

        # Write the DataFrame to a PostgreSQL table - works only if this is a new table being written to
        nrows = df.to_sql('target_schools_main', engine, if_exists='append', index=False)

        if nrows > 0:
            print("CSV data successfully written to PostgreSQL table. Num rows: ", nrows)
        else:
            print("No data was written to the table.")
except Exception as e:
    print(f"An error occurred: {e}")