import datetime
import re
import pandas as pd
import pywikibot
from pywikibot import pagegenerators
import requests
import os

# Set up Pywikibot
site = pywikibot.Site("commons", "commons")  # Wikimedia Commons

# Set the image download directory
download_dir = "~/Google\ Drive/My\ Drive/college-pics/dump"

# read college urls from a file and loop through the below for each college
with open("./colleges_200.data", "r") as f:
    colleges = f.readlines()

# Create the download directory if it doesn't exist
if not os.path.exists(download_dir):
    os.makedirs(download_dir)

# List of acceptable licenses
acceptable_licenses = [
    'public domain', 'cc-by-sa-4.0', 'cc-by-4.0', 'cc0', 'cc-by-sa-3.0', 'cc-by-3.0'
]

# Function to check if the image has an acceptable license
def is_acceptable_license(page):
    categories = page.categories()
    for category in categories:
        category_title = category.title()
        for license in acceptable_licenses:
            if license in category_title.lower():
                return True
    return False
    
cnt = 0
college_info = pd.DataFrame(columns=['college_name', 'image_count'])
for college in colleges:
    college = college.strip()
    # Create the download directory if it doesn't exist
    path = f"{download_dir}/{college}"
    bkup_path = f"{path}/backup"
    if not os.path.exists(path):
        os.makedirs(path)
        os.makedirs(bkup_path)

    search_query = f"{college}"
    generator = pagegenerators.SearchPageGenerator(search_query, namespaces=[6], total=20, site=site)
    cnt += 1
    if cnt % 10 == 0:
        print(f"Got details for {cnt} colleges")

    image_cnt = 0
    # Download full-resolution images
    for page in generator:
        if page.namespace() == 6:  # File namespace (images)
            image_title = page.title()
            #print(f"Checking image: {image_title}")
            image_page = pywikibot.FilePage(site, image_title)
            if is_acceptable_license(image_page):
                location = path

                image_cnt += 1
                image_file_url = image_page.get_file_url()
                if image_file_url:
                    image_path = os.path.join(location, image_title.replace("File:", "").replace(":", "_"))
                    try:
                        headers = {
                            'User-Agent': 'dabbL/1.0 (dabbl@go-dabbl.ai) Python/3.8 requests/2.25.1'
                        }
                        response = requests.get(image_file_url, headers=headers)
                        response.raise_for_status()  # Check if the request was successful
                        with open(image_path, "wb") as f:
                            f.write(response.content)
                        print(f"Image downloaded: {image_path}")
                    except Exception as e:
                        print(f"Error downloading image: {e}")
            
    print(f"Total images found for {search_query}: {image_cnt}")
    college_info.loc[len(college_info)] = [search_query, image_cnt]

college_info.to_csv("college_images_info.csv", index=False)