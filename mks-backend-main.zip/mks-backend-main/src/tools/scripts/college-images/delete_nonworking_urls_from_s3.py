import boto3
from urllib.parse import urlparse
import pandas as pd
import os
from dotenv import load_dotenv
load_dotenv()

s3 = boto3.client('s3',
                  aws_access_key_id=os.environ.get("AWS_ACCESS_KEY"),
                  aws_secret_access_key=os.environ.get("AWS_SECRET_KEY"),
                  region_name=os.environ.get("APP_REGION")
                )
bucket_name = os.environ.get("S3_COLLEGE_PICS_BUCKET")

df = pd.read_csv("colleges_images_upload_results.csv")
urls_to_delete = df['file_id']

failed_urls = pd.DataFrame(columns=['url'])

for url in urls_to_delete:
    try:
        # Parse the URL to get the bucket name and object key
        parsed_url = urlparse(url)
        bucket_name = parsed_url.netloc.split('.')[0]
        object_key = parsed_url.path.lstrip('/')
        
        try:
            # Delete the object
            s3.delete_object(Bucket=bucket_name, Key=object_key)
            print(f"Deleted {url}")
        except Exception as e:
            print(f"Error deleting {url}: {str(e)}")
    except Exception as e:
        print(f"Error in parsing the url {url}")
        failed_urls.loc[len(failed_urls)] = [url]

failed_urls.to_csv("urls_to_delete.csv")
