import datetime
import mimetypes
import re
import pandas as pd
import pywikibot
from pywikibot import pagegenerators
import requests
import os
import boto3
from typing import List
import sys
import requests
from io import BytesIO
from PIL import Image

from dotenv import load_dotenv, find_dotenv
_ = load_dotenv(find_dotenv(filename=".env"))

# Add the project root directory to the Python path
home_dir = os.environ['DABBL_HOME']
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), home_dir)))

from db.database import SessionLocal, engine

# Initialize the S3 client
s3_client = boto3.client('s3',
                         aws_access_key_id=os.environ["AWS_ACCESS_KEY"],
                         aws_secret_access_key=os.environ["AWS_SECRET_KEY"],
                         region_name=os.environ["APP_REGION"])


def upload_to_s3(file_obj, bucket_name, s3_path, file_type, metadata):
    try:
        content_type = file_type
        print(f"content type is {content_type}")
        # Set the Content-Disposition header for inline display
        extra_args = {
            "Metadata": metadata,
            'ContentDisposition': 'inline',
            'ContentType': content_type  # Adjust this based on your image type
        }

        s3_client.upload_fileobj(
            file_obj, 
            bucket_name, 
            s3_path,
            ExtraArgs=extra_args
        )

        # Generate a direct URL for the uploaded object
        url = f"https://{bucket_name}.s3.amazonaws.com/{s3_path}"

        print(f"Successfully uploaded to {url}")
        return url

    except Exception as e:
        print(f"Error uploading to S3: {str(e)}")
        return None

def read_file_as_jpg(image_path: str):
    # Open the image using Pillow
    img = Image.open(image_path)
    
    # Convert to RGB mode if it's not already (this handles PNG with transparency)
    if img.mode != 'RGB':
        img = img.convert('RGB')
    
    # Save as JPEG to a BytesIO object
    jpeg_io = BytesIO()
    img.save(jpeg_io, format='JPEG', quality=85)
    jpeg_io.seek(0)

    return jpeg_io

def process_images(df, bucket_name):
    results = []
    for index, row in df.iterrows():
        college_name = row['college_name']
        file_id = row['file_id']
        image_path = row['image_path']
        # Prepare metadata
        metadata = {
            'Author': df['author'],
            'License': df['license'],
            'Source': df['url']
        }

        s3_path = f"private-resources/{college_name}/{file_id}.jpg"  # Customize your S3 path as needed
        print(f"file: {file_id}; s3_path: {s3_path}")
        file_obj = read_file_as_jpg(image_path)

        print(f"Uploading file {file_id}")
        s3_url = upload_to_s3(file_obj, bucket_name, s3_path, 'image/jpeg', metadata)
        if s3_url:
            results.append({
                "College Name": college_name,
                "S3 Path": s3_url
            })
        else:
            print(f"Index: {index}; College: {college_name}; Failed to upload image")

    return results

# Set up Pywikibot
site = pywikibot.Site("commons", "commons")  # Wikimedia Commons

# # Set the image download directory
# download_dir = "~/Google\ Drive/My\ Drive/college-pics/dump"

# read college urls from a file and loop through the below for each college
with open("./colleges_200.data", "r") as f:
    colleges = f.readlines()

# # Create the download directory if it doesn't exist
# if not os.path.exists(download_dir):
#     os.makedirs(download_dir)

# List of acceptable licenses
acceptable_licenses = [
    'public domain', 'cc-by-sa-4.0', 'cc-by-4.0', 'cc0', 'cc-by-sa-3.0', 'cc-by-3.0'
]

# Function to check if the image has an acceptable license
def is_acceptable_license(page):
    categories = page.categories()
    for category in categories:
        category_title = category.title()
        for license in acceptable_licenses:
            if license in category_title.lower():
                return True
    return False

def get_image_attributes(image_page):
    attributes = {
        'title': image_page.title(),
        'url': image_page.get_file_url(),
        'description': image_page.text,
        'author': image_page.latest_file_info.get('user', 'Unknown'),
        'timestamp': image_page.latest_file_info.get('timestamp', 'Unknown'),
        'size': image_page.latest_file_info.get('size', 'Unknown'),
        'width': image_page.latest_file_info.get('width', 'Unknown'),
        'height': image_page.latest_file_info.get('height', 'Unknown'),
        'mime': image_page.latest_file_info.get('mime', 'Unknown'),
        'license': 'Unknown'  # You'll need to parse this from the description or use a specific method if available
    }
    
    # Try to extract license information from the file description
    if '{{cc-by-sa' in image_page.text.lower():
        attributes['license'] = 'CC-BY-SA'
    elif '{{cc-by' in image_page.text.lower():
        attributes['license'] = 'CC-BY'
    elif '{{pd' in image_page.text.lower():
        attributes['license'] = 'Public Domain'
    
    return attributes

cnt = 0
college_info = pd.DataFrame(columns=['college_name', 'image_count'])
college_images = pd.DataFrame(columns=['college_name', 'image_path', 'file_id', 'source', 'license', 'author']) # list of college name, image path

for college in colleges:
    college = college.strip()
    # Create the download directory if it doesn't exist
    path = f"{download_dir}/{college}"
    bkup_path = f"{path}/backup"
    if not os.path.exists(path):
        os.makedirs(path)
        os.makedirs(bkup_path)

    search_query = f"{college}"
    generator = pagegenerators.SearchPageGenerator(search_query, namespaces=[6], total=20, site=site)
    cnt += 1
    if cnt % 10 == 0:
        print(f"Got details for {cnt} colleges")

    image_cnt = 0
    # Download full-resolution images
    for page in generator:
        if page.namespace() == 6:  # File namespace (images)
            image_title = page.title()
            #print(f"Checking image: {image_title}")
            image_page = pywikibot.FilePage(site, image_title)
            if is_acceptable_license(image_page):
                location = path
                attributes = get_image_attributes(image_page)

                image_cnt += 1
                image_file_url = image_page.get_file_url()
                if image_file_url:
                    # Guess the file type based on the URL
                    mime_type, _ = mimetypes.guess_type(image_file_url)
                    if mime_type:
                        extension = mimetypes.guess_extension(mime_type)
                    else:
                        extension = ".jpg"  # Default to .jpg if the type cannot be determined

                    image_path = os.path.join(location, image_title.replace("File:", "").replace(":", "_"))
                    try:
                        headers = {
                            'User-Agent': 'dabbL/1.0 (dabbl@go-dabbl.ai) Python/3.8 requests/2.25.1'
                        }
                        response = requests.get(image_file_url, headers=headers)
                        response.raise_for_status()  # Check if the request was successful
                        with open(image_path, "wb") as f:
                            f.write(response.content)
                        print(f"Image downloaded: {image_path}")
                        file_id = "file" + image_cnt + extension
                        college_images.loc[len(college_images)] = [search_query,
                                                                   image_path,
                                                                   file_id,
                                                                   attributes['url'],
                                                                   attributes['license'],
                                                                   attributes['author']]
                    except Exception as e:
                        print(f"Error downloading image: {e}")
            
    print(f"Total images found for {search_query}: {image_cnt}")
    college_info.loc[len(college_info)] = [search_query, image_cnt]

college_info.to_csv("college_images_info.csv", index=False)
college_images.to_csv("college_images_downloaded.csv", index=False)

#Upload these images to S3

# Your S3 bucket name
bucket_name = os.environ["S3_COLLEGE_PICS_BUCKET"]

#df = pd.read_csv("./college-links.csv")

# Process the images and get the results
results = process_images(college_images, bucket_name)

# Convert results to a DataFrame and save to a CSV file
df = pd.DataFrame(results)
df.to_csv('uploaded_images.csv', index=False)

print("All images processed and results saved to uploaded_images.csv")
