#!/bin/bash

# This script is used to run the jobs scrapers every week

# Make a timestamp

echo "Running jobs scraper at $(date)"

# Set the project directory
PROJECT_DIR="/home/ubuntu/buddybot-server/mks-backend"

# Activate the virtual environment at $> source ~/buddybot-server/py310/bin/activate
source /home/ubuntu/buddybot-server/py310/bin/activate || { echo "Error activating virtual environment"; exit 1; }

# Change directory to the news scrapers directory
cd "$PROJECT_DIR/src/tools/scripts/job_scraping/standoutsearch/standoutsearch/spiders" || { echo "Directory not found"; exit 1; }

# Run the jobs spider script 
scrapy crawl standout_search_spider || { echo "Error running jobs scraper"; exit 1; }

# Deactivate the virtual environment
deactivate || { echo "Error deactivating virtual environment"; exit 1; }

echo "Jobs scraper ran successfully"