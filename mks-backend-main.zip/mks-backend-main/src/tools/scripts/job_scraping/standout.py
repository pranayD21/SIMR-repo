import time
import json
import spacy
import os
import sys
from selenium import webdriver
from selenium.common.exceptions import ElementClickInterceptedException
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
from sqlalchemy.orm import Session

# Use the DABBL_HOME environment variable for the project root
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../src"))
sys.path.append(project_root)

from db.database import SessionLocal
from db.crud import create_job, get_job_by_title_and_org, get_jobs
from db.schemas import JobCreate

# Initialize spaCy
nlp = spacy.load("en_core_web_sm")

# List of keywords for NLP
keywords = [
    "internship", "program", "volunteer", "scholarship", "workshop", "research", "summer camp",
    "fellowship", "competition", "hackathon", "leadership", "mentorship", "community service",
    "apprenticeship", "training", "course", "STEM", "coding", "robotics", "science", "technology",
    "engineering", "mathematics", "arts", "humanities", "sports", "athletics", "debate",
    "public speaking", "writing", "journalism", "creative writing", "theater", "music", "choir",
    "band", "orchestra", "dance", "art", "painting", "drawing", "sculpture", "photography",
    "graphic design", "animation", "film", "video production", "computer science", "programming",
    "web development", "app development", "game development", "cybersecurity", "AI",
    "machine learning", "data science", "biology", "chemistry", "physics", "environmental science",
    "health", "medicine", "nursing", "pre-med", "biotechnology", "neuroscience",
    "psychology", "sociology", "economics", "business", "entrepreneurship", "finance",
    "marketing", "management", "law", "advocacy", "government", "politics", "public policy",
    "international relations", "cultural exchange", "language", "foreign language",
    "diversity", "inclusion", "social justice", "sustainability", "conservation", "ecology"
]

# Chrome WebDriver for Selenium
service = ChromeService(executable_path=ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)

url = 'https://standoutsearch.com'
driver.get(url)

filters = ['Medicine', 'Engineering', 'Science', 'Computer Science', 'Arts', 'Business', 'Law/Advocacy', 'Government', 'Nonprofit', 'Museum', 'Education', 'Environment', 'Writing', 'Psychology', 'Architecture']
opportunities = []

age_dropdown = WebDriverWait(driver, 10).until(
    EC.presence_of_element_located(
        (By.XPATH, '/html/body/div[1]/div/div/div/div[1]/div[2]/div/div[1]/div/div[2]/div[2]/div')
    )
)

def click_element_with_retry(element, max_attempts=2):
    attempts = 0
    while attempts < max_attempts:
        try:
            element.click()
            return True
        except ElementClickInterceptedException:
            time.sleep(1)
            attempts += 1
    return False

def analyze_keywords(text):
    doc = nlp(text.lower())
    found_keywords = set()
    for token in doc:
        if token.lemma_ in keywords:
            found_keywords.add(token.lemma_)
    return list(found_keywords)

def upload_to_db(opportunity, db_session):
    existing_job = get_job_by_title_and_org(db_session, opportunity['title'], opportunity['organization'])
    if existing_job:
        print(f"Job already exists: {opportunity['title']}")
    else:
        job_data = JobCreate(**opportunity)
        create_job(db_session, job_data)
        print(f"Uploaded: {opportunity['title']}")

for age in filters:
    print(age)
    driver.get(url)
    age_dropdown = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located(
            (By.XPATH, '/html/body/div[1]/div/div/div/div[1]/div[2]/div/div[1]/div/div[2]/div[4]/div/div/div[2]/div')
        )
    )
    age_dropdown.click()
    time.sleep(1)
    dropdown_menu = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.CLASS_NAME, 'css-3v07ki-menu'))
    )
    ee = dropdown_menu.find_element(By.XPATH, f'.//*[text()="{age}"]')
    driver.execute_script("arguments[0].scrollIntoView(true);", ee)
    ee.click()
    time.sleep(1)

    seen_titles = set()
    i = 0

    while True:
        listings_container = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located(
                (By.XPATH, '/html/body/div[1]/div/div/div/div[1]/div[2]/div/div[2]/div/div/div/div[1]/div')
            )
        )
        listings = listings_container.find_elements(By.XPATH, './div')

        new_listings = []

        for listing in listings:
            if i >= 150:
                break
            title_element = listing.find_element(By.XPATH, './/p[1]') 
            title = title_element.text
            if title not in seen_titles:
                seen_titles.add(title)
                new_listings.append(listing)

        if not new_listings:
            break

        for listing in new_listings:
            print("Clicking on listing:", listing.text)
            listing.click()
            popup_content = WebDriverWait(driver, 30).until(
                    EC.presence_of_element_located(
                        (By.XPATH, '/html/body/div[3]')
                    )
                )
            print("Popup content loaded successfully.")
            
            print("after pop up")
            get_url = driver.current_url
            print(get_url)

            pop_up_html = driver.page_source
            soup = BeautifulSoup(pop_up_html, 'html.parser')

            def get_field(label):
                element = soup.find(string=label)
                if element:
                    return element.find_next().text.strip()
                return ""
            
            def get_list(str):
                l = []
                listlabel = soup.find('p', string=str)
                if listlabel:
                    ul_element = listlabel.find_next('ul')
                    if ul_element:
                        li_elements = ul_element.find_all('li')
                        l = [li.get_text(strip=True) for li in li_elements]
                return l
            
            def get_deadline(soup, title):
                title_element = soup.find(string=title)
                if title_element:
                    deadline_element = title_element.find_next('ul', class_='chakra-wrap__list')
                    if deadline_element:
                        li_elements = deadline_element.find_all('li')
                        if li_elements:
                            return [li.get_text(strip=True) for li in li_elements]
                return ["Contact/Check Website For Deadline"]

            def get_apply_link(soup):
                apply_link_element = soup.find('a', class_='chakra-link chakra-button css-x297hf')
                if apply_link_element:
                    return apply_link_element['href']
                return ""

            title = driver.find_element(By.XPATH, '/html/body/div[3]/div[3]/div/section/div/div/div[1]/div/div[1]/div/div/div[2]/p[1]').text
            organization = driver.find_element(By.XPATH, '/html/body/div[3]/div[3]/div/section/div/div/div[1]/div/div[1]/div/div/div[2]/p[1]').text
            deadline = get_deadline(soup, title)
            description = get_field("Description:")  # Ensure this is a string, not a tuple
            apply_link = get_apply_link(soup)

            keywords_found = analyze_keywords(title + " " + description)

            opportunity = {
                "title": title,
                "organization": organization,
                "deadline": ', '.join(deadline),
                "area": age,
                "age": ', '.join(get_list("Age:")),
                "season": ', '.join(get_list("Season:")),
                "eligibility": get_field("This Opportunity is Only Open To:"),
                "description": description,
                "requirements": get_field("Requirements:"),
                "mode": ', '.join(get_list("Mode:")),
                "location": ', '.join(get_list("Location:")),
                "address": get_field("Address:"),
                "salary": ', '.join(get_list("Salary:")),
                "program_fee": get_field("Program Fee/Tuition:"),
                "keywords": keywords_found,
                "link": apply_link,
                "listing_type": ""
            }

            opportunities.append(opportunity)
            print(opportunity)
            i += 1

            db = SessionLocal()
            try:
                upload_to_db(opportunity, db)
            finally:
                db.close()

            close_button = driver.find_element(By.XPATH, '/html/body/div[3]/div[3]/div/section/header/div/button')
            close_button.click()

        if i >= 100:
            break

        try:
            view_more_button = driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[1]/div[2]/div/div[2]/div/div/div/div[2]/button')
            if view_more_button:
                driver.execute_script("window.scrollTo(0, arguments[0].getBoundingClientRect().top + window.scrollY - 150);", view_more_button)
                time.sleep(1)
                view_more_button.click()
                time.sleep(2)
            else:
                break
        except:
            break

    cancelout = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable(
            (By.XPATH, '/html/body/div[1]/div/div/div/div[1]/div[2]/div/div[1]/div/div[2]/div[2]/div/div/div[2]/div[1]')
        )
    )
    driver.execute_script("arguments[0].scrollIntoView(true);", cancelout)
    if not click_element_with_retry(cancelout):
        driver.execute_script("arguments[0].scrollIntoView(true); window.scrollBy(0, -100);", age_dropdown)

driver.quit()