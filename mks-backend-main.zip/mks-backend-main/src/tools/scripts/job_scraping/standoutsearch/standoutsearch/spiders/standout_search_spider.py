import os
import sys
import asyncio
from twisted.internet import asyncioreactor
asyncioreactor.install(asyncio.get_event_loop())
import scrapy
import json
import urllib.parse
import spacy
from sqlalchemy.orm import Session
from dotenv import load_dotenv, find_dotenv
from datetime import datetime
import dateutil.parser as dparser

_ = load_dotenv(find_dotenv()) 

# Load project root
project_root = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../../../../../src"))
sys.path.append(project_root)

from db.database import SessionLocal
from db.crud import create_job, get_job_by_title_and_org, delete_outdated_jobs
from db.schemas import JobCreate

# Initialize spaCy
nlp = spacy.load("en_core_web_sm")

# List of keywords for NLP
keywords = [
    "internship", "program", "volunteer", "scholarship", "workshop", "research", "summer camp",
    "fellowship", "competition", "hackathon", "leadership", "mentorship", "community service",
    "apprenticeship", "training", "course", "STEM", "coding", "robotics", "science", "technology",
    "engineering", "mathematics", "arts", "humanities", "sports", "athletics", "debate",
    "public speaking", "writing", "journalism", "creative writing", "theater", "music", "choir",
    "band", "orchestra", "dance", "art", "painting", "drawing", "sculpture", "photography",
    "graphic design", "animation", "film", "video production", "computer science", "programming",
    "web development", "app development", "game development", "cybersecurity", "AI",
    "machine learning", "data science", "biology", "chemistry", "physics", "environmental science",
    "health", "medicine", "nursing", "pre-med", "biotechnology", "neuroscience",
    "psychology", "sociology", "economics", "business", "entrepreneurship", "finance",
    "marketing", "management", "law", "advocacy", "government", "politics", "public policy",
    "international relations", "cultural exchange", "language", "foreign language",
    "diversity", "inclusion", "social justice", "sustainability", "conservation", "ecology"
]

def analyze_keywords(text):
    doc = nlp(text.lower())
    found_keywords = set()
    for token in doc:
        if token.lemma_ in keywords:
            found_keywords.add(token.lemma_)
    return list(found_keywords)

def upload_to_db(opportunity, db_session, counts):
    counts["processed"] += 1
    existing_job = get_job_by_title_and_org(db_session, opportunity['title'], opportunity['organization'])
    if existing_job:
        counts["existing"] += 1
    else:
        job_data = JobCreate(**opportunity)
        create_job(db_session, job_data)
        counts["uploaded"] += 1

def parse_deadline(deadline_str):
    try:
        return dparser.parse(deadline_str, fuzzy=True)
    except ValueError:
        return None

class StandoutSearchSpider(scrapy.Spider):
    name = "standout_search_spider"
    allowed_domains = ["standoutsearch.com"]
    start_urls = ['https://www.standoutsearch.com']
    counts = {"processed": 0, "uploaded": 0, "skipped": 0, "existing": 0}

    def start_requests(self):
        base_url = 'https://www.standoutsearch.com/api/data/63b6cfb34a0e5f00084f2802/records?filters='
        areas = ['Medicine', 'Engineering', 'Science', 'Arts', 'Computer+Science', 'Business', 'Law/Advocacy', 'Government', 'Nonprofit', 'Museum', 'Education', 'Environment', 'Writing', 'Psychology', 'Architecture']

        headers = {
            'accept': 'application/json, text/plain, */*',
            'accept-language': 'en-US,en;q=0.9,es;q=0.8',
            'referer': 'https://www.standoutsearch.com/',
            'sec-ch-ua': '"Not/A)Brand";v="8", "Chromium";v="126", "Google Chrome";v="126"',
            'sec-ch-ua-mobile': '?0',
            'sec-ch-ua-platform': '"macOS"',
            'sec-fetch-dest': 'empty',
            'sec-fetch-mode': 'cors',
            'sec-fetch-site': 'same-origin',
            'user-agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
            'x-pory-host': 'www.standoutsearch.com'
        }

        cookies = {
            '_gcl_au': '1.1.13423624.1719444043',
            '_ga': 'GA1.1.1421791193.1719444043',
            '_hjSessionUser_3332247': 'eyJpZCI6ImI2MjM1NGZjLTUxYmItNWI0Zi1hMDEzLWRhZGY2ODQxMDM5MCIsImNyZWF0ZWQiOjE3MTk0NDQwNDI2NzksImV4aXN0aW5nIjp0cnVlfQ==',
            '__Host-next-auth.csrf-token': '14618a149861c5df8a39a350186f4c2bb1c989efaa09b18db369db3fc77b6eb8%7C76ecd4f59c46847e9357d8994b9267611e39c288ff1e07ccad3ea0021908d495',
            '__Secure-next-auth.callback-url': 'https%3A%2F%2Fwww.standoutsearch.com',
            '_ga_2PLH6NK4ZK': 'GS1.1.1721905962.20.0.1721905962.0.0.0',
            '_hjSession_3332247': 'eyJpZCI6ImY5YjRhNGVlLWEzMWItNGZhYi05ZjQyLTJkN2ZmMGJlNjI1ZiIsImMiOjE3MjE5MDU5NjMwNTUsInMiOjAsInIiOjAsInNiIjowLCJzciI6MCwic2UiOjAsImZzIjowLCJzcCI6MH0='
        }
        for area in areas:
            filters = {"Interest Area:": [area]}
            filters_encoded = urllib.parse.quote(json.dumps(filters))
            url = f"{base_url}{filters_encoded}"
            yield scrapy.Request(url, self.parse_area, headers=headers, cookies=cookies, meta={'area': area, 'base_url': base_url, 'filters_encoded': filters_encoded})

    def parse_area(self, response):
        area = response.meta['area']
        base_url = response.meta['base_url']
        filters_encoded = response.meta['filters_encoded']
        data = json.loads(response.text)
        records = data.get('records', [])
        offset = data.get('offset', None)

        for record in records:
            fields = record.get('fields', {})
            description = fields.get('Description:', '')
            keywords_found = analyze_keywords(description)

            deadline_str = fields.get('Application Deadline:', '')
            deadline = parse_deadline(deadline_str)
            if deadline and deadline < datetime.now():
                self.counts["skipped"] += 1
                continue

            opportunity = {
                'title': fields.get('Name of Program', ''),
                'organization': fields.get('Entity Name', ''),
                'deadline': deadline_str,  # Store as string
                'area': fields.get('Interest Area:', []),
                'age': fields.get('Age:', []),
                'season': fields.get('Season:', []),
                'eligibility': fields.get('This Opportunity is Only Open To:', []),
                'description': description,
                'requirements': fields.get('Requirements:', ''),
                'mode': fields.get('Mode:', []),
                'location': fields.get('Location:', []),
                'address': fields.get('Address:', ''),
                'salary': fields.get('Salary:', ''),
                'program_fee': fields.get('Program Fee/Tuition:', ''),
                'keywords': keywords_found,
                'link': fields.get('Link to Application Page/Website ', ''),
                'listing_type': fields.get('Type of Opportunity:', []),
                'is_priority': False
            }

            db = SessionLocal()
            try:
                upload_to_db(opportunity, db, self.counts)
            finally:
                db.close()

        if offset:
            next_url = f"{base_url}{filters_encoded}&offset={urllib.parse.quote(offset)}"
            yield scrapy.Request(next_url, self.parse_area, headers=response.request.headers, cookies=response.request.cookies, meta={'area': area, 'base_url': base_url, 'filters_encoded': filters_encoded})

    def closed(self, reason):
        db = SessionLocal()
        try:
            deleted_jobs_count = delete_outdated_jobs(db)
            self.counts["deleted"] = deleted_jobs_count
            print(f"Summary: Processed {self.counts['processed']} jobs, Uploaded {self.counts['uploaded']} jobs, Skipped {self.counts['skipped']} jobs, Deleted {self.counts['deleted']} outdated jobs.")
        finally:
            db.close()
