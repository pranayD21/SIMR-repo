class CollegeInformation:
    def __init__(self):
        self.university_name = ""
        self.university_url = ""
        self.university_major = ""
        self.university_instate = ""
        self.university_outstate = ""
        self.university_address = ""
        self.university_phone = ""
        self.university_website = ""
        self.university_type = ""

    def __str__(self):
        return ("name : " + self.university_name + ", url " + self.university_url + ", major " + self.university_major +
                ", instate " + self.university_instate + ", outstate " + self.university_outstate)
