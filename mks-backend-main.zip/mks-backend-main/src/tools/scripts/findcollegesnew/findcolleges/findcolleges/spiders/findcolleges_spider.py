#Name: Rishi Saravanan
#Program Function: Web scraping spider using Scrapy to extract major information from college websites.
import csv
from typing import Any

from bs4 import BeautifulSoup

import scrapy
from scrapy import Selector
from scrapy.http import Response
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import Rule

from findcolleges import CollegeInformation


class FindCollegeSpider(scrapy.spiders.CrawlSpider):

    name = "findcolleges"
    inState = "N/A"
    outState = "N/A"

    # Open a CSV file for writing majors data
    majorsFile = open('majors.csv', 'w', newline='')

    # Create a LinkExtractor with unique links
    link_extractor = LinkExtractor(unique=True)

    # Define rules for crawling
    rules = [
        Rule(LinkExtractor(allow=" https://mycollegeselection.com/colleges-by-state/colleges-in-")),
        Rule(LinkExtractor(allow="majors/"), callback='parse_majors', follow=True)
    ]

    # Initializes the spider by defining the initial URLs to crawl and creating a CSV file for storing major information.
    # Yields requests for each starting URL and invokes the parse method.
    def start_requests(self):
        # Define the initial URLs to crawl
        urls = [
            "https://mycollegeselection.com/colleges-by-state/"
        ]

        # Create the CSV file and yield requests for each URL
        self.create_csv_file()
        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

    # Parses the main page, extracting links using the LinkExtractor.
    # Yields requests for each extracted link, directing them to the
    # parse2 method for further processing.
    def parse(self, response: Response, **kwargs: Any) -> Any:
        # Extract links from the response and yield requests for each link
        for link in self.link_extractor.extract_links(response):
            yield scrapy.Request(url=link.url, callback=self.parse2)

    # Parses secondary pages to filter out links ending with "/majors."
    # Yields requests for links that meet the condition, directing them to the parse_majors method.
    def parse2(self, response: Response, **kwargs: Any) -> Any:

        # Convert the response body to a string
        html_content = response.body.decode('utf-8')

        # Parse the HTML content using BeautifulSoup
        soup = BeautifulSoup(html_content, 'html.parser')
        college_info = CollegeInformation
        # Extract information from the university main page.
        self.extract_cost(soup, college_info)
        self.extract_details(soup, college_info)
        # extractAddress(soup)
        # extractAcceptanceRate(response)
        # extractPic(response)
        # extractCollegeWebsite(response)
        # Iterate through links and yield requests for links ending with /majors
        for link in self.link_extractor.extract_links(response):
            if str(link.url).endswith("majors/"):
                yield scrapy.Request(url=link.url, callback=self.parse_majors, meta={'college_info': college_info})

    #Extracts major information from each row in the table and writes it to the CSV file.
    def parse_majors(self, response: Response, **kwargs: Any) -> Any:
        # Create a Selector to parse the response body
        sel = Selector(text=response.body, type="html")
        print(response.meta)

        # Extract major information from each row in the table and write to CSV
        for row in sel.xpath('//table//tbody//tr'):
            # Extract the major from the current row
            major = row.xpath('./td/text()').get("data")
            college_info = response.meta.get("college_info")

            # Write the major and the corresponding university URL to the CSV file
            self.writer.writerow({'University': response.url,
                                  'Major': major,
                                  'Cost': college_info.university_outState,
                                  'Address': college_info.university_address,
                                  'Phone': college_info.university_phone,
                                  'Website': college_info.university_website,
                                  'Type': college_info.university_type})

    def extract_cost(self, soup: BeautifulSoup, college_info: CollegeInformation):
        # Find the figure element with class "wp-block-table"
        figure = soup.find('figure', class_='wp-block-table')

        if (figure):
            # Find the table element within the figure
            table = figure.find('table')
            # Iterate over each row in the table
            for row in table.find_all('tr'):
                # Extract the data from each cell in the row
                cells = row.find_all('td')
                if len(cells) != 0:
                    if cells[0].text.strip() == "Total Cost":
                        college_info.university_inState = cells[1].text
                        college_info.university_outState = "N/A"
                        if (len(cells) > 2):
                            college_info.university_outState = cells[2].text.strip()

    def extract_details(self, soup:BeautifulSoup, college_info: CollegeInformation):
        # Find the following information - address, phone, website, and Type.
        details_div = soup.find('div', class_='wp-block-column is-layout-flow wp-block-column-is-layout-flow')
        if (details_div):
            for details in details_div.find_all('li'):
                detail = details.text
                detail.strip("::marker")
                if (detail.startswith("Address:")):
                    address = detail.split(':')
                    college_info.university_address = address[1]
                elif (detail.startswith("Phone:")):
                    phone = detail.split(':')
                    college_info.university_phone = phone[1]
                elif (detail.startswith("Website:")):
                    website = detail.split(':')
                    college_info.university_website = website[1]
                elif (detail.startswith("Type:")):
                    type = detail.split(':')
                    college_info.university_type = type[1]





    #Creates a CSV file and writes the header with specified fields ('University', 'Major').
    def create_csv_file(self):
        # Define the header fields for the CSV file
        fieldnames = ['University', 'Major', 'Cost', 'Address','Phone','Website','Type']

        # Create a CSV DictWriter with the specified fieldnames and write the header
        self.writer = csv.DictWriter(self.majorsFile, fieldnames=fieldnames)
        self.writer.writeheader()


