import csv
import time
from typing import Any
from bs4 import BeautifulSoup

import scrapy
from scrapy import Request, Selector
from scrapy.http import Response
from scrapy.linkextractors import LinkExtractor
from scrapy.spiders import Rule

#
class FindInternshipsSpider(scrapy.spiders.CrawlSpider):
    name = "findinternships"
    majorsFile = open('internships.csv', 'w', newline='')
    link_extractor = LinkExtractor(unique=True)
    def start_requests(self):
        urls = [
            "https://www.teenlife.com/category/summer/?program-type=summer&sp_categories=STEM"
        ]

        self.create_csv_file()

        start_time = time.perf_counter()

        for url in urls:
            yield scrapy.Request(url=url, callback=self.parse)

        end_time = time.perf_counter()
        time_elapsed = end_time - start_time

        print (f"Time to find internships {time_elapsed:0.2f} seconds")


    def parse(self, response: Response, **kwargs: Any) -> Any:

        data = response.text
        print (data)
        soup = BeautifulSoup(data, "html.parser")

        for matchDiv in soup.find_all("h3", class_="program-heading featured"):
            h3Url = matchDiv.find("a")
            #print (h3Url)


        # Assuming the HTML structure is <div class="your_div_class"><h3 class="your_h3_class">Your Text</h3></div>
        #link = soup.find('h3', class_='program-heading feature').find('a').get('href').

        #link = soup.find('h3', class_='FOO1').find('a').get('href')


        #your_text = soup.find('div', class_='content').find('h3', class_='program-heading feature').
        #print(your_text)

        #print (response)
        #print (response.xpath("//div[@class='content']/h3[@class='program-heading feature']").extract())
        #print(response.xpath('//h3[@class="program-heading"]').get())

        #sel = Selector(text=response.body, type="html")

        #product = sel.xpath('//div[@class="content"]')
        #product_features = product.xpath('.//div[@class="features"]')
        #print (sel)
        # find all the entries that match the
        #for slider_item in sel.xpath('//div[@class="program-heading"]/a/title()'):
        #    print (slider_item)

    #filter out the links that end with /majors
    def parse2(self, response: Response, **kwargs: Any) -> Any:
        #print ("Inside major checks")
        for link in self.link_extractor.extract_links(response):
            if (str(link.url).endswith("majors/")):
                yield scrapy.Request(url=link.url, callback=self.parse_majors)
            # yield Request(link.url, callback=self.parse)

    def parse_majors(self, response: Response, **kwargs: Any) -> Any:
        sel = Selector(text=response.body, type="html")

        for row in sel.xpath('//table//tbody//tr'):
            major = row.xpath('./td/text()').get("data")
            self.writer.writerow({'University': response.url, 'Major': major})


    def create_csv_file(self):
        fieldnames = ['University', 'Major']
        self.writer = csv.DictWriter(self.majorsFile, fieldnames=fieldnames)
        self.writer.writeheader()
