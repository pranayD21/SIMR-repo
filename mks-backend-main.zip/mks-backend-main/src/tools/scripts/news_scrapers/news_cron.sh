#!/bin/bash

# This script is used to run the news scrapers every 24 hours

# Make a timestamp

echo "Running college news scraper at $(date)"

# Set the project directory
PROJECT_DIR="/home/ubuntu/buddybot-server/mks-backend"

# Activate the virtual environment at $> source ~/buddybot-server/py310/bin/activate
source /home/ubuntu/buddybot-server/py310/bin/activate || { echo "Error activating virtual environment"; exit 1; }

# Change directory to the news scrapers directory
cd "$PROJECT_DIR/src/tools/scripts/news_scrapers" || { echo "Directory not found"; exit 1; }

# Run the news_task.py script with input "college news"
python3 news_task.py "college news,financial aid and scholarships,SAT & ACT,college admissions" || { echo "Error running college news scraper"; exit 1; }

# Deactivate the virtual environment
deactivate || { echo "Error deactivating virtual environment"; exit 1; }

echo "College news scraper ran successfully"