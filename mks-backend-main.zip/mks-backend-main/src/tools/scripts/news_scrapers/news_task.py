import spacy
nlp = spacy.load('en_core_web_sm')
import os
from sqlalchemy import create_engine
from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta
from dateutil.parser import parse as parse_date
import sys
import pandas as pd
import re
import serpapi
import dotenv

dotenv.load_dotenv(dotenv.find_dotenv())
dabbl_home = os.getenv('DABBL_HOME')

# Check if DABBL_HOME is set
if dabbl_home:
    # Expand the user's home directory symbol (~) if present
    dabbl_home = os.path.expanduser(dabbl_home)
    # Ensure the path is absolute
    dabbl_home = os.path.abspath(dabbl_home)
    # Add the DABBL_HOME directory to the Python path
    sys.path.append(dabbl_home)
else:
    raise EnvironmentError("DABBL_HOME environment variable is not set")

# Import the necessary modules from db
from db.database import SessionLocal, engine
import db.schemas as schemas
from db.crud import create_news_post, delete_outdated_news

SERP_API_KEY = os.getenv('SERP_API_KEY')

if not SERP_API_KEY:
    raise Exception("SERP_API_KEY environment variable is not set")

def process_snippet(snippet):

    # Process the snippet using spaCy
    doc = nlp(snippet)
    # Extract named entities and their labels
    entities = [(ent.text, ent.label_) for ent in doc.ents]
    # Identify key themes (keywords) and sentiments
    keywords = []
    # Analyze the tokens in the snippet
    for token in doc:
        # Extract relevant keywords (nouns, verbs, adjectives)
        if token.pos_ in ['NOUN', 'VERB', 'ADJ'] and not token.is_stop:
            keywords.append(token.text.lower())

    main_focus = (lambda lst: [x[0] for x in lst])(entities) + keywords[:5]
    
    return main_focus

def parse_relative_date(phrase):
    # Get the current date and time
    current_date = datetime.now()

    # replace word numbers 0-9 with digits
    phrase = re.sub(r"\bzero\b", "0", phrase)
    phrase = re.sub(r"\bone\b", "1", phrase)
    phrase = re.sub(r"\btwo\b", "2", phrase)
    phrase = re.sub(r"\bthree\b", "3", phrase)
    phrase = re.sub(r"\bfour\b", "4", phrase)
    phrase = re.sub(r"\bfive\b", "5", phrase)
    phrase = re.sub(r"\bsix\b", "6", phrase)
    phrase = re.sub(r"\bseven\b", "7", phrase)
    phrase = re.sub(r"\beight\b", "8", phrase)
    phrase = re.sub(r"\bnine\b", "9", phrase)

    # Define patterns and corresponding relativedeltas or timedeltas
    patterns = [
        (r"(\d+)\s*days?\s*ago", lambda n: current_date - relativedelta(days=int(n))),
        (r"(\d+)\s*weeks?\s*ago", lambda n: current_date - relativedelta(weeks=int(n))),
        (r"(\d+)\s*months?\s*ago", lambda n: current_date - relativedelta(months=int(n))),
        (r"(\d+)\s*years?\s*ago", lambda n: current_date - relativedelta(years=int(n))),
        (r"(\d+)\s*hours?\s*ago", lambda n: current_date - timedelta(hours=int(n))),
        (r"(\d+)\s*minutes?\s*ago", lambda n: current_date - timedelta(minutes=int(n))),
        (r"(\d+)\s*seconds?\s*ago", lambda n: current_date - timedelta(seconds=int(n))),
        (r"yesterday\s*", lambda _: current_date - timedelta(days=1)),
    ]

    # Match phrase with patterns for relative dates
    for pattern, delta in patterns:
        match = re.match(pattern, phrase, re.IGNORECASE)
        if match:
            if match.groups():  # Check if there are capturing groups
                n = match.group(1)
                relative_date = delta(n)
            else:
                relative_date = delta(None)
            return relative_date.strftime('%Y-%m-%d %H:%M:%S')

    # Attempt to parse absolute dates using dateutil.parser
    try:
        parsed_date = parse_date(phrase)
        if parsed_date:
            return parsed_date.strftime('%Y-%m-%d %H:%M:%S')
    except Exception as e:
        pass

    # Return None if parsing fails
    return None

def fetch_search_results(queries):
    all_results = []
    for query in queries:
        results = []
        params = {
            "api_key": SERP_API_KEY,
            "q": query,
            "tbm": 'nws',
            # "as_epq": "college" or "university",  # Search for exact phrase
            # "as_sitesearch": "usnews.com",  # Search only in nytimes.com
            "as_qdr": "d2",  # Filter for results from the past week
            "as_q": 'college' or 'university',
            "num": 20
        }

        try:
            search = serpapi.search(params)
            data = search["news_results"]
            if "error" in data:
                raise Exception("Error accessing API")
            print("Successful API connection")
            for result in data:
                # Extract the title, link, and date of publication of each news item
                formatted_date = parse_relative_date(result["date"])
                keywords = process_snippet(result["snippet"])
                results.append([result["title"], result["link"], formatted_date, keywords])
            all_results.extend(results)

        except Exception as e:
            print(f"Error: {e}")

    return all_results

def save_to_db(news_list):

    DB_URL = os.environ['DB_URL'] + "?client_encoding=utf8"
    engine = create_engine(DB_URL)
    session = SessionLocal(bind=engine)
    count = 0

    for news in news_list:
        news_post = schemas.NewsCreate(
            news_title=news[0],
            news_content_url=news[1],
            news_published_date=news[2],
            news_keywords=news[3],
            likes=[]
        )

        news_item = create_news_post(session, news_post)
        count += 1

    print(f"Saved {count} news articles to the database")
    print("--------------------------------")

    threshold_date = datetime.now() - timedelta(days=2)
    formatted_threshold_date = threshold_date.strftime("%Y-%m-%d %H:%M:%S")

    print("Deleting outdated news articles...")
    print("--------------------------------")

    delete_outdated_news(session, formatted_threshold_date)

    print("Outdated news articles deleted successfully")

    session.close()

def main():

    topic_tokens = sys.argv[1]
    # ask the user to enter queries and the output file name
    tokens = topic_tokens.split(",")

    print("Searching for news articles...")
    print("--------------------------------")

    news = fetch_search_results(tokens)

    print("News articles fetched successfully")
    print("--------------------------------")

    save_to_db(news)

    print("--------------------------------")
    print("News articles saved to the database")

if __name__ == "__main__":
    main()

