# News Scrapers Important Information

#### Set up:

1. Create a virtual environment to download dependencies
```
python -m venv venv
```
2. In terminal, type the following command (make sure you are in the directory)
```
source venv/bin/activate
```
3. Ensure that all dependencies are installed
```
pip install -r requirements.txt
```

4. Create your .env and ensure you have these fields:
```
API_KEY=your_key
EMAIL_ADDRESS=your_email
PASS=password
SMTP_SERVER=server
SMTP_PORT=server_port
DB_SERVER_URL= "http://localhost:8000/db"
TEST_AUTH_TOKEN= "your_token"
```
5. All set up! 

To deactivate the virtual environment, type ```deactivate``` in the terminal

#### Usage:

Run the script in the terminal and provide inputs as command arguments:
```
python news_scraper.py "Food,Football" "recipient_email@gmail.com" "Search Results" "These are the search results. Please see attached" "queries_test"
```

Ensure that entries follow this format. First entry should be a string and comma-separated. Entries should be separated by spaces. For the file name, please do not add the .csv extension, just put what you want to name the file.

To run the shell script for the news job do the following:

1. Modify the following varaible in news_cron.sh

```
PROJECT_DIR = "Your repo location (full path)"
```

2. Then run

```
chmod +x news_cron.sh
./news_cron.sh
```

## Notes: 
Adjust the port and smtp server variables accordingly based on the email server. Ensure that the queries are inputted as a list. 