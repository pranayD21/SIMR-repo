import hmac
import hashlib
import base64
import os

app_client_secret = os.environ.get("COGNITO_APP_CLIENT_SECRET") 
app_client_id = os.environ.get("COGNITO_APP_CLIENT_ID")
username = "testuser" # replace with the username of the user you want to authenticate

secret_hash = base64.b64encode(hmac.new(bytes(app_client_secret, 'utf-8'), bytes(
    username + app_client_id, 'utf-8'), digestmod=hashlib.sha256).digest()).decode()

print(secret_hash)
