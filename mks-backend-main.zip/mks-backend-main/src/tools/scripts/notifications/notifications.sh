#!/bin/bash

# This script schedules and sends notifications based on the type passed as an argument

# Usage: ./notifications.sh <notification_type>, For example: "./notifications.sh general" or "./notifications.sh fun_fact"


NOTIFICATION_TYPE="$1"

if [[ "$NOTIFICATION_TYPE" != "general" && "$NOTIFICATION_TYPE" != "fun_fact" ]]; then
    echo "Invalid notification type. Choose 'general' or 'fun_fact'."
    exit 1
fi

PROJECT_DIR="/home/ubuntu/buddybot-server/mks-backend"

# Activate the virtual environment
source /home/ubuntu/buddybot-server/py310/bin/activate || { echo "Error activating virtual environment"; exit 1; }

cd "$PROJECT_DIR/src/tools/scripts/notifications" || { echo "Directory not found"; exit 1; }

# Run the notification scheduler with the given type
python3 schedule_send.py "$NOTIFICATION_TYPE" || { echo "Error scheduling $NOTIFICATION_TYPE notifications"; exit 1; }

# Deactivate the virtual environment
deactivate || { echo "Error deactivating virtual environment"; exit 1; }

echo "$NOTIFICATION_TYPE notifications scheduled and sent successfully"
