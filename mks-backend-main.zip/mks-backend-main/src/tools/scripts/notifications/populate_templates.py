#script for populating the notification templates into database so we can schedule send.

import requests
from dotenv import load_dotenv
import os

load_dotenv()

BASE_URL = "http://127.0.0.1:8000"

AUTH_TOKEN = os.getenv("TEST_AUTH_TOKEN")

headers = {
    "Authorization": f"Bearer {AUTH_TOKEN}",
    "Content-Type": "application/json",
    "accept": "application/json"
}

def template_exists(template_title):
    response = requests.get(f"{BASE_URL}/db/all_notification_templates", headers=headers)
    if response.status_code == 200:
        templates = response.json()  
        for template in templates:
            if template['title'] == template_title:
                return True
    return False

# General notifications
general_notifications = [
    {"type": "general", "title": "👋 Have You dabbLed Today?", "message": "Explore new opportunities, connect with peers, or just see what's new. It's always a good time to dabbL!"},
    {"type": "general", "title": "✨ What Will You dabbL In Today?", "message": "Take a moment to explore something new. Whether it's a career or a college, your journey starts with dabbL."},
    {"type": "general", "title": "👀 Have You Seen What's New?", "message": "Fresh content, new opportunities, and more! Log in to dabbL and explore what's new this week."},
    {"type": "general", "title": "🔍 Find Your Next Adventure on dabbL!", "message": "There's always something new to discover on dabbL. What will you explore today?"},
    {"type": "general", "title": "🌟 Keep the Momentum Going with dabbL!", "message": "Consistency is key to success. Log in today and take one step toward your goals on dabbL."},
    {"type": "general", "title": "💼 Explore New Opportunities on dabbL!", "message": "Check out the latest opportunities on dabbL. Your next big break could be just a click away!"},
    {"type": "general", "title": "💡 Discover Something New Today!", "message": "Your future is full of possibilities. Explore new career paths and colleges on dabbL!"},
    {"type": "general", "title": "✨ What Will You dabbL In Next?", "message": "Achieve your dreams one step at a time. Log in and take steps forward!"},
    {"type": "general", "title": "🔧 Build Your Future with dabbL!", "message": "From career exploration to college discovery, every tool you need is right here on dabbL."},
    {"type": "general", "title": "🚀 Take the Next Step Today!", "message": "Every journey starts with a single step. Start yours on dabbL and discover your path."},
    {"type": "general", "title": "📅 What's on Your To-Do List?", "message": "Tick off your goals! Discover new careers, explore colleges, or learn something new on dabbL."},
    {"type": "general", "title": "🧠 Fuel Your Curiosity!", "message": "Keep your mind sharp by exploring fresh content and new opportunities on dabbL."},
    {"type": "general", "title": "🌱 Grow with dabbL!", "message": "Your future is like a plant. Nurture it! Discover new opportunities on dabbL."},
    {"type": "general", "title": "📈 Keep Building Your Success!", "message": "Each small step adds up to success. You got this! Keep going and explore more on dabbL."},
    {"type": "general", "title": "💥 Ready for a Breakthrough?", "message": "Your next big opportunity is just around the corner. Start exploring new opportunities on dabbL today!"},
    {"type": "general", "title": "💪 Make Progress Today!", "message": "Success is built on small steps. Take one today by discovering new opportunities on dabbL."},
    {"type": "general", "title": "🌎 Explore Beyond Your Limits!", "message": "Step out of your comfort zone. New opportunities await you on dabbL—start your journey now!"},
    {"type": "general", "title": "📚 The More You Know, The Further You'll Go!", "message": "Keep learning and growing. dabbL is here to help! Log in today and take steps forward."},
    {"type": "general", "title": "🏆 Set Your Sights on Success!", "message": "Aim high and take the next step. Every tool you need is right here on dabbL!"},
]

# Fun fact notifications
fun_fact_notifications = [
    {"type": "fun_fact", "title": "🤔 Career Fact!", "message": "Did you know? The average person spends about 90,000 hours at work over their lifetime. Make sure it's something you love—explore careers on dabbL!"},
    {"type": "fun_fact", "title": "🏛 College Fun Fact!", "message": "Did you know? There are over 5,000 colleges in the U.S. alone. Ready to find your perfect match? Start your search on dabbL!"},
    {"type": "fun_fact", "title": "🎓 Where Leaders Are Made!", "message": "Did you know? More U.S. presidents have graduated from Harvard than any other university. Ready to make your mark? Explore top-ranked colleges on dabbL!"},
    {"type": "fun_fact", "title": "🍦 Sweetest Major Ever?", "message": "Did you know? Penn State offers a course on the Science of Ice Cream. Imagine studying your favorite dessert! Ready to find your perfect college fit? Start exploring on dabbL!"},
    {"type": "fun_fact", "title": "🤔 Did You Know?", "message": "The most popular college major in the U.S. is Business Administration. Is it the right fit for you? Explore more majors on dabbL!"},
    {"type": "fun_fact", "title": "🌶️ Discover the Hottest Major!", "message": "Did you know? New Mexico State University has a Chile Pepper Institute dedicated to studying chili peppers. Ready to find a college as unique as you? Explore your fit on dabbL!"},
    {"type": "fun_fact", "title": "🐐 Goat Yoga?", "message": "Did you know? Cornell University offers courses in goat management that might just include yoga with goats. Ready to bend and bleat? Find your unique college on dabbL!"},
    {"type": "fun_fact", "title": "🧀 Say Cheese!", "message": "Did you know? Wisconsin offers a Master Cheesemaker program. Explore flavorful careers on dabbL!"},
    {"type": "fun_fact", "title": "🧹 Magical Sports!" , "message": "The magic sport Quidditch isn't just fantasy—it's played competitively at colleges across the country. Want to join the league? Explore colleges on dabbL that support your wizardly ambitions!"},
    {"type": "fun_fact", "title": "🍫 Chocolate Science!", "message": "Did you know? UC Davis offers a course in Chocolate Science. Ready to indulge in sweet studies? Find your flavorful major on dabbL!"},
    {"type": "fun_fact", "title": "🥇 Did you know?", "message": "A Stanford student has won a medal at every Olympics since 1908. Aspiring to greatness? Start your champion path on dabbL!"},
    {"type": "fun_fact", "title": "🦆 Duck Tales!", "message": "Quack up your brain! Did you know Caltech's ducks have their own Instagram? Dive into more fun colleges and find your flock on dabbL!"},
    {"type": "fun_fact", "title": "🐙 Octopus Psychology?", "message": "Ever wondered what an octopus thinks about? Oberlin College offers a class on animal consciousness. Expand your mind in unique ways on dabbL!"},
    {"type": "fun_fact", "title": "🕵️ Spy for a Living?", "message": "Did you know? The CIA recruits directly from college campuses. Ready to lead a life of intrigue? Discover your perfect fit on dabbL!"},
    {"type": "fun_fact", "title": "📖 Literary Legends!", "message": "Ever wonder where your favorite authors studied? J.K. Rowling, the creator of Harry Potter, graduated from Exeter University. Find magical college programs on dabbL!"},
    {"type": "fun_fact", "title": "🍿 Popcorn Studies?", "message": "Believe it or not, some universities explore the science behind cinema snacks like popcorn. Popping into Food Science could be your tastiest career move on dabbL!"},
    {"type": "fun_fact", "title": "🎢 Thrill Engineers!", "message": "Engineering can be a thrill ride—literally! Specialize in designing roller coasters and theme park rides. Start your engineering adventure on dabbL!"},
    {"type": "fun_fact", "title": "🦆Quack Attack?", "message": "Did you know? At the University of Oregon, there is an official title for the person who dresses up as the school's duck mascot: The Duck Handler. Find your unique college fit on dabbL!"},
    {"type": "fun_fact", "title": "🎓 College Fun Fact!", "message": "The oldest university in the world is the University of Bologna, founded in 1088. Where will your academic journey take you? Find out on dabbL!"},
    {"type": "fun_fact", "title": "💼 Career Match!", "message": "Did you know? Your hobbies might just be the key to your perfect career. Love gaming? Art? Coding? Discover your fit on dabbL!"},
    {"type": "fun_fact", "title":  "🎓 College Tradition!", "message": "Did you know? Some colleges have traditions like screaming during finals week to help students relieve stress. What unique traditions will you find? Discover your fit on dabbL!"},
    {"type": "fun_fact", "title": "📚 College History Fact!", "message":"Did you know? The University of Oxford has been teaching students since 1096, making it older than the Aztec Empire. Ready to explore historic colleges? Start your journey on dabbL!"},
    {"type": "fun_fact", "title": "🌋 Study Volcanos!", "message": "Did you know? You can study volcanoes up close at the University of Hawaii, right on the slopes of an active volcano. Find your next adventure on dabbL!"},
    {"type": "fun_fact", "title": "🦖 Digging into Dinosaurs!", "message": "Did you know? Montana State University has its own paleontology program, where students dig for dinosaur fossils. Ready to uncover the past? Start exploring on dabbL!"},
    {"type": "fun_fact", "title": "🌌 The Final Frontier!", "message": "Did you know? Purdue University is called the 'Cradle of Astronauts'—25 of its grads have gone to space! Ready to shoot for the stars? Start your journey on dabbL!"},
    {"type": "fun_fact", "title": "🛠️ Build Your Future!", "message": "Did you know? MIT students have built a piano that plays on its own. What innovations will you create? Start exploring engineering schools on dabbL!"},
    {"type": "fun_fact", "title": "💻 Ethical Hacking!", "message": "Did you know? Companies pay ethical hackers to break into their systems to test security. Ready to hack your way to success? Explore your perfect career on dabbL!"},
    {"type": "fun_fact", "title": "💬 Yap for a Living!", "message": "Did you know? Careers in marketing and PR are perfect for those who love to chat. Ready to turn your words into a career? Find your fit on dabbL!"},
    {"type": "fun_fact", "title": "🧛 Vampire Studies!", "message":"Did you know? The University of California offers a course on vampire literature and folklore. Ready to sink your teeth into something unique? Find your perfect fit on dabbL!"},
    {"type": "fun_fact", "title": "🧠 Brainy Jobs!", "message": "Did you know? Careers in data science and AI are among the highest-paid and fastest-growing in tech. Ready to tap into the future? Explore careers on dabbL!"},
    {"type": "fun_fact", "title": "🍵 Tea Science!", "message": "Did you know? The University of California, Davis, offers a course in Tea Science, where students learn about the beloved beverage. Ready to brew up the perfect college fit? Explore dabbL!"}

]

# Create general notifications
for template in general_notifications:
    if template_exists(template['title']):
        print(f"Template '{template['title']}' already exists.")
        continue
    
    payload = {
        "type": template["type"],
        "title": template["title"],
        "message": template["message"],
        "repeatable": True, 
        "active": True
    }
    response = requests.post(f"{BASE_URL}/db/notification_templates", headers=headers, json=payload)
    
    if response.status_code == 200:
        print(f"Successfully created template: {template['title']}")
    else:
        print(f"Failed to create template: {template['title']}. Status Code: {response.status_code}")

# Create fun fact notifications (repeatable = false in this case)
for template in fun_fact_notifications:
    if template_exists(template['title']):
        print(f"Template '{template['title']}' already exists.")
        continue
    
    payload = {
        "type": template["type"],
        "title": template["title"],
        "message": template["message"],
        "repeatable": False, 
        "active": True
    }
    response = requests.post(f"{BASE_URL}/db/notification_templates", headers=headers, json=payload)
    
    if response.status_code == 200:
        print(f"Successfully created template: {template['title']}")
    else:
        print(f"Failed to create template: {template['title']}. Status Code: {response.status_code}")
