import sys
import os
from dotenv import load_dotenv

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../../..")))
from db.notification_handler import NotificationHandler
from db.database import SessionLocal 

load_dotenv()

# Ensure the script receives a valid notification type
if len(sys.argv) != 2:
    print("Usage: python3 schedule_send.py <notification_type>")
    print("notification_type should be either 'general' or 'fun_fact'")
    sys.exit(1)

notification_type = sys.argv[1].lower()

if notification_type not in ["general", "fun_fact"]:
    print("Invalid notification type. Choose 'general' or 'fun_fact'.")
    sys.exit(1)

# Create a database session
db = SessionLocal()

# Create an instance of the NotificationHandler
notification_handler = NotificationHandler()

try:
    # Schedule notifications based on the provided type
    result = notification_handler.schedule_notifications(db=db, type=notification_type)

    if "error" in result:
        print(f"Error scheduling notifications: {result['error']}")
    else:
        print(result['message'])

finally:
    db.close()