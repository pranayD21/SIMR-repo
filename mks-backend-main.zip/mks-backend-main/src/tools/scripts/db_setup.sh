!#/bin/bash

# Setup pgdb locally
# First get the schema from AWS
pg_dump -h ${AWS_DB_HOST_NAME} -U ${USER} -d ${DB_NAME} -s -f schema_dump.sql

createdb -U ${LOCAL_USER} -h localhost ${LOCAL_DB_NAME}
psql -U ${LOCAL_USER} -h localhost -d ${LOCAL_DB_NAME} -f schema_dump.sql

# Now get the data from AWS
pg_dump -h ${AWS_DB_HOST_NAME} -U ${USER} -d ${DB_NAME} -a -f data_dump.sql

# Insert the data into local db
psql -U ${LOCAL_USER} -h localhost -d ${LOCAL_DB_NAME} -f data_dump.sql

