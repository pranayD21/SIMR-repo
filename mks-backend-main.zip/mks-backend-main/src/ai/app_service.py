from flask import Flask
from flask import request, jsonify
from app_functions import AppFunctions
from logger import log_trace, logging

app_service = Flask(__name__)
app_fn = AppFunctions()

@app_service.route("/careers",methods=['POST'])
def show_career_options():
    results = []

    try:
        payload = request.json
        strength, weakness, extra_curricular,model = payload['strength'], payload['weakness'], payload['extra'],payload['model']
        results = app_fn.get_career_options(strength, weakness, extra_curricular,model =model)
        log_trace(logging.INFO, f"Fetch results {results}")
    except Exception as e:
        log_trace(logging.ERROR, str(e))

    return jsonify(results)

@app_service.route("/colleges",methods=['POST'])
def show_college_options():
    results = []

    try:
        payload = request.json
        grade = payload['grade']
        gpa = payload['gpa']
        extra = payload['extra']
        field_of_interest = payload['field_of_interest']
        state = payload['state']
        courses = payload['courses']
        credits = payload['credits']
        num_colleges = payload['num_colleges']
        tution_budget_per_year = payload['tution_budget_per_year']
        school = payload['school']
        model = payload['model']
        rank = payload['rank']
        states_preference = payload['states_preference']
        sat_score = payload['sat_score']
        act_score = payload['act_score']
        results = app_fn.get_top_colleges(grade, gpa, extra, 
                            field_of_interest, state, courses, credits,
                            num_colleges,tution_budget_per_year,school,
                            rank, sat_score, act_score, states_preference,
                            model=model)
        log_trace(logging.INFO, f"Fetch results {results}")
    except Exception as e:
        log_trace(logging.ERROR, str(e))

    return jsonify(results)

@app_service.route("/roadmap",methods=['POST'])
def show_roadmap():
    results = []

    try:
        payload = request.json
        grade = payload['grade']
        gpa = payload['gpa']
        extra = payload['extra']
        target_field = payload['target_field']
        courses = payload['courses']
        school = payload['school']
        target_college = payload['target_college']
        course_catalog = payload['course_catalog']
        results = app_fn.get_roadmap_options(school, course_catalog,
                                grade, extra, 
                                courses,
                                target_college,target_field,gpa
                                )
        log_trace(logging.INFO, f"Fetch results {results}")
    except Exception as e:
        log_trace(logging.ERROR, str(e))

    return jsonify(results)


def start_app(port):
    try:
        host = '0.0.0.0'
        app_service.run(host=host,port=port,threaded=True,debug=False)
    except Exception as e:
        log_trace(logging.ERROR, "Sorry, the server couldn't start...Here's the error:"+str(e),exec_info=True)

def main(port=8081):
    start_app(port=port)

if __name__=="__main__":
    main()