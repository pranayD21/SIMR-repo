"""
This File contains functions to preprocess analytic data before sending it to the collector.
It preprocesses the data by removing any private information, filtering or transforming the data appropriately and then sends it to the collector.

"""
from analytics.analytics_constants import EventType, AnalyticsEvent, generate_auth_header, timeout, BASE_URL
from feature_flags import is_feature_enabled
import requests
from typing import List, Dict, Any
from datetime import datetime
from logger import log_trace, logging




def parse_recommended_colleges_data(user_id: int, data: List[Dict[str, Any]]):
    """
    This function parses the recommended college data and tracks the user activity.

    Args:
        user_id (int): The ID of the user.
        data (List[Dict[str, Any]]): The list of college data.

    Returns:
        None
    """
    log_trace(logging.INFO, f"College Recommendation- Raw Analytics data before processing : {data}")
    # Extract the college names from the data
    college_names = [college['college_name'] for college in data]
    log_trace(logging.INFO, f"College Recommendation- Analytics data after processing : {college_names}")
    track_user_activity_data(EventType.RECOMMENDATION_COLLEGE, user_id, attributes={"college_names": college_names})


def track_user_activity_data(event: EventType , user_id: int, attributes: Dict[str, Any]):
    """
    # User Activity Events
    USER_SIGNUP = auto()
    USER_LOGIN = auto()
    USER_LOGOUT = auto()
    ACCOUNT_UPDATE = auto()
    
    """
    if not is_feature_enabled("Analytics"):
        log_trace(logging.INFO, "Analytics feature is disabled!")
        return
    headers = generate_auth_header()
    event_data = AnalyticsEvent(
                event_type = event,
                unique_id = str(user_id),
                timestamp = datetime.now(),
                attributes=attributes
               )
    payload = event_data.to_json()
    log_trace(logging.INFO, f"posting the event {payload}")
    try:
        response = requests.post(f"{BASE_URL}/analytics/event",data=payload, headers=headers, timeout=timeout)
        log_trace(logging.INFO, f"Analytical Post event Response: {response}")
    except Exception as e:
        log_trace(logging.INFO, f"Analytical Post event Error: {e}")
    else:
        if response.status_code != 200:
            log_trace(logging.INFO, f"Analytical Post event Unsuccessful Response  {response.status_code}, Message: {response.text}")
        

