import os
import json
from fastapi import HTTPException
import pandas as pd
from time import time
from langchain_core.prompts import ChatPromptTemplate
from langchain.agents import AgentExecutor
from langchain.agents import create_tool_calling_agent
from logger import log_trace, logging
from .open_ai import MyOpenAI
# from .google_gemini import MyGemini
from .pplx import Perplexity
from .groq_lpu import GroqLPU
from db import schemas
from fuzzywuzzy import fuzz, process

root_dir = os.path.dirname(os.path.abspath(__file__))

class AppFunctions:
    def __init__(self) -> None:
        with open(f"{root_dir}/prompts.json") as f:
            self.prompts = json.load(f)
        with open(f"{root_dir}/examples.json") as f:
            self.examples = json.load(f)
        self.myopenai = MyOpenAI(temperature=0.0)#,model="gpt-3.5-turbo-0125")
        # self.mygoogle = MyGemini(temperature=0.0)
        self.mypplx = Perplexity()#model='mixtral-8x7b-instruct')
        self.groq = GroqLPU()
        self.output_type={
            "openai":"table",
            "google":"table",
            "pplx":"table",
            "groq":"table"
        }
        self.career_columns = list(schemas.CareersCreate.model_fields.keys())
        self.roadmap_columns = ["grade", "courses_and_grade_recommendation", "extracurricular_activities"]
        #self.college_columns = ["college_name", "tution_fees", "positives", "negatives", "why_this_recommendation", "probability_of_admission"]
        self.college_columns = ["college_name", "acceptance_rate", "tution_fees", "positives", "negatives", "why_this_recommendation", "probability_of_admission", "classification"]
        self.essay_review_columns = ["criterion", "feedback", "score", "suggestions"]

    def run_prompt_on_given_model(self, model, message, output_type='table'):
        tries = 1
        next_model = model
        response = []
        while tries < 3:
            log_trace(logging.INFO, f"Number of tries: {tries}, model: {model}")
            try:
                if model=='openai':
                    next_model = 'groq' # For a retry if this fails
                    try:
                        response = self.myopenai.get_completion(message)
                        try:
                            response = json.loads(response)
                            log_trace(logging.INFO, f"{model} fetched response {response}")
                            tries = 3
                        except Exception as err:
                            log_trace(logging.ERROR, f"Unexpected error {err} parsing the response with model {model}.")    
                    except Exception as e:
                        log_trace(logging.ERROR, f"Unexpected error {e} generating with model {model}.")
                elif model=='pplx':
                    next_model = 'groq' # For a retry if this fails
                    try:
                        response = self.mypplx.generate(message)
                        try:
                            response = json.loads(response)
                            tries = 3
                        except Exception as err:
                            log_trace(logging.ERROR, f"Unexpected error {err} parsing the response with model {model}.")
                            response = self._fix_json(response,error=err)
                    except Exception as e:
                        log_trace(logging.ERROR, f"Unexpected error {e} generating with model {model}.")
                    log_trace(logging.INFO, f"{model} fetched response {response}")
                elif model=='groq':
                    next_model = 'openai' # For a retry if this fails
                    try:
                        start_time = time()
                        log_trace(logging.INFO, f"{model} data message content: {message}")
                        response = self.groq.generate(message, output_type=output_type)
                        total_time = time()-start_time
                        log_trace(logging.INFO, f"{model} Response: {response} data loaded in {total_time}")
                        try:
                            response = json.loads(response)
                            tries = 3
                        except Exception as err:
                            log_trace(logging.ERROR, f"Unexpected error {err} parsing the response with model {model}.")
                            response = self._fix_json(response,error=err)
                    except Exception as e:
                        log_trace(logging.ERROR, f"Unexpected error {e} generating with model {model}.")
                    log_trace(logging.INFO, f"{model} fetched response {response}")
                else:
                    next_model = 'groq' # For a retry if this fails
                    try:
                        response = self.mygoogle.get_completion(message)
                        log_trace(logging.INFO, "mygoogle.get_completion fetch completed")
                        try:
                            response = json.loads(response)
                        except Exception as err:
                            log_trace(logging.ERROR, f"Unexpected error {err} parsing the response with model {model}.")
                            response = self._fix_json(response,error=err)
                    except Exception as e:
                        log_trace(logging.ERROR, f"Error at mygoogle.get_completion: {e}")
                    log_trace(logging.INFO, f"{model} fetched response {response}")
            except Exception as e:
                log_trace(logging.ERROR, f"Error generating responses using model {model}, error: {e}")
            # Retry with next_model
            model = next_model
            tries = tries + 1
        return response
        
    def get_top_colleges(self,grade, gpa, extra, 
                        field_of_interest, state, courses, credits,
                        num_colleges,tution_budget_per_year,school,
                        rank, sat_score, act_score, states_preference,
                        model='openai'):
        log_trace(logging.INFO, f"rank: {rank}, states_preference: {states_preference}, sat_score: {sat_score}, act_score: {act_score}")
        # if model=='groq':
        try: 
            prompt_template = ChatPromptTemplate.from_template(self.prompts['colleges'][self.output_type[model]])
            log_trace(logging.INFO, "#########################################")
            log_trace(logging.INFO, f"Prompt is {prompt_template}")
            log_trace(logging.INFO, "#########################################")
            # else:
            #     prompt_template = ChatPromptTemplate.from_template(self.prompts['colleges']['others'])
            messages = prompt_template.format_messages(grade=grade,
                                                        gpa = gpa,
                                                        extra=extra,
                                                        field_of_interest=field_of_interest,
                                                        state = state,
                                                        courses = courses,
                                                        credits = credits,
                                                        num_colleges = num_colleges,
                                                        tution_budget_per_year=tution_budget_per_year, 
                                                        school = school,
                                                        example=self.examples['colleges'],
                                                        rank=rank,
                                                        sat_score=sat_score,
                                                        act_score=act_score,
                                                        states_preference=states_preference)
            log_trace(logging.INFO, "#########################################")
            log_trace(logging.INFO, f"Formatted message is {messages}")
            log_trace(logging.INFO, "#########################################")
        except Exception as e:
            log_trace(logging.ERROR, f"Error formatting prompt template: {e}")
            response = self._fix_json(response,error=e)

        response = self.run_prompt_on_given_model(model, message=messages[0].content)
        
        if not isinstance(response, list) and len(response.keys())==1:
            key = list(response.keys())[0]
            response = response[key]
        #log_trace(logging.INFO, f"response: {response}")
        final_response = []
        if len(response)==1 and isinstance(response[0],list):
            response = response[0]
        for r in response:
            normalized_r = {}
            # print(r)
            log_trace(logging.INFO, f"Processing record: {r}")
            for k,v in r.items():
                if k in self.college_columns:
                    normalized_r[k] = v
                    #log_trace(logging.INFO, f"Normalized key: {k}, value: {v}")
                else:
                    nk,score = process.extractOne(k,self.college_columns,scorer=fuzz.ratio)
                    #log_trace(logging.INFO, f"nk: {nk}, score: {score}")
                    normalized_r[nk] = v
                    #log_trace(logging.INFO, f"Normalized key: {nk}, value: {v}")

            #log_trace(logging.INFO, f"normalized_r: {normalized_r}")
            if len(set(list(normalized_r.keys())).intersection(set(self.college_columns)))==len(self.college_columns):
                final_response.append(normalized_r)
        log_trace(logging.INFO, "Final response returned")
        return final_response

    def get_roadmap_options(self,school, course_catalog,
                            grade, extra, 
                            courses,
                            target_college,target_field,gpa, model='openai'
                            ):
        prompt_template = ChatPromptTemplate.from_template(self.prompts['roadmap'][self.output_type[model]][grade])
        # if model=='groq':
        #     prompt_template = ChatPromptTemplate.from_template(self.prompts['roadmap']['groq'][grade])
        # else:
        #     prompt_template = ChatPromptTemplate.from_template(self.prompts['roadmap']['others'][grade])
        # prompt_template = ChatPromptTemplate.from_template(self.prompts['roadmap'][grade])
        messages = prompt_template.format_messages(school=school,
                                                target_college=target_college,
                                                target_field=target_field,
                                                courses=courses,
                                                extra=extra,
                                                course_catalog=course_catalog,gpa=gpa,
                                                example=self.examples['roadmap'][grade])
        log_trace(logging.INFO, f"messages[0].content: {messages[0].content}")
        if model=='openai':
            response = self.myopenai.get_completion(messages[0].content)
            response = json.loads(response)
            log_trace(logging.INFO, f"Response {response} loaded for model {model}")
        elif model=='pplx':
            response = self.mypplx.generate(messages[0].content)
            try:
                response = json.loads(response)
            except Exception as e:
                log_trace(logging.ERROR, f"Error while handling response at model {model}: {e}")
                response = self._fix_json(response,error=e)
            log_trace(logging.INFO, f"{model} model loaded response {response}")
        elif model=='groq':
            response = self.groq.generate(messages[0].content)
            try:
                response = json.loads(response)
            except Exception as e:
                log_trace(logging.ERROR, f"Error while handling response loaded {e}")
                response = self._fix_json(response,error=e)
            log_trace(logging.INFO, f"{model} model loaded response {response}")
        else:
            response = self.mygoogle.get_completion(messages[0].content)
            try:
                response = json.loads(response)
            except Exception as e:
                log_trace(logging.ERROR, "Error at mygoogle.get_completion")
                response = self._fix_json(response,error=e)
            log_trace(logging.INFO, "Response loaded at mygoogle.get_completion")
        if not isinstance(response, list) and len(response.keys())==1:
            key = list(response.keys())[0]
            response = response[key]
        if len(response)==1 and isinstance(response[0],list):
            response = response[0]
        final_response = []
        for r in response:
            normalized_r = {}
            # print(r)
            for k,v in r.items():
                if k in self.roadmap_columns:
                    normalized_r[k] = v
                else:
                    nk,score = process.extractOne(k,self.roadmap_columns,scorer=fuzz.ratio)
                    log_trace(logging.INFO, f"nk: {nk}, score: {score}")
                    normalized_r[nk] = v 
            if len(set(list(normalized_r.keys())).intersection(set(self.roadmap_columns)))==len(self.roadmap_columns):
                final_response.append(normalized_r)
            # final_response.append(normalized_r)
        log_trace(logging.INFO, f"Final loaded response {final_response}")
        return final_response

    
    def get_career_options(self,grade, strength, weakness, extra_curricular,model='openai'):
        prompt_template = ChatPromptTemplate.from_template(self.prompts['career_options'][self.output_type[model]])
        messages = prompt_template.format_messages(grade=grade, strength=strength,
                                                extra_curricular=extra_curricular,
                                                weakness=weakness
                                                ,example=self.examples['career_options'])

        response = self.run_prompt_on_given_model(model, message=messages[0].content)
        if not isinstance(response, list) and len(response.keys())==1:
            key = list(response.keys())[0]
            response = response[key]
        final_response = []
        for r in response:
            normalized_r = {}
            for k,v in r.items():
                if k in self.career_columns:
                    normalized_r[k] = v
                else:
                    k,score = process.extractOne(k,self.career_columns,scorer=fuzz.ratio)
                    normalized_r[k] = v 
            if len(set(list(normalized_r.keys())).intersection(set(self.career_columns)))==len(self.career_columns):
                final_response.append(normalized_r)
        log_trace(logging.INFO, f"Final loaded response {final_response}")

        return final_response

    # letter_of_recommendation": "You are a fair, experienced and expert college and career counselor at high school {school}, {state}.
    # You are writing a letter of recommendation for a student applying to college {college} for the major {field_of_interest}.
    # Please provide a letter of recommendation for the student based on the following information: Student Name: {student_name},
    # GPA: {gpa}, Extracurricular Activities: {extra}, Courses: {courses}, Strengths: {strengths}, Weaknesses: {weaknesses},
    # Why you are recommending the student for the college and major. Do not make the letter generic, and focus on the student
    # strengths, highlight where possible how the student activities {extra} align with the {college} institutional priorities.
    # For any glaring negatives in the student profile, please offer remedial pathways and always encourage the {college} to give
    # the student due consideration. Use my past essays {past_essay1} and {past_essay2} to mimic my style of writing. Please address
    # the letter to the college admissions committee. Please use stellar examples of letters of recommendation on college websites
    # as an example.",
    def get_letter_of_recommendation(self, school, city, state, college, field_of_interest,
                                     name, gpa, w_gpa, sat, act, extra_curricular, courses, strengths, weakness,
                                     work_experience, projects, example1, example2, model='groq'):
        
        log_trace(logging.INFO, "Generating letter of recommendation")

        try:
            # prompt_template = ChatPromptTemplate.from_template(self.prompts['letter_of_recommendation'][self.output_type[model]])
            prompt_template = ChatPromptTemplate.from_template(self.prompts['LoR'])
            log_trace(logging.INFO, "#########################################")
            log_trace(logging.INFO, f"Prompt is {prompt_template}")
            log_trace(logging.INFO, "#########################################")
            messages = prompt_template.format_messages(school=school,
                                                       city=city,
                                                       state=state,
                                                       college=college,
                                                       field_of_interest=field_of_interest,
                                                       name=name,
                                                       gpa=gpa,
                                                       w_gpa=w_gpa,
                                                       sat=sat,
                                                       act=act,
                                                       extra_curricular=extra_curricular,
                                                       courses=courses,
                                                       strengths=strengths,
                                                       weakness=weakness,
                                                       work_experience=work_experience,
                                                       projects=projects,
                                                       example=self.examples['LoR'],
                                                       example1=example1,
                                                       example2=example2)
            log_trace(logging.INFO, "#########################################")
            log_trace(logging.INFO, f"Formatted message is {messages}")
            log_trace(logging.INFO, "#########################################")

            # response = self.run_prompt_on_given_model(model, message=messages[0].content, output_type='table')
            response = self.run_prompt_on_given_model(model, message=messages[0].content, output_type='json')
            print("Response loaded for groq.get_completion fetched")
            log_trace(logging.INFO, f"Response is {response}")
        except Exception as e:
            print(f"Error formatting prompt template: {e}")
            raise HTTPException(status_code=500, detail=f"Error generating letter of recommendation: {e}")

        return response
    

    def get_essay_review(self, #user_corpus,
                         school, city, state, college, field_of_interest, essay, essay_prompt, model='groq'):
        
        essay_criteria = ""
        essay_criteria_template = ""
        try:
            essay_criteria_template = ChatPromptTemplate.from_template(self.prompts['essay_criteria'])
            print("#########################################")
            print(f"Prompt is {essay_criteria_template}")
            print("#########################################")

            essay_criteria_prompt = essay_criteria_template.format_messages(essay_prompt = essay_prompt,
                                                               college = college,
                                                               field_of_interest = field_of_interest)
            print("###########################################################")
            print(f"Formatted essay criteria prompt is {essay_criteria_prompt}")
            print("###########################################################")
            essay_criteria = self.run_prompt_on_given_model(model, message=essay_criteria_prompt[0].content)
            print("Response loaded for groq.get_completion fetched")
            print(essay_criteria)
        except Exception as e:
            print(f"Error getting essay critera from the prompt template {essay_criteria_template}: {e}")
            essay_criteria = "Content, Grammar, Organization, Fit, Style, Diversity, Authenticity"

        messages = []
        response = []
        try:
            prompt_template = ChatPromptTemplate.from_template(self.prompts['essay_review'][self.output_type[model]])
            print("#########################################")
            print(f"Prompt is {prompt_template}")
            print("#########################################")
            
            messages = prompt_template.format_messages(essay_prompt = essay_prompt,
                                                       college = college,
                                                       school = school,
                                                       city = city,
                                                       state = state,
                                                       field_of_interest = field_of_interest,
                                                       essay_criteria = essay_criteria,
                                                       essay = essay)
            print("#########################################")
            print(f"Formatted message is {messages}")
            print("#########################################")
        except Exception as e:
            print(f"Error formatting prompt template: {e}")
            raise HTTPException(status_code=500, detail=f"Error formatting prompt template: {e}")
        
        try:
            response = self.run_prompt_on_given_model(model, message=messages[0].content)
            print("Response loaded for groq.get_completion fetched")
            print(response)
        except Exception as e:
            print(f"Error formatting prompt template: {e}")
            response = self._fix_json(response,error=e)

        if len(response)==1 and isinstance(response[0],list):
            response = response[0]

        final_response = []
        for r in response:
            normalized_r = {}
            # print(r)
            log_trace(logging.INFO, f"Processing record: {r}, Columns: {self.essay_review_columns}")
            for k,v in r.items():
                # Each key in the response should be one of the essay_review_columns
                if k in self.essay_review_columns:
                    normalized_r[k] = v
                    log_trace(logging.INFO, f"Normalized key: {k}, value: {v}")
                else:
                    nk,score = process.extractOne(k,self.essay_review_columns,scorer=fuzz.ratio)
                    log_trace(logging.INFO, f"nk: {nk}, score: {score}")
                    normalized_r[nk] = v
                    log_trace(logging.INFO, f"Normalized key: {nk}, value: {v}")

            log_trace(logging.INFO, f"normalized_r: {normalized_r}")
            if len(set(list(normalized_r.keys())).intersection(set(self.essay_review_columns)))==len(self.essay_review_columns):
                final_response.append(normalized_r)
        log_trace(logging.INFO, "Final response returned")
        return final_response

    def get_transcript_data(self, buffer, model, tools):
        custom_prompt = self.prompts['transcript_parsing']        
        prompt = ChatPromptTemplate.from_messages(
        [
            (
                "system",
                custom_prompt,
            ),
            ("human", "{input}"),
            ("placeholder", "{agent_scratchpad}"),
        ]
        )
        
        if model == 'openai':
            llm = self.myopenai.get_chat_llm()
        elif model == 'groq':
            llm = self.groq.get_chat_llm()
        
        agent = create_tool_calling_agent(llm, tools, prompt)
        agent_executor = AgentExecutor(agent=agent, tools=tools, verbose=True)
        transcript_parser = tools[0]
        extracted_data = transcript_parser._run(buffer)
        output = agent_executor.invoke({'input': f"Parse this transcript data: {extracted_data}"})['output']
        
        if isinstance(output, str):
            output = output.strip()
            if output.startswith('```json'):
                output = output[7:].strip()
            if output.endswith('```'):
                output = output[:-3].strip()
            output = output.strip('`')
        log_trace(logging.INFO, f"output: {output}")
        try:
            output = json.loads(output) if isinstance(output, str) else output
        except json.JSONDecodeError as e:
            log_trace(logging.ERROR, f"Error: {e}")
            raise ValueError("Failure, not valid JSON output")
        log_trace(logging.INFO, "Response loaded")

        return output

    def _fix_json(self,json_bug,error):
        log_trace(logging.INFO, "Fixing errors in JSON syntax")
        prompt = """Loading this json {0} gives this error - {1}.\n Can you fix this json to right syntax?""".format(json_bug,error)
        # prompt = "can you convert this to JSON format?{0}".format(json_bug)
        start_time = time()
        response = self.myopenai.get_completion(prompt)
        total_time = time()-start_time
        print(total_time)
        return json.loads(response)
