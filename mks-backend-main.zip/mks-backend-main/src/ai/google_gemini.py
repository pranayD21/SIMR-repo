import os
import json
import time
import google.generativeai as genai
from logger import log_trace, logging
from dotenv import load_dotenv, find_dotenv

# from langchain.chat_models import ChatOpenAI
_ = load_dotenv(find_dotenv()) # read local .env file
genai.configure(api_key=os.environ['GOOGLE_API_KEY'])


class MyGemini:
    def __init__(self,temperature=0.0) -> None:
        # self.temperature = temperature

        self.llm_model = genai.GenerativeModel('gemini-pro')
    
    # def get_completion(self,prompt,temperature=None):
    #     messages = [{"role": "user", "content": prompt}]
    #     response = self.client.chat.completions.create(
    #         model=self.llm_model,
    #         messages=messages,
    #         temperature=self.temperature if not temperature else temperature, 
    #         response_format ={"type":"json_object"},
    #         max_tokens=1000
    #     )
    #     print(response)
    #     return response.choices[0].message.content
        
    def _get_json(self, out):
        # Split the data into lines and then into columns
        # print(out)
        lines = out.strip().split('\n')
        useful_lines = [s for s in lines if '|' in s]
        columns = ["_".join(x.strip("|").strip().replace('/','_and_').lower().split()) for x in useful_lines[0].split(' | ')]
        log_trace(logging.INFO, f"Columns: {columns}")
        data_list = []

        # Parse each row in the table
        for line in useful_lines[2:]:
            values = line.split(' | ')
            data_dict = {}
            for i, value in enumerate(values):
                # Handle multi-line values in "Strengths" and "Weaknesses" by splitting on '<br>'
                if columns[i] in ['strengths', 'weaknesses','positives','negatives']:
                    data_dict[columns[i]] = [v.strip('- ').strip().strip("|").strip("*") for v in value.split('<br>')]
                else:
                    data_dict[columns[i]] = value.strip("|").strip().strip("*")
            data_list.append(data_dict)
            # Convert the list of dictionaries to JSON
        json_data = json.dumps(data_list, indent=4)
        return json_data
    
    def get_completion(self,prompt):
        response = self.llm_model.generate_content(prompt)
        # print(response.text)
        response = self._get_json(response.text)
        # if 'JSON' in response.text:
        #     response = " ".join(response.text.split('JSON')[1].strip("```").split("\n"))
        # elif 'json' in response.text:
        #     response =" ".join(response.text.split('json')[1].strip("```").split("\n"))
        # elif '```' in response.text:
        #     print("yess")
        #     response = " ".join(response.text.split('```')[1].strip("```").split("\n"))
        # else:
        #     response = " ".join(response.text.split('\n'))
        log_trace(logging.INFO, f"Response: {response}")
        return response


if __name__=="__main__":
     gem = MyGemini()
     start = time.time()
     out = gem.get_completion("""give me top colleges in mechanical engineering in US. I want the following fields -college name,
                   tution fees, program, strengths and weaknesses. Can you give output as a table?""")
     total = time.time()-start
     log_trace(logging.INFO, f"Total: {total}")
     log_trace(logging.INFO, f"Out: {out}")
