import os
import time
import json
import openai
import datetime
from openai import OpenAI
from logger import log_trace, logging
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv, find_dotenv

# read local .env file
_ = load_dotenv(find_dotenv())
openai.api_key = os.environ['OPENAI_API_KEY']

# Define the date after which the model should be set to "gpt-3.5-turbo"
target_date = datetime.date(2024, 6, 12)


class MyOpenAI:
    def __init__(self,temperature=0.0,model="gpt-4o-mini") -> None:
        # Get the current date
        # current_date = datetime.datetime.now().date()
        # Define the date after which the model should be set to "gpt-3.5-turbo"
        # target_date = datetime.date(2024, 6, 12)
        # Set the model variable based on the current date
        # if current_date > target_date:
        self.llm_model = model
        self.temperature = temperature
        self.client = OpenAI()

    def _get_json(self, out):
        # Split the data into lines and then into columns
        lines = out.strip().split('\n')
        useful_lines = [s for s in lines if '|' in s]
        columns = ["_".join(x.strip("|").strip().replace('/','_and_').lower().split()) for x in useful_lines[0].split(' | ')]
        log_trace(logging.INFO, f"Columns: {columns}")
        data_list = []

        # Parse each row in the table
        for line in useful_lines[2:]:
            values = line.split(' | ')
            data_dict = {}
            for i, value in enumerate(values):
                # Handle multi-line values in "Strengths" and "Weaknesses" by splitting on '<br>'
                if columns[i] in ['strengths', 'weaknesses','positives','negatives']:
                    data_dict[columns[i]] = [v.strip('- ').strip().strip("|").strip("*") for v in value.split('<br>')]
                else:
                    data_dict[columns[i]] = value.strip("|").strip().strip("*")
            data_list.append(data_dict)
            # Convert the list of dictionaries to JSON
        json_data = json.dumps(data_list, indent=4)
        return json_data
    
    def get_completion(self,prompt,temperature=None):
        messages = [{"role": "user", "content": prompt}]
        if self.llm_model=='gpt-4-0125-preview':
            response = self.client.chat.completions.create(
            model=self.llm_model,
            messages=messages,
            temperature=self.temperature if not temperature else temperature, 
            # response_format ={"type":"json_object"},
            max_tokens=8192
            )
            #return response.choices[0].message.content
        else:
            response = self.client.chat.completions.create(
            model=self.llm_model,
            messages=messages,
            temperature=self.temperature if not temperature else temperature, 
            #response_format ={"type":"json_object"},
            max_tokens=8192
            )
        return self._get_json(response.choices[0].message.content)
        # print(response.choices[0].message.content)
    
    def get_chat_llm(self):
        return ChatOpenAI(
            openai_api_key=os.environ['OPENAI_API_KEY'],
            model_name=self.llm_model,
            temperature=self.temperature
        )
        

if __name__=="__main__":
    #oai = MyOpenAI(model='gpt-3.5-turbo-0125')
    oai = MyOpenAI(model='gpt-4o-mini')
    start = time.time()
    out = oai.get_completion("""give me top colleges in mechanical engineering in US. I want the following fields -college name,
                   tution fees, program, strengths and weaknesses. Can you give output as a table?""")
    total = time.time()-start 
    log_trace(logging.INFO, f"Total: {total}")

    out = json.loads(out)
    log_trace(logging.INFO, f"Out: {out}")
