# from groq.cloud.core import Completion
# import requests
import os
import json
from groq import Groq
from langchain_groq import ChatGroq
from logger import log_trace, logging
from dotenv import load_dotenv, find_dotenv

# read local .env file
_ = load_dotenv(find_dotenv())


class GroqLPU:
    def __init__(self) -> None:
        #api_key = os.environ['GROQ_API_KEY']
        self.model = Groq() # Groq(api_key=api_key)#"llama2-70b-4096")

    def _get_json(self, out):
        # Split the data into lines and then into columns
        lines = out.strip().split('\n')
        useful_lines = [s for s in lines if '|' in s]
        columns = ["_".join(x.strip("|").strip().replace('/','_and_').lower().split()) for x in useful_lines[0].split(' | ')]
        log_trace(logging.INFO, f"Columns: {columns}")
        data_list = []

        # Parse each row in the table
        for line in useful_lines[2:]:
            values = line.split(' | ')
            data_dict = {}
            for i, value in enumerate(values):
                # Handle multi-line values in "Strengths" and "Weaknesses" by splitting on '<br>'
                if columns[i] in ['strengths', 'weaknesses','positives','negatives']:
                    data_dict[columns[i]] = [v.strip('- ').strip().strip("|").strip("*") for v in value.split('<br>')]
                else:
                    data_dict[columns[i]] = value.strip("|").strip().strip("*")
            data_list.append(data_dict)
            # Convert the list of dictionaries to JSON

        json_data = json.dumps(data_list, indent=4)
        return json_data

    def clean_llm_output(self, output):
        # Remove leading empty line
        cleaned_output = output.lstrip()
        # Remove newlines between sections
        cleaned_output = cleaned_output.replace('\n\n', '\n')

        return cleaned_output

    def prep_json_output(self, output):
        # Remove any leading characters before the JSON '{'   
        output = output[output.find('{'):]
        # Remove any trailing characters after the JSON '}'
        output = output[:output.rfind('}')+1]
        return output
    
    # def generate(self,prompt):
    #     response, id, stats = self.model.send_prompt("llama2-70b-4096", user_prompt=prompt)
    #     #self.model.send_prompt("llama2-70b-4096", user_prompt=prompt)
    #     print(response)
    #     # print(reso)

    #     response = self._get_json(response)
    #     return response
    
    def generate(self, prompt,output_type="table"):
        log_trace(logging.INFO, f"Prompt: {prompt}")
        chat_completion = self.model.chat.completions.create(
        messages=[
                    {
                        "role": "system",
                        "content": "you are a professional student career counselor. please respond using table format."
                    },
                    # Set a user message for the assistant to respond to.
                    {
                        "role": "user",
                        "content": prompt,
                    }
                ],
            # The language model which will generate the completion.
            model="llama3-70b-8192", #"mixtral-8x7b-32768",#"llama2-70b-4096",#"mixtral-8x7b-32768",#
            temperature=0.5,
            max_tokens=8192
        )
        response = chat_completion.choices[0].message.content
        log_trace(logging.INFO, f"Response: {response}")
        response = self.clean_llm_output(response)
        log_trace(logging.INFO, f"Response after cleaning up newlines: {response}")

        if output_type=='table':
            response = self._get_json(response)
        elif output_type=='string':
            response = response.strip()
        else:
            log_trace(logging.INFO, f"Parsing response as json")
            if isinstance(response, str):
                log_trace(logging.INFO, f"response is a string object, processing it as json!\n{response}")
                response = self.prep_json_output(response)
                response = json.loads(response)
                log_trace(logging.INFO, f"Response as JSON\n{response}")
        return response
    
    def get_chat_llm(self):
        return ChatGroq(
            temperature=1,
            model_name="llama3-70b-8192",
            api_key=os.environ['GROQ_API_KEY']
        )

if __name__=="__main__":
    gq = GroqLPU()
    import time 
    start_time = time.time()
    out = gq.generate("""give me top colleges in mechanical engineering in US. Give me response with fields -college name, tution fees, program, strengths and weaknesses. can you give me output as a tsv table""",output_type="table")
    # out = out.split(":")[1]
    end_time = time.time()
    log_trace(logging.INFO, f"Out: {out}")
    log_trace(logging.INFO, f"Time Taken: {end_time-start_time}")
