import json
import os
import re
import time
from typing import Optional, Union
from fastapi import FastAPI, APIRouter, Depends, UploadFile, File
from pydantic import BaseModel
from db import Constants
from utils import wrap_response, get_identity_token, create_formatted_pdf, create_lor_formatted_pdf
from .app_functions import AppFunctions
import db.db_api as api
from auth_jwt.jwt_token import JWKS, JWTAuthorizationCredentials, JWTBearer, fetch_jwks
import shutil
from io import BytesIO
from ai.transcript_parsing_tools import TranscriptParser
import time
from logger import log_trace, logging
from . import analytic_data

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/ai",
    tags=["ai"],
    # dependencies=[Depends(get_token_header)],
    responses={404: {"description": "Not found"}},
)

# Needed for parsing the auth token in the request headers
jwks = JWKS.model_validate(fetch_jwks())
auth = JWTBearer(jwks)

app_fn = AppFunctions()


class Student(BaseModel):
    grade: Union[str, None] = None
    gpa: Union[float,None] = None
    extra_curricular: Union[str, None] = None
    field_of_interest: Union[str, None] = None 
    state: Union[str, None] = None  
    courses: Union[str, None] = None 
    num_colleges: Union[int, None] = None 
    tution_budget_per_year: Union[str,None] = None 
    school: Union[str,None] = None 
    strength: Union[str,None] = None
    weakness: Union[str,None] = None
    credits: Union[int, None] = None
    target_major: Union[str,None] = None
    target_college: Union[str,None] = None
    course_catalog: Union[str, None] = None

class StudentCareer(BaseModel):
    grade: Union[str, None] = None
    extra_curricular: Union[str, None] = None
    strength: Union[str,None] = None
    weakness: Union[str,None] = None

grade_lookup = {
    '9':"Freshman",
    '10':"Sophomre",
    '11':"Junior",
    '12':"Senior"
}

def clean_college_name(name):
    # Remove numbering at the start (e.g., "1. ")
    name = re.sub(r'^\d+\.\s*"', '', name)
    # Remove any leading and trailing quotation marks or whitespaces
    name = re.sub(r'^[\s"]+|[\s"]+$', '', name)
    return name

@router.post("/careers/{model}")
def show_career_options(user_id: int,
                        refresh_results:bool =True, 
                        model="openai",
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    # print(model)
    error = None
    final_results=[]
    try:
        student = api.get_student_by_uid(user_id=user_id, credentials=credentials)
        if not student:
            # bail?
            output = {
                "message":"Student not found.",
                "data": [],
                "statusCode": 500,
                    "error": {"Student not found!":500}       
            }
            return output
        
        log_trace(logging.INFO, f"student: {student}")
        log_trace(logging.INFO, f"refresh_results: {refresh_results}")
        if not refresh_results:
            results = api.get_student_careers(student_id=student['id'], credentials=credentials)
            log_trace(logging.INFO, f"results: {results}")
            return results
        else:
            student_details = api.get_student_primary_school(user_id=user_id, credentials=credentials)
            log_trace(logging.INFO, f"student_details: {student_details}")
            if not student_details:
                student_details={}
                student_details['current_grade']=''
            student_sw = api.get_student_strengths_weakness_by_id(student_id=student['id'], credentials=credentials)
            if not student_sw:
                student_sw={}
                student_sw['strengths']=''
                student_sw['weakness']= ''
            activities = api.get_student_activities(user_id=user_id, credentials=credentials)
            extra = []
            strengths = []
            if activities:
                for act in activities:
                    if act['type'] =='Co-curricular Activities':
                        extra.append(act['activity_name'])
                    else:
                        strengths.append(act['activity_name'])
            log_trace(logging.INFO, f"activities: {activities}")
            extra_curricular = ", ".join(extra) if len(extra)>0 else ''
            student_sw['strengths'] = ", ".join(strengths) if len(strengths)>0 else ''

            log_trace(logging.INFO, f"Extra curriculars are {extra_curricular}")
            log_trace(logging.INFO, f"Strengths are {student_sw['strengths']}")
            log_trace(logging.INFO, f"Current grade is {student_details['current_grade']}")

            if (student_details['current_grade']):
                grade, strength, weakness = grade_lookup[student_details['current_grade']], student_sw['strengths'], student_sw['weakness']
            else:
                grade, strength, weakness = "", student_sw['strengths'], student_sw['weakness']

            log_trace(logging.INFO, f"Grade : {grade}, Strengths: {strength}, Weaknesses: {weakness}")
            results = app_fn.get_career_options(grade, strength, weakness, extra_curricular,model=model)
            log_trace(logging.INFO, f"show_career_options: results {results}")
            # final_results = results
            for result in results:
                # print(result)
                #career = api.get_career_by_id
                career = api.create_career(career=result,
                                           refresh=refresh_results, credentials=credentials)
                # sc = api.create_student_career(student_career={"student_id":student['id'],
                #                                         "career_id":career['id']})
                result['career_id']=career['id']
                final_results.append(result)
    except Exception as e:
        error = e
        log_trace(logging.ERROR, f"Error: {e}")
        # results = []
    output = {
        "message":"Possible Careers Generated!",
        "data": final_results if len(final_results)>0 else [],
        "statusCode": 200 if error is None else 500,
            "error":{} if error is None else {str(error):500}       
            }
    return output
        

@router.post("/colleges/{model}")
def show_college_options(user_id: int,
                         career_id: int|None,
                         num_colleges:int|None, 
                         tution_budget_per_year:int|None,
                         refresh_results:bool =True,
                         model="openai",
                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    try:
        student = api.get_student_by_uid(user_id, credentials)
        if not student:
            output = {
                "message":"Student not found.",
                "data": [],
                "statusCode": 500,
                    "error": {"Student not found!":500}       
            }
            return output

        if not refresh_results:
            results = api.get_student_target_schools(student_id=student['id'], credentials=credentials)
            return results
        else:
            student_details = api.get_student_primary_school(user_id=user_id, credentials=credentials)
            log_trace(logging.INFO, f"show_college_options: student_details: {student_details}")
            if not student_details:
                grade = ''
                gpa = 3.0
                school = ''
                state = ''
            else:
                grade = grade_lookup[student_details['current_grade']]
                gpa = student_details['gpa']
                school = api.get_school_by_id(school_id=student_details['school_id'], credentials=credentials)
                state = school['state']
                school = school['name']
                log_trace(logging.INFO, f"show_college_options: school: {school}")

            # Get standardized test score
            tests = api.get_student_standardized_test_by_id(student_id=student["id"], credentials=credentials)
            sat_score = 0
            act_score = 0
            for test in tests:
                if test["test_type"] == Constants.STD_TEST_TYPE_ACT.value:
                    act_score = test["total_score"]
                    log_trace(logging.INFO, f"show_college_options: act_score: {act_score}")
                elif test["test_type"] == Constants.STD_TEST_TYPE_SAT.value:
                    sat_score = test["total_score"]
                    log_trace(logging.INFO, f"show_college_options: sat_score: {sat_score}")
            
            rank = ""
            states_preference = "in-state and out-of-state"

            student_activities = api.get_student_activities(user_id=user_id, credentials=credentials)
            log_trace(logging.INFO, f"show_college_options: student_activities: {student_activities}")
            extra = [x['activity_name'] for x in student_activities]
            extra = ", ".join(extra) if len(extra)>0 else ''

            career = api.get_career_by_id(career_id=career_id, credentials=credentials)
            field_of_interest = career['majors']
            
            student_courses = api.get_student_courses(user_id=user_id, credentials=credentials)
            log_trace(logging.INFO, f"student_courses: {student_courses}")
            courses = [x['course_name'] for x in student_courses]
            courses = ", ".join(courses) if len(courses)>0 else ''

            course_credits = [x['credits'] for x in student_courses]
            total_credits = sum(course_credits) if len(course_credits)>0 else 0
                        
            results = app_fn.get_top_colleges(grade, gpa, extra, 
                                field_of_interest, state, courses, total_credits,
                                num_colleges,tution_budget_per_year,school,
                                rank, sat_score, act_score, states_preference,
                                model=model)
            
            # augment results with the college pics if we have them
            for college in results:
                # college_columns = ["college_name", "tuition_fees", "positives", "negatives", why_this_recommendation, "probability_of_admission"]            
                name = clean_college_name(college['college_name'])
                if not name:
                    continue
                pic_url = api.get_target_school_pic_url(college_name=name, credentials=credentials)
                college['college_pic_url'] = pic_url
                college['college_url'] = pic_url
                target_school = api.get_target_school(college_name=name, credentials=credentials)
                friends_info = None
                if target_school:
                    id = target_school["id"]
                    log_trace(logging.INFO, f"Get friends also interested in this college {id}")
                    # Get friends who have saved these colleges
                    friends_info = api.get_student_college_intersections(college_id=target_school["id"],
                                                                         user_id=user_id,
                                                                         credentials=credentials)
                    college['college_id'] = id
                if friends_info and len(friends_info) > 0:
                    college['friends_info_count'] = len(friends_info)
                    college['friends_info'] = friends_info
                else:
                    college['friends_info_count'] = 0
                    college['friends_info'] = None
    except Exception as e:
        error = e
        log_trace(logging.ERROR, f"Error: {error}")
        results = []
    output = {
        "message":"Suitable College Options Generated!",
        "data": results,
        "statusCode": 200 if error is None else 500,
            "error":{} if error is None else {str(error):500}         
            }
    # Post the recommended college details to the analytics
    # getting a list of dictionarys. 
    if results:
        analytic_data.parse_recommended_colleges_data(user_id, results)
    return output

@router.post("/roadmap/{model}")
def show_roadmap(payload: Student,model,
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    grade = payload.grade
    gpa = payload.gpa
    extra = payload.extra_curricular
    target_major = payload.target_major
    courses = payload.courses
    school = payload.school
    target_college = payload.target_college
    course_catalog = payload.course_catalog
    results = app_fn.get_roadmap_options(school, course_catalog,
                            grade, extra, 
                            courses,
                            target_college,target_major,gpa,
                            model=model
                            )
    log_trace(logging.INFO, "show_roadmap: Results fetched successfully")
    output = {
        "message":"College Roadmap Generated!",
        "data": results,
        "statusCode": 200 if error is None else 500,
            "error":{} if error is None else {str(error):500}        
            }
    return output

@router.post("/transcript/processing/{model}")
def transcript_processing(user_id: int, model='groq', file: UploadFile = File(...), credentials: JWTAuthorizationCredentials = Depends(auth)):
    message = "Transcript Processing Failed!"
    output = {}

    if not file.filename.lower().endswith('.pdf'):
        message = "Invalid file type. Only PDF files are accepted."
        log_trace(logging.INFO, f"transcript_processing: {message}")
        return wrap_response(data=None, message=message, code=404,
                             error={"exception": "InvalidArgument", "message": "Invalid file type"})    

    buffer = BytesIO()
    shutil.copyfileobj(file.file, buffer)
    buffer.seek(0)
    if not buffer.read(5) == b'%PDF-':
        message = "Invalid file content. The file is not a valid PDF."
        log_trace(logging.INFO, f"transcript_processing: {message}")
        return wrap_response(data=None, message=message, code=404,
                             error={"exception": "InvalidArgument", "message": "Invalid file content"})

    retries = 2
    for attempt in range(retries + 1):
        try:
            result = app_fn.get_transcript_data(buffer, model, [TranscriptParser()])
            if (result is None) or (len(result) == 0):
                message = "Failed to extract data from the transcript using pdf extraction tool."
                log_trace(logging.ERROR, f"{message}")
                # raise Exception(message)
                return wrap_response(data=None, message=message, code=500,
                             error={"exception": "InternalServerError", "message": "Unknown error processing request"})    

            break
        except Exception as e:
            log_trace(logging.ERROR, f"Attempt {attempt + 1} failed: {str(e)} at {time.time()}")
            if attempt < retries:
                wait_time = 2 * (attempt + 1)
                time.sleep(wait_time)
                buffer.seek(0)
            else:
                message = f"Transcript Processing Failed: {str(e)}"
                log_trace(logging.ERROR, f"{message}")
                return wrap_response(data=None, message=message, code=404,
                             error={"exception": "InternalServerError", "message": "Unknown error processing request"})    

    try:
        school_data = result['school_info']
        if not school_data['country'] or school_data['country'] == '':
            school_data['country'] = 'United States'
        
        school_response = api.create_school(school=school_data, credentials=credentials)
        if 'detail' in school_response:
            message = f"Failed to create school: {school_response['detail'][0]['msg']}"
            log_trace(logging.ERROR, f"{message}")
            return wrap_response(data=None, message=message, code=404,
                             error={"exception": "InternalServerError", "message": "Unknown error processing request"}) 
        school_id = school_response['id']

        student_response = api.get_student_by_uid(user_id=user_id, credentials=credentials)
        if 'detail' in student_response:
            message = f"Failed to get student: {student_response['detail'][0]['msg']}"
            log_trace(logging.ERROR, f"{message}")
            return wrap_response(data=None, message=message, code=404,
                             error={"exception": "InternalServerError", "message": "Unknown error processing request"}) 

        student_id = student_response['id']
        student_school_data = result['student_school_info']
        student_school_data.update(result['school_info'])
        student_school_data['student_id'] = student_id
        student_school_data['school_id'] = school_id
        student_school_data['user_id'] = user_id

        create_student_school_response = api.create_student_school(student_school=student_school_data, credentials=credentials)
        if 'detail' in create_student_school_response:
            message = f"Failed to create student school: {create_student_school_response['detail'][0]['msg']}"
            log_trace(logging.ERROR, f"{message}")
            return wrap_response(data=None, message=message, code=404,
                             error={"exception": "InternalServerError", "message": "Unknown error processing request"}) 

        courses_data = result['courses']
        for course in courses_data:
            course["student_id"] = student_id
            course["school_id"] = school_id

        add_courses_response = api.add_student_courses(user_id=user_id, student_course=courses_data, credentials=credentials)
        if 'detail' in add_courses_response:
            message = f"Failed to add student courses: {add_courses_response['detail'][0]['msg']}"
            log_trace(logging.ERROR, f"{message}")
            return wrap_response(data=None, message=message, code=404,
                             error={"exception": "InternalServerError", "message": "Unknown error processing request"}) 

        message = "Transcript Processed Successfully!"
        log_trace(logging.INFO, f"transcript_processing: {message}")
        output["data"] = result

    except Exception as e:
        log_trace(logging.ERROR, f"transcript_processing: Error during processing: {str(e)} at {time.time()}")
        message = f"Transcript Processing Failed: {str(e)}"
        return wrap_response(data=None, message=message, code=404,
                             error={"exception": "InternalServerError", "message": "Unknown error processing request"}) 

    output["message"] = message
    return output

@router.post("/essay_review/student_target_school/{student_target_school_id}/college/{college}/major/{major}/prompt/{prompt}/{model}")
def essay_review(student_target_school_id: int, college: str, major: str, prompt: str,
                 essay: UploadFile = File(...), model='openai', credentials: JWTAuthorizationCredentials = Depends(auth),
                 identity_token: str = Depends(get_identity_token)):
    error = None
    upload_response = None
    output_message = "Essay Review Completed!"
    response = None
    try:
        buffer = BytesIO()
        shutil.copyfileobj(essay.file, buffer)
        buffer.seek(0)

        # user_corpus = api.get_user_corpus(user_id, credentials)
        # Get the student_target_school object
        student_target_school = api.get_student_target_school(student_target_school_id, credentials)
        if not student_target_school:
            log_trace(logging.ERROR, f"Student Target School id {student_target_school_id} not found!")
            output = {
                "message":"Unable to find the saved college for the student.",
                "data": [],
                "statusCode": 500,
                "error": {
                    "Student Target School not found!":500
                    }
            }
            return output
        log_trace(logging.INFO, f"student_target_school: {student_target_school}")

        # Get student school details
        student = api.get_student_by_id(student_target_school["student_id"], credentials)
        if not student:
            output = {
                "message":"Student not found.",
                "data": [],
                "statusCode": 500,
                "error": {
                    "Student not found!":500
                    }
            }
            return output
        log_trace(logging.INFO, f"student: {student}")

        student_details = api.get_student_primary_school(user_id=student["user_id"], credentials=credentials)
        log_trace(logging.INFO, f"student_details: {student_details}")
        if not student_details:
            school = ''
            city = ''
            state = ''
        else:
            school_info = api.get_school_by_id(school_id=student_details['school_id'], credentials=credentials)
            school = school_info['name']
            city = school_info['city']
            state = school_info['state']
            log_trace(logging.INFO, f"school: {school_info}")
        
        result = app_fn.get_essay_review(#user_corpus=user_corpus,
                                         school=school,
                                         city = city,
                                         state = state,
                                         college = college,
                                         field_of_interest = major,
                                         essay_prompt=prompt,
                                         essay=buffer.getbuffer().tobytes().decode('utf-8'),
                                         model = model)

        log_trace(logging.INFO, f"essay_review: result: {result}")
        
        buffer.seek(0)
        data = json.dumps(result)
        log_trace(logging.INFO, f"essay_review: data: {data}")
        output_buffer = create_formatted_pdf(prompt=prompt, essay=buffer, json_data=data)
        epoch = int(time.time())
        # Add a file name to this buffer
        output_buffer.filename = f"essay_review_{student['user_id']}_{college}_{major}_{epoch}.pdf"
        output_buffer.seek(0)
        output_buffer.file = output_buffer
        output_buffer.content_type = "application/pdf"

        log_trace(logging.INFO, f"essay_review: output_buffer: {output_buffer}")
        try:
            # If its test env, we dont want to upload to S3
            db_server = os.getenv("DB_URL")
            # If db_server contains 'localhost', then we are in test env
            if db_server and db_server.find('localhost') != -1:
                log_trace(logging.INFO, f"Test environment detected, skipping S3 upload")
                # Write the buffer to a file
                filename = f"/tmp/essay_review_{student['user_id']}_{college}_{major}_{epoch}.pdf"
                with open(filename, 'wb') as f:
                    f.write(output_buffer.getbuffer())

                upload_response = {"status_code": 200, "data": "mock_s3_url", "message": "Mock S3 upload successful"}
            else:
                upload_response = api.upload_pdf_file(file=output_buffer, credentials=credentials, object_type="essay_review", identity_token=identity_token)
            log_trace(logging.INFO, f"essay_review: upload_response: {upload_response}")
        except Exception as e:
            log_trace(logging.ERROR, f"essay_review: Error uploading file: {str(e)}")
            raise Exception("Failed to upload the essay review to the S3 bucket.")

        if upload_response["status_code"] == 200:
            # Save the response to the database
            log_trace(logging.INFO, f"Saving the review to db")
            timestamp = time.time()
            response = api.save_essay_review(essay_review={"student_target_school_id":student_target_school_id,
                                                        "user_id":student['user_id'],
                                                        "essay_review_s3_url":upload_response['data'],
                                                        "date_reviewed":timestamp},
                                                        credentials=credentials)
            if not response:
                log_trace(logging.INFO, f"Error saving the review to db")
                raise Exception("Failed to save essay review to the database.")
        else:
            log_trace(logging.INFO, f"Error uploading file {upload_response['message']}")
            output = {
                        "message": upload_response["message"],
                        "data": None,
                        "statusCode": 500,
                        "error":{
                            "Unknown Error in Upload to S3":500
                            }
                    }
            return output
    except Exception as e:
        log_trace(logging.ERROR, f"Unknown error uploading essay {str(e)}")
        error = e
        output_message = "Essay Review Failed!"
        result = []
        output = {
                    "message": output_message,
                    "data": None,
                    "statusCode": 500,
                    "error":{
                        "Unknown Error in Upload to S3":500
                        }
                }
        return output

    log_trace(logging.INFO, f"Successfully completed essay review, error: {error}")
    output = {
                "message":upload_response['message'],
                "data": response,
                "statusCode": 200 if error is None else 500,
                "error":{} if error is None else {str(error):500}
            }
    return output

def concatenate_work_experience(work_experience):
    # Concatenate the work experience
    work_experience_string = ""
    for work in work_experience:
        log_trace(logging.INFO, f"work: {work}")
        title = work['job_title'] if work['job_title'] else ''
        company = work['company_name'] if work['company_name'] else ''
        start_date = work['start_date'] if work['start_date'] else ''
        end_date = work['end_date'] if work['end_date'] else ''
        if work['active']:
            end_date = 'Present'
        description = work['job_description'] if work['job_description'] else ''
        work_experience_string += f"{title} at {company} from {start_date} to {end_date}\n"
        work_experience_string += f"Highlights: {description}\n"
    return work_experience_string

def concatenate_projects(projects):
    # Concatenate the projects
    projects_string = ""
    for project in projects:
        log_trace(logging.INFO, f"project: {project}")
        title = project['project_title'] if project['project_title'] else ''
        description = project['project_description'] if project['project_description'] else ''
        skills = project['skills'] if project['skills'] else ''
        rewards = project['rewards_recognition'] if project['rewards_recognition'] else ''
        projects_string += f"{title}\n"
        projects_string += f"Description: {description}\n"
        projects_string += f"Skills: {skills}\n"
        projects_string += f"Rewards: {rewards}\n"
    return projects_string

# Letter of recommendation
@router.post("/letters_of_recommendation/counselors/id/{counselor_id}/recommendation/letter/{model}")
def recommendation_letter(counselor_id: int,
                          student_target_school_id: int,
                          example1: UploadFile = File(...),
                          example2: UploadFile = File(...), 
                          model='groq', credentials: JWTAuthorizationCredentials = Depends(auth),
                          identity_token: str = Depends(get_identity_token)):
    error = None
    output = {}
    buffer = None
    buffer2 = None
    response = None
    try:
        buffer = BytesIO()
        shutil.copyfileobj(example1.file, buffer)
        buffer.seek(0)
        buffer2 = BytesIO()
        shutil.copyfileobj(example2.file, buffer2)
        buffer2.seek(0)
    except Exception as e:
        log_trace(logging.ERROR, f"Error reading example files file: {str(e)}")
        output_message = "Recommendation Letter Failed!"
        output = {
                    "message": output_message,
                    "data": None,
                    "statusCode": 500,
                    "error":{
                        "Unknown Error reading examples {str(e)}":500
                        }
                }
        return output
    
    try:
        # Get the student_target_school object
        student_target_school = api.get_student_target_school(student_target_school_id, credentials)
        if not student_target_school:
            log_trace(logging.ERROR, f"Student Target School id {student_target_school_id} not found!")
            output = {
                "message":"Unable to find the saved college for the student.",
                "data": [],
                "statusCode": 500,
                    "error": {"Student Target School not found!":500}       
            }
            return output
        
        # Get college from college id
        college = api.get_target_school_by_id(college_id=student_target_school['college_id'], credentials=credentials)
        if not college:
            output = {
                "message":"College not found.",
                "data": [],
                "statusCode": 500,
                    "error": {"College not found!":500}       
            }
            return output
        
        # Get major from the career
        career = api.get_career_by_id(career_id=student_target_school['career_id'], credentials=credentials)
        if not career:
            output = {
                "message":"Career not found.",
                "data": [],
                "statusCode": 500,
                    "error": {"Career not found!":500}       
            }
            return output

        student = api.get_student_by_id(student_id=student_target_school['student_id'], credentials=credentials)
        if not student:
            output = {
                "message":"Student not found.",
                "data": [],
                "statusCode": 500,
                    "error": {"Student not found!":500}       
            }
            return output

        user_result = api.get_user_by_id(user_id=student['user_id'], credentials=credentials)
        if not user_result:
            output = {
                "message":"User not found.",
                "data": [],
                "statusCode": 500,
                    "error": {"User not found!":500}       
            }
            return output
        else:
            user_info = user_result['data']
        
        student_details = api.get_student_primary_school(user_id=student['user_id'], credentials=credentials)
        log_trace(logging.INFO, f"recommendation_letter: student_details: {student_details}")
        if not student_details:
            school = ''
            city = ''
            state = ''
            current_grade = ''
            gpa = ''
            w_gpa = ''
        else:
            school_info = api.get_school_by_id(school_id=student_details['school_id'], credentials=credentials)
            school = school_info['name']
            city = school_info['city']
            state = school_info['state']
            current_grade = student_details['current_grade']
            gpa = student_details['gpa']
            w_gpa = student_details['w_gpa']
            log_trace(logging.INFO, f"recommendation_letter: school: {school_info}")

        # Get student courses
        student_courses = api.get_student_courses(user_id=student['user_id'], credentials=credentials)
        log_trace(logging.INFO, f"student_courses: {student_courses}")
        courses = [x['course_name'] for x in student_courses]
        courses_string = ", ".join(courses) if len(courses)>0 else ''

        student_sw = api.get_student_strengths_weakness_by_id(student_id=student_target_school['student_id'], credentials=credentials)
        if not student_sw:
            student_sw={}
            student_sw['strengths']=''
            student_sw['weakness']= ''

        activities = api.get_student_activities(user_id=student['user_id'], credentials=credentials)
        extra = []
        strengths = []
        if activities:
            for act in activities:
                if act['type'] =='Co-curricular Activities':
                    extra.append(act['activity_name'])
                else:
                    strengths.append(act['activity_name'])
        log_trace(logging.INFO, f"activities: {activities}")
        extra_curricular = ", ".join(extra) if len(extra)>0 else ''
        student_sw['strengths'] = ", ".join(strengths) if len(strengths)>0 else ''

        log_trace(logging.INFO, f"Extra curriculars are {extra_curricular}")
        log_trace(logging.INFO, f"Strengths are {student_sw['strengths']}")
        log_trace(logging.INFO, f"Current grade is {current_grade}")

        # Get the test score
            
        tests = api.get_student_standardized_test_by_id(student_id=student_target_school["student_id"], credentials=credentials)
        sat_score = 0
        act_score = 0
        for test in tests:
            if test["test_type"] == Constants.STD_TEST_TYPE_ACT.value:
                act_score = test["total_score"]
                log_trace(logging.INFO, f"show_college_options: act_score: {act_score}")
            elif test["test_type"] == Constants.STD_TEST_TYPE_SAT.value:
                sat_score = test["total_score"]
                log_trace(logging.INFO, f"show_college_options: sat_score: {sat_score}")

        # Get the work experience and projects
        work_experience = api.get_student_work_experiences(user_id=student['user_id'], credentials=credentials)
        # Concetenate the work experience
        work_experience_string = concatenate_work_experience(work_experience)

        projects = api.get_student_projects(user_id=student['user_id'], credentials=credentials)
        # Concetenate the projects
        projects_string = concatenate_projects(projects)

        log_trace(logging.INFO, f"work_experience: {work_experience_string}")
        log_trace(logging.INFO, f"projects: {projects_string}")

        # Concatenate majors
        majors = career['majors']
        if isinstance(majors, list):
            majors = ", ".join(majors)

        ex1 = buffer.getbuffer().tobytes().decode('utf-8')
        ex2 = buffer2.getbuffer().tobytes().decode('utf-8')
        log_trace(logging.INFO, f"ex1: {ex1}")
        log_trace(logging.INFO, f"ex2: {ex2}")

        log_trace(logging.INFO, f"recommendation_letter: school: {school} city: {city} state: {state}")
        log_trace(logging.INFO, f"college: {college['college_name']} field_of_interest: {career['majors']} user: {user_info}")
        log_trace(logging.INFO, f"name: {user_info['first_name']} gpa: {gpa} w_gpa: {w_gpa}")
        log_trace(logging.INFO, f"sat: {sat_score} act: {act_score} extra_curricular: {extra_curricular}")
        log_trace(logging.INFO, f"courses: {courses_string} strengths: {student_sw['strengths']}")
        log_trace(logging.INFO, f"weakness: {student_sw['weakness']} work_experience: {work_experience_string}")
        log_trace(logging.INFO, f"projects: {projects_string}")

        result = app_fn.get_letter_of_recommendation(school=school,
                                                     city=city,
                                                     state=state,
                                                     college=college['college_name'],
                                                     field_of_interest=career['majors'],
                                                     name=user_info['first_name'],
                                                     gpa=gpa,
                                                     w_gpa=w_gpa,
                                                     sat=sat_score,
                                                     act=act_score, 
                                                     extra_curricular=extra_curricular,
                                                     courses=courses_string,
                                                     strengths=student_sw['strengths'],
                                                     weakness=student_sw['weakness'],
                                                     work_experience=work_experience_string,
                                                     projects=projects_string,
                                                     example1=ex1,
                                                     example2=ex2,
                                                     model=model)
        log_trace(logging.INFO, f"recommendation_letter: result: {result}")

        data = json.dumps(result)
        log_trace(logging.INFO, f"LoR: data: {response}")
        name = user_info['first_name'] + " " + user_info['last_name']
        output_buffer = create_lor_formatted_pdf(student_name=name,
                                                 school=school,
                                                 college=college['college_name'],
                                                 json_data=data)
        college_name = college['college_name']
        # Get epoch - append to file name
        epoch = int(time.time())
        # Add a file name to this buffer
        output_buffer.filename = f"recommendation_letter_{name}_{school}_{college_name}_{epoch}.pdf"
        # Insert the recommendation letter content
        # output_buffer.write(f"Recommendation Letter: \n".encode('utf-8'))
        # Encode the result to utf-8 and write it to the buffer
        # output_buffer.write(result.encode('utf-8'))
        # output_buffer.seek(0)
        output_buffer.file = output_buffer
        output_buffer.content_type = "application/pdf"

        log_trace(logging.INFO, f"recommendation_letter: output_buffer: {output_buffer}")
        try:
            # If its test env, we dont want to upload to S3
            db_server = os.getenv("DB_URL")
            # If db_server contains 'localhost
            if db_server and db_server.find('localhost') != -1:
                log_trace(logging.INFO, f"Test environment detected, skipping S3 upload")
                # Write the buffer to a file
                filename = f"/tmp/recommendation_letter_{student['user_id']}_{epoch}.pdf"
                with open(filename, 'wb') as f:
                    f.write(output_buffer.getbuffer())
                upload_response = {"status_code": 200, "data": "mock_s3_url", "message": "Mock S3 upload successful"}
            else:
                upload_response = api.upload_pdf_file(file=output_buffer, credentials=credentials, object_type="lor", identity_token=identity_token)
            log_trace(logging.INFO, f"recommendation_letter: upload_response: {upload_response}")
        except Exception as e:
            log_trace(logging.ERROR, f"recommendation_letter: Error uploading file: {str(e)}")
            raise Exception("Failed to upload the recommendation letter to the S3 bucket.")
        
        if upload_response["status_code"] == 200:
            # Save the response to the database
            log_trace(logging.INFO, f"Saving the recommendation letter to db")
            timestamp = time.time()
            response = api.save_letter_of_recommendation(lor={
                                                      "student_target_school_id":student_target_school_id,
                                                      "user_id":student['user_id'],
                                                      "counselor_id":counselor_id,
                                                      "letter_of_recommendation_s3_url":upload_response['data'],
                                                      "date_created":timestamp},
                                                      credentials=credentials)
            if not response:
                log_trace(logging.INFO, f"Error saving the recommendation letter to db")
                raise Exception("Failed to save recommendation letter to the database.")
        else:
            log_trace(logging.INFO, f"Error uploading file {upload_response['message']}")
            output = {
                        "message": upload_response["message"],
                        "data": None,
                        "statusCode": 500,
                        "error":{
                            "Unknown Error in Upload to S3":500
                            }
                    }
            return output
    except Exception as e:
        log_trace(logging.ERROR, f"Unknown error uploading recommendation letter {str(e)}")
        error = e
        output_message = "Recommendation Letter Failed!"
        result = []
        output = {
                    "message": output_message,
                    "data": None,
                    "statusCode": 500,
                    "error":{
                        "Unknown Error in Upload to S3":500
                        }
                }
        return output
    
    log_trace(logging.INFO, f"Successfully completed recommendation letter, error: {error}")
    output = {
                "message":upload_response['message'],
                "data": response,
                "statusCode": 200 if error is None else 500,
                "error":{} if error is None else {str(error):500}
            }
    return output