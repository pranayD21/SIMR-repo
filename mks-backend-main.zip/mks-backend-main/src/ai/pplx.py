import os
import json
import time
import requests
from logger import log_trace, logging
from dotenv import load_dotenv, find_dotenv

# read local .env file
_ = load_dotenv(find_dotenv())


class Perplexity:
    def __init__(self,model="sonar-small-online") -> None:
        self.url = "https://api.perplexity.ai/chat/completions"
        self.headers = {
                "accept": "application/json",
                "content-type": "application/json",
                "authorization": "Bearer "+os.environ.get("PPLX_TOKEN","")
            }
        self.model = model 
    
    def _get_json(self, out):
        # Split the data into lines and then into columns
        lines = out.strip().split('\n')
        useful_lines = [s for s in lines if '|' in s]
        columns = ["_".join(x.strip("|").strip().replace('/','_and_').lower().split()) for x in useful_lines[0].split(' | ')]
        log_trace(logging.INFO, f"Columns: {columns}")
        data_list = []

        # Parse each row in the table
        for line in useful_lines[2:]:
            values = line.split(' | ')
            data_dict = {}
            for i, value in enumerate(values):
                # Handle multi-line values in "Strengths" and "Weaknesses" by splitting on '<br>'
                if columns[i] in ['strengths', 'weaknesses','positives','negatives']:
                    data_dict[columns[i]] = [v.strip('- ').strip().strip("|").strip("*") for v in value.split('<br>')]
                else:
                    data_dict[columns[i]] = value.strip("|").strip().strip("*")
            data_list.append(data_dict)
            # Convert the list of dictionaries to JSON
        json_data = json.dumps(data_list, indent=4)
        return json_data
    
    def generate(self,prompt):
            payload = {
                "model": self.model,
                "messages": [
                    {
                        "role": "system",
                        "content": "Be precise and concise."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ]
            }
            response = requests.post(self.url, json=payload, headers=self.headers)
            log_trace(logging.INFO, f"Response: {response.json()}")
            json_out = self._get_json(response.json()['choices'][0]['message']['content'])
            return json_out

if __name__=="__main__":
     pplx = Perplexity()
     start = time.time()
    #  out = pplx.generate("""give me top colleges in mechanical engineering in US. I want the following fields -college name,
    #                tution fees, program, strengths and weaknesses. Can you give output as a table?""")
     prompt = """Generate a detailed course catalog table for {0} for the {1} with the following format:
Subject Area	Course Name	Credits	Prerequisites
English			
[English Course 1]	[Credits]	[Pre-reqs]
[English Course 2]	[Credits]	[Pre-reqs]
...	...	...
Mathematics			
[Math Course 1]	[Credits]	[Pre-reqs]
[Math Course 2]	[Credits]	[Pre-reqs]
...	...	...
Science			
[Science Course 1]	[Credits]	[Pre-reqs]
[Science Course 2]	[Credits]	[Pre-reqs]
...	...	...
Social Studies			
[Social Studies Course 1]	[Credits]	[Pre-reqs]
[Social Studies Course 2]	[Credits]	[Pre-reqs]
...	...	...
World Languages			
[Language Course 1]	[Credits]	[Pre-reqs]
[Language Course 2]	[Credits]	[Pre-reqs]
...	...	...
Physical Education			
[PE Course 1]	[Credits]	[Pre-reqs]
[PE Course 2]	[Credits]	[Pre-reqs]
...	...	...
Visual/Performing Arts			
[VAPA Course 1]	[Credits]	[Pre-reqs]
[VAPA Course 2]	[Credits]	[Pre-reqs]
...	...	...
Career Technical Education (CTE)			
[CTE Course 1]	[Credits]	[Pre-reqs]
[CTE Course 2]	[Credits]	[Pre-reqs]
...	...	...
Other Electives			
[Elective Course 1]	[Credits]	[Pre-reqs]
[Elective Course 2]	[Credits]	[Pre-reqs]
...	...	...
Additional Notes:
Include the total credits required for graduation at {0}
List the specific credit requirements for core subject areas
Note the typical number of courses students take per term
Mention any special requirements like auditions or applications for certain courses
Indicate prerequisites for AP/Honors courses
Note if any CTE or dual enrollment courses are offered at other campuses or in partnership with local colleges
Please include all the key subject areas offered at {0}, along with specific courses, credits, and prerequisites in the provided table format.""".format("Harker School, San Jose","2023-2024")

     out = pplx.generate(prompt)
     log_trace(logging.INFO, f"Out: {out}")

     total = time.time()-start
     log_trace(logging.INFO, f"Total: {total}")

     with open("school_cat.json",'w') as f:
       json.dump(out,f)
    #  out = out.split("```")[1].strip("\n").strip("json")
    #  print(out)
    #  print(json.loads(out))
