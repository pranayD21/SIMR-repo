# feature_flags.py

feature_flags = {
    "Analytics": True
    
}


def is_feature_enabled(feature_name):
    return feature_flags.get(feature_name, False)
