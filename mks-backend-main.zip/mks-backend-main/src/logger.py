import os
import inspect
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime
from dotenv import load_dotenv, find_dotenv

# Load environment variables
_ = load_dotenv(find_dotenv())

dabbl_home = os.getenv("DABBL_HOME")
log_dir = os.path.join(dabbl_home, "..", "logs", "dabbl") 
os.makedirs(log_dir, exist_ok=True)

# Create a logger
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)

log_file = os.path.join(log_dir, f'server_debug_{datetime.now().strftime("%Y-%m-%d")}.log')
rotating_file_handler = RotatingFileHandler(
    log_file,
    maxBytes=1 * 1024 * 1024,  # 1 MB
    backupCount=5
)

file_formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
rotating_file_handler.setFormatter(file_formatter)

# Create a stream handler (optional, for logging to console)
stream_handler = logging.StreamHandler()
stream_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
stream_handler.setFormatter(stream_formatter)

# Add handlers to the logger
logger.addHandler(rotating_file_handler)
logger.addHandler(stream_handler)

def log_trace(level, message):
    function_name = ""
    class_name = ""

    frame = inspect.currentframe().f_back
    if frame:
        # Extract class name if available
        class_name = frame.f_locals.get('self', None).__class__.__name__ if 'self' in frame.f_locals else ""
        function_name = frame.f_code.co_name
    logger.log(level, f" {class_name}:{function_name}: {message}")