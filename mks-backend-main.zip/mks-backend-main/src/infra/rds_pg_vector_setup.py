# Prerequisite: Make sure the PG version is updated to 16.4 or greater
import psycopg2
from psycopg2.extras import execute_values

# Database connection parameters
db_params = {
    'dbname': 'your_database_name',
    'user': 'your_username',
    'password': 'your_password',
    'host': 'your_rds_endpoint',
    'port': 'your_port'
}

# Connect to the database
conn = psycopg2.connect(**db_params)
cur = conn.cursor()

# Enable the pg_vector extension
cur.execute("CREATE EXTENSION IF NOT EXISTS vector;")

# Create a table with a vector column
cur.execute("""
CREATE TABLE IF NOT EXISTS items (
    id SERIAL PRIMARY KEY,
    embedding vector(3)
);
""")

# Insert sample data
sample_data = [
    ([1, 2, 3],),
    ([4, 5, 6],),
    ([1, 1, 1],),
]
execute_values(cur, "INSERT INTO items (embedding) VALUES %s", sample_data)

# Perform a similarity search
query_vector = [2, 3, 4]
cur.execute("""
SELECT id, embedding <-> %s AS distance
FROM items
ORDER BY distance
LIMIT 5;
""", (query_vector,))

results = cur.fetchall()
print("Similarity search results:")
for row in results:
    print(f"ID: {row[0]}, Distance: {row[1]}")

# Commit changes and close connection
conn.commit()
cur.close()
conn.close()