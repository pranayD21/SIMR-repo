from fastapi import APIRouter, Depends

from auth_jwt.auth_infra import get_current_user

router = APIRouter()


@router.get("/test")
async def test(username: str = Depends(get_current_user)):
    return {"username": username}