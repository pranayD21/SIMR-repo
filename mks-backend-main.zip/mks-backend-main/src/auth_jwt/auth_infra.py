import os
import requests
from dotenv import load_dotenv
from logger import log_trace, logging
from fastapi import Depends, HTTPException
from starlette.status import HTTP_403_FORBIDDEN
from jwt_token import JWKS, JWTBearer, JWTAuthorizationCredentials

load_dotenv()  # Automatically load environment variables from a '.env' file.

jwks = JWKS.model_validate(
    requests.get(
        f"https://cognito-idp.us-east-2.amazonaws.com/"
        f"{os.environ.get('APP_USER_POOL_ID')}/.well-known/jwks.json"
    ).json()
)

auth = JWTBearer(jwks)


async def get_current_user(
    credentials: JWTAuthorizationCredentials = Depends(auth)
) -> str:
    try:
        return credentials.claims["username"]
    except KeyError:
        log_trace(logging.ERROR, "Username missing")
        HTTPException(status_code=HTTP_403_FORBIDDEN, detail="Username missing")
