from typing import List, Optional
from pydantic import BaseModel
from datetime import datetime, date

class SchoolBase(BaseModel):
    name: str
    city: str
    state: str
    zip: str
    country: str

class SchoolCreate(SchoolBase):
    name: str
    city: str
    state: str
    zip: str
    country: str
    pass

class School(SchoolBase):
    id: int

    class Config:
        from_attributes = True

class UserSignup(BaseModel):
    username: str
    password: str
    email: str
    first_name: str
    last_name: str
    dob: str
    is_minor: bool
    parentname: str
    parentemail: str
    consentdate: str
    type: str
    class Config:
        from_attributes = True

class UserVerify(BaseModel):
    confirmation_code: str
    email: str

class UserLogin(BaseModel):
    username: str
    password: str

class UserBase(BaseModel):
    username: str
    email: str
    first_name: str
    last_name: str
    birthdate: date 
    type: Optional[str] = 'student'
    parent_name: str
    parent_email: str
    consentdate: date
    uid: str
    followers: List[int]
    following: List[int]
    website: str
    personal_statement: str
    connections: List[int]
    profile_pic_url: str
    is_online: bool
    is_minor: bool
    fcm_token: str
    show_sensitive_info: bool
    is_active: Optional[bool] = True
    delete_date: Optional[date] = None
    counselor_connections: List[int]
    # gpa: float
    # w_gpa: float
    # sat_score: float 
    # sat_super_score: float
    # act_score: float
    # grade: int 

class UserCreate(UserBase):
    pass

class UserProfile(BaseModel):
    email: str
    first_name: str
    last_name: str
    birthdate: date
    uid: str # cognito user id
    website: str
    personal_statement: str
    connections: List[int]
    profile_pic_url: str
    show_sensitive_info: bool

    # gpa: float
    # w_gpa: float
    # sat_score: float 
    # sat_super_score: float
    # act_score: float
    # grade: int 
    # pass

class UserStatus(BaseModel):
    uid: str
    is_online: bool

class User(UserBase):
    id: int

    class Config:
        from_attributes = True

class UserFollowUnfollow(BaseModel):
    user_id: int 
    follow_id: int

class UserBlob(BaseModel):
    id: int
    username: str
    profile_pic_url: str

class StudentBase(BaseModel):
    user_id: int

class StudentCreate(StudentBase):
    user_id: int


class Student(StudentBase):
    id: int
    user_id: int
    class Config:
        from_attributes = True

class CourseBase(BaseModel):
    course_name: str
    course_desc: str
    course_type: str # Honors, AP, IB, etc.
    course_credits: int

class CourseCreate(CourseBase):
    pass

class Course(CourseBase):
    id: int 
    
    class Config:
        from_attributes = True

class ActivityBase(BaseModel):
    activity_name: str
    activity_description: str

class ActivityCreate(ActivityBase):
    pass
    # hours_committed_per_week: float

class Activity(ActivityBase):
    id: int 

    class Config:
        from_attributes = True

class StudentStrengthsWeaknessBase(BaseModel):
    student_id: int
    strengths: str
    weakness: str

class StudentStrengthsWeaknessCreate(StudentStrengthsWeaknessBase):
    pass

class StudentStrengthsWeaknessUpdate(StudentStrengthsWeaknessBase):
    pass

class StudentStrengthsWeaknessDelete(StudentStrengthsWeaknessBase):
    student_id: int

class StudentStrengthsWeakness(StudentStrengthsWeaknessBase):
    id: int
    class Config:
        from_attributes = True


class StudentSchoolBase(BaseModel):
    student_id: int
    school_id: int
    user_id: int
    start_date: date
    end_date: Optional[date] = None
    currently_enrolled: bool
    gpa: float
    w_gpa: float
    current_grade: str
    is_primary: bool
    graduation_year: date

class StudentSchoolCreate(StudentSchoolBase):
    # Need school info
    user_id: int
    name: str
    city: str
    state: str
    zip: str
    country: str
    pass

class StudentSchoolUpdate(StudentSchoolCreate):
    pass


class StudentSchool(StudentSchoolBase):
    id: int 

    class Config:
        from_attributes = True

class StudentSchoolDelete(StudentSchoolBase):
    student_id: int
    school_id: int

class StudentStandardizedTestBase(BaseModel):
    student_id: int
    total_score: int
    english_score: float
    math_score: float
    science_score: Optional[float] = 0
    reading_score: Optional[float] = 0
    date_taken: date
    test_type: str

class StudentStandardizedTestCreate(StudentStandardizedTestBase):
    pass

class StudentStandardizedTestUpdate(StudentStandardizedTestBase):
    pass

class StudentStandardizedTest(StudentStandardizedTestBase):
    id: int

    class Config:
        orm_mode = True


class StudentCourseBase(BaseModel):
    student_id: int
    # course_id: int

class StudentCourseCreate(StudentCourseBase):
    student_id: int
    school_id: Optional[int] = 1
    course_name: str
    credits: Optional[int] = 10
    grade: str
    grade_year: str
    term: Optional[str] = ""
    difficulty_level: str
    feedback: str


# class StudentCourseUpdate(StudentCourseBase):
#     student_id: int
#     activity_id: int
#     credits: int
#     grade: str

class StudentCourse(StudentCourseBase):
    id: int 
    student_id: int
    course_id: int
    school_id: int
    credits: Optional[int] = 10
    grade: str
    grade_year: str
    difficulty_level: str
    feedback: str
    class Config:
        from_attributes = True

class StudentCourseDelete(StudentCourseBase):
    student_id: int
    School_id: int
    course_id: int

class StudentActivityBase(BaseModel):
    student_id: int
    hours_committed_per_week: Optional[float] = 0
    student_role: Optional[str] = None
    achievements: Optional[str] = None
    type: str
    # activity_id: int

class StudentActivityCreate(StudentActivityBase):
    activity_name: str
    activity_description: str

class StudentActivity(StudentActivityBase):
    id: int 
    activity_id: int

    class Config:
        from_attributes = True

# Combination of Student Activity and StudentActivityCreate
class StudentActivityUpdate(StudentActivityCreate):
    id: int 
    activity_id: int

class StudentActivityDelete(BaseModel):
    student_id: int
    activity_id: int

class CareersBase(BaseModel):
    career_name: str
    career_description: str
    job_duties: str
    skills: str
    median_salary: str 
    majors: str
    career_outlook: str

class CareersCreate(CareersBase):
    career_name: str
    career_description: str
    job_duties: str
    skills: str
    median_salary: str 
    majors: str
    career_outlook: str

class Careers(CareersBase):
    id: int 
    class Config:
        from_attributes = True

class StudentCareerCreate(BaseModel):
    student_id: int
    career_id: int
    rank: Optional[int] = 0


class StudentCareer(BaseModel):
    id: int 
    student_id: int
    rank: int
    career: Careers

    class Config:
        from_attributes = True


class StudentCareerDelete(BaseModel):
    student_id: int
    career_id: int


class StudentCareerCommentBase(BaseModel):
    user_id: int
    student_career_id: int
    content: str
    date_published: datetime
    content_url: Optional[str] = None

class StudentCareerCommentCreate(StudentCareerCommentBase):
    pass

class StudentCareerComment(StudentCareerCommentBase):
    id: int


class TargetSchools(BaseModel):
    id: int
    college_name: str
    college_url: str
    campus: str
    college_pic_url: str
    college_control: str # Pvt/Public/for-profit/etc
    college_type: str # 4 year/2 year/trade school/community college/etc
    college_size: str # small/med/large
    is_hbcu: bool # HBCU institution?
    is_mstc: bool # Minority serving institution?
    class Config:
        from_attributes = True

class StudentTargetSchoolBase(BaseModel):
    # student_id: int
    # career_id: int
    college_name: str
    tution_fees: str
    probability_of_admission: str
    positives: List[str]
    negatives: List[str]
    why_this_recommendation: str
    classification: str # Safety/Target/Reach/Extreme Reach
    acceptance_rate: str
    # rank: Optional[int] = 0
    class Config:
        from_attributes = True

class StudentTargetSchoolCreate(StudentTargetSchoolBase):
    student_id: int
    career_id: int
    rank: Optional[int] = 0
    class Config:
        from_attributes = True

class StudentTargetSchool(StudentTargetSchoolBase):
    id: int 
    student_id: int
    career_id: int
    college_id: int
    rank: int
    class Config:
        from_attributes = True

class StudentTargetSchoolDelete(StudentTargetSchoolBase):
    student_id: int
    career_id: int
    college_name: str


class StudentTargetSchoolCommentBase(BaseModel):
    user_id: int
    target_school_id: int
    content: str
    date_published: datetime
    content_url: Optional[str] = None


class StudentTargetSchoolCommentCreate(StudentTargetSchoolCommentBase):
    pass


class StudentTargetSchoolComment(StudentTargetSchoolCommentBase):
    id: int


class PostBase(BaseModel):
    post_title: str
    post_content: str
    likes: List[int]
    date_published: datetime
    post_content_url: str

class PostCreate(PostBase):
    user_id: int
    post_title: str
    post_content: str
    likes: List[int]
    date_published: datetime
    post_content_url: str

class Post(PostBase):
    id: int 
    user_id: int
    post_title: str
    post_content: str
    likes: List[int]
    date_published: datetime
    post_content_url: str
    class Config:
        from_attributes = True

class PostResult(PostBase):
    id: int 
    type: str # Whether its a regular post or a news post
    user_id: int
    post_title: str
    post_content: str
    profile_pic_url: str
    likes: List[int]
    date_published: datetime
    post_content_url: str
    username: str
    comment_count: int

class PostLikeUnlike(BaseModel):
    user_id: int
    post_id: int


class NewsLikeUnlike(BaseModel):
    user_id: int
    news_id: int


class NewsPostLike(BaseModel):
    id: int
    user_id: int
    post_id: int


class NewsBase(BaseModel):
    news_title: str
    news_content_url: str
    news_published_date: datetime
    news_keywords: List[str]


class NewsCreate(NewsBase):
    pass


class News(NewsBase):
    id: int
    likes: List[NewsPostLike]

    class Config:
        from_attributes = True


class NewsResult(NewsBase):
    id: int
    comment_count: int

class NewsCommentBase(BaseModel):
    news_id: int
    content: str
    date_published: datetime
    content_url: Optional[str] = None


class NewsCommentLikeUnlike(BaseModel):
    user_id: int
    comment_id: int


class NewsCommentLike(NewsCommentLikeUnlike):
    id: int


class NewsCommentCreate(NewsCommentBase):
    user_id: int


class NewsCommentResponse(NewsCommentBase):
    id: int
    user: UserBlob
    likes: Optional[List[NewsCommentLike]] = []

    class Config:
        from_attributes = True


class CommentBase(BaseModel):
    user_id: int
    post_id: int
    content: str
    likes: List[int]
    date_published: datetime
    content_url: Optional[str] = None

class CommentCreate(CommentBase):
    pass

class Comment(CommentBase):
    id: int
    
    class Config:
        from_attributes = True

class CommentResult(CommentBase):
    id: int
    username: str
    profile_pic_url: str

class CommentLikeUnlike(BaseModel):
    user_id: int
    comment_id: int


class StudentWorkExperienceBase(BaseModel):
    student_id: int
    job_title: str
    company_name: str
    job_description: str
    start_date: date
    end_date: Optional[date] = None
    employment_type: Optional[str] = None
    active: bool

class StudentWorkExperienceCreate(StudentWorkExperienceBase):
    pass

class StudentWorkExperience(StudentWorkExperienceBase):
    id: int

    class Config:
        orm_mode = True

class StudentProjectsBase(BaseModel):
    student_id: int
    project_title: str
    project_description: str
    skills: Optional[str] = ''
    rewards_recognition: str
    start_date: date
    end_date: Optional[date] = None
    is_complete: bool

class StudentProjectsCreate(StudentProjectsBase):
    pass

class StudentProjects(StudentProjectsBase):
    id: int

    class Config:
        orm_mode = True

class Text(BaseModel):
    text: str

class CounselorStudentConnection(BaseModel):
    counselor_id: int
    counselor_name: str
    counselor_email: str
    student_name: str
    student_email: str
    parent_email: str
    date_requested: date
    token: str

    class Config:
        from_attributes = True
        json_encoders = {
            date: lambda v: v.isoformat()
        }


class StudentDetails(BaseModel):
    student_name: str
    student_email: str
    parent_email: str


class CounselorStudentConnectRequest(BaseModel):
    counselor_id: int
    student_details: List[StudentDetails]

    class Config:
        from_attributes = True


class CounselorCreate(BaseModel):
    user_id: int
    class Config:
        from_attributes = True

class Counselor(CounselorCreate):
    id: int
    is_school_counselor: Optional[bool] = False
    school_id: Optional[int] = 0
    class Config:
        from_attributes = True

class BookmarkBase(BaseModel):
    user_id: int
    job_id: int

class BookmarkCreate(BookmarkBase):
    pass

class Bookmark(BookmarkBase):
    id: int

    class Config:
        orm_mode = True

class JobBase(BaseModel):
    title: str
    organization: str
    deadline: str
    area: List[str]
    age: List[str]
    season: List[str]
    eligibility: List[str]
    description: str
    requirements: str
    mode: List[str]
    location: List[str]
    address: str
    salary: str
    program_fee: str
    keywords: List[str]
    link: str
    listing_type: List[str]
    is_priority: bool = False  # Field to mark high-priority listings

class JobUpdate(BaseModel):
    title: Optional[str] = None
    organization: Optional[str] = None
    deadline: Optional[str] = None
    area: Optional[List[str]] = None
    age: Optional[List[str]] = None
    season: Optional[List[str]] = None
    eligibility: Optional[List[str]] = None
    description: Optional[str] = None
    requirements: Optional[str] = None
    mode: Optional[List[str]] = None
    location: Optional[List[str]] = None
    address: Optional[str] = None
    salary: Optional[str] = None
    program_fee: Optional[str] = None
    keywords: Optional[List[str]] = None
    link: Optional[str] = None
    listing_type: Optional[List[str]] = None
    is_priority: Optional[bool] = None  # Optional field for updating

class JobCreate(JobBase):
    pass

class Job(JobBase):
    id: int
    created_at: datetime

    class Config:
        orm_mode = True

class MatchedJobResponse(BaseModel):
    id: int
    user_id: int
    job_id: int
    job: Job 

    class Config:
        orm_mode = True

class NotificationBase(BaseModel):
    user_id: int
    type: Optional[str] = None
    title: str = "New Notification"
    message: str
    scheduled: bool = False  
    sent: bool = False 
    data: object
    send_time: Optional[datetime]

class NotificationCreate(NotificationBase):
    pass

class NotificationUpdate(BaseModel):
    is_read: bool


class Notification(NotificationBase):
    id: int
    is_read: bool
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


# Notification Template Schemas
class NotificationTemplateBase(BaseModel):
    type: str
    title: str
    message: str
    repeatable: bool
    active: bool

class NotificationTemplateCreate(NotificationTemplateBase):
    pass

class NotificationTemplateUpdate(BaseModel):
    active: Optional[bool]
    repeatable: Optional[bool]

class NotificationTemplate(NotificationTemplateBase):
    id: int
    created_at: datetime

    class Config:
        from_attributes = True
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

class EssayReviewBase(BaseModel):
    student_target_school_id: int
    user_id: int
    essay_review_s3_url: str
    date_reviewed: datetime

class EssayReview(EssayReviewBase):
    id: int

    class Config:
        from_attributes = True

class LorBase(BaseModel):
    student_target_school_id: int
    user_id: int
    counselor_id: int
    letter_of_recommendation_s3_url: str
    date_created: datetime

class Lor(LorBase):
    id: int

    class Config:
        from_attributes = True