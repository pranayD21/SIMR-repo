import os
from sqlalchemy import create_engine, text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from logger import log_trace, logging
from dotenv import load_dotenv, find_dotenv

_ = load_dotenv(find_dotenv()) 

DB_URL = os.environ['DB_URL']

engine = create_engine(
    DB_URL)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

Base = declarative_base()

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Function to create the pg_trgm extension - for similarity
def create_pg_trgm_extension():
    with engine.connect() as connection:
        # Execute the SQL command to create the extension
        connection.execute(text("CREATE EXTENSION IF NOT EXISTS pg_trgm;"))
        log_trace(logging.INFO, "pg_trgm extension created or already exists.")

# Call the function to create the extension
create_pg_trgm_extension()
