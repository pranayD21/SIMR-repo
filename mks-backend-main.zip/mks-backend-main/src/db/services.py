from operator import and_
import os
import re
import uuid
import random
from typing import List, Optional, Union
from profanity_check import predict
from fastapi import Depends, HTTPException, APIRouter, Header, Query, Request
from sqlalchemy.orm import Session
from sqlalchemy import func
from pydantic import ValidationError
from utils import wrap_response
from auth_jwt.jwt_token import JWKS, JWTAuthorizationCredentials, JWTBearer, fetch_jwks
from auth import s3_utils
from logger import log_trace, logging
from . import crud, models, schemas
from .database import SessionLocal, engine
from . import Constants
from .crud import NewsHandler, StudentCareerHandler, StudentTargetSchoolHandler
from .notification_handler import NotificationHandler

__package__ = "src.db"

models.Base.metadata.create_all(bind=engine)

router = APIRouter(
    prefix="/db",
    tags=["db"],
    # dependencies=[Depends(get_token_header)],
    responses={404: {"description": "Not found"}},
)

# Needed for parsing the auth token in the request headers
jwks = JWKS.model_validate(fetch_jwks())
auth = JWTBearer(jwks)

# Dependency
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def validate_user_records(db: Session, db_users: List[models.User]):
    valid_users = []
    for db_user in db_users:
            try:
                # Validate each user entry with the Pydantic model
                user = schemas.User(username=db_user.username, 
                                    email=db_user.email,
                                    first_name=db_user.first_name,
                                    last_name=db_user.last_name,
                                    birthdate=db_user.birthdate,
                                    type=db_user.type,
                                    parent_name=db_user.parent_name,
                                    parent_email=db_user.parent_email,
                                    consentdate=db_user.consentdate,
                                    uid=db_user.uid,
                                    followers=db_user.followers,
                                    following=db_user.following,
                                    website=db_user.website,
                                    personal_statement=db_user.personal_statement,
                                    connections=db_user.connections,
                                    profile_pic_url=db_user.profile_pic_url,
                                    id=db_user.id,
                                    is_online=db_user.is_online,
                                    is_minor=db_user.is_minor,
                                    fcm_token=db_user.fcm_token,
                                    show_sensitive_info=db_user.show_sensitive_info,
                                    counselor_connections=db_user.counselor_connections)
                # Validate that connections list has valid users
                user = crud.validate_and_update_user_ids(db, user)
                valid_users.append(user)
            except ValidationError as e:
                # Handle entries that do not pass validation
                log_trace(logging.ERROR, f"{str(e)}")
                continue  # Skip invalid entries or log them as needed
    return valid_users


########################################################################################
#################################### Users #############################################
########################################################################################

@router.post("/users/create")#, response_model=schemas.User)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    # print(user.email,school.name)
    message = ''
    db_user_dict = {}
    try:
        db_user = crud.get_user_by_username_or_email(db, email=user.email,username=user.username)
        if db_user:
            message = "Email already registered"
            raise HTTPException(status_code=400, detail="Email already registered")

        db_user = crud.create_user_ep(db=db, user=user)
        if not db_user:
            message = "Error adding a user record"
            raise HTTPException(status_code=404, detail="Error adding a user record")
        
        message = f"User {user.username} created successfully!"
        db_user_dict = {}
        for k,v in db_user.__dict__.items():
            db_user_dict[k] = v

        if user.type == Constants.DB_USER_TYPE_STUDENT.value:
            db_student = crud.get_student_by_uid(db, uid=db_user.id)
            if not db_student:
                db_student = crud.create_student(db=db, student=schemas.StudentCreate(user_id = db_user.id))
                if not db_student:
                    message = "Error creating a student record"
                    log_trace(logging.ERROR, message)
                    raise HTTPException(status_code=404, detail=message)
        elif user.type == Constants.DB_USER_TYPE_COUNSELOR.value:
            db_counselor = crud.get_counselor_by_uid(db, uid=db_user.id)
            if not db_counselor:
                db_counselor = crud.create_counselor(db, counselor=schemas.CounselorCreate(user_id = db_user.id))
                if not db_counselor:
                    message = "Error creating a counselor record"
                    log_trace(logging.ERROR, message)
                    raise HTTPException(status_code=404, detail=message)
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
        return wrap_response(data=db_user_dict, message=message, code=500,
                             error={"exception": "InternalServerError",
                                    "message": str(e)})
    log_trace(logging.INFO, f"{message}")
    return wrap_response(data=db_user_dict, message=message, code=200)


@router.get("/users/get")#, response_model=list[schemas.User])
def read_users(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
               credentials: JWTAuthorizationCredentials = Depends(auth)):
    valid_users = []
    try:
        db_users = crud.get_users(db, skip=skip, limit=limit)
        valid_users = validate_user_records(db, db_users=db_users)
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
        return wrap_response(data=valid_users, message="An error occurred", code=500,
                             error={"exception": "InternalServerError", "message":str(e)})
    log_trace(logging.INFO, f"list: {valid_users}")
    return wrap_response(data=valid_users, message="User List!", code=200)


@router.get("/users/get_other_users/user_id/{user_id}")#, response_model=list[schemas.User])
def read_other_users(user_id: int, skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                     credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_users = crud.get_users(db, skip=skip, limit=limit)
    log_trace(logging.INFO, f"Found {len(db_users)} users")
    valid_users = validate_user_records(db, db_users=db_users)
    for user in valid_users:
        # Skip the user with the given user_id
        if user.id == user_id:
            valid_users.remove(user)

    response = wrap_response(data=valid_users, message="User List!", code=200)
    return response
    

@router.get("/users/get/user_id/{user_id}")#, response_model=schemas.User)
def read_user(user_id: int, db: Session = Depends(get_db),
              credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        return wrap_response(data=db_user, message="User not found", code=404,
                             error={"exception": "InternalServerError", "message": "User not found"})
    user = crud.validate_and_update_user_ids(db=db, user=db_user)
    log_trace(logging.INFO, f"Fetched User {user}")
    return wrap_response(data=user, message="User Fetched!", code=200)

# Search for users with the given 'email'
@router.get("/users/get/search_by_email/{email}")
def search_users_by_email(email: str, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user_by_username_or_email(db, email=email, username=None)    
    if db_user:
        log_trace(logging.INFO, f"Found user {db_user}")
        message = "User found!"
    else:
        message = "No matching users found!"
    
    return wrap_response(data=db_user, message=message, code=200)

# Search for users with first name or last name like the given 'name' string
@router.get("/users/get/search/{name}")#, response_model=list[schemas.User])
def search_users(name: str, db: Session = Depends(get_db),
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    valid_users = []
    invalid_records = 0
    error = None
    total_count = 0
    try:
        db_users = crud.search_user_by_name(db, name=name)
        total_count = len(db_users)
        valid_users = validate_user_records(db, db_users=db_users)
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
    
    total_count = len(valid_users)
    log_trace(logging.INFO, f"List of searched users {valid_users}")

    status_code = 200
    message = "Users Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch users!"
    elif len(valid_users) == 0:
        status_code = 200
        error = "No matching users found!"
        message = "No matching users found!"
        
    output = {
        "message": message,
        "data": {
            "result": valid_users,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error": {} if error is None else {str(error): 500}
    }
    return output


@router.get("/users/get/paginated/search/{name}")#, response_model=list[schemas.User])
def search_user_by_name_paginated(name: str, page_num: int = 1, limit: int = 10, db: Session = Depends(get_db),
                                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    # error = None
    valid_users = []
    total_count = 0
    invalid_records = 0

    try:
        total_count, db_users = crud.search_user_by_name_paginated(db, name=name, page_num=page_num, limit=limit)
        # valid_users = []
        log_trace(logging.INFO, f"total_count: {total_count}, db_users: {db_users}")
        valid_users = validate_user_records(db, db_users=db_users)
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
        return wrap_response(data=valid_users,
                             message="Failed to fetch users!",
                             code=500,
                             error={
                                 "exception": "InternalServerError",
                                 "message": str(e)},
                             limit=limit,
                             page_num=page_num,
                             total_count=total_count)

    total_count = len(valid_users)
    log_trace(logging.INFO, f"Fetched users {valid_users}")
    message = "Users Fetched!"
    if total_count == 0:
        # status_code = 200
        message = "No matching users found!"
        log_trace(logging.INFO, f"{message}")
        return wrap_response(data=valid_users,
                             message="No matching users found!",
                             code=200,
                             limit=limit,
                             page_num=page_num,
                             total_count=total_count)

    return wrap_response(data=valid_users,message=message,code=200,limit=limit,page_num=page_num,total_count=total_count)


@router.get("/users/get/paginated/search")
def search_user_by_name_and_type_paginated(name: str = "", user_type: str = "", page_num: int = 1, limit: int = 10, db: Session = Depends(get_db),
                                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    valid_users = []
    try:
        total_count, db_users = crud.search_user_by_name_and_type_paginated(db, name=name, user_type=user_type, page_num=page_num, limit=limit)
        log_trace(logging.INFO, f"total_count: {total_count}, db_users: {db_users}")
        valid_users = validate_user_records(db, db_users=db_users)
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
        return wrap_response(data=valid_users,
                             message="Failed to fetch users!",
                             code=500,
                             error={"exception": "InternalServerError", "message": str(e)},
                             limit=limit,
                             page_num=page_num,
                             total_count=total_count)

    total_count = len(valid_users)
    log_trace(logging.INFO, f"Fetched users {valid_users}")
    message = "Users Fetched!"
    if total_count == 0:
        message = "No matching users found!"
        log_trace(logging.INFO, f"{message}")
        return wrap_response(data=valid_users,
                             message="No matching users found!",
                             code=200,
                             limit=limit,
                             page_num=page_num,
                             total_count=total_count)

    return wrap_response(data=valid_users,
                         message=message,
                         code=200,
                         limit=limit,
                         page_num=page_num,
                         total_count=total_count)


@router.delete("/users/delete/id/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.delete_user(db, user_id=user_id)
    if not db_user:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")
    log_trace(logging.INFO, f"User {db_user} deleted.")
    return wrap_response(data=db_user, message="User Deleted!",code=200)


@router.post("/users/restore-account/")
def restore_user(user_email: str, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.restore_user(db, user_email=user_email)
    if not db_user:
        log_trace(logging.INFO, f"Unable to restore user account with email {user_email}")
        raise HTTPException(status_code=404, detail="Unable to restore user account.")

    log_trace(logging.INFO, f"User account with email {user_email} restored")
    return wrap_response(data=db_user, message="User account restored!", code=200)


# Update User
@router.post("/users/update/{user_id}")#, response_model=schemas.User)
def update_user(user_id: int, user: schemas.UserCreate, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.update_user(db, user_id=user_id, user=user)
    if not db_user:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")

    log_trace(logging.INFO, f"updated user details {db_user}")
    return wrap_response(data=db_user, message="User Updated!", code=200)


# Update User Status
@router.post("/users/update/status/user_id/{user_id}")
def update_user_status(user_id: int, user_status: schemas.UserStatus, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.update_user_status(db, user_id=user_id, user_status=user_status)
    if not db_user:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")

    log_trace(logging.INFO, f"User with id {user_id}, status updated to {user_status}")
    return wrap_response(data=db_user, message="User Status Updated!", code=200)


# Update UserProfile
@router.post("/users/update/profile/user_id/{user_id}")#, response_model=schemas.User)
def update_user_profile(user_id: int, user_profile: schemas.UserProfile, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.update_user_profile(db, user_id=user_id, user_profile=user_profile)
    if not db_user:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")

    log_trace(logging.INFO, f"updated user details {db_user}")
    return wrap_response(data=db_user, message="User Profile Updated!", code=200)


# Get user show_sensitive_info
@router.get("/users/get/show_sensitive_info/user_id/{user_id}")#, response_model=bool)
def get_user_show_sensitive_info(user_id: int, db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")

    log_trace(logging.INFO, f"User with id {user_id}, show sensitive info flag is {db_user.show_sensitive_info}")
    return wrap_response(data=db_user.show_sensitive_info, message="User Sensitive Info Flag", code=200)


# Update user show_sensitive_info
@router.post("/users/update/show_sensitive_info/user_id/{user_id}")#, response_model=schemas.User)
def update_user_show_sensitive_info(user_id: int, show_sensitive_info: bool, db: Session = Depends(get_db),
                                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.update_user_show_sensitive_info(db, user_id=user_id, show_sensitive_info=show_sensitive_info)
    if not db_user:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")

    log_trace(logging.INFO, f"User with id {user_id}, show sensitive info flag is set to {show_sensitive_info}")
    return wrap_response(data=db_user, message="User Profile Updated!", code=200)


# Get user following
@router.get("/users/get/following/user_id/{user_id}")#, response_model=List[int])
def get_user_following(user_id: int, db: Session = Depends(get_db),
                       credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")
    followings = []
    for following in db_user.following:
        user = crud.get_user(db, user_id=following)
        if user:
            followings.append(user)

    log_trace(logging.INFO, f"User following list {followings}")
    return wrap_response(data=followings, message="User Following!", code=200)


# Get user followers
@router.get("/users/get/followers/user_id/{user_id}")#, response_model=List[int])
def get_user_followers(user_id: int, db: Session = Depends(get_db),
                       credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")
    followers = []
    for follower in db_user.followers:
        user = crud.get_user(db, user_id=follower)
        if user:
            followers.append(user)

    log_trace(logging.INFO, f"User followers list {followers}")
    return wrap_response(data=followers, message="User Followers!", code=200)


# Follow user. If already following user, unfollow. If not following user, follow.
############## Race conditions possible here. Need to fix. ###############
@router.post("/users/follow_user/user_id/{user_id}")#, response_model=schemas.User)
def follow_unfollow_user(user: schemas.UserFollowUnfollow, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.update_user_following(db, user_id=user.user_id, following_user_id=user.follow_id)
    # log_trace(logging.INFO, f"Followers {db_user.following}, Following {_.followers}")
    return wrap_response(data=db_user, message="User Follow/Un-Follow!", code=200)


@router.get("/users/get/email/{email}") #, response_model=schemas.User)
def read_user_by_email(email: str, db: Session = Depends(get_db),
                       credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user_by_username_or_email(db, email=email,username=None)
    if db_user is None:
        log_trace(logging.INFO, f"User with email {email} not found")
        raise HTTPException(status_code=404, detail="User not found")

    log_trace(logging.INFO, f"User {db_user} retrieved by email")
    return wrap_response(data=db_user, message="User Retrieved by Email!", code=200)


@router.get("/users/get/username/{username}") #, response_model=schemas.User)
def read_user_by_username(username: str, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user_by_username_or_email(db, username=username,
                                                 email=None)
    if db_user is None:
        log_trace(logging.INFO, f"User with username {username} not found")
        raise HTTPException(status_code=404, detail="User not found")

    log_trace(logging.INFO, f"User {db_user} retrieved by username")
    return wrap_response(data=db_user, message="User Retrieved by username!", code=200)

# Get user followers
@router.get("/users/get/counselor_connections/user_id/{user_id}")
def get_user_counselor_connections(user_id: int, db: Session = Depends(get_db),
                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        log_trace(logging.INFO, f"User with id {user_id} not found")
        raise HTTPException(status_code=404, detail="User not found")
    counselor_connections = []
    for counselor_uid in db_user.counselor_connections:
        user = crud.get_user(db, user_id=counselor_uid)
        if user:
            counselor_connections.append(user)

    log_trace(logging.INFO, f"User counselor connections list {counselor_connections}")
    return wrap_response(data=counselor_connections, message="User counselor connections!", code=200)


########################################################################################
############################## Student #################################################
########################################################################################

@router.post("/users/students/create/{uid}", response_model=schemas.Student)
def create_student(
                student: schemas.StudentCreate, 
                uid: str,
                db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_user = crud.get_user(db, user_id=uid)
    if not db_user:
        log_trace(logging.INFO, f"Student not registered as user.")
        raise HTTPException(status_code=400, detail="Student not registered as user.")
    
    db_student = crud.get_student_by_uid(db, uid=uid)
    if db_student:
        log_trace(logging.INFO, f"Student with uid {uid} already registered")
        raise HTTPException(status_code=400, detail="Student already registered")

    db_student = crud.create_student(db=db, student=student)
    log_trace(logging.INFO, f"Registered student details {db_student}")
    return db_student


@router.get("/users/students/get/")
def read_students(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    students = crud.get_students(db, skip=skip, limit=limit)
    log_trace(logging.INFO, f"All Students details {students}")
    return students


@router.get("/users/students/get/{user_id}")
def get_student_by_uid(user_id: int, db: Session = Depends(get_db),
                       credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        log_trace(logging.INFO, f"Student with id {user_id} not found")
        return None

    log_trace(logging.INFO, f"Student details {db_student}")
    return db_student


@router.get("/users/students/get/id/{student_id}")# response_model=schemas.Student)
def read_student(student_id: int, db: Session = Depends(get_db),
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student(db, student_id=student_id)
    if db_student is None:
        log_trace(logging.INFO, f"Student with id {student_id} not found")
        raise HTTPException(status_code=404, detail="User not found")
    db_student_schools = crud.get_student_schools(db,student_id=db_student.id)
    student_details = {}
    student_details['user_id'] = db_student.user_id
    student_details['Education'] = []
    if db_student_schools is not None and len(db_student_schools) > 0:
        for student_school in db_student_schools:
            school_info = {}
            school = crud.get_school_by_id(db, school_id=student_school['school_id'])
            if school is None:
                log_trace(logging.INFO, f"School with id {student_school['school_id']} not found")
                raise HTTPException(status_code=404, detail="School not found")
            school_info[school.name] = {}
            print(student_school)
            log_trace(logging.INFO, f"Student school details {student_school}")
            # student_school = student_school.__dict__
            for k, v in student_school.items():
                if k not in ['student_id','school_id','school_name']:
                    school_info[school.name][k] = v
                    school_info[school.name]['courses'] = crud.get_student_courses_by_school(db,
                                                                    student_id=student_id,
                                                                    school_id=student_school['school_id'])
            student_details['Education'].append(school_info)
    student_details['Activities'] = crud.get_activities_of_student(db, student_id=student_id)
    student_details['Work Experience'] = crud.get_student_work_experiences(db,student_id=student_id)
    student_details['Strengths & Weakness'] = crud.get_student_strengths_weakness(db, student_id=student_id)
    student_details['Standardized Tests'] = crud.get_student_standardized_test(db,student_id=student_id)

    log_trace(logging.INFO, f"Student details {student_details}")
    return student_details


@router.delete("/users/students/delete/id/{student_id}")
def delete_student(student_id: int, db: Session = Depends(get_db),
                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted = crud.delete_student(db, student_id=student_id)
    if not deleted:
        log_trace(logging.INFO, f"Student with id {student_id} not deleted")
        raise HTTPException(status_code=404, detail="Student not deleted")

    log_trace(logging.INFO, f"Student with id {student_id} deleted")
    return deleted


@router.post("/users/students/update/{student_id}", response_model=schemas.Student)
def update_student(student_id: int, student: schemas.StudentCreate, db: Session = Depends(get_db),
                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Create a student entry, then a school entry and then a studentschool entry
    db_student = crud.get_student_by_uid(db, uid=student.user_id)
    if not db_student:
        db_student = crud.create_student(db=db, student=student)
        if not db_student:
            log_trace(logging.INFO, f"Error adding a student record")
            raise HTTPException(status_code=404, detail="Error adding a student record")
    
    db_school = crud.get_school_by_name_city_state_country(
        db,
        name=student.school_name,
        city=student.school_city,
        state=student.school_state,
        country=student.country
    )
    if not db_school:
        db_school = crud.create_school(db=db, new_school=schemas.SchoolCreate(name=student.school_name,
                                                                         city=student.school_city,
                                                                         state=student.school_state,
                                                                         zip=student.school_zip,
                                                                         country=student.country))
        if not db_school:
            log_trace(logging.INFO, f"Error adding a school record")
            raise HTTPException(status_code=404, detail="Error adding a school record")

        log_trace(logging.INFO, f"Created school record details {db_school}")
    else:
        db_school = crud.update_school(db=db, school_id=db_school.id,
                                       school=schemas.SchoolCreate(name=student.school_name,
                                                                   city=student.school_city,
                                                                   state=student.school_state,
                                                                   zip=student.school_zip,
                                                                   country=student.country))
        if not db_school:
            log_trace(logging.INFO, f"Error updating a school record")
            raise HTTPException(status_code=404, detail="Error updating a school record")

        log_trace(logging.INFO, f"Updated school record details {db_school}")
    
    db_student_school = crud.get_student_school_by_id(db, student_id=student_id, school_id=db_school.id)
    if not db_student_school:
        db_student_school = crud.create_student_school(db=db, student_school=schemas.StudentSchoolCreate(
                                                                        student_id = db_student.id,
                                                                        school_id = db_school.id,
                                                                        is_primary = student.is_primary,
                                                                        current_grade = student.current_grade,
                                                                        gpa = student.gpa,
                                                                        w_gpa = student.w_gpa,
                                                                        start_date = student.start_date,
                                                                        end_date = student.end_date,
                                                                        graduation_year = student.graduation_year,
                                                                        currently_enrolled = student.currently_enrolled))
        log_trace(logging.INFO, f"Created school details {db_student_school} for student with id {student_id}")
    else:
        db_student_school = crud.update_student_school(db=db, student_school_id=db_student_school.id,
                                                       student_school_update=schemas.StudentSchoolUpdate(
                                                                        student_id = db_student.id,
                                                                        school_id = db_school.id,
                                                                        is_primary = student.is_primary,
                                                                        current_grade = student.current_grade,
                                                                        gpa = student.gpa,
                                                                        w_gpa = student.w_gpa,
                                                                        start_date = student.start_date,
                                                                        end_date = student.end_date,
                                                                        graduation_year = student.graduation_year,
                                                                        currently_enrolled = student.currently_enrolled))
        log_trace(logging.INFO, f"Updated school details {db_student_school} for student with id {student_id}")
    if not db_student_school:
        raise HTTPException(status_code=404, detail="Error updating a student school record")

    log_trace(logging.INFO, f"Updated student record details {db_school}")
    return db_student


########################################################################################
################################## Schools #############################################
########################################################################################


@router.post("/schools/create", response_model=schemas.School)
def create_school(school: schemas.SchoolCreate, db: Session = Depends(get_db),
                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_school = crud.get_school_by_name_city_state(db, name=school.name,
                                                 city=school.city, state=school.state)
    if db_school:
        log_trace(logging.INFO, f"Already available school details {db_school}")
        return db_school

    db_school = crud.create_school(db=db, new_school=school)
    log_trace(logging.INFO, f"Created school details {db_school}")
    return db_school


@router.get("/schools/get", response_model=list[schemas.School])
def read_schools(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    schools = crud.get_schools(db, skip=skip, limit=limit)
    log_trace(logging.INFO, f"List of schools details {schools}")
    return schools


@router.get("/schools/get/id/{school_id}", response_model=schemas.School)
def get_school(school_id: int, db: Session = Depends(get_db),
               credentials: JWTAuthorizationCredentials = Depends(auth)):
    school = crud.get_school_by_id(db, school_id=school_id)
    log_trace(logging.INFO, f"School details {school}")
    return school


@router.delete("/schools/delete/id/{school_id}")
def delete_school(school_id: int, db: Session = Depends(get_db),
                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted = crud.delete_school(db, school_id)
    if not deleted:
        log_trace(logging.INFO, f"School with id {school_id} not found")
        raise HTTPException(status_code=404, detail="School not found")

    log_trace(logging.INFO, f"School with id {school_id} deleted")
    return deleted


########################################################################################
############################## student school ops ######################################
########################################################################################


# StudentSchool routes
@router.post("/users/students/schools/add/") #, response_model=schemas.StudentSchool)
def create_student_school(student_school: schemas.StudentSchoolCreate, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_school = crud.create_student_school(db=db, student_school=student_school)
    log_trace(logging.INFO, f"Created student school details {db_student_school}")
    return db_student_school


@router.get("/users/students/schools/get")
def read_student_schools(student_id: int, db: Session = Depends(get_db),
                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    schools = crud.get_student_schools(db, student_id=student_id)
    # for school in schools:
    #     print(school['student_id'])
    log_trace(logging.INFO, f"Fetched student school details {schools}")
    return schools


@router.get("/users/students/schools/get/user_id/{user_id}")
def get_schools_by_uid(user_id: int, db: Session = Depends(get_db),
                       credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        # raise HTTPException(status_code=404, detail="Student not found")
        # Return an empty list here!
        return []
    
    db_schools = crud.get_student_schools(db, student_id=db_student.id)
    for school in db_schools:
        for k, v in school.items():
            log_trace(logging.INFO, f"school[{k}] = {v}")

    log_trace(logging.INFO, f"Schools details {db_schools} for user with id {user_id}")
    return db_schools


@router.get("/users/students/schools/get/student_school/{student_school_id}")
def get_student_schools_by_student_school_id(student_school_id: int,
                                             db: Session = Depends(get_db),
                                             credentials: JWTAuthorizationCredentials = Depends(auth)):
    print(student_school_id)
    db_student_schools = crud.get_student_schools_by_student_school_id(db,
                                                                       student_school_id=student_school_id)

    log_trace(logging.INFO, f"Student Schools details {db_student_schools}")
    return db_student_schools


@router.get("/users/students/schools/get/id/{student_id}")
def get_student_schools(student_id: int, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_schools = crud.get_student_schools(db, student_id=student_id)
    if db_student_schools is None:
        log_trace(logging.INFO, f"Student with id {student_id} schools details not found")
        raise HTTPException(status_code=404, detail="StudentSchool not found")

    log_trace(logging.INFO, f"Student with id {student_id} schools details {db_student_schools}")
    return db_student_schools


@router.get("/users/students/schools/get/id/{student_id}/{school_id}")
def get_student_school(student_id: int, 
                       school_id: int,
                       db: Session = Depends(get_db),
                       credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_school = crud.get_student_school_by_id(db, 
                                                      student_id = student_id, 
                                                      school_id = school_id)
    if db_student_school is None:
        log_trace(logging.INFO, f"For student with id {student_id} school with {school_id} not found")
        raise HTTPException(status_code=404, detail="StudentSchool not found")

    log_trace(logging.INFO, f"Student School details {db_student_school}")
    return db_student_school


@router.get("/users/students/schools/get/primary/user_id/{user_id}")
def get_student_primary_school(user_id: int, 
                       db: Session = Depends(get_db),
                       credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db,uid=user_id)
    if db_student is None:
        return None
    db_student_school = crud.get_student_primary_school(db, 
                                                        student_id = db_student.id)
    # Upto the caller to throw an exception if the school is not found

    log_trace(logging.INFO, f"Student primary school details {db_student_school}")
    return db_student_school


#@router.post("/users/students/schools/update/id/{user_id}/{school_id}")
def update_student_school_by_userid(user_id: int, school_id: int,
                                    student_school: schemas.StudentSchoolUpdate,
                                    db: Session = Depends(get_db),
                                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_school = crud.update_student_school_by_id(db=db,
                                                         user_id=user_id,
                                                         school_id=school_id,
                                                         student_school=student_school)
    if db_student_school is None:
        log_trace(logging.INFO, f"For student with id {user_id} school not found")
        raise HTTPException(status_code=404, detail="StudentSchool not found")

    log_trace(logging.INFO, f"Student school details {db_student_school}")
    return db_student_school


@router.delete("/users/students/schools/delete/id/{user_id}/{school_id}", response_model=schemas.StudentSchool)
def delete_student_school_by_id(user_id: int, school_id: int, db: Session = Depends(get_db),
                                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_school = crud.delete_student_school_by_id(db=db, user_id=user_id, school_id=school_id)
    if db_student_school is None:
        log_trace(logging.INFO, f"For student with id {user_id} school with id {school_id} not found")
        raise HTTPException(status_code=404, detail="StudentSchool not found")

    log_trace(logging.INFO, f"For student with id {user_id} school with id {school_id} deleted")
    return db_student_school


@router.put("/users/students/schools/update/student_school_id/{student_school_id}")
def update_student_school(student_school_id: int, student_school: schemas.StudentSchoolCreate,
                          db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_school = crud.update_student_school(db=db,
                                                   student_school_id=student_school_id,
                                                   student_school_update=student_school)
    if db_student_school is None:
        log_trace(logging.INFO, f"Student school with id {student_school_id} not found")
        raise HTTPException(status_code=404, detail="StudentSchool not found")

    log_trace(logging.INFO, f"Updated student school with id {student_school_id} details {db_student_school}")
    return db_student_school


# THIS IS USED RIGHT NOW TO DELETE A STUDENT SCHOOL RECORD FROM UI
@router.delete("/users/students/schools/delete/student_school_id/{student_school_id}",
               response_model=schemas.StudentSchool)
def delete_student_school(student_school_id: int, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_school = crud.delete_student_school(db=db, student_school_id=student_school_id)
    if db_student_school is None:
        log_trace(logging.INFO, f"Student school with id {student_school_id} not found")
        raise HTTPException(status_code=404, detail="StudentSchool not found")

    log_trace(logging.INFO, f"Student school with id {student_school_id} deleted")
    return db_student_school


########################################################################################
############################## student strengths weakness ops ##########################
########################################################################################

@router.post("/users/students/strengthsweakness/add", response_model=schemas.StudentStrengthsWeakness)
def create_student_strengths_weakness(student_sw: schemas.StudentStrengthsWeaknessCreate,
                                      db: Session = Depends(get_db),
                                      credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.create_student_strengths_weakness(db=db, student_sw=student_sw)

@router.get("/users/students/strengthsweakness/get/id/{student_id}", 
            response_model=Union[schemas.StudentStrengthsWeakness,None])
def get_student_strengths_weakness(student_id: int, db: Session = Depends(get_db),
                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_sw = crud.get_student_strengths_weakness(db, student_id=student_id)
    if db_student_sw is None:
        log_trace(logging.INFO, f"student strength & weakness not found")
        return None
        #raise HTTPException(status_code=404, detail="Student details doesn't exist")

    log_trace(logging.INFO, f"Fetched student strength & weakness {db_student_sw}")
    return db_student_sw


@router.put("/users/students/strengthsweakness/update/",
            response_model=schemas.StudentStrengthsWeakness)
def update_student_strengths_weakness(student_sw: schemas.StudentStrengthsWeaknessUpdate, 
                                      db: Session = Depends(get_db),
                                      credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_sw = crud.update_student_strengths_weakness(db=db, student_sw=student_sw)
    if db_student_sw is None:
        log_trace(logging.ERROR, f"Student details doesn't exist")
        raise HTTPException(status_code=404, detail="Student details doesn't exist")
    
    log_trace(logging.INFO, f"{db_student_sw}")
    return db_student_sw


@router.delete("/users/students/strengthsweakness/delete/id/{student_id}",
                response_model=schemas.StudentStrengthsWeakness)
def delete_student_strengths_weakness(
                                student_id: int, 
                                db: Session = Depends(get_db),
                                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_sw = crud.delete_student_strengths_weakness(
                                                    db=db, 
                                                    student_id=student_id)
    if db_student_sw is None:
        log_trace(logging.ERROR, f"Student details doesn't exist")
        raise HTTPException(status_code=404, detail="Student details doesn't exist")
    
    log_trace(logging.ERROR, f"Studnet with id {student_id} strengths & weeksness deleted")
    return db_student_sw


########################################################################################
############################## student standardized tests ops ##########################
########################################################################################

@router.post("/users/students/standardizedtests/add/user_id/{user_id}",
             response_model=schemas.StudentStandardizedTest)
def create_student_standardized_test(user_id: int,
                                     student_standardized_test: schemas.StudentStandardizedTestCreate,
                                     db: Session = Depends(get_db),
                                     credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.create_student_standardized_test(db=db,
                                                 user_id=user_id,
                                                 student_standardized_test=student_standardized_test)


@router.post("/users/students/standardizedtests/add_list/user_id/{user_id}",
             response_model=list[schemas.StudentStandardizedTest])
def create_student_standardized_test_list(user_id: int,
                                          student_standardized_tests: list[schemas.StudentStandardizedTestCreate],
                                          db: Session = Depends(get_db),
                                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    res_tests = []
    for test in student_standardized_tests:
        res_tests.append(crud.create_student_standardized_test(db=db,
                                                               user_id=user_id,
                                                               student_standardized_test=test))
        
    log_trace(logging.INFO, f"{res_tests}")
    return res_tests


@router.get("/users/students/standardizedtests/get/id/{student_id}",
            response_model=list[schemas.StudentStandardizedTest])
def get_student_standardized_test_by_student_id(student_id: int,
                                                db: Session = Depends(get_db),
                                                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_standardized_test = crud.get_student_standardized_test(db, student_id=student_id)
    # print(db_student_standardized_test.student_id)
    if db_student_standardized_test is None:
        log_trace(logging.INFO, f"Student standardized test not found")
        #raise HTTPException(status_code=404, detail="StudentStandardizedTest not found")
        return []
    
    log_trace(logging.INFO, f"Student standardized test {db_student_standardized_test} for student id {student_id}")
    return db_student_standardized_test


@router.get("/users/students/standardizedtests/get/user_id/{user_id}",
            response_model=list[schemas.StudentStandardizedTest])
def get_student_standardized_test_by_userid(user_id: int,
                                            db: Session = Depends(get_db),
                                            credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        #raise HTTPException(status_code=404, detail="Student not found")
        log_trace(logging.INFO, f"Student id {user_id} not found")
        return []

    db_student_standardized_test = crud.get_student_standardized_test(db, student_id=db_student.id)

    if db_student_standardized_test is None:
        log_trace(logging.INFO, f"Student stradardized test not found")
        return []
    
    log_trace(logging.INFO, f"Student stradardized test {db_student_standardized_test} for user id {user_id}")
    return db_student_standardized_test


@router.put("/users/students/standardizedtests/update/{student_std_test_id}",
            response_model=schemas.StudentStandardizedTest)
def update_student_standardized_test(student_std_test_id: int,
                                     student_standardized_test: schemas.StudentStandardizedTestCreate,
                                     db: Session = Depends(get_db),
                                     credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_standardized_test = crud.update_student_standardized_test(db=db,
                                                                         student_std_test_id=student_std_test_id,
                                                                         student_standardized_test_update=student_standardized_test)
    if db_student_standardized_test is None:
        log_trace(logging.ERROR, f"Student stradardized test with id {student_std_test_id} not found")
        raise HTTPException(status_code=404, detail="StudentStandardizedTest not found")
    
    log_trace(logging.INFO, f"Updated student stradardized test {db_student_standardized_test}")
    return db_student_standardized_test


@router.delete("/users/students/standardizedtests/delete/id/{test_id}",
               response_model=schemas.StudentStandardizedTest)
def delete_student_standardized_test(test_id: int,
                                     db: Session = Depends(get_db),
                                     credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_standardized_test = crud.delete_student_standardized_test(db=db, test_id=test_id)
    if db_student_standardized_test is None:
        log_trace(logging.ERROR, f"Student stradardized test with id {test_id} not found")
        raise HTTPException(status_code=404, detail="StudentStandardizedTest not found")
    
    log_trace(logging.INFO, f"Student stradardized test with id {test_id} deleted")
    return db_student_standardized_test


########################################################################################
############################## student workexp ops ##########################
########################################################################################

@router.post("/users/students/workexperience/add/user_id/{user_id}",
             response_model=schemas.StudentWorkExperience)
def create_student_work_experience(user_id: int, student_work_experience: schemas.StudentWorkExperienceCreate, 
                                   db: Session = Depends(get_db),
                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.add_student_work_experience(db=db, user_id=user_id,
                                               student_work_experience=student_work_experience)


@router.get("/users/students/workexperience/get/{student_id}",
            response_model=list[schemas.StudentWorkExperience])
def get_student_work_experiences(student_id: int, 
                                 db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.get_student_work_experiences(db, student_id=student_id)


@router.get("/users/students/workexperience/get/user_id/{user_id}",
            response_model=list[schemas.StudentWorkExperience])
def get_student_work_experiences_by_uid(user_id: int, 
                                 db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        #raise HTTPException(status_code=404, detail="Student not found")
        log_trace(logging.INFO, f"student not found for user_id {user_id}")
        return []
    student_id = db_student.id
    return crud.get_student_work_experiences(db, student_id=student_id)


@router.put("/users/students/workexperience/update/{work_experience_id}",
            response_model=schemas.StudentWorkExperience)
def update_student_work_experience(work_experience_id: int, 
                                   student_work_experience: schemas.StudentWorkExperienceCreate, 
                                   db: Session = Depends(get_db),
                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.update_student_work_experience(db=db, 
                                               work_experience_id=work_experience_id, 
                                               student_work_experience=student_work_experience)

@router.delete("/users/students/workexperience/delete/{work_experience_id}", 
               response_model=schemas.StudentWorkExperience)
def delete_student_work_experience(work_experience_id: int, 
                                   db: Session = Depends(get_db),
                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.delete_student_work_experience(db, 
                                               work_experience_id=work_experience_id)

# StudentProjects routes
@router.post("/users/students/projects/add/user_id/{user_id}", 
             response_model=schemas.StudentProjects)
def add_student_project(user_id: int, student_project: schemas.StudentProjectsCreate, 
                           db: Session = Depends(get_db),
                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        log_trace(logging.INFO, f"Student not found with user_id {user_id}")
        raise HTTPException(status_code=404, detail="Student not found")
    
    log_trace(logging.INFO, f"{db_student.id}, for user_id {user_id}")
    return crud.add_student_project(db=db, 
                                        student_id = db_student.id,
                                        student_project=student_project)


@router.get("/users/students/projects/get/user_id/{user_id}",
            response_model=list[schemas.StudentProjects])
def get_student_projects(user_id: int, 
                         db: Session = Depends(get_db),
                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        #raise HTTPException(status_code=404, detail="Student not found")
        log_trace(logging.INFO, f"Student not found with user_id {user_id}")
        return []
    student_id = db_student.id
    return crud.get_student_projects(db, 
                                     student_id=student_id)


@router.put("/users/students/projects/update/{project_id}",
            response_model=schemas.StudentProjects)
def update_student_project(project_id: int, 
                           student_project: schemas.StudentProjectsCreate, 
                           db: Session = Depends(get_db),
                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    log_trace(logging.INFO, f"Updating project {project_id} with {student_project}")
    return crud.update_student_project(db=db, 
                                       project_id=project_id, 
                                       student_project=student_project)


@router.delete("/users/students/projects/delete/{project_id}",
               response_model=schemas.StudentProjects)
def delete_student_project(project_id: int, 
                           db: Session = Depends(get_db),
                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.delete_student_project(db, 
                                       project_id=project_id)


########################################################################################
############################## course ops ##############################################
########################################################################################

@router.post("/courses/create/", response_model=schemas.Course)
def create_course(course: schemas.CourseCreate, db: Session = Depends(get_db),
                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    try:
        db_course = crud.get_course(db,course=course.course_name)
        if db_course:
            log_trace(logging.ERROR, f"Course already exists")
            raise HTTPException(status_code=400, detail="Course already exists")
        return crud.create_course(db=db, course_name = course.course_name)
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
        raise HTTPException(status_code=500, detail =str(e)) from e


@router.get("/courses/get/", response_model=list[schemas.Course])
def read_courses(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    courses = crud.get_courses(db, skip=skip, limit=limit)
    return courses


@router.get("/courses/get/id/{course_id}", response_model=schemas.Course)
def read_courses_by_courseid(course_id: int, db: Session = Depends(get_db),
                             credentials: JWTAuthorizationCredentials = Depends(auth)):
    courses = crud.get_course(db, course=course_id)
    return courses


@router.delete("/courses/delete/id/{course_id}")
def delete_courses(course_id: int, db: Session = Depends(get_db),
                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted = crud.delete_course(db, course_id=course_id)
    if not deleted:
        log_trace(logging.ERROR, f"Course already exists")
        raise HTTPException(status_code=404, detail="Course not found")
    return deleted


########################################################################################
################################# activities ops #######################################
########################################################################################


@router.post("/activities/create/", response_model=schemas.Activity)
def create_activity(activity: schemas.ActivityCreate, db: Session = Depends(get_db),
                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_activity = crud.get_activity(db,activity=activity.activity_name)
    if db_activity:
        log_trace(logging.ERROR, f"Activity already exists")
        raise HTTPException(status_code=400, detail="Activity already exists")
    return crud.create_activity(db=db, activity_name=activity.activity_name)


@router.get("/activities/get/", response_model=list[schemas.Activity])
def read_activities(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    activities = crud.get_activites(db, skip=skip, limit=limit)
    return activities


@router.get("/activities/get/id/{activity_id}", response_model=schemas.Activity)
def read_activity(activity_id: int, db: Session = Depends(get_db),
                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    activity = crud.get_activity(db, activity=activity_id)
    return activity


@router.delete("/activities/delete/id/{activity_id}")
def delete_activity(activity_id: int, db: Session = Depends(get_db),
                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted = crud.delete_activity(db, activity_id=activity_id)
    if not deleted:
        log_trace(logging.ERROR, f"Activity not found")
        raise HTTPException(status_code=404, detail="Activity not found")
    
    log_trace(logging.INFO, f"Activity with id {activity_id} deleted")
    return deleted


########################################################################################
############################## careers ops #############################################
########################################################################################


@router.post("/careers/get_create_or_update/", response_model=schemas.Careers)
def create_career(career: schemas.CareersCreate, 
                  db: Session = Depends(get_db),
                  refresh: bool = False,
                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    try:
        # @kk, do we need to do the get? just add the career?
        log_trace(logging.INFO, f"{career}")
        db_career = crud.get_career(db,career=career.career_name)
        if db_career:
            if not refresh:
                return db_career
            return crud.update_career(db,career=career)
        db_career = crud.create_career(db=db, career=career)
        return db_career
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/careers/get/", response_model=list[schemas.CareersBase])
def read_careers(skip: int = 0, limit: int = 100, db: Session = Depends(get_db),
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    careers = crud.get_careers(db, skip=skip, limit=limit)
    return careers


@router.get("/careers/get/id/{career_id}", response_model=schemas.CareersBase)
def read_career(career_id: int, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    career = crud.get_career(db, career=career_id)
    return career


@router.delete("/careers/delete/id/{career_id}")
def delete_career(career_id: int, db: Session = Depends(get_db),
                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted = crud.delete_career(db, career_id=career_id)
    if not deleted:
        log_trace(logging.INFO, f"Career with {career_id} not found")
        raise HTTPException(status_code=404, detail="Career not found")

    log_trace(logging.INFO, f"Career with {career_id} deleted")
    return deleted


########################################################################################
########################## student-course ops ##########################################
########################################################################################

@router.post("/users/students/courses/add/") #, response_model=schemas.StudentCourse)
def create_student_course(usercourse: schemas.StudentCourseCreate, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_courses = crud.get_student_courses_by_school_and_student_id(db,
                                          student_id = usercourse.student_id,
                                          school_id=usercourse.school_id)
    log_trace(logging.INFO, f"{db_courses}")
    if len(db_courses)>0:
        course_names, courses_dict = crud.get_current_courses(db, db_courses)
        if usercourse.course_name in course_names:
            # Find the course term and see if they match
            for course_id, course_info in courses_dict.items():
                if course_info['name'] == usercourse.course_name and \
                   course_info['term'] == usercourse.term and \
                   course_info['year'] == usercourse.grade_year:
                    log_trace(logging.ERROR, "Course already present for user")
                    raise HTTPException(status_code=400, detail="Course already present for user") 

    return crud.add_student_course(db=db, usercourse=usercourse)

#### DO WE NEED THIS????????????? REMOVE IF NOT USED
#@router.post("/users/students/courses/add/user_id/{user_id}", response_model=schemas.StudentCourse)
# def create_student_course_by_userid(user_id: int, usercourse: schemas.StudentCourseCreate,
#                                     db: Session = Depends(get_db),
#                                     credentials: JWTAuthorizationCredentials = Depends(auth)):
#     db_student = crud.get_student_by_uid(db, uid=user_id)
#     if db_student is None:
#         # Student record should be added as soon as we add a school record
#         raise HTTPException(status_code=404, detail="Student not found")
    
#     usercourse.student_id = db_student.id                                  
#     db_courses = crud.get_student_courses_by_school(db,
#                                                     student_id = usercourse.student_id,
#                                                     school_id=usercourse.school_id)
#     print(db_courses)
#     if len(db_courses)>0:
#         course_names, courses_dict = crud.get_current_courses(db, db_courses)
#         if usercourse.course_name in course_names:
#             # Find the course term and see if they match
#             for course_id, course_info in courses_dict.items():
#                 if course_info['name'] == usercourse.course_name and course_info['term'] == usercourse.term:
#                     raise HTTPException(status_code=400, detail="Course already present for user") 
                    
#     return crud.add_student_course(db=db, usercourse=usercourse)


### THIS API IS USED BY THE APP TO ADD MULTIPLE COURSES FOR A STUDENT
@router.post("/users/students/courses/addlist/")
def create_student_courses_list(usercourses: list[schemas.StudentCourseCreate],
                                db: Session = Depends(get_db),
                                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_courses = []
    course_names = []
    added_courses = []
    if len(usercourses) == 0:
        return []
    
    if usercourses[0].student_id == 0:
        log_trace(logging.ERROR, "Invalid student specified")
        raise HTTPException(status_code=404, detail="Invalid student specified")
    
    if not usercourses[0].school_id:
        schools = crud.get_student_schools(db,student_id=usercourses[0].student_id)
        if schools is None or len(schools) == 0:
            log_trace(logging.ERROR, "Please add a school before adding courses.")
            raise HTTPException(status_code=404, detail="Please add a school before adding courses.")    
        
        school_id = schools[0]['school_id']
    else:
        school_id = usercourses[0].school_id

    course_names = []
    courses_dict = {}
    for usercourse in usercourses:
        if len(db_courses) == 0:
            db_courses = crud.get_student_courses_by_school_and_student_id(db,
                                                  student_id = usercourse.student_id,
                                                  school_id=school_id)
            if len(db_courses)>0:
                # Do this only for the first course we are adding
                log_trace(logging.INFO, f"{db_courses}")
                course_names, courses_dict = crud.get_current_courses(db, db_courses)
        is_valid = True
        if usercourse.course_name in course_names:
            # Find the course term and see if they match
            for course_id, course_info in courses_dict.items():
                if course_info['name'] == usercourse.course_name and \
                   course_info['term'] == usercourse.term and \
                   course_info['year'] == usercourse.grade_year:
                    is_valid = False
                    # raise HTTPException(status_code=400, detail="Course already present for user")
                    log_trace(logging.ERROR, f"Course {usercourse.course_name} already present for user")
                    break
        if not is_valid:
            continue

        # To make sure we don't add the same course again, keep course_names up-to-date
        course_names.append(usercourse.course_name)
        db_course = crud.add_student_course(db=db, usercourse=usercourse)
        added_courses.append(db_course)
    return added_courses


@router.delete("/users/students/courses/delete/{student_course_id}")
def delete_student_course(student_course_id: int, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    log_trace(logging.INFO, f"Deleting student course {student_course_id}")
    deleted  = crud.delete_student_course(db, student_course_id=student_course_id)
    if not deleted:
        log_trace(logging.ERROR, "Student or course doesn't exist")
        raise HTTPException(status_code=404, detail="Student or course doesn't exist")
    
    log_trace(logging.INFO, f"Student course with id {student_course_id} deleted")
    return deleted


@router.post("/users/students/courses/update/{student_course_id}")
def update_student_course(student_course_id: int, usercourse: schemas.StudentCourseCreate,
                          db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    if usercourse.student_id == 0 or usercourse.school_id == 0:
        log_trace(logging.ERROR, "Student or school not found")
        raise HTTPException(status_code=404, detail="Student or school not found")
    
    # Check if we have a course with this student course id
    db_course = crud.get_student_course_by_id(db, student_course_id=student_course_id)
    if not db_course:
        log_trace(logging.ERROR, "Student course not found, cant update course")
        raise HTTPException(status_code=404, detail="Student course not found, cant update course.")

    db_course_basic = crud.get_course(db, course=db_course.course_id)
    if not db_course_basic:
        log_trace(logging.ERROR, "Course not found, cant update course")
        raise HTTPException(status_code=404, detail="Course not found, cant update course.")
    db_course_name = db_course_basic.course_name
    course_id_updated = db_course_basic.id

    log_trace(logging.INFO, "Course name {db_course_name}")

    # Check if the course in the request matches the course names. If not, then the update is in the course name
    if usercourse.course_name != db_course_name:
        # Check if course exists
        db_course_new = crud.get_course(db,course=usercourse.course_name)
        if not db_course_new:
            # Add this course, update the course id in the student course record
            db_course_new = crud.create_course(db=db, course_name = usercourse.course_name)
        course_id_updated = db_course_new.id

    return crud.update_student_course(db=db, student_course=usercourse,
                                      student_course_id=student_course_id,
                                      course_id=course_id_updated)


# Adding coursename so cant specify the schema here
@router.get("/users/students/courses/get/student_school_id/{student_id}/{school_id}")
def get_user_courses_by_school(student_id: int, school_id: int,
                               db: Session = Depends(get_db),
                               credentials: JWTAuthorizationCredentials = Depends(auth)):
    courses = crud.get_student_courses_by_school(db, 
                                                 student_id = student_id,
                                                 school_id=school_id)
    return courses


@router.get("/users/students/courses/get/student_id/{student_id}")
def get_user_courses(student_id: int, db: Session = Depends(get_db),
                     credentials: JWTAuthorizationCredentials = Depends(auth)):
    courses = crud.get_student_courses(db, student_id = student_id)
    return courses


@router.get("/users/students/courses/get/user_id/{user_id}")
def get_user_courses_by_user_id(user_id: int, db: Session = Depends(get_db),
                                credentials: JWTAuthorizationCredentials = Depends(auth)):
    student = crud.get_student_by_uid(db, uid = user_id)
    if student:
        student_id = student.id
        courses = crud.get_student_courses(db, student_id = student_id)
        log_trace(logging.INFO, "course {courses}")
        return courses
    
    #raise HTTPException(status_code=404, detail="Student not found")
    log_trace(logging.ERROR, f"found for user_id {user_id}")
    return []


########################################################################################
######################### student activity ops #########################################
########################################################################################

@router.post("/users/students/activities/add/{user_id}", response_model=schemas.StudentActivity)
def create_student_activity(user_id: int, useractivity: schemas.StudentActivityCreate,
                            db: Session = Depends(get_db),
                            credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        #raise HTTPException(status_code=404, detail="Student not found")
        # Add student
        db_student = crud.create_student(db, student=schemas.StudentCreate(uid=user_id))
        if db_student is None:
            log_trace(logging.ERROR, "Unexpected error creating student record")
            raise HTTPException(status_code=404, detail="Unexpected error creating student record")
        
    return crud.add_student_activity(db=db, student_id=db_student.id, activity=useractivity)


@router.post("/users/students/activities/addlist/{user_id}")
def create_student_activities_list(user_id: int, useractivities: list[schemas.StudentActivityCreate],
                                   db: Session = Depends(get_db),
                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    if len(useractivities) == 0:
        return []
    
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        #raise HTTPException(status_code=404, detail="Student not found")
        # Add student
        db_student = crud.create_student(db, student=schemas.StudentCreate(uid=user_id))
        if db_student is None:
            log_trace(logging.ERROR, "Unexpected error creating student record")
            raise HTTPException(status_code=404, detail="Unexpected error creating student record")
        
    added_activities = []
    for useractivity in useractivities:
        added_activities.append(crud.add_student_activity(db=db,
                                                          student_id=db_student.id,
                                                          activity=useractivity))
    return added_activities


@router.delete("/users/students/activities/delete/")
def delete_student_activity(useractivity: schemas.StudentActivityDelete,
                            db: Session = Depends(get_db),
                            credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted  = crud.delete_student_activity(db=db, student_id = useractivity.student_id, 
                                          activity_id = useractivity.activity_id)
    if not deleted:
        log_trace(logging.ERROR, "Student or activity doesn't exist")
        raise HTTPException(status_code=404, detail="Student or activity doesn't exist")
    return deleted


@router.delete("/users/students/activities/delete/activity_id/{student_activity_id}")
def delete_student_activity_by_id(student_activity_id: int, db: Session = Depends(get_db),
                                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted  = crud.delete_student_activity_by_id(db=db, student_activity_id = student_activity_id)
    if not deleted:
        log_trace(logging.ERROR, "Student or activity doesn't exist")
        raise HTTPException(status_code=404, detail="Student or activity doesn't exist")
    return deleted


@router.post("/users/students/activities/update/{student_activity_id}")
def update_user_activity(student_activity_id: int, useractivity: schemas.StudentActivityCreate,
                         db: Session = Depends(get_db),
                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_activity = crud.get_student_activity_by_id(db, student_activity_id=student_activity_id)
    if not db_student_activity:
        log_trace(logging.ERROR, "Student activity not found")
        raise HTTPException(status_code=404, detail="Student activity not found")

    # check if activity name changed
    if db_student_activity['activity_name'] != useractivity.activity_name:
        # Check if activity exists
        db_activity = crud.get_activity(db,activity=useractivity.activity_name)
        if not db_activity:
            # Add this activity, update the activity id in the student activity record
            db_activity = crud.create_activity(db=db, activity_name = useractivity.activity_name)
    else:
        db_activity = crud.get_activity(db,activity=db_student_activity['activity_id'])
        if not db_activity:
            log_trace(logging.ERROR, "Activity not found")
            raise HTTPException(status_code=404, detail="Activity not found")
    
    return crud.update_student_activity(db=db, student_activity=useractivity,
                                        student_activity_id=student_activity_id,
                                        activity_id=db_activity.id)


# INTERNAL ROUTINE - auth credentials have already been validated before this func is called.
def validate_user_activity(student_activity_id: int, useractivity: schemas.StudentActivityUpdate,
                           db: Session = Depends(get_db)):
    db_student_activity = crud.get_student_activity_by_id(db, student_activity_id=student_activity_id)
    if not db_student_activity:
        log_trace(logging.ERROR, "Student activity not found")
        raise HTTPException(status_code=404, detail="Student activity not found")

    # check if activity name changed
    if db_student_activity['activity_name'] != useractivity.activity_name:
        # Check if activity exists
        db_activity = crud.get_activity(db,activity=useractivity.activity_name)
        if not db_activity:
            # Add this activity, update the activity id in the student activity record
            db_activity = crud.create_activity(db=db, activity_name = useractivity.activity_name)
    else:
        db_activity = crud.get_activity(db,activity=db_student_activity['activity_id'])

    return db_activity

# Update a list of student activities
@router.post("/users/students/activities/update_list")
def update_student_activities_list(useractivities: list[schemas.StudentActivityUpdate],
                                   db: Session = Depends(get_db),
                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    updated_activities = []
    for useractivity in useractivities:
        db_activity = validate_user_activity(useractivity.id, useractivity, db)
        if not db_activity:
            log_trace(logging.ERROR, "Activity not found")
            raise HTTPException(status_code=404, detail="Activity not found")
        updated_activities.append(crud.update_student_activity(db=db,
                                                               student_activity=useractivity,
                                                               student_activity_id=useractivity.id,
                                                               activity_id=db_activity.id))
    return updated_activities

@router.post("/users/students/activities/bulkupdate/user_id/{user_id}")
def bulk_update_student_activities(user_id: int, useractivities: list[schemas.StudentActivityUpdate],
                                   db: Session = Depends(get_db),
                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Get the student id
    db_student = crud.get_student_by_uid(db, uid=user_id)
    if db_student is None:
        # Add student record
        db_student = crud.create_student(db, student=schemas.StudentCreate(uid=user_id))
        if db_student is None:
            log_trace(logging.ERROR, "Unexpected error creating student record")
            raise HTTPException(status_code=404, detail="Unexpected error creating student record")
    
    # Have to do this check after getting the current list of activities for 
    # student from db - in case the input list is empty, we need to delete all activities
    # for the student
    if len(useractivities) == 0:
        # Delete all activities for the student
        deleted = crud.delete_student_activities(db, student_id = db_student.id)
        return []
    
    # Get a list of all student activities
    current_activities = crud.get_activities_of_student(db, student_id = db_student.id)
    # Generate a list of activities to be deleted
    activities_to_delete = []
    for activity in current_activities:
        if activity['id'] not in [useractivity.id for useractivity in useractivities]:
            activities_to_delete.append(activity['id'])
    
    # trans = None
    try:
        log_trace(logging.INFO, "Activities update")
        # # Create a transaction to update all activities
        # if db._transaction is not None and db._transaction._state == 'active':
        #     print("Transaction already active")
        #     db.rollback()
        
        # trans = db.begin()
        # print("started a transaction")
        updated_activities = []
        for useractivity in useractivities:
            if useractivity.id == 0:
                # This is a new activity, add it
                updated_activities.append(crud.add_student_activity(db=db,
                                                                    student_id=db_student.id,
                                                                    activity=useractivity))
            else:
                # Update the record
                db_activity = validate_user_activity(useractivity.id, useractivity, db)
                if not db_activity:
                    log_trace(logging.ERROR, "Activity not found")
                    raise HTTPException(status_code=404, detail="Activity not found")
                updated_activities.append(crud.update_student_activity(db=db,
                                                                       student_activity=useractivity,
                                                                       student_activity_id=useractivity.id,
                                                                       activity_id=db_activity.id))

        # Delete the activities that are not in the list
        for activity_id in activities_to_delete:
            deleted = crud.delete_student_activity_by_id(db, student_activity_id = activity_id)
            if not deleted:
                log_trace(logging.ERROR, "Student activity not found")
                raise HTTPException(status_code=404, detail="Student activity not found")
    except Exception as e:
        # if trans is not None:
        #     trans.rollback()
        log_trace(logging.ERROR, f"Error updating activities {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
    
    # finally:
    #     db.close()

    return updated_activities

@router.get("/users/students/activities/get/user_id/{user_id}")
def get_user_activities_by_uid(user_id: int, db: Session = Depends(get_db),
                               credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student = crud.get_student_by_uid(db, uid = user_id)
    if db_student is None:
        # Return an empty list here!
        log_trace(logging.INFO, f"Student not found for user_id {user_id}")
        return []
    activities = crud.get_activities_of_student(db, student_id = db_student.id)
    return activities


@router.get("/users/students/activities/get/student_id/{student_id}")
def get_user_activities(student_id: int, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):

    log_trace(logging.INFO, f"Student id {student_id}")
    activities = crud.get_activities_of_student(db, student_id = student_id)
    return activities

########################################################################################
########################## student-career ops ##########################################
########################################################################################

@router.post("/users/students/careers/add/", response_model=schemas.StudentCareer)
def create_student_career(student_career: schemas.StudentCareerCreate, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_career = crud.get_student_career(db,student_career=student_career)
    if not db_student_career:
        # courses = [course.course_id for course in db_courses]
        # course_names = [crud.get_course(db, course=id).course_name for id in courses]
        # if usercourse.course_name in course_names:
        #raise HTTPException(status_code=400, detail="Career create failed for Student")    
        return crud.add_student_career(db=db, student_career=student_career)
    return db_student_career

@router.delete("/users/students/careers/delete/")
def delete_student_career(student_career: schemas.StudentCareerDelete, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted  = crud.delete_student_career(db,student_career=student_career)
    if not deleted:
        log_trace(logging.ERROR, f"Student or Career doesn't exist")
        raise HTTPException(status_code=404, detail="Student or Career doesn't exist")
    return deleted


@router.post("/users/students/careers/update/", response_model=schemas.StudentCareer)
def update_student_career(student_career: schemas.StudentCareerCreate, db: Session = Depends(get_db),
                          credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_career = crud.update_student_career(db, student_career=student_career)
    if not db_career:
        log_trace(logging.ERROR, f"Career not present for user")
        raise HTTPException(status_code=400, detail="Career not present for user")
    
    return db_career

@router.get("/users/students/careers/student_id/{student_id}")
def get_student_careers(student_id: int, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    out = []
    careers = crud.get_student_careers(db, student_id=student_id)
    log_trace(logging.INFO, f"Career is {careers}")

    for career in careers:
        temp_career = {}
        temp_career['id'] = career.id
        career_details = crud.get_career(db,career=career.career_id)
        for k,v in career_details.__dict__.items():
            if k!='id':
                temp_career[k] = v
            else:
                temp_career['career_id'] = v
        
        # Remove _sa_instance_state 
        temp_career.pop('_sa_instance_state')
        out.append(temp_career)

    return out

@router.get("/users/students/careers/student_career_id/{student_career_id}")
def get_student_career_by_id(student_career_id: int, db: Session = Depends(get_db),
                             credentials: JWTAuthorizationCredentials = Depends(auth)):
    career = crud.get_student_career_by_id(db, student_career_id=student_career_id)
    if not career:
        return None
    temp_career = {}
    career_details = crud.get_career(db,career=career.career_id)
    for k,v in career_details.__dict__.items():
        if k!='id':
            temp_career[k] = v
        else:
            temp_career['career_id'] = v
    temp_career['id'] = student_career_id
    return temp_career


@router.post("/users/students/careers/comment/create", response_model=schemas.StudentCareerComment)
def comment_student_career(comment: schemas.StudentCareerCommentCreate, db: Session = Depends(get_db),
                                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    handler = StudentCareerHandler()
    handler.check_student_career_exists(db, comment.student_career_id)
    db_comment = handler.create_comment(db, comment)
    return db_comment


@router.get("/users/students/careers/comments/{career_id}")
def get_student_career_comments(career_id: int, db: Session = Depends(get_db),
                                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    handler = StudentCareerHandler()
    handler.check_student_career_exists(db, career_id)
    db_comment = handler.get_comments(db, career_id)
    return db_comment


@router.get("/users/students/careers/comments/paginated/{career_id}")
def get_student_career_comments_paginated(career_id: int, page_num: int = 0, limit: int = 10,
                                                   db: Session = Depends(get_db),
                                                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    valid_comments = []
    invalid_records = 0
    total_count = 0
    try:
        [total_count, db_comments] = StudentCareerHandler().get_comments_paginated(db,
                                                                                         career_id=career_id,
                                                                                         page_num=page_num,
                                                                                         limit=limit)
        for db_comment in db_comments:
            try:
                # Validate each comment entry with the Pydantic model
                comment = schemas.StudentCareerComment(
                    id = db_comment['id'],
                    content = db_comment['content'],
                    date_published = db_comment['date_published'].isoformat(),
                    user_id = db_comment['user_id'],
                    student_career_id = db_comment['student_career_id'],
                )
                valid_comments.append(db_comment)
            except ValidationError as e:
                # Handle entries that do not pass validation
                invalid_records = invalid_records + 1
                log_trace(logging.ERROR, f"get_student_career_comments_paginated: Invalid record {db_comment} error is {str(e)}")
                continue  # Skip invalid entries or log them as needed
    except Exception as e:
        error = e
        log_trace(logging.ERROR, f"get_student_career_comments_paginated: {str(e)}")

    total_count = total_count - invalid_records
    log_trace(logging.INFO, f"get_student_career_comments_paginated: valid comments {valid_comments}")

    status_code = 200
    message = "Comments Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch comments!"
    elif len(valid_comments) == 0:
        status_code = 200
        message = "No comments found!"

    output = {
        "message": message,
        "data": {
            "result": valid_comments,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error":{} if error is None else {str(error):500}
    }
    return output


########################################################################################
########################## student-target-school ops ##########################################
########################################################################################

@router.get("/users/targetschools/get/id/{target_school_id}")
def read_post(target_school_id: int, db: Session = Depends(get_db),
              credentials: JWTAuthorizationCredentials = Depends(auth)):
    target_school = crud.get_target_school(db, target_school_id=target_school_id)
    return target_school


@router.post("/users/students/targetschools/add/", response_model=schemas.StudentTargetSchool)
def create_student_target_school(student_target_school: schemas.StudentTargetSchoolCreate,
                                 db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_target_school = crud.get_student_target_schools_by_career(db,
                                                                         student_id=student_target_school.student_id,
                                                                         career_id=student_target_school.career_id,
                                                                         college_name=student_target_school.college_name)
    if not db_student_target_school:
        # courses = [course.course_id for course in db_courses]
        # course_names = [crud.get_course(db, course=id).course_name for id in courses]
        # if usercourse.course_name in course_names:
        #raise HTTPException(status_code=400, detail="Career create failed for Student")    
        return crud.add_student_target_school(db=db, student_target_school=student_target_school)
    return db_student_target_school


@router.delete("/users/students/targetschools/delete/")
def delete_student_target_school(student_target_school: schemas.StudentTargetSchoolDelete,
                                 db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    deleted  = crud.delete_student_target_school(db,student_target_school=student_target_school)
    if not deleted:
        log_trace(logging.ERROR, f"Student or Career doesn't exist")
        raise HTTPException(status_code=404, detail="Student or Career doesn't exist")
    return deleted


@router.post("/users/students/targetschools/update/", response_model=schemas.StudentTargetSchool)
def update_student_target_school(student_target_school: schemas.StudentTargetSchoolCreate,
                                 db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_student_target_school = crud.update_student_target_school(db, student_target_school=student_target_school)
    if not db_student_target_school:
        log_trace(logging.ERROR, f"Career not present for user")
        raise HTTPException(status_code=400, detail="Career not present for user")
    return db_student_target_school

@router.get("/users/students/targetschools/student_id/{student_id}")
def get_student_target_schools(student_id: int, db: Session = Depends(get_db),
                               credentials: JWTAuthorizationCredentials = Depends(auth)):
    out = []
    student_target_schools = crud.get_student_target_schools(db, student_id = student_id)
    for school in student_target_schools:
        temp_school ={}
        career_details = crud.get_career(db,career=school["career_id"])
        for k,v in school.items():
            temp_school[k] = v
            # if k!='id':
            #     temp_career[k] = v
            # else:
            #     temp_career['career_id'] = v
        temp_school['career_name']= career_details.career_name
        temp_school['majors'] = career_details.majors
        
        out.append(temp_school)
    return out

@router.get("/users/students/targetschools/student_target_school_id/{student_target_school_id}")
def get_student_target_school_by_id(student_target_school_id: int, db: Session = Depends(get_db),
                                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    student_target_school = crud.get_student_target_school_by_id(db, student_target_school_id=student_target_school_id)
    if not student_target_school:
        return None

    career_id = student_target_school.career_id
    career_details = crud.get_career(db,career=career_id)
    result = student_target_school.__dict__
    result['career_name']= career_details.career_name
    result['majors'] = career_details.majors
    return result


@router.get("/users/students/targetschools/search/{college_name}")
def get_target_school_by_name(college_name: str, db: Session = Depends(get_db),
                              credentials: JWTAuthorizationCredentials = Depends(auth)):
    log_trace(logging.INFO, f"Get target school by name: {college_name}")
    db_target_school = db.query(models.TargetSchools).filter(
        func.similarity(models.TargetSchools.college_name, college_name) > 0.9).first()
    log_trace(logging.INFO, f"Target school is {db_target_school}")
    return db_target_school

@router.get("/users/students/targetschools/picture_url/{college_name}")
def get_target_school_pic_url(college_name: str, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_target_school = db.query(models.TargetSchools).filter(
        func.similarity(models.TargetSchools.college_name, college_name) > 0.9).first()
    if db_target_school:
        return db_target_school.college_pic_url
    return None

@router.post("/users/students/targetschools/comment/create")
def comment_student_targeted_school(comment: schemas.StudentTargetSchoolCommentCreate, db: Session = Depends(get_db),
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    handler = StudentTargetSchoolHandler()
    # handler.check_target_school_exists(db, comment.target_school_id)
    db_comment = handler.create_comment(db, comment)
    return db_comment


@router.get("/users/students/targetschools/comments/{targetschool_id}")
def get_student_targeted_school_comments(targetschool_id: int, db: Session = Depends(get_db),
                                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    handler = StudentTargetSchoolHandler()
    handler.check_target_school_exists(db, targetschool_id)
    db_comment = handler.get_comments(db, targetschool_id)
    return db_comment


@router.get("/users/students/targetschools/comments/paginated/{targetschool_id}")
def get_student_targeted_school_comments_paginated(targetschool_id: int, page_num: int = 0, limit: int = 10,
                                db: Session = Depends(get_db),
                                credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    valid_comments = []
    invalid_records = 0
    total_count = 0
    try:
        [total_count, db_comments] = StudentTargetSchoolHandler().get_comments_paginated(db,
                                                                            targetschool_id=targetschool_id,
                                                                            page_num=page_num,
                                                                            limit=limit)
        for db_comment in db_comments:
            try:
                # Validate each comment entry with the Pydantic model
                comment = schemas.StudentTargetSchoolComment(
                    id = db_comment['id'],
                    content = db_comment['content'],
                    date_published = db_comment['date_published'].isoformat(),
                    user_id = db_comment['user_id'],
                    target_school_id = db_comment['target_school_id'],
                )
                valid_comments.append(db_comment)
            except ValidationError as e:
                # Handle entries that do not pass validation
                invalid_records = invalid_records + 1
                log_trace(logging.ERROR, f"get_student_targeted_school_comments_paginated: Invalid record {db_comment} error is {str(e)}")
                continue  # Skip invalid entries or log them as needed
    except Exception as e:
        log_trace(logging.ERROR, f"get_student_targeted_school_comments_paginated: {str(e)}")

    total_count = total_count - invalid_records
    log_trace(logging.INFO, f"get_student_targeted_school_comments_paginated: valid comments {valid_comments}")

    status_code = 200
    message = "Comments Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch comments!"
    elif len(valid_comments) == 0:
        status_code = 200
        message = "No comments found!"

    output = {
        "message": message,
        "data": {
            "result": valid_comments,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error":{} if error is None else {str(error):500}
    }
    return output


########################################################################################
###########################################   POSTS   ##################################
########################################################################################

@router.post("/users/posts/create", response_model=schemas.PostResult)
def create_post(post: schemas.PostCreate, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    print(post)
    db_post = crud.create_post(db=db, post=post)
    if not db_post:
        log_trace(logging.ERROR, f"Post create failed")
        raise HTTPException(status_code=400, detail="Post create failed")
    post = crud.augment_post_with_user_and_comment_count(db=db, post=db_post)
    post["type"] = Constants.POST_TYPE_REGULAR.value
    return post

@router.post("/users/posts/update/{post_id}", response_model=schemas.PostResult)
def update_post(post_id: int, post: schemas.PostCreate, 
                db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_post = crud.update_post(db=db, post_id=post_id,post=post)
    if not db_post:
        log_trace(logging.ERROR, f"Post doens't exists")
        raise HTTPException(status_code=400, detail="Post doens't exists")
    post = crud.augment_post_with_user_and_comment_count(db=db, post=db_post)
    return post

# Get post by id - replace user_id with username
@router.get("/users/posts/get/post_id/{post_id}", response_model=schemas.PostResult)
def get_post(post_id: int, db: Session = Depends(get_db),
             credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_post = crud.get_post(db,post=post_id)
    if db_post is None:
        log_trace(logging.ERROR, f"Post not found")
        raise HTTPException(status_code=404, detail="Post not found")
    # post = db_post.__dict__
    db_post["type"] = Constants.POST_TYPE_REGULAR.value
    return db_post


# Get posts by user_id - replace user_id with username
@router.get("/users/posts/get/user_id/{user_id}", response_model=list[schemas.PostResult]) 
def get_post_by_uid(user_id: int, db: Session = Depends(get_db),
                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_posts = crud.get_post_by_uid(db,user_id=user_id)
    if db_posts is None:
        log_trace(logging.ERROR, f"No posts found")
        raise HTTPException(status_code=404, detail="No posts found")
    posts = []
    for db_post in db_posts:
        db_post["type"] = Constants.POST_TYPE_REGULAR.value
        posts.append(db_post)
    return posts


@router.get("/users/posts/get_paginated/user_id/{user_id}")
def get_post_by_uid_paginated(user_id: int, page_num: int = 0, limit: int = 10, db: Session = Depends(get_db),
                              credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    valid_posts = []
    invalid_records = 0
    total_count = 0
    try:
        [total_count, db_posts] = crud.get_post_by_uid_paginated(db,
                                                                 user_id=user_id,
                                                                 page_num=page_num,
                                                                 limit=limit,
                                                                 sorted=True)
        for db_post in db_posts:
            try:
                # Validate each post entry with the Pydantic model
                post = schemas.PostResult(
                    id = db_post['id'],
                    type = Constants.POST_TYPE_REGULAR.value,
                    post_title = db_post['post_title'],
                    post_content = db_post['post_content'],
                    date_published = db_post['date_published'],
                    user_id = db_post['user_id'],
                    profile_pic_url=db_post['profile_pic_url'],
                    likes=db_post['likes'],
                    post_content_url=db_post['post_content_url'],
                    username=db_post['username'],
                    comment_count=db_post['comment_count']
                )
                valid_posts.append(post)
            except ValidationError as e:
                log_trace(logging.ERROR, f"Skipping invalid post {db_post['id']} with error {str(e)}")
                # Handle entries that do not pass validation
                invalid_records = invalid_records + 1
                continue  # Skip invalid entries or log them as needed
    except Exception as e:
        error = e
    
    total_count = total_count - invalid_records
    log_trace(logging.INFO, f"valid posts {valid_posts}")

    status_code = 200
    message = "Posts Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch posts!"
    elif len(valid_posts) == 0:
        status_code = 200
        message = "No posts found!"
        
    output = {
        "message": message,
        "data": {
            "result": valid_posts,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error":{} if error is None else {str(error):500}       
    }
    return output

# Get all posts
@router.get("/users/posts/get/")
def get_all_posts(skip: int = 0, limit: int = 10, db: Session = Depends(get_db),
                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    #posts = db.query(models.Post).offset(skip).limit(limit).all()
    # Replace user_id with username
    posts = crud.get_posts(db, skip=skip, limit=limit)
    return posts

# Get posts with pagination
@router.get("/users/posts/get_paginated/")
def get_all_posts_paginated(page_num: int = 0, limit: int = 10, db: Session = Depends(get_db),
                            credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    valid_posts = []
    invalid_records = 0
    total_count = 0
    try:
        [total_count, db_posts] = crud.get_posts_paginated(db, page_num=page_num, limit=limit)
        for db_post in db_posts:
            try:
                # Validate each post entry with the Pydantic model
                post = schemas.PostResult(
                    id = db_post['id'],
                    type = Constants.POST_TYPE_REGULAR.value,
                    post_title = db_post['post_title'],
                    post_content = db_post['post_content'],
                    date_published = db_post['date_published'],
                    user_id = db_post['user_id'],
                    profile_pic_url=db_post['profile_pic_url'],
                    likes=db_post['likes'],
                    post_content_url=db_post['post_content_url'],
                    username=db_post['username'],
                    comment_count=db_post['comment_count']
                )
                valid_posts.append(post)
            except ValidationError as e:
                # Handle entries that do not pass validation
                invalid_records = invalid_records + 1
                continue  # Skip invalid entries or log them as needed
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
        error = e
    
    total_count = total_count - invalid_records
    log_trace(logging.INFO, f"valid posts {valid_posts}")

    status_code = 200
    message = "Posts Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch posts!"
    elif len(valid_posts) == 0:
        status_code = 200
        message = "No posts found!"
        
    output = {
        "message": message,
        "data": {
            "result": valid_posts,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error":{} if error is None else {str(error):500}       
    }
    return output

# Get all posts sorted by date published
@router.get("/users/posts/get_sorted_by_date_published", response_model=list[schemas.Post])
def get_all_posts_sorted_by_date_published(skip: int = 0, limit: int = 10, db: Session = Depends(get_db),
                                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.get_all_posts_sorted_by_date_published(db, skip=skip, limit=limit)

# Get all posts sorted by date published
@router.get("/users/posts/get_paginated/sort_by_date_published")
def get_all_posts_paginated_and_sorted_by_date_published(page_num: int = 0, limit: int = 10,
                                                         db: Session = Depends(get_db),
                                                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    valid_posts, total_count, error = crud.get_validated_posts(db, page_num=page_num, limit=limit)
    status_code = 200
    message = "Posts Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch posts!"
    elif len(valid_posts) == 0:
        status_code = 200
        message = "No posts found!"
        
    output = {
        "message": message,
        "data": {
            "result": valid_posts,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error":{} if error is None else {str(error):500}       
    }
    return output

# Delete post
@router.delete("/users/posts/delete/{post_id}")
def delete_post(post_id: int, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_post = crud.delete_post(db,post_id=post_id)
    if not db_post:
        log_trace(logging.ERROR, f"Post not found")
        raise HTTPException(status_code=404, detail="Post not found")
    return db_post

# Like a post
@router.put("/users/posts/like/{post_id}", response_model=schemas.Post)
def like_post(post_like: schemas.PostLikeUnlike, db: Session = Depends(get_db),
              credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_post = db.query(models.Post).filter(models.Post.id == post_like.post_id).first()
    if db_post is None:
        log_trace(logging.ERROR, f"Post not found")
        raise HTTPException(status_code=404, detail="Post not found")
    
    likes = []
    for like in db_post.likes:
        likes.append(like)

    if not post_like.user_id in likes:
        log_trace(logging.INFO, f"Appending userid {post_like.user_id} to likes! {likes}")
        likes.append(post_like.user_id)
        db_post.likes = likes
        db.add(db_post)
        db.commit()
        db.refresh(db_post)
    else:
        log_trace(logging.INFO, f"User already liked this post!")
    return db_post


# Unlike a post
@router.put("/users/posts/unlike/{post_id}", response_model=schemas.Post)
def unlike_post(post_unlike: schemas.PostLikeUnlike, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_post = db.query(models.Post).filter(models.Post.id == post_unlike.post_id).first()
    if db_post is None:
        log_trace(logging.ERROR, f"Post not found")
        raise HTTPException(status_code=404, detail="Post not found")
    likes = []
    for like in db_post.likes:
        likes.append(like)
    if post_unlike.user_id in likes:
        log_trace(logging.INFO, f"{post_unlike.user_id} from likes! {likes}")
        likes.remove(post_unlike.user_id)
        db_post.likes = likes
        db.add(db_post)
        db.commit()
        db.refresh(db_post)
    else:
        log_trace(logging.INFO, f"User already unliked this post! {post_unlike.user_id}")
    return db_post

# Get all likes for a post
@router.get("/users/posts/likes/{post_id}", response_model=List[int])
def get_all_likes_for_post(post_id: int, db: Session = Depends(get_db),
                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_post = db.query(models.Post).filter(models.Post.id == post_id).first()
    if db_post is None:
        log_trace(logging.ERROR, f"Post not found")
        raise HTTPException(status_code=404, detail="Post not found")
    likes = []
    for like in db_post.likes:
        likes.append(like)
    return likes

# Add comment to a post
@router.put("/users/posts/comment/{post_id}", response_model=schemas.Comment)
def comment_post(post_comment: schemas.CommentCreate, db: Session = Depends(get_db),
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    if post_comment.likes is None:
        post_comment.likes = []
    db_comment = crud.create_comment(db=db, comment=post_comment)
    if not db_comment:
        log_trace(logging.ERROR, f"Comment create failed")
        raise HTTPException(status_code=400, detail="Comment create failed")
    return db_comment

# Get comments of a post
@router.get("/users/posts/comments/{post_id}")
def get_post_comments(post_id: int, db: Session = Depends(get_db),
                      credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_comments = crud.get_comments_of_post(db, post_id=post_id)
    return db_comments

# Get comments of a post with pagination
@router.get("/users/posts/comments/paginated/{post_id}")
def get_post_comments_paginated(post_id: int, page_num: int = 0, limit: int = 10,
                                db: Session = Depends(get_db),
                                credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    valid_comments = []
    invalid_records = 0
    total_count = 0
    try:
        [total_count, db_comments] = crud.get_comments_of_post_paginated(db,
                                                                         post_id=post_id,
                                                                         page_num=page_num,
                                                                         limit=limit)
        for db_comment in db_comments:
            try:
                likes_list = []
                if 'likes' in db_comment and db_comment['likes'] is not None and len(db_comment['likes']) > 0:
                    for like in db_comment['likes']:
                        likes_list.append(like)
                # Validate each comment entry with the Pydantic model
                comment = schemas.CommentResult(
                    id = db_comment['id'],
                    content = db_comment['content'],
                    date_published = db_comment['date_published'].isoformat(),
                    user_id = db_comment['user_id'],
                    post_id = db_comment['post_id'],
                    profile_pic_url=db_comment['profile_pic_url'] if 'profile_pic_url' in db_comment else None,
                    likes = likes_list,
                    username=db_comment['username'],
                )
                valid_comments.append(db_comment)
            except ValidationError as e:
                # Handle entries that do not pass validation
                invalid_records = invalid_records + 1
                log_trace(logging.ERROR, f"Invalid record {db_comment} error is {str(e)}")
                continue  # Skip invalid entries or log them as needed
    except Exception as e:
        log_trace(logging.ERROR, f"{str(e)}")
    
    total_count = total_count - invalid_records
    log_trace(logging.INFO, f"valid comments {valid_comments}")

    status_code = 200
    message = "Comments Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch comments!"
    elif len(valid_comments) == 0:
        status_code = 200
        message = "No comments found!"
        
    output = {
        "message": message,
        "data": {
            "result": valid_comments,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error":{} if error is None else {str(error):500}       
    }
    return output

# Delete comment
@router.delete("/users/posts/comments/delete/{comment_id}", response_model=schemas.Comment)
def delete_comment(comment_id: int, db: Session = Depends(get_db),
                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_comment = crud.delete_comment(db,comment_id=comment_id)
    if not db_comment:
        log_trace(logging.ERROR, f"Comment with id {comment_id} not found")
        raise HTTPException(status_code=404, detail="Comment not found")
    return db_comment

# Like a comment
@router.put("/users/posts/comments/like_unlike/{comment_id}", response_model=schemas.Comment)
def like_unlike_comment(comment_like: schemas.CommentLikeUnlike, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_comment = db.query(models.Comment).filter(models.Comment.id == comment_like.comment_id).first()
    if db_comment is None:
        log_trace(logging.ERROR, f"Comment with id {comment_like.comment_id} not found")
        raise HTTPException(status_code=404, detail="Comment not found")
    
    likes = []
    if comment_like.user_id in db_comment.likes:
        for like in db_comment.likes:
            if like != comment_like.user_id:
                likes.append(like)
            else:
                log_trace(logging.INFO, f"Removing userid {comment_like.user_id} from likes! {likes}")
    else:
        for like in db_comment.likes:
            likes.append(like)
        log_trace(logging.INFO, f"Appending userid {comment_like.user_id} to likes! {likes}")
        likes.append(comment_like.user_id)
    db_comment.likes = likes
    db.add(db_comment)
    db.commit()
    db.refresh(db_comment)
    return db_comment

# Unlike a comment
@router.put("/users/posts/comments/unlike/{comment_id}", response_model=schemas.Comment)
def unlike_comment(comment_id: int, comment_unlike: schemas.CommentLikeUnlike, db: Session = Depends(get_db),
                   credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_comment = db.query(models.Comment).filter(models.Comment.id == comment_unlike.comment_id).first()
    if db_comment is None:
        log_trace(logging.ERROR, f"Comment with id {comment_id} not found")
        raise HTTPException(status_code=404, detail="Comment not found")
    likes = []
    for like in db_comment.likes:
        likes.append(like)
    if comment_unlike.user_id in likes:
        log_trace(logging.INFO, f"Removing userid {comment_unlike.user_id} from likes! {likes}")
        likes.remove(comment_unlike.user_id)
        db_comment.likes = likes
        db.add(db_comment)
        db.commit()
        db.refresh(db_comment)
    else:
        log_trace(logging.INFO, f"User already unliked this comment! {comment_unlike.user_id}")
    return db_comment

@router.post("/check-profanity", response_model=dict)
def check_profanity(text: schemas.Text):
    prediction = str(predict([text.text])[0])
    return {'profanity': prediction}

########################################################################################
############################## general school ops ######################################
########################################################################################

@router.get("/get-states/", response_model=list[str])
def get_states(db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    states = crud.get_all_states(db)
    if not states:
        log_trace(logging.ERROR, f"States not found")
        raise HTTPException(status_code=404, detail="States not found")
    return states

@router.get("/get-cities-by-state/", response_model=list[str])
def get_cities_by_state(state: str, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    cities = crud.get_cities_by_state(db, state=state)
    if not cities:
        log_trace(logging.ERROR, f"Cities not found")
        raise HTTPException(status_code=404, detail="Cities not found")
    return cities

@router.get("/get-cities-by-state-hint/", response_model=list[str])
def get_cities_by_state_starting_with(state: str, starts_with: str = "", page: int = 1, per_page: int = 10, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    cities = crud.get_cities_by_state_starting_with(db, state=state, starts_with=starts_with, page=page, per_page=per_page)
    if not cities:
        raise HTTPException(status_code=404, detail="Cities not found")
    return cities


@router.get("/get-schools-state/", response_model=list[schemas.School])
def get_schools_by_state(
    state: str,
    starts_with: str = "",
    page: int = 1,
    per_page: int = 10,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    schools = crud.get_schools_by_state(db, state=state, starts_with=starts_with, page=page, per_page=per_page)
    if not schools:
        log_trace(logging.ERROR, f"Schools not found")
        raise HTTPException(status_code=404, detail="Schools not found")
    return schools

@router.get("/get-all-schools-city-state/", response_model=list[schemas.School])
def get_all_schools_city_state(city: str, state: str, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    schools = crud.get_all_schools_by_city_state(db, city=city, state=state)
    if not schools:
        log_trace(logging.ERROR, f"Schools not found")
        raise HTTPException(status_code=404, detail="Schools not found")
    return schools

########################################################################################
############################## News Ops ################################################

@router.post("/news/create", response_model=schemas.News)
def create_news(news: schemas.NewsCreate, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_news = crud.create_news_post(db=db, news=news)

    if not db_news:
        log_trace(logging.ERROR, f"News create failed")
        raise HTTPException(status_code=400, detail="News create failed")
    return db_news

@router.delete("/news/delete/{news_title}")
def delete_news(news_title: str, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_news = crud.delete_news_post(db, news_title=news_title)
    if not db_news:
        log_trace(logging.ERROR, f"News with title {news_title} not found")
        raise HTTPException(status_code=404, detail="News not found")
    return db_news

@router.get("/news/get/{news_title}", response_model=schemas.News)
def get_news(news_title: str, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
        db_news = crud.get_news_post(db,news=news_title)
        if not db_news:
            log_trace(logging.ERROR, f"News with title {news_title} not found")
            raise HTTPException(status_code=404, detail="News not found")
        return db_news

@router.get("/news/get/id/{news_id}", response_model=schemas.News)
def get_news_by_id(news_id: int, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
        db_news = crud.get_news_post_by_id(db,news_id=news_id)
        if not db_news:
            log_trace(logging.ERROR, f"News with id {news_id} not found")
            raise HTTPException(status_code=404, detail="News not found")
        return db_news


# Like / Unlike a new post
@router.put("/news/like_unlike/{news_id}", response_model=schemas.News)
def like_unlike_news_post(
        news_like: schemas.NewsLikeUnlike,
        db: Session = Depends(get_db),
        credentials: JWTAuthorizationCredentials = Depends(auth),
):
    db_news = NewsHandler().get_post(db, news_like.news_id)

    db_like = NewsHandler().get_news_like(db, news_like.news_id, news_like.user_id)
    if db_like:
        db.delete(db_like)
    else:
        new_like = models.NewsPostLike(post_id=db_news.id, user_id=news_like.user_id)
        db.add(new_like)

    db.commit()
    db.refresh(db_news)
    return db_news


# Get all likes for a news post
@router.get("/news/likes/{news_id}", response_model=List[schemas.NewsPostLike])
def get_all_likes_for_news_post(
        news_id: int,
        db: Session = Depends(get_db),
        credentials: JWTAuthorizationCredentials = Depends(auth),
):
    news = NewsHandler().get_post(db, news_id)
    return news.likes


@router.post("/news/create_comment", response_model=schemas.NewsCommentResponse)
def create_news_comment(comment: schemas.NewsCommentCreate, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_comment = NewsHandler().create_news_comment(db=db, news_comment=comment)
    return db_comment


@router.get("/news/get_comments/{news_id}", response_model=list[schemas.NewsCommentResponse])
def get_news_comments(news_id: int, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_comments = NewsHandler().get_news_comments(db, news_id=news_id)
    return db_comments


@router.delete("/news/delete_comment/{comment_id}")
def delete_news_comment(comment_id: int, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_comment = crud.delete_news_comment(db, news_comment_id=comment_id)
    if not db_comment:
        log_trace(logging.ERROR, f"Comment with id {comment_id} not found")
        raise HTTPException(status_code=404, detail="Comment not found")
    return db_comment


@router.put("/news/comments/like_unlike", response_model=schemas.NewsCommentResponse)
def like_unlike_news_comment(
        comment_like: schemas.NewsCommentLikeUnlike,
        db: Session = Depends(get_db),
        credentials: JWTAuthorizationCredentials = Depends(auth),
):
    news_handler = NewsHandler()
    db_news_comment = news_handler.get_news_comment(db, comment_like.comment_id)

    db_news_comment_like = news_handler.get_news_comment_like(db, comment_like.comment_id, comment_like.user_id)
    if db_news_comment_like:
        db.delete(db_news_comment_like)
    else:
        new_comment_like = models.NewsCommentLike(comment_id=db_news_comment.id, user_id=comment_like.user_id)
        db.add(new_comment_like)

    db.commit()
    db.refresh(db_news_comment)
    return db_news_comment


@router.delete("/news/delete_outdated/{date}")
def delete_news_outdated(db: Session = Depends(get_db), date: str = "2021-01-01T00:00:00",):
    db_news = crud.delete_outdated_news(db, date)
    return db_news

@router.get("/news/get_news_paginated/")
def get_all_news_paginated(page_num: int = 0, limit: int = 10, db: Session = Depends(get_db),
                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    valid_posts = []
    invalid_records = 0
    total_count = 0
    
    try:
        [total_count, db_news] = crud.get_news_paginated(db, page_num=page_num, limit=limit)
        for db_news_item in db_news:
            try:
                # Validate each post entry with the Pydantic model
                news_item = schemas.NewsResult(
                    id =  db_news_item['id'], 
                    news_title = db_news_item['news_title'],
                    news_content_url = db_news_item['news_content_url'],
                    news_published_date= db_news_item['news_published_date'],
                    likes = [like.__dict__ for like in db_news_item['likes']],
                    news_keywords= db_news_item['news_keywords'],
                    comment_count = db_news_item['comment_count'],
                )
                valid_posts.append(news_item)

            except ValidationError as e:
                log_trace(logging.ERROR, f"{str(e)}")
                # Handle entries that do not pass validation
                invalid_records = invalid_records + 1
                continue  # Skip invalid entries or log them as needed
    except Exception as e:
        error = e
        log_trace(logging.ERROR, f"{str(e)}")
    
    total_count = total_count - invalid_records
    status_code = 200
    message = "News Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch news!"
    elif len(valid_posts) == 0:
        status_code = 200
        message = "No news found!"

    output = {
        "message": message,
        "data": {
            "result": valid_posts,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error":{} if error is None else {str(error):500}       
    }
    return output

@router.get("/feed/get_news_and_posts_paginated")
def get_news_and_posts_paginated(page_num: int = 0, limit: int = 10, db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    news_limit = round(20*limit/100) # 20% of records
    posts_limit = limit - news_limit
    combined_list = []
    log_trace(logging.INFO, f"news limit {news_limit} posts limit {posts_limit}")
    message = ""
    status_code = 200
    valid_posts, total_count, error = crud.get_validated_posts(db, page_num=page_num, limit=posts_limit)
    log_trace(logging.INFO, f"valid: {len(valid_posts)} total: {total_count}")
    if error is not None:
        status_code = 500
        message = "Failed to fetch posts!"
    elif len(valid_posts) == 0:
        status_code = 200
        message = "No posts found!"
    else:
        log_trace(logging.INFO, "Fetching news")
        valid_news, news_count, news_error = crud.get_validated_news(db, page_num=page_num, limit=news_limit)
        log_trace(logging.INFO, f"valid: {len(valid_news)} total: {news_count}")
        if news_error is None:
            combined_list = valid_posts + valid_news
            # Shuffle the combined list
            # random.shuffle(combined_list)

            total_count = total_count + news_count
            log_trace(logging.INFO, f"total {total_count}")
    
    output = {
        "message": message,
        "data": {
            "result": combined_list, # valid_posts
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error":{} if error is None else {str(error):500}       
    }

    return output

@router.get("/news/get_num_news_posts")
def get_num_news_posts(db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.get_num_news_posts(db)

# @router.get("/news/get_best_news_posts/{uid}")
# def get_best_news_posts(db: Session = Depends(get_db),
#                         uid: int = 0,
#                         credentials: JWTAuthorizationCredentials = Depends(auth)):
#     return crud.get_best_news_posts(db, uid)

######################################################################
# Support APIs
######################################################################
# Report a post
@router.post("/users/posts/report/post_id/{post_id}")
def report_post(post_id: int, user_id: int, reason: str, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Send an email to support@go-dabbl.ai
    response = crud.send_support_email(db, post_id=post_id, user_id=user_id, message=reason)
    return response

# Request support
@router.post("/users/request_support/user_id/{user_id}")
def report_post(user_id: int, message: str, db: Session = Depends(get_db),
                credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Send an email to support@go-dabbl.ai
    response = crud.send_support_email(db, post_id=None, user_id=user_id, message=message)
    return response

######################################################################
# Counselor APIs
######################################################################

@router.get("/users/counselors/get/{user_id}")
def get_counselor_by_uid(user_id:int, db: Session = Depends(get_db),
                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_counselor = crud.get_counselor_by_uid(db,uid=user_id)
    if db_counselor is None:
        return None
    return db_counselor

@router.get("/users/counselors/get/id/{counselor_id}")
def get_counselor(counselor_id: int, db: Session = Depends(get_db),
                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    counselor = crud.get_counselor_by_id(db, counselor_id=counselor_id)
    return counselor

# Connect with students
@router.post("/counselor/connect-with-students")
def counselor_connect_with_students(request: Request,
                                    connect_req: schemas.CounselorStudentConnectRequest,
                                    db: Session = Depends(get_db),
                                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Host that saw this request - this should give us the hostname
    host = os.getenv("WEB_APP_URL")     
    if not host:
        log_trace(logging.ERROR, f"Unable to raise connect request")
        raise HTTPException(status_code=404, detail="Unknown error initiating connect request. Please try again later.")

    # Request ID (if available)
    request_id = request.headers.get("X-Request-ID")
    if not request_id:
        request_id = str(uuid.uuid4())

    # Scheme used (http/https)
    # url_scheme = request.url.scheme

    # To fix invalid schemes such as https://https://, use regular expressions to clean it
    # url_scheme = re.sub(r'^(https?://)+(https?://)', r'\2', request.url.scheme)
    return crud.send_counselor_connect_requests(db, host, request_id, connect_req)

@router.delete("/counselor/delete_connect_request/{conn_req_id}")
def counselor_delete_connect_request(conn_req_id: int,
                                     db: Session = Depends(get_db),
                                     credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_conn_req = db.query(models.CounselorStudentsConnection).filter(models.CounselorStudentsConnection.id == conn_req_id).first()
    if not db_conn_req:
        raise HTTPException(status_code=404, detail="Connection request not found")
    
    db.delete(db_conn_req)
    db.commit()
    return db_conn_req

@router.get("/counselor/get-connect-with-students-status/{counselor_id}")
def get_counselor_connect_with_students_status(counselor_id: int, db: Session = Depends(get_db),
                                               credentials: JWTAuthorizationCredentials = Depends(auth)):

    counselor_student_requests_details = []
    counselor_student_requests = crud.get_counselor_connect_with_students_all_request_status(db, counselor_id)

    for req in counselor_student_requests:
        req_details = req
        student = crud.get_student_by_username_or_email(db=db, username=None, email=req_details['student_email'])
        user = crud.get_user(db, student.user_id)
        req_details.update({k: v for k, v in user.__dict__.items() if k != 'id'})
        req_details['career_status'] = get_student_career_status(db, student_id=student.id)
        req_details['college_status'] = get_student_college_status(db, student_id=student.id)
        req_details['current_grade'] = req['current_grade']
        counselor_student_requests_details.append(req_details)

    return counselor_student_requests_details

@router.get("/counselor/get-connection-request-by-id/{counselor_connection_request_id}")
def get_counselor_connection_request_by_id(counselor_connection_request_id: int,
                                           db: Session = Depends(get_db),
                                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    req = crud.get_counselor_connection_request_by_id(db, counselor_connection_request_id)
    if req:
        return req.__dict__
    return {}

@router.get("/counselor/get-connect-with-student-status")
def get_counselor_connect_with_student_status(counselor_id: int, student_email: str, db: Session = Depends(get_db),
                                               credentials: JWTAuthorizationCredentials = Depends(auth)):

    counselor_student_requests = crud.get_counselor_connect_with_student_request_status(db, counselor_id, student_email)
    req_details = counselor_student_requests.__dict__
    student = crud.get_student_by_username_or_email(db=db, username=None, email=req_details["student_email"])
    user = crud.get_user(db, student.user_id)
    req_details.update({k: v for k, v in user.__dict__.items() if k != 'id'})
    req_details['career_status'] = get_student_career_status(db, student_id=student.id)
    req_details['college_status'] = get_student_college_status(db, student_id=student.id)

    return req_details


# Get student saved colleges
@router.get("/counselor/get-student-saved-colleges/cid/{counselor_id}/student-id/{student_id}")
def counselor_get_student_saved_colleges(counselor_id: int, student_id: int,
                                         db: Session = Depends(get_db),
                                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    saved_colleges = crud.get_student_target_schools(db, student_id=student_id)
    return saved_colleges

# Get student saved careers
@router.get("/counselor/get-student-saved-careers/cid/{counselor_id}/student-id/{student_id}",
            response_model = List[schemas.StudentCareer])
def counselor_get_student_saved_careers(counselor_id: int, student_id: int,
                                        db: Session = Depends(get_db),
                                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    saved_careers = crud.get_student_careers(db, student_id=student_id)
    return saved_careers

def get_student_college_status(db: Session, student_id: int):
    saved_colleges = crud.get_student_target_schools(db, student_id=student_id)
    if saved_colleges and len(saved_colleges) > 0:
        status = "Exploring"
    else:
        status = "Not started"
    return status

# Get student status wrt colleges
@router.get("/counselor/get-student-colleges-status/cid/{counselor_id}/student-id/{student_id}", response_model = str)
def counselor_get_student_colleges_status(counselor_id: int, student_id: int,
                                        db: Session = Depends(get_db),
                                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    return get_student_college_status(db, student_id=student_id)

def get_student_career_status(db: Session, student_id: int):
    saved_careers = crud.get_student_careers(db, student_id=student_id)
    if saved_careers:
        status = "Exploring"
    else:
        status = "Not started"
    return status

# Get student status wrt careers
@router.get("/counselor/get-student-careers-status/cid/{counselor_id}/student-id/{student_id}", response_model = str)
def counselor_get_student_careers_status(counselor_id: int, student_id: int,
                                        db: Session = Depends(get_db),
                                        credentials: JWTAuthorizationCredentials = Depends(auth)):
    return get_student_career_status(db, student_id=student_id)

# Get a list of all student users for the counselor
@router.get("/counselor/get-student-users/cid/{counselor_id}")
def counselor_get_students(counselor_id: int, db: Session = Depends(get_db),
                           credentials: JWTAuthorizationCredentials = Depends(auth)):
    users = []
    counselor_students = crud.get_all_students_with_counselor(db, counselor_id = counselor_id)
    if counselor_students:
        # Get the user records
        for student in counselor_students:
            db_student = crud.get_student(db, student_id=student.student_id)
            db_user = crud.get_user(db, db_student.user_id)
            user = db_user.__dict__
            #user['student_id'] = student.student_id
            # Augment with career and college exploration status
            user['career_status'] = get_student_career_status(db, student_id=student.student_id)
            user['college_status'] = get_student_college_status(db, student_id=student.student_id)
            users.append(user)
    return users

# Remove a student from the counselor's list
@router.delete("/counselor/remove-student/cid/{counselor_id}/student-id/{student_id}")
def counselor_remove_student(counselor_id: int, student_id: int, db: Session = Depends(get_db),
                             credentials: JWTAuthorizationCredentials = Depends(auth)):
    response = crud.remove_student_from_counselor(db, counselor_id=counselor_id, student_id=student_id)
    return

@router.get("/counselors/get") # Get a list of counselors
def get_all_counselors(db: Session = Depends(get_db),
                       credentials: JWTAuthorizationCredentials = Depends(auth)):
    valid_counselors = []
    try:
        counselors = crud.get_all_counselors(db)
        # Validate the list of counselors
        valid_counselors = validate_user_records(db, counselors)
    except Exception as e:
        log_trace(logging.ERROR, f"Failed to fetch counselors!")
        return wrap_response(data=valid_counselors, message="Failed to fetch counselors!", code=500,
                             error={"exception": "InternalServerError", "message": str(e)})    
    return valid_counselors

@router.get("/counselors/get/paginated/") # Get a list of counselors
def get_all_counselors_paginated(page_num: int = 1, limit: int = 10, db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    valid_counselors=[]
    try:
        total_count, counselors = crud.get_all_counselors_paginated(db, page_num=page_num, limit=limit)
        # Validate the list of counselors
        valid_counselors = validate_user_records(db, counselors)
    except Exception as e:
        log_trace(logging.ERROR, f"Failed to fetch counselors!")
        return wrap_response(data=valid_counselors, message="Failed to fetch counselors!", code=500,
                             error={"exception": "InternalServerError", "message":str(e)})
    
    total_count = len(valid_counselors)
    # print(valid_users)
    message = "Counselors Fetched!"
    if total_count == 0:
        # status_code = 200
        message = "No counselors found!"
        log_trace(logging.ERROR, f"{message}")
        return wrap_response(data=valid_counselors, message="No counselors found!", code=200)
    
    return wrap_response(data=valid_counselors,message=message,code=200,limit=limit,page_num=page_num,total_count=total_count)
  
 ######################################################################
# Jobs APIs
######################################################################

@router.post("/jobs/create")
def create_job(job: schemas.JobCreate, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_job = models.Job(**job.model_dump())
    db.add(db_job)
    db.commit()
    db.refresh(db_job)
    return db_job

@router.get("/jobs/get")
def get_jobs(page_num: int = Query(1, ge=1), limit: int = Query(10, le=20), db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    error = None
    valid_jobs = []
    total_count = 0
    
    try:
        db_jobs, total_count = crud.get_jobs(db, page_num=page_num-1, limit=limit)  # Adjust page_num to be zero-based
        valid_jobs = db_jobs
    except Exception as e:
        error = e
        print(f"Error fetching jobs: {e}")
    
    status_code = 200
    message = "Jobs Fetched!"
    if error is not None:
        status_code = 500
        message = "Failed to fetch jobs!"
    elif len(valid_jobs) == 0:
        status_code = 200
        message = "No jobs found!"
        
    output = {
        "message": message,
        "data": {
            "result": valid_jobs,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error": {} if error is None else {str(error): 500}
    }

    return output

@router.put("/jobs/update/{job_id}", response_model=schemas.Job)
def update_job(job_id: int, job: schemas.JobUpdate, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_job = crud.update_job(db, job_id=job_id, updates=job)
    if not db_job:
        raise HTTPException(status_code=404, detail="Job not found")
    return db_job

@router.delete("/jobs/delete/{job_id}", response_model=schemas.Job)
def delete_job(job_id: int, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not db_job:
        raise HTTPException(status_code=404, detail="Job not found")
    
    db.delete(db_job)
    db.commit()
    return db_job

@router.get("/jobs/findid", response_model=Optional[int])
def find_job_by_title_and_org(
    title: str = Query(..., description="The title of the job"),
    organization: str = Query(..., description="The organization offering the job"),
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    job = crud.get_job_by_title_and_org(db, title, organization)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job.id

@router.get("/jobs/search", response_model=List[schemas.Job])
def search_jobs(
    filter_by: str = Query(..., description="The field to filter by (e.g., 'title', 'organization', 'area', etc.)"),
    query: str = Query(..., description="The search query"),
    page_num: int = Query(1, ge=1),
    limit: int = Query(10, le=20),
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    if filter_by not in models.Job.__table__.columns.keys():
        raise HTTPException(status_code=400, detail=f"Invalid filter field: {filter_by}")

    jobs = crud.search_jobs(db, filter_by=filter_by, query=query, page_num=page_num, limit=limit)
    if not jobs:
        raise HTTPException(status_code=404, detail="No jobs found")
    return jobs

@router.post("/jobs/bookmark", response_model=schemas.Bookmark)
def bookmark_job(bookmark: schemas.BookmarkCreate, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    return crud.create_bookmark(db=db, bookmark=bookmark)

@router.get("/users/{user_id}/bookmarks")
def get_user_bookmarked_jobs(user_id: int, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20),
                             db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    [total_count, bookmarks] = crud.get_bookmarked_jobs(db, user_id=user_id, page_num=page_num, limit=limit)
    job_ids = [bookmark.job_id for bookmark in bookmarks]
    jobs = db.query(models.Job).filter(models.Job.id.in_(job_ids)).all()

    status_code = 200
    message = "Jobs Fetched!"
    if len(jobs) == 0:
        message = "No jobs found!"

    output = {
        "message": message,
        "data": {
            "result": jobs,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
        },
        "statusCode": status_code,
        "error": {}
    }

    return output


@router.delete("/jobs/bookmark", response_model=schemas.Bookmark)
def remove_bookmark(user_id: int, job_id: int, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    bookmark = crud.delete_bookmark(db, user_id=user_id, job_id=job_id)
    if not bookmark:
        raise HTTPException(status_code=404, detail="Bookmark not found")
    return bookmark

@router.get("/db/jobs/trending", response_model=List[schemas.Job])
def get_most_bookmarked_jobs(limit: int = 10, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    results = (
        db.query(models.Job)
        .join(models.Bookmark, models.Job.id == models.Bookmark.job_id)
        .group_by(models.Job.id)
        .order_by(func.count(models.Bookmark.job_id).desc())
        .limit(limit)
        .all()
    )
    return results

@router.put("/jobs/update_priority", response_model=schemas.Job)
def update_job_priority(
    job_id: int = Query(..., description="The ID of the job"),
    is_priority: bool = Query(..., description="The new priority status"),
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    job = crud.update_job_priority(db, job_id, is_priority)
    if not job:
        raise HTTPException(status_code=404, detail="Job not found")
    return job


########################################################################################
############################## Notifications APIs ######################################
########################################################################################


@router.post("/notifications/create")
def create_notification(
    notification: schemas.NotificationCreate,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    return NotificationHandler().create_notification(db=db, notification=notification)

@router.get("/notifications/read/{user_id}")
def read_notifications(
    user_id: int,
    page_num: int = Query(1, ge=1),
    limit: int = Query(10, le=20),
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    result = []
    total_count, num_unread, notifications = NotificationHandler().get_notifications(db, user_id=user_id, page_num=page_num, limit=limit)

    status_code = 200
    message = "Notifications Fetched!"
    if total_count == 0:
        message = "No notifications found!"
    output = {
        "message": message,
        "data": {
            "result": notifications,
            "pageNo": page_num,
            "limit": limit,
            "numUnread": num_unread,
            "totalData": total_count,
            },
        "statusCode": status_code,
        "error": {}
    }

    return output


@router.put("/notifications/update/{notification_id}", response_model=schemas.Notification)
def update_notification(
    notification_id: int,
    notification: schemas.NotificationUpdate,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    db_notification = NotificationHandler().update_notification(db, notification_id=notification_id, update_data=notification)
    if not db_notification:
        raise HTTPException(status_code=404, detail="Notification not found")
    return db_notification


@router.delete("/notifications/delete/{notification_id}", response_model=schemas.Notification)
def delete_notification(
    notification_id: int,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    notification_handler = NotificationHandler()
    db_notification = notification_handler.get_notification(db, notification_id)

    if not db_notification:
        raise HTTPException(status_code=404, detail="Notification not found")

    notification_handler.delete_notification(db, notification_id)
    return db_notification

@router.get("/users/students/career_intersections/{student_career_id}")
def get_student_career_intersections(student_career_id: int, db: Session = Depends(get_db),
                                     credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Verify the student career id
    student_career = crud.get_student_career_by_id(db, student_career_id=student_career_id)
    if student_career is None:
        log_trace(logging.ERROR, f"Invalid student career id: {student_career_id}")
        return None
    intersections = crud.get_student_career_intersections(db, student_career_id)
    return intersections

@router.get("/users/students/career_intersections_paginated/{student_career_id}")
def get_student_career_intersections_paginated(student_career_id: int, 
                                               page_num: int = Query(1, ge=1),
                                               limit: int = Query(10, le=20),
                                               db: Session = Depends(get_db),
                                               credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Verify the student career id
    student_career = crud.get_student_career_by_id(db, student_career_id=student_career_id)
    if student_career is None:
        log_trace(logging.ERROR, f"Invalid student career id: {student_career_id}")
        return None
    total_count, intersections = crud.get_student_career_intersections_paginated(db, student_career_id,
                                                                                 page_num=page_num, limit=limit)
    
    status_code = 200
    message = "Student saved career intersections fetched!"
    if total_count == 0:
        message = "No common saved careers found!"
    output = {
        "message": message,
        "data": {
            "result": intersections,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
            },
        "statusCode": status_code,
        "error": {}
    }

    return output

@router.get("/users/students/target_school_intersections/{student_target_school_id}")
def get_student_target_school_intersections(student_target_school_id: int, db: Session = Depends(get_db),
                                            credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Verify the student_target_school id
    student_target_school = crud.get_student_target_school_by_id(db, student_target_school_id=student_target_school_id)
    if student_target_school is None:
        log_trace(logging.ERROR, f"Invalid student target school id: {student_target_school_id}")
        return None
    intersections = crud.get_student_target_school_intersections(db, student_target_school_id)
    return intersections

@router.get("/users/students/target_school_intersections/user_id/{user_id}")
def get_student_target_school_intersections(user_id: int, db: Session = Depends(get_db),
                                            credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Verify the user id
    db_user = crud.get_user(db, user_id=user_id)
    if db_user is None:
        log_trace(logging.ERROR, f"Invalid user id: {user_id}")
        return None
    intersections = crud.get_student_target_school_intersections_by_user_id(db, user_id)
    return intersections

@router.get("/users/students/target_school_intersections_paginated/{student_target_school_id}")
def get_student_target_school_intersections_paginated(student_target_school_id: int, 
                                                      page_num: int = Query(1, ge=1),
                                                      limit: int = Query(10, le=20),
                                                      db: Session = Depends(get_db),
                                                      credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Verify the student target school id
    student_target_school = crud.get_student_target_school_by_id(db, student_target_school_id=student_target_school_id)
    if student_target_school is None:
        log_trace(logging.ERROR, f"Invalid student target school id: {student_target_school_id}")
        return None
    total_count, intersections = crud.get_student_career_intersections_paginated(db, student_target_school_id,
                                                                                 page_num=page_num, limit=limit)
    
    status_code = 200
    message = "Student saved college intersections fetched!"
    if total_count == 0:
        message = "No common saved colleges found!"
    output = {
        "message": message,
        "data": {
            "result": intersections,
            "pageNo": page_num,
            "limit": limit,
            "totalData": total_count,
            },
        "statusCode": status_code,
        "error": {}
    }

    return output

@router.get("/users/students/target_school_intersections/college_id/{college_id}/{user_id}")
def get_student_target_school_intersections_by_collegeid(college_id: int, user_id: int, db: Session = Depends(get_db),
                                                         credentials: JWTAuthorizationCredentials = Depends(auth)):
    log_trace(logging.INFO, f"Check for friends of user {user_id} who are also looking at the same college {college_id}")
    # Verify the college id
    db_college = crud.get_target_school(db, target_school_id=college_id)
    if db_college is None:
        log_trace(logging.ERROR, f"Invalid college id: {college_id}")
        return None
    
    intersections = crud.get_student_target_school_intersections_by_college_id(db, college_id=college_id, user_id=user_id)
    return intersections

@router.post("/send_notification/{user_id}")
def send_notification(user_id: int, title: str, body: str, data: Optional[dict] = None, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    notification_handler = NotificationHandler()
    response = notification_handler.send_notification_to_user(user_id=user_id, title=title, body=body, data=data, db=db)
    return response

@router.post("/notifications/schedule/{type}")
def schedule_notifications_endpoint(
    type: str,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    normalized_type = type.lower()

    if normalized_type not in ["general", "fun_fact"]:
        raise HTTPException(status_code=400, detail="Invalid notification type. Valid types are 'general' and 'fun_fact'.")
    
    notification_handler = NotificationHandler()

    result = notification_handler.schedule_notifications(db=db, type=normalized_type)
    if "error" in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result

@router.post("/notifications/send_scheduled")
def send_scheduled_notifications_endpoint(
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    notification_handler = NotificationHandler()
    result = notification_handler.send_scheduled_notifications(db=db)
    return result



# -------------------- Notification Template CRUD --------------------

@router.post("/notification_templates", response_model=schemas.NotificationTemplate)
def create_notification_template(
    template: schemas.NotificationTemplateCreate,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    """
    Create a new notification template.
    """
    notification_handler = NotificationHandler()
    result = notification_handler.create_notification_template(db=db, template=template)
    if result is None:
        raise HTTPException(status_code=400, detail="Failed to create notification template.")
    return result


@router.get("/notification_templates/{template_id}", response_model=schemas.NotificationTemplate)
def get_notification_template(
    template_id: int,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    """
    Get a specific notification template by ID.
    """
    notification_handler = NotificationHandler()
    template = notification_handler.get_notification_template(db=db, template_id=template_id)
    if not template:
        raise HTTPException(status_code=404, detail="Notification template not found.")
    return template


@router.get("/all_notification_templates", response_model=list[schemas.NotificationTemplate])
def get_all_notification_templates(
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    """
    Get all notification templates, active or inactive.
    """
    notification_handler = NotificationHandler()
    templates = notification_handler.get_all_notification_templates(db=db)
    if not templates:
        raise HTTPException(status_code=404, detail="No notification templates found.")
    return templates

@router.get("/notification_templates", response_model=list[schemas.NotificationTemplate])
def get_active_notification_templates(
    type: str,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    """
    Get all active notification templates by type (e.g., 'general', 'fun_fact').
    """
    notification_handler = NotificationHandler()
    templates = notification_handler.get_active_notification_templates(db=db, type=type)
    if not templates:
        raise HTTPException(status_code=404, detail="No active notification templates found.")
    return templates


@router.put("/notification_templates/{template_id}", response_model=schemas.NotificationTemplate)
def update_notification_template(
    template_id: int,
    update_data: schemas.NotificationTemplateUpdate,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    """
    Update an existing notification template.
    """
    notification_handler = NotificationHandler()
    updated_template = notification_handler.update_notification_template(db=db, template_id=template_id, update_data=update_data)
    if not updated_template:
        raise HTTPException(status_code=404, detail="Notification template not found or failed to update.")
    return updated_template


@router.delete("/notification_templates/{template_id}", response_model=schemas.NotificationTemplate)
def delete_notification_template(
    template_id: int,
    db: Session = Depends(get_db),
    credentials: JWTAuthorizationCredentials = Depends(auth)
):
    """
    Delete a notification template by ID.
    """
    notification_handler = NotificationHandler()
    deleted_template = notification_handler.delete_notification_template(db=db, template_id=template_id)
    if not deleted_template:
        raise HTTPException(status_code=404, detail="Notification template not found or failed to delete.")
    return deleted_template

# Add endpoints for essay review
@router.post("/users/students/essay_review/add/")
def create_essay_review(essay_review: schemas.EssayReviewBase, db: Session = Depends(get_db), credentials: JWTAuthorizationCredentials = Depends(auth)):
    log_trace(logging.INFO, f"Creating essay review for student {essay_review.user_id}")
    db_essay_review = models.EssayReview(**essay_review.model_dump())
    db.add(db_essay_review)
    db.commit()
    db.refresh(db_essay_review)
    return db_essay_review

@router.post("/users/students/essay_review/delete/{essay_review_id}")
def delete_essay_review(essay_review_id: int, db: Session = Depends(get_db),
                        credentials: JWTAuthorizationCredentials = Depends(auth),
                        identity_token: str = Header(None)):
    db_essay_review = db.query(models.EssayReview).filter(models.EssayReview.id == essay_review_id).first()
    if not db_essay_review:
        raise HTTPException(status_code=404, detail="Essay review not found")
    
    # delete the essay review, first delete the file in S3
    # then delete the record in the database
    try:
        deleted = s3_utils.delete_s3_file(filename=db_essay_review.essay_review_s3_url, id_token=identity_token, object_type="essay_review")
    except Exception as e:
        log_trace(logging.ERROR, f"Error deleting essay review: {str(e)}")
        # raise Exception("Failed to delete the essay review from the S3 bucket.")
        output = {
            "message": "Error deleting essay review!",
            "data": {},
            "statusCode": 500,
            "error": {str(e): 500}
        }
        return output
    
    if not deleted:
        log_trace(logging.ERROR, f"Failed to delete essay review file {db_essay_review.essay_review_s3_url}")
        output = {
            "message": "Error deleting essay review!",
            "data": {},
            "statusCode": 500,
            "error": {"Unknown error deleting the file from S3": 500}
        }
        return output
    
    db.delete(db_essay_review)
    db.commit()
    output = {
        "message": "Essay review deleted!",
        "data": {},
        "statusCode": 200,
        "error": {}
    }
    return output

@router.get("/users/students/essay_review/{essay_review_id}")
def get_essay_review(essay_review_id: int, db: Session = Depends(get_db),
                     credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_essay_review = db.query(models.EssayReview).filter(models.EssayReview.id == essay_review_id).first()
    if not db_essay_review:
        raise HTTPException(status_code=404, detail="Essay review not found")
    return db_essay_review

@router.get("/users/students/essay_review/user_id/{user_id}")
def get_essay_reviews(user_id: int, db: Session = Depends(get_db),
                      credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Get reviews order by date_reviewed
    db_essay_reviews = db.query(models.EssayReview)\
        .filter(models.EssayReview.user_id == user_id).order_by(models.EssayReview.date_reviewed.desc()).all()
    return db_essay_reviews

# Letters of recommendation
@router.post("/users/counselors/letter_of_recommendation/add/{counselor_id}")
def create_letter_of_recommendation(counselor_id: int, lor: schemas.LorBase, db: Session = Depends(get_db),
                                    credentials: JWTAuthorizationCredentials = Depends(auth)):
    log_trace(logging.INFO, f"Creating letter of recommendation for student {lor.user_id}")
    try:
        db_lor = models.LetterOfRecommendation(**lor.model_dump())
        db.add(db_lor)
        db.commit()
        db.refresh(db_lor)
        return db_lor
    except Exception as e:
        log_trace(logging.ERROR, f"Failed to create letter of recommendation: {str(e)}")
        return None

@router.delete("/users/counselors/letter_of_recommendation/delete/{counselor_id}/{lor_id}")
def delete_letter_of_recommendation(counselor_id: int, lor_id: int, db: Session = Depends(get_db),
                                    credentials: JWTAuthorizationCredentials = Depends(auth),
                                    identity_token: str = Header(None)):
    db_lor = db.query(models.LetterOfRecommendation).filter(models.LetterOfRecommendation.id == lor_id).first()
    if not db_lor:
        raise HTTPException(status_code=404, detail="Letter of recommendation not found")
    
    # delete the letter of recommendation, first delete the file in S3
    # then delete the record in the database
    try:
        log_trace(logging.INFO, f"LoR file is {db_lor.letter_of_recommendation_s3_url}")
        deleted = s3_utils.delete_s3_file(db_lor.letter_of_recommendation_s3_url, identity_token, "essay_review")
    except Exception as e:
        log_trace(logging.ERROR, f"Error deleting LoR: {str(e)}")
        # raise Exception("Failed to delete the letter of recommendation from the S3 bucket.")
        output = {
            "message": "Error deleting letter of recommendation!",
            "data": {},
            "statusCode": 500,
            "error": {str(e): 500}
        }
        return output

    if not deleted:
        log_trace(logging.ERROR, f"Failed to delete letter of recommendation file {db_lor.letter_of_recommendation_s3_url}")
        output = {
            "message": "Error deleting letter of recommendation!",
            "data": {},
            "statusCode": 500,
            "error": {"Unknown error deleting letter of recommendation from S3": 500}
        }
        return output
    
    db.delete(db_lor)
    db.commit()
    output = {
        "message": "Letter of recommendation deleted!",
        "data": {},
        "statusCode": 200,
        "error": {}
    }
    return output


@router.get("/users/counselors/letter_of_recommendation/{counselor_id}/{lor_id}")
def get_letter_of_recommendation(counselor_id: int, lor_id: int, db: Session = Depends(get_db),
                                 credentials: JWTAuthorizationCredentials = Depends(auth)):
    db_lor = db.query(models.LetterOfRecommendation).filter(models.LetterOfRecommendation.id == lor_id).first()
    if not db_lor:
        raise HTTPException(status_code=404, detail="Letter of recommendation not found")
    return db_lor

@router.get("/users/counselors/letter_of_recommendation/{counselor_id}/user_id/{user_id}")
def get_letter_of_recommendations(counselor_id: int, user_id: int, db: Session = Depends(get_db),
                                  credentials: JWTAuthorizationCredentials = Depends(auth)):
    # Get LoRs order by date_created    
    db_lors = db.query(models.LetterOfRecommendation).filter(and_(models.LetterOfRecommendation.user_id == user_id,
                                                                  models.LetterOfRecommendation.counselor_id == counselor_id))\
                                                     .order_by(models.LetterOfRecommendation.date_created.desc()).all()
    return db_lors