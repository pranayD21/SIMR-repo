Steps to add new fields to a table in the database:

1. Change models.py to add the new column in the corresponding table. Mark as optional if you think this value will not always be set - typically used across versions?
2. Change the schemas.py to reflect what models will be passing in the new field.
3. Change services.py and crud.py to handle the new field in the appropriate APIs.
4. MAKE SURE YOU ADD THE COLUMN IN THE TABLE IN THE ACTUAL DATABASE. :)
5. If adding a NEW API, make sure you update db_api.py to reflect the new endpoint added.
6. Test your new rest API via postman or through the website docs portal.
7. Make sure to get code review by generating the pull request.
8. Happy coding!