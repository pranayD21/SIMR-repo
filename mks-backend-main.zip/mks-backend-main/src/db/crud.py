import json
import os
from datetime import date, datetime, timedelta, timezone
import secrets
from zoneinfo import ZoneInfo
from aiohttp import ClientError
from fastapi import HTTPException, Query, status, Depends
from pydantic import ValidationError
from fastapi.responses import JSONResponse
from sqlalchemy.orm import Session, joinedload
from sqlalchemy import alias, and_, or_, join, func, desc
from dateutil.parser import parse
from typing import Dict, List, Optional
from auth_jwt.jwt_token import JWTAuthorizationCredentials
import spacy
from sqlalchemy.exc import SQLAlchemyError
from utils import clean_college_name, wrap_response, normalize_email
from webhooks import ses_utils, schemas as wschemas, services
from webhooks.ses_utils import ses_client
from logger import log_trace, logging
from . import Constants, models, schemas
from .models import NewsPost, NewsPostLike, NewsComment, NewsCommentLike, Notification
import requests
import os
from pyfcm import FCMNotification
import json
import random
from .notification_handler import NotificationHandler

from . import analytic_data
from  analytics.analytics_constants import EventType



##########################################################################################
################################### User Ops #############################################
##########################################################################################

def get_user(db: Session, user_id: int):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    if not user or not user.is_active:
        return None
    convert_user_follows_from_array(db=db, db_user=user)
    db_user = augment_user_info_with_following(db=db, db_user=user)
    return db_user

# Return True if user is active, False if user doesn't exist or is marked for deletion
def is_user_active(db: Session, user_id: int):
    user = db.query(models.User).filter(models.User.id == user_id).first()
    return bool(user and user.is_active)

def delete_user_by_email(db: Session, email: str):
    normalized_email = normalize_email(email)
    log_trace(logging.DEBUG, f"Normalized email is {normalized_email}")
    db_user = db.query(models.User).filter(models.User.normalized_email == normalized_email).first()
    if not db_user:
        return False
    return delete_user(db, db_user.id)

# Return True if delete was successful, False if user not found
def delete_user(db: Session, user_id: int):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        return False
    if db_user.is_active == False:
        # Already marked for deletion, so nothing to do
        return True

    # Remove any records of the user in student_career_user table
    remove_student_career_users_by_user_id(db, user_id)
    # Remove any records of the user in student_school table
    remove_student_target_school_users_by_user_id(db, user_id)

    db_user.is_active = False
    # Save the date of deletion
    db_user.delete_date = datetime.now().date()
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    # send event to analytic database indictaing the user was deleted. Only user id is required
    analytic_data.track_user_activity_data(EventType.USER_DISABLE_ACCOUNT , db_user.id, attributes={"delete_date": db_user.delete_date})
    return True

def delete_user_final(db: Session, user_id: int):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        return False
    assert(db_user.is_active == False)
    db.delete(db_user)
    db.commit()
    # send event to analytic database indictaing the user was deleted. Only user id is required
    analytic_data.track_user_activity_data(EventType.USER_DELETE , db_user.id, attributes={})
    return True

# If a user recovered the account, then undelete the user
def restore_user(db: Session, user_email: str) -> bool:
    """
    Restore a user by setting the user's is_active status to True and delete_date to None in the database.

    Parameters:
        db (Session): The database session.
        user_email (str): The email of the user to be restored.

    Returns:
        bool: True if the user is successfully restored, False otherwise.
    """
    log_trace(logging.INFO, f"Restoring user: {user_email}")
    normalized_email = normalize_email(user_email)
    log_trace(logging.DEBUG, f"Normalized email is {normalized_email}")
    user = db.query(models.User).filter(models.User.normalized_email == normalized_email).first()
    if not user: # User doesn't exist :
        return False
    if user.is_active:  # User is already active
        # Do nothing for now. Ideally this code path should never be hit
        return True
    user.is_active = True
    user.delete_date = None
    db.add(user)
    db.commit()
    db.refresh(user)
    # send event to analytic database indictaing the user was deleted. Only user id is required
    analytic_data.track_user_activity_data(EventType.USER_RESTORE_ACCOUNT, user.id, attributes={})
    return True

# Don't filter out records marked for deletion - this method is called when a
# new user is being created.
def get_user_by_username_or_email(db: Session, email: [str,None],username: [str,None]):
    if username is None and email is None:
        return None
    if username:
        db_user = db.query(models.User).filter(models.User.username == username).first()
    elif email:
        normalized_email = normalize_email(email)
        log_trace(logging.DEBUG, f"Normalized email is {normalized_email}")
        db_user = db.query(models.User).filter(models.User.normalized_email == normalized_email).first()
    if db_user:
        convert_user_follows_from_array(db=db, db_user=db_user)
        db_user = augment_user_info_with_following(db=db, db_user=db_user)
    return db_user

# For a list of user records, augement with user following info
def add_user_following_details_to_userlist(db: Session, users: List[models.User]):
    results = []
    for user in users:
        convert_user_follows_from_array(db=db, db_user=user)
        db_user = augment_user_info_with_following(db=db, db_user=user)
        results.append(db_user)
    return results

# Filter out records marked for deletion
def search_user_by_name(db: Session, name: [str,None]):
    # log_trace(logging.INFO, name[0])
    users = db.query(models.User).filter(
        and_(
            or_(
                models.User.first_name.ilike(f"%{name}%"),
                models.User.last_name.ilike(f"%{name}%")
            ),
            models.User.is_active == True
        )
    ).all()
    # log_trace(logging.INFO, results)
    results = add_user_following_details_to_userlist(db=db, users=users)
    return results

# Get records by page # and limit
# Filter out records marked for deletion
def search_user_by_name_paginated(db: Session, name: [str, None], page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    offset = (page_num - 1) * limit
    query = db.query(models.User).filter(
        and_(
            models.User.is_active == True,
            or_(
                models.User.first_name.ilike(f"%{name}%"),
                models.User.last_name.ilike(f"%{name}%")
            )
        )
    )
    total_count = query.count()  # Obtain the total count without fetching all records
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    users = query.offset(offset).limit(limit).all()
    results = add_user_following_details_to_userlist(db=db, users=users)
    return total_count, results

def search_user_by_name_and_type_paginated(db: Session, name: [str, None], user_type: [str, None], page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    offset = (page_num - 1) * limit
    query = db.query(models.User).filter(
        and_(
            models.User.is_active == True,
            models.User.type.ilike(f"%{user_type}%"),
            or_(
                models.User.first_name.ilike(f"%{name}%"),
                models.User.last_name.ilike(f"%{name}%")
            )
        )
    )
    total_count = query.count()  # Obtain the total count without fetching all records
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    users = query.offset(offset).limit(limit).all()
    results = add_user_following_details_to_userlist(db=db, users=users)
    return total_count, results


# Filter out records marked for deletion
def get_users(db: Session, skip: int = 0, limit: int = 100):
    users = db.query(models.User).filter(models.User.is_active == True).offset(skip).limit(limit).all()
    results = add_user_following_details_to_userlist(db=db, users=users)
    return results

def create_user(db: Session, user: schemas.UserCreate):
    db_user = create_user_ep(db, user)
    if db_user.type == Constants.DB_USER_TYPE_STUDENT.value:
        student = create_student(db=db, student=schemas.StudentCreate(user_id=db_user.id))
    elif db_user.type == Constants.DB_USER_TYPE_COUNSELOR.value:
        db_counselor = create_counselor(db=db, counselor=schemas.CounselorCreate(user_id=db_user.id))
    return db_user

# USED ONLY BY CREATE_USER ENDPOINT
def create_user_ep(db: Session, user: schemas.UserCreate):
    db_user = models.User(**user.model_dump())
    db_user.normalized_email = normalize_email(db_user.email)
    db.add(db_user)
    db.commit()
    db.refresh(db_user)
    # Data Analytics Tracking. We need only the id of the user. additional attributes to create a empty profile
    # This data is provided from front end
    # analytic_data.track_user_activity_data(EventType.USER_SIGNUP , db_user.id, attributes = {"gpa": 0} ) #attributes=db_user.to_dict())
    return db_user

def update_user(db: Session, user_id: int, user: schemas.UserCreate):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user:
        log_trace(logging.INFO, f"updating user: {user_id}")
        for var, value in vars(user).items():
            if var not in ['connections','followers','following']:
                if (var =='consentdate') and (value is not None) and isinstance(value,str):
                    setattr(db_user, var, parse(value))
                elif (var =='birthdate') and (value is not None) and isinstance(value,str):
                    setattr(db_user, var, parse(value))
                elif (var in ['fcm_token', 'website']):
                    setattr(db_user, var, value)
                elif value:
                    setattr(db_user, var, value)
    
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
    return db_user

def update_user_connections(db: Session, user_id: int, connection_user_id:int):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user:
        log_trace(logging.INFO, f"updating user: {user_id}")
        # for connections in db_user.connections:
        connections = db_user.connections
        connections.append(connection_user_id)
        db_user.connections = connections
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
    return db_user


def convert_user_follows_from_array(db: Session, db_user: models.User):
    log_trace(logging.INFO, f"Processing user follows for user {db_user.id}")
    # Check if we have converted from the array list to records in Follows for the user connections
    has_follows = db.query(models.Follows).filter(models.Follows.user_id == db_user.id).all()
    if has_follows is None and len(db_user.following) > 0:
        log_trace(logging.INFO, f"Processing following: {db_user.following}")
        # Move from array list to Follows
        for following in db_user.following:
            add_user_follows(db, db_user.id, following)
        has_follows = db.query(models.Follows).filter(models.Follows.user_id == db_user.id).all()
        assert(len(has_follows) == len(db_user.following))

    has_follows = db.query(models.Follows).filter(models.Follows.following_id == db_user.id).all()
    if has_follows is None and len(db_user.followers) > 0:
        log_trace(logging.INFO, f"Processing followers: {db_user.followers}")
        # For each follower, add records
        for follower in db_user.followers:
            add_user_follows(db, follower, db_user.id)
        has_follows = db.query(models.Follows).filter(models.Follows.following_id == db_user.id).all()
        log_trace(logging.INFO, f"Added followers: {has_follows}")
        assert(len(has_follows) == len(db_user.followers))

    return

def augment_user_info_with_following(db: Session, db_user: models.User):
    # Get user following
    db_following = db.query(models.Follows).filter(models.Follows.user_id == db_user.id).all()
    db_followers = db.query(models.Follows).filter(models.Follows.following_id == db_user.id).all()
    db_user.following = []
    if db_following:
        for following in db_following:
            db_user.following.append(following.following_id)
    db_user.followers = []
    if db_followers:
        for follower in db_followers:
            db_user.followers.append(follower.user_id)
    return db_user

# User with id 'user_id' is following user with id 'following_user_id'
def update_user_following(db: Session, user_id: int, following_user_id:int):
    db_user = get_user(db=db, user_id=user_id) # db.query(models.User).filter(models.User.id == user_id).first()
    if not db_user:
        return None
    
    # Check if the user was already following this user. If yes, we need to unfollow the user.
    follows = db.query(models.Follows).filter(and_(models.Follows.user_id == user_id),
                                                  (models.Follows.following_id == following_user_id)).first()
    if follows:
        # Unfollow the user
        remove_user_follows(db, user_id=db_user.id, following_id=following_user_id)
        # Remove the specific student career intersections
        remove_intersections_on_unfollow(db, user_id, following_user_id)
    else:
        # Set up the follow relationship
        add_user_follows(db, user_id=db_user.id, following_id=following_user_id)
        # Update the student career intersections
        update_intersections_on_follow(db, user_id, following_user_id)
    db_user = augment_user_info_with_following(db=db, db_user=db_user)
    return db_user

def update_user_profile(db: Session, user_id: int, user_profile: schemas.UserProfile):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user:
        log_trace(logging.INFO, f"updating user: {user_id}")
        #db_user = models.User(**user.model_dump())
        db_user.email = user_profile.email
        db_user.normalized_email = normalize_email(db_user.email)
        db_user.first_name = user_profile.first_name
        db_user.last_name = user_profile.last_name
        db_user.birthdate = user_profile.birthdate
        db_user.uid = user_profile.uid
        db_user.website = user_profile.website
        db_user.personal_statement = user_profile.personal_statement
        db_user.profile_pic_url = user_profile.profile_pic_url
        db_user.show_sensitive_info = user_profile.show_sensitive_info
        db_user.connections = []
        for connections in user_profile.connections:
            db_user.connections.append(connections)
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
    return db_user

def update_user_status(db: Session, user_id: int, user_status: schemas.UserStatus):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user:
        db_user.is_online = user_status.is_online
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
    return db_user

def update_user_show_sensitive_info(db: Session, user_id: int, show_sensitive_info: bool):
    db_user = db.query(models.User).filter(models.User.id == user_id).first()
    if db_user:
        db_user.show_sensitive_info = show_sensitive_info
        db.add(db_user)
        db.commit()
        db.refresh(db_user)
    return db_user

##########################################################################################
################################ Student Ops #############################################
##########################################################################################

def create_student(db: Session, student: schemas.StudentCreate): #, user_id: int, school_id: int):
    # db_user = models.UserCreate()
    db_student = models.Student(**student.model_dump()) #,user_id = user_id)
    db.add(db_student)
    db.commit()
    db.refresh(db_student)
    return db_student

def get_student(db: Session, student_id: int):
    student = db.query(models.Student).filter(models.Student.id==student_id).first()
    # check that the user is not deleted
    if student and is_user_active(db, student.user_id):
        return student
    return None

def get_student_by_uid(db: Session, uid: int):
    student = db.query(models.Student).filter(models.Student.user_id==uid).first()
    if not student:
        return None
    # check that the user is not deleted
    if is_user_active(db, student.user_id):
        return student
    return None

def get_students(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Student).offset(skip).limit(limit).all()

def get_student_by_username_or_email(db: Session, username: [str,None],email: [str,None]):
    if username:
        log_trace(logging.INFO, f"Find student by username: {username}")
        db_user = db.query(models.User).filter(models.User.username==username).first()
    elif email:
        log_trace(logging.INFO, f"Find student by email: {email}")
        db_user = db.query(models.User).filter(models.User.normalized_email == normalize_email(email)).first()
    if not db_user:
        log_trace(logging.ERROR, f"Could not find student!")
        return None
    
    return db.query(models.Student).filter(models.Student.user_id==db_user.id).first()

def delete_student(db: Session, student_id: int):
    db_student = db.query(models.Student).filter(models.Student.id==student_id).first()
    if not db_student:
        return False
    db.delete(db_student)
    db.commit()
    return True

def add_school_details(results_dict, school_info: models.School):
    results_dict['name'] = school_info.name
    results_dict['city'] = school_info.city
    results_dict['state'] = school_info.state
    results_dict['zip'] = school_info.zip
    results_dict['country'] = school_info.country
    return results_dict

## Student School
def get_student_school_by_id(db: Session, 
                             student_id: int,
                             school_id: int):
    ss_rec = db.query(models.StudentSchool).filter(
        and_(models.StudentSchool.school_id == school_id,
             models.StudentSchool.student_id == student_id)).first()
    
    if not ss_rec:
        log_trace(logging.INFO, "No student school record found")
        return []
    student_school = ss_rec.__dict__
    school_info = db.query(models.School).filter(models.School.id==student_school['school_id']).first()
    student_school = add_school_details(student_school, school_info=school_info)
    return student_school

def get_student_primary_school(db: Session, 
                               student_id: int):
    db_student_school = db.query(models.StudentSchool).filter(
        and_(models.StudentSchool.is_primary == True,
             models.StudentSchool.student_id == student_id)).first()

    if not db_student_school:
        log_trace(logging.INFO, f"No primary school found for student: {student_id}")
        return None
    # Create a dict, include school name in the dict.
    student_school = db_student_school.__dict__
    school_info = db.query(models.School).filter(models.School.id==student_school['school_id']).first()
    if not school_info:
        raise HTTPException(status_code=404, detail="School not found")
    student_school = add_school_details(student_school, school_info=school_info)
    # log_trace(logging.INFO, student_school)
    return student_school

def get_student_schools(db: Session, student_id: int):
    ss_recs = db.query(models.StudentSchool).filter(models.StudentSchool.student_id==student_id).all()
    # Get the school name for each school using the id
    student_schools = []
    for ss in ss_recs:
        student_school = ss.__dict__
        student_schools.append(student_school)

    # student_schools = [dict(school) for school in student_schools]
    for school in student_schools:
        school_info = db.query(models.School).filter(models.School.id==school['school_id']).first()
        school = add_school_details(school, school_info=school_info)
    return student_schools

# Get student school details by the student-school detail id
def get_student_schools_by_student_school_id(db: Session, student_school_id: int):
    student_school = db.query(models.StudentSchool).filter(models.StudentSchool.id == student_school_id).first()
    if not student_school:
        return None
    
    # Replace school id with school name
    school = db.query(models.School).filter(models.School.id == student_school.school_id).first()
    if not school:
        raise HTTPException(status_code=404, detail="School not found")
    
    school_name = school.name
    student_school_dict = student_school.__dict__
    student_school_dict = add_school_details(student_school_dict, school_info=school)
    return student_school_dict

## DUPLICATE METHOD????
def get_student_schools_by_student_id(db: Session, student_id: int):
    student_schools = db.query(models.StudentSchool).filter(models.StudentSchool.student_id == student_id).all()
    schools_list = []
    for school in student_schools:
        school_elem = school.__dict__
        school = db.query(models.School).filter(models.School.id == school.school_id).first()
        if not school:
            continue
        school_elem = add_school_details(school_elem, school_info=school)
        schools_list.append(school_elem)
    return schools_list

def create_student_school(db: Session, student_school: schemas.StudentSchoolCreate):
    log_trace(logging.INFO, student_school.model_dump())
    # Search for student by user_id - student_id hasnt been created if the student doesn't exist
    db_student = db.query(models.Student).filter(models.Student.user_id == student_school.user_id).first()
    # Check if student exists, if not create
    if not db_student:
        # Create student
        db_student = models.Student(user_id=student_school.user_id)
        db.add(db_student)
        db.commit()
        db.refresh(db_student)
    
    student_school.student_id = db_student.id
    
    # Check if school exists, if not create - need to search by school name and zip, id is not created if the school doesn't exist
    db_school = db.query(models.School).filter(and_(models.School.name == student_school.name,
                                                    models.School.zip == student_school.zip)).first()
    if not db_school:
        # Create school
        db_school = models.School(name=student_school.name, city=student_school.city, state=student_school.state,
                                  zip=student_school.zip, country=student_school.country)
        db.add(db_school)
        db.commit()
        db.refresh(db_school)
    
    student_school.school_id = db_school.id
    
    # Check if we have student school records for the student. If not, MAKE THIS THE PRIMARY SCHOOL UNTIL UI ADDS A CHECKBOX FOR PRIMARY SCHOOL.
    db_student_school = db.query(models.StudentSchool).filter(models.StudentSchool.student_id == student_school.student_id).first()
    if not db_student_school:
        student_school.is_primary = True
    else:
        student_school.is_primary = False
    
    # Check if we have a record for the student and school, add if its not there
    db_student_school = db.query(models.StudentSchool).filter(
                                            and_(models.StudentSchool.school_id==student_school.school_id,
                                                 models.StudentSchool.student_id==student_school.student_id)).first()
    
    if db_student_school:
        log_trace(logging.INFO, f"Found an existing entry for the student and school id: {db_student_school.id}. Not adding a new entry")
        student_school_dict = db_student_school.__dict__
        student_school_dict["name"] = student_school.name
        # Post the analytical data event
        analytic_data.track_school_update_data(student_school_dict, student_school.dict())
        return student_school_dict
    
    db_student_school_new = models.StudentSchool(student_id=student_school.student_id,
                                              school_id=student_school.school_id,
                                              user_id=student_school.user_id,
                                              start_date=student_school.start_date,
                                              end_date=student_school.end_date,
                                              graduation_year = student_school.graduation_year,
                                              currently_enrolled=student_school.currently_enrolled,
                                              gpa=student_school.gpa,
                                              w_gpa=student_school.w_gpa,
                                              current_grade=student_school.current_grade,
                                              is_primary=student_school.is_primary,
                                              )

    #db_student_school_new = models.StudentSchool(**student_school.model_dump())
    db.add(db_student_school_new)
    db.commit()
    db.refresh(db_student_school_new)

    student_school_dict = db_student_school_new.__dict__
    student_school_dict = add_school_details(student_school_dict, student_school)
    # Post the analytical data event
    analytic_data.track_school_update_data(student_school_dict, student_school_dict)
    return student_school_dict

def update_student_school(db: Session, student_school_id: int, student_school_update: schemas.StudentSchoolUpdate):
    db_school_new = None
    school_name = student_school_update.name
    # Check if the school details have changed
    db_school = db.query(models.School).filter(models.School.id == student_school_update.school_id).first()
    if not db_school:
        raise HTTPException(status_code=404, detail="School not found")
    
    if student_school_update.name != db_school.name or \
        student_school_update.zip != db_school.zip or \
        student_school_update.city != db_school.city or \
        student_school_update.state != db_school.state or \
        student_school_update.country != db_school.country:
        db_school_new = db.query(models.School).filter(and_(models.School.name == student_school_update.name,
                                                            models.School.zip == student_school_update.zip)).first()
        if not db_school_new:
            db_school_new = models.School(name=student_school_update.name, city=student_school_update.city,
                                          state=student_school_update.state, zip=student_school_update.zip,
                                          country=student_school_update.country)
            db.add(db_school_new)
            db.commit()
            db.refresh(db_school_new)
        else:
            # Update the school record
            for var in ['name', 'city', 'state', 'zip', 'country']:
                if getattr(student_school_update, var) is not None:
                    setattr(db_school_new, var, getattr(student_school_update, var))
            db.commit()
            db.refresh(db_school_new)
        student_school_update.school_id = db_school_new.id
        school_name = db_school_new.name

    db_student_school = db.query(models.StudentSchool).filter(models.StudentSchool.id == student_school_id).first()
    if not db_student_school:
        raise HTTPException(status_code=404, detail="Student School not found")
    
    student_school = {}
    for var, value in vars(student_school_update).items():
        if value:
            setattr(db_student_school, var, value)
    db.commit()
    db.refresh(db_student_school)
    student_school = db_student_school.__dict__
    student_school = add_school_details(student_school, school_info=db_school_new)
    return student_school

def update_student_school_by_id(db: Session, user_id: int, school_id: int, student_school: schemas.StudentSchoolUpdate):
    assert user_id == student_school.user_id
    # Get student id from user id
    db_student = db.query(models.Student).filter(models.Student.user_id == student_school.user_id).first()
    if not db_student:
        return None
    
    db_student_school = db.query(models.StudentSchool).filter(
        and_(models.StudentSchool.school_id == school_id,
             models.StudentSchool.student_id == db_student.id)).first()
    if db_student_school:
        for var, value in vars(student_school).items():
            if value:
                setattr(db_student_school, var, value)
        db.commit()
        db.refresh(db_student_school)
    else:
        raise HTTPException(status_code=404, detail="Student School not found")

    student_school = db_student_school.__dict__
    school = db.query(models.School).filter(models.School.id == db_student_school.school_id).first()
    student_school = add_school_details(student_school, school_info=school)
    return student_school


def delete_student_school(db: Session, student_school_id: int):
    db_student_school = db.query(models.StudentSchool).filter(models.StudentSchool.id == student_school_id).first()
    if db_student_school:
        db.delete(db_student_school)
        db.commit()
    return db_student_school

def delete_student_school_by_id(db: Session, user_id: int, school_id: int):
    # Get student id from user id
    db_student = db.query(models.Student).filter(models.Student.user_id == user_id).first()
    if not db_student:
        return None
    
    db_student_school = db.query(models.StudentSchool).filter(
        and_(models.StudentSchool.school_id == school_id,
             models.StudentSchool.student_id == db_student.id)).first()
    if db_student_school:
        db.delete(db_student_school)
        db.commit()
    return db_student_school

## Student Standardized Tests
def create_student_standardized_test(db: Session, user_id: int, student_standardized_test: schemas.StudentStandardizedTestCreate):
    db_student = db.query(models.Student).filter(models.Student.user_id == user_id).first()
    if not db_student:
        db_student = models.Student(user_id=user_id)
        db.add(db_student)
        db.commit()
        db.refresh(db_student)

    student_standardized_test.student_id = db_student.id    
    db_student_standardized_test = models.StudentStandardizedTests(**student_standardized_test.model_dump())
    db.add(db_student_standardized_test)
    db.commit()
    db.refresh(db_student_standardized_test)
    return db_student_standardized_test

def get_student_standardized_test(db: Session, student_id: int):
    tests = db.query(models.StudentStandardizedTests).filter(models.StudentStandardizedTests.student_id == student_id).all()
    # Replace std tests to full lower case
    result_std_tests = []
    for test in tests:
        test.test_type = test.test_type.lower() # Convert test type to lowercase
        result_std_tests.append(test)
    return result_std_tests

def get_student_standardized_test_by_id(db: Session, test_id: int):
    test = db.query(models.StudentStandardizedTests).filter(models.StudentStandardizedTests.id == test_id).first()
    test.test_type = test.test_type.lower()
    return test

def get_student_standardized_test_by_user_id(db: Session, user_id: int):
    student = db.query(models.Student).filter(models.Student.user_id == user_id).first()
    if not student:
        return None
    if not student.standardized_scores:
        return None
    test = student.standardized_scores[0]
    test.test_type = test.test_type.lower()
    return test

def update_student_standardized_test(db: Session, student_std_test_id: int, student_standardized_test_update: schemas.StudentStandardizedTestUpdate):
    db_student_standardized_test = db.query(models.StudentStandardizedTests).filter(models.StudentStandardizedTests.id == student_std_test_id).first()
    if db_student_standardized_test:
        for var, value in vars(student_standardized_test_update).items():
            if value:
                setattr(db_student_standardized_test, var, value)
        db.commit()
        db.refresh(db_student_standardized_test)
    return db_student_standardized_test

def delete_student_standardized_test(db: Session, test_id: int):
    db_student_standardized_test = db.query(models.StudentStandardizedTests).filter(models.StudentStandardizedTests.id == test_id).first()
    if db_student_standardized_test:
        db.delete(db_student_standardized_test)
        db.commit()
        # db.refresh(db_student_standardized_test)
    return db_student_standardized_test


## Student Strengths Weakness
def create_student_strengths_weakness(db: Session, student_sw: schemas.StudentStrengthsWeaknessCreate):
    db_student_sw = db.query(models.StudentStrengthsWeakness).filter(
        models.StudentStrengthsWeakness.student_id==student_sw.student_id).first()
    if db_student_sw:
        return db_student_sw
    db_student_sw = models.StudentStrengthsWeakness(**student_sw.model_dump())
    db.add(db_student_sw)
    db.commit()
    db.refresh(db_student_sw)
    return db_student_sw

def get_student_strengths_weakness(db: Session, student_id: int):
    student = db.query(models.Student).filter(models.Student.id == student_id).first()
    if not student:
        return None
    if not student.strengths_weakness:
        return None
    return student.strengths_weakness[0]

def update_student_strengths_weakness(
                            db: Session, 
                            student_sw: schemas.StudentStandardizedTestUpdate):
    db_student_sw = db.query(
        models.StudentStrengthsWeakness).filter(
            models.StudentStrengthsWeakness.student_id == student_sw.student_id).first()
    if db_student_sw:
        for var, value in vars(student_sw).items():
            if value:
                setattr(db_student_sw, var, value)
        db.commit()
        db.refresh(db_student_sw)
    return db_student_sw

def delete_student_strengths_weakness(
                            db: Session, 
                            student_id: int):
    db_student_sw = db.query(
        models.StudentStrengthsWeakness).filter(
        models.StudentStrengthsWeakness.student_id == student_id).first()
    if db_student_sw:
        db.delete(db_student_sw)
        db.commit()
    return db_student_sw


## Student WorkExperience

# DOESNT LOOK RIGHT
def create_student_work_experience(
        db: Session, student_work_experience: schemas.StudentWorkExperienceCreate):
    db_student_work_experience = db.query(models.StudentWorkExperience).filter(
        models.StudentWorkExperience.student_id==student_work_experience.student_id
    ).first()
    if db_student_work_experience:
        return db_student_work_experience
    db_student_work_experience = models.StudentWorkExperience(**student_work_experience.model_dump())
    db.add(db_student_work_experience)
    db.commit()
    db.refresh(db_student_work_experience)
    return db_student_work_experience

def add_student_work_experience(
        db: Session, user_id: int, student_work_experience: schemas.StudentWorkExperienceCreate):
    db_student = db.query(models.Student).filter(models.Student.user_id == user_id).first()
    if not db_student:
        db_student = models.Student(user_id=user_id)
        db.add(db_student)
        db.commit()
        db.refresh(db_student)
    
    student_work_experience.student_id = db_student.id
    db_student_work_experience = models.StudentWorkExperience(**student_work_experience.model_dump())
    db.add(db_student_work_experience)
    db.commit()
    db.refresh(db_student_work_experience)
    return db_student_work_experience

def get_student_work_experiences_by_uid(db: Session, user_id: int):
    student = db.query(models.Student).filter(models.Student.user_id == user_id).first()
    if not student:
        return None
    return db.query(models.StudentWorkExperience).filter(
        models.StudentWorkExperience.student_id == student.id).all()


def get_student_work_experiences(db: Session, 
                                 student_id: int):
    return db.query(models.StudentWorkExperience).filter(
        models.StudentWorkExperience.student_id == student_id).all()

def update_student_work_experience(db: Session, 
                                   work_experience_id: int, 
        student_work_experience: schemas.StudentWorkExperienceCreate):
    db_student_work_experience = db.query(
        models.StudentWorkExperience).filter(
            models.StudentWorkExperience.id == work_experience_id).first()
    if db_student_work_experience:
        update_data = student_work_experience.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_student_work_experience, key, value)
        db.commit()
        db.refresh(db_student_work_experience)
    return db_student_work_experience

def delete_student_work_experience(db: Session, 
                                   work_experience_id: int):
    db_student_work_experience = db.query(
        models.StudentWorkExperience).filter(
            models.StudentWorkExperience.id == work_experience_id).first()
    if db_student_work_experience:
        db.delete(db_student_work_experience)
        db.commit()
    return db_student_work_experience

## Student Projects

# Doesnt look right
def create_student_project(db: Session, 
                           student_project: schemas.StudentProjectsCreate):
    db_student_project = db.query(models.StudentProjects).filter(
        models.StudentProjects.student_id == student_project.student_id
    ).first()
    if db_student_project:
        return db_student_project
    db_student_project = models.StudentProjects(**student_project.model_dump())
    db.add(db_student_project)
    db.commit()
    db.refresh(db_student_project)
    return db_student_project

def add_student_project(db: Session, student_id: int,
                           student_project: schemas.StudentProjectsCreate):
    student_project.student_id = student_id
    db_student_project = models.StudentProjects(**student_project.model_dump())
    db.add(db_student_project)
    db.commit()
    db.refresh(db_student_project)
    return db_student_project

def get_student_projects(db: Session, 
                         student_id: int):
    return db.query(models.StudentProjects).filter(
        models.StudentProjects.student_id == student_id).all()

def update_student_project(db: Session, project_id: int, student_project: schemas.StudentProjectsCreate):
    db_student_project = db.query(models.StudentProjects).filter(models.StudentProjects.id == project_id).first()
    if db_student_project:
        # Update student project
        update_data = student_project.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_student_project, key, value)
        db.commit()
        db.refresh(db_student_project)
    return db_student_project

def delete_student_project(db: Session, project_id: int):
    db_student_project = db.query(
            models.StudentProjects).filter(
            models.StudentProjects.id == project_id).first()
    if db_student_project:
        db.delete(db_student_project)
        db.commit()
    return db_student_project


##########################################################################################
################################# School Ops #############################################
##########################################################################################


def get_schools(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.School).offset(skip).limit(limit).all()

# Return states in sorted order
def get_all_states(db: Session):
    states = db.query(models.School.state).distinct().order_by(models.School.state).all()
    return [state[0] for state in states]

# Return cities sorted alphabetcally
def get_cities_by_state(db: Session, state: str):
    # Use case insensitive search for the state.
    cities = db.query(models.School.city).filter(models.School.state.ilike(state)).distinct().order_by(models.School.city).all()
    return [city[0] for city in cities]

def get_cities_by_state_starting_with(db: Session, state: str, starts_with: str = "", page: int = 1, per_page: int = 10):
    query = db.query(models.School.city).filter(models.School.state.ilike(state)).distinct().order_by(models.School.city)
    if starts_with:
        query = query.filter(models.School.city.ilike(starts_with + '%'))
    cities = query.offset((page - 1) * per_page).limit(per_page).all()
    return [city[0] for city in cities]

def get_school_by_name_city_state(db: Session, name: str, city: str, state: str):
    return db.query(models.School).filter(and_(models.School.name.ilike(name), \
                                               models.School.city.ilike(city), \
                                               models.School.state.ilike(state))).first()

def get_school_by_name_city_state_country(db: Session, name: str, city: str, state: str, country: str):
    return db.query(models.School).filter(and_(models.School.name.ilike(name), \
                                               models.School.city.ilike(city), \
                                               models.School.state.ilike(state), \
                                               models.School.country.ilike(country))).first()

def get_all_schools_by_city_state(db: Session, city: str, state: str):
    return db.query(models.School).filter(
        and_(
            models.School.city.ilike(city),
            models.School.state.ilike(state)
        )
    ).all()

def get_schools_by_state(db: Session, state: str, starts_with: str = "", page: int = 1, per_page: int = 10):
    query = db.query(models.School).filter(models.School.state.ilike(state))
    if starts_with:
        query = query.filter(models.School.name.ilike(starts_with + '%'))
    schools = query.offset((page - 1) * per_page).limit(per_page).all()
    return schools

def get_school_by_id(db: Session, school_id: int):
    return db.query(models.School).filter(models.School.id == school_id).first()

def create_school(db: Session, new_school: schemas.SchoolCreate):
    school = db.query(models.School).filter(and_(models.School.name.ilike(new_school.name), \
                                                 models.School.city.ilike(new_school.city), \
                                                 models.School.state.ilike(new_school.state), \
                                                 models.School.country.ilike(new_school.country))).first()
    if school:
        return school
    db_school = models.School(name=new_school.name, city = new_school.city,
                              state = new_school.state, zip = new_school.zip,
                              country = new_school.country)
    db.add(db_school)
    db.commit()
    db.refresh(db_school)
    return db_school

def delete_school(db: Session, school_id: int):
    db_school = db.query(models.School).filter(models.School.id == school_id).first()
    if not db_school:
        return False
    db.delete(db_school)
    db.commit()
    #db.refresh(db_user)
    return True

def update_school(db: Session, school_id: int, school: schemas.SchoolCreate):
    db_school = db.query(models.School).filter(models.School.id == school_id).first()
    if db_school:
        db_school.name = school.name
        db_school.city = school.city
        db_school.state = school.state
        db_school.zip = school.zip
        db_school.country = school.country
        db.add(db_school)
        db.commit()
        db.refresh(db_school)
    return db_school

##########################################################################################
################################ Courses Ops #############################################
##########################################################################################

def get_courses(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Course).offset(skip).limit(limit).all()

def get_course(db: Session, course: [int,str]):
    if isinstance(course,int):
        return db.query(models.Course).filter(models.Course.id==course).first()
    return db.query(models.Course).filter(models.Course.course_name==course).first()    

def create_course(db: Session, course_name: str):
    db_course = models.Course(course_name=course_name)
    db.add(db_course)
    db.commit()
    db.refresh(db_course)
    return db_course

def delete_course(db: Session, course_id: int):
    db_course = models.Course(id=course_id)
    if not db_course:
        return False
    db.delete(db_course)
    db.commit()
    # db.refresh(db_course)
    return True

##########################################################################################
################################ Activity Ops ############################################
##########################################################################################

def get_activites(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Activity).offset(skip).limit(limit).all()

def get_activity(db: Session, activity: [int,str]):
    if isinstance(activity,int):
        return db.query(models.Activity).filter(models.Activity.id==activity).first()
    if isinstance(activity,str):
        return db.query(models.Activity).filter(models.Activity.activity_name==activity).first()
    return None


def create_activity(db: Session, activity_name: str):
    db_activity = models.Activity(activity_name=activity_name)
    db.add(db_activity)
    db.commit()
    db.refresh(db_activity)
    return db_activity

def delete_activity(db: Session, activity_id: int):
    db_activity = models.Activity(id=activity_id)
    if not db_activity:
        return False
    db.delete(db_activity)
    db.commit()
    # db.refresh(db_course)
    return True

##########################################################################################
################################ Student Course Ops ######################################
##########################################################################################

def get_current_courses(db: Session, db_courses: list[models.StudentCourse]):
    courses_dict = {}
    for course in db_courses:
        courses_dict[course.course_id] = {'id': course.course_id, 'term': course.term, 'year': course.grade_year} 
    
    course_names = []
    courses = [course.course_id for course in db_courses]
    for id in courses:
        course_dict_item = courses_dict[id]
        course_name = get_course(db, course=id).course_name
        course_dict_item['name'] = course_name
        course_names.append(course_name)

    return course_names, courses_dict

def add_student_course_old(db:Session,student_id:int, 
                       school_id: int, 
                       course_name:str, 
                       credits: int, 
                       grade: str,
                       grade_year: str,
                       difficulty_level: str,
                       feedback: str):
    course = get_course(db, course=course_name)
    if not course:
        course = create_course(db, course_name=course_name)

    db_user_course = models.StudentCourse(student_id=student_id, 
                                            course_id=course.id, 
                                            school_id = school_id,
                                            credits=credits, 
                                            grade=grade,
                                            grade_year = grade_year,
                                            difficulty_level = difficulty_level,
                                            feedback = feedback)
    db.add(db_user_course)
    db.commit()
    db.refresh(db_user_course)
    return db_user_course

def add_student_course(db:Session, usercourse: schemas.StudentCourseCreate):
    course = get_course(db, course=usercourse.course_name)
    if not course:
        course = create_course(db, course_name=usercourse.course_name)

    add_usercourse = {}
    for k in usercourse.__dict__.keys():
        # Add all keys except course_name, which will be replaced with course_id
        if k=='course_name':
            course = get_course(db, course=usercourse.__dict__[k])
            add_usercourse['course_id'] = course.id
            continue
        add_usercourse[k] = usercourse.__dict__[k]

    db_user_course = models.StudentCourse(**add_usercourse)
    db.add(db_user_course)
    db.commit()
    db.refresh(db_user_course)

    course = db_user_course.__dict__
    course['course_name'] = usercourse.course_name
    return course

def add_student_course_by_student_school_id(db:Session,student_school_id:int, course_name:str, credits: int, grade: str, difficulty: str, feedback: str):
    course = get_course(db, course=course_name)
    if not course:
        course = create_course(db, course_name=course_name)

    db_user_course = models.StudentCourse(student_school_id=student_school_id,
                                            course_id=course.id, 
                                            credits=credits, 
                                            grade=grade,
                                            difficulty=difficulty,
                                            feedback=feedback)
    db.add(db_user_course)
    db.commit()
    db.refresh(db_user_course)
    course = db_user_course.__dict__
    course['course_name'] = course_name
    return db_user_course

def add_student_course_by_student_school_id(db:Session,student_school_id:int, course_name:str, credits: int, grade: str, difficulty: str, feedback: str):
    course = get_course(db, course=course_name)
    if not course:
        course = create_course(db, course_name=course_name)

    db_user_course = models.StudentCourse(student_school_id=student_school_id,
                                            course_id=course.id, 
                                            credits=credits, 
                                            grade=grade,
                                            difficulty=difficulty,
                                            feedback=feedback)
    db.add(db_user_course)
    db.commit()
    db.refresh(db_user_course)
    course = db_user_course.__dict__
    course['course_name'] = course_name
    return db_user_course


def get_student_courses_by_school(db: Session, student_id: int,school_id: int):
    user = db.query(models.StudentCourse).filter(and_(models.StudentCourse.student_id==student_id,
                                                      models.StudentCourse.school_id==school_id)).all()
    # log_trace(logging.INFO, dict(user))
    user_courses = []
    for u in user:
        user_course = {}
        for k in u.__dict__.keys():
            user_course[k] = u.__dict__[k]
            if k=='course_id':
                course = get_course(db,  course=u.__dict__[k])
                user_course['course_name'] = course.course_name 
        user_courses.append(user_course)
    return user_courses

def get_student_courses_by_school_and_student_id(db: Session, student_id: int, school_id: int):
    return db.query(models.StudentCourse).filter(and_(models.StudentCourse.student_id==student_id,
                                                      models.StudentCourse.school_id==school_id)).all()

def get_student_courses_by_student_school_id(db: Session, student_school_id: int):
    user = db.query(models.StudentCourse).filter(models.StudentCourse.student_school_id==student_school_id).all()
    # log_trace(logging.INFO, dict(user))
    user_courses = []
    for u in user:
        user_course = {}
        for k in u.__dict__.keys():
            user_course[k] = u.__dict__[k]
            if k=='course_id':
                course = get_course(db, course=u.__dict__[k])
                user_course['course_name'] = course.course_name 
        user_courses.append(user_course)
    return user_courses


def get_student_courses(db: Session, student_id: int):
    user = db.query(models.StudentCourse).filter(models.StudentCourse.student_id==student_id).all()
    # log_trace(logging.INFO, dict(user))
    user_courses = []
    for u in user:
        user_course = {}
        for k in u.__dict__.keys():
            user_course[k] = u.__dict__[k]
            if k=='course_id':
                course = get_course(db, course=u.__dict__[k])
                user_course['course_name'] = course.course_name 
        user_courses.append(user_course)
    return user_courses

def get_student_course_by_id(db: Session, student_course_id: int):
    return db.query(models.StudentCourse).filter(models.StudentCourse.id==student_course_id).first()


def update_student_course(db:Session,student_course: schemas.StudentCourseCreate, student_course_id: int, course_id: int):
    if course_id == 0:
        raise HTTPException(status_code=404, detail="Error in course_id: Invalid course specified.")
    
    db_user_course = db.query(models.StudentCourse).filter(models.StudentCourse.id==student_course_id).first()
    if not db_user_course:
        raise HTTPException(status_code=404, detail="Student Course not found")
    
    update_data = student_course.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_user_course, key, value)
    db_user_course.course_id = course_id
    db.commit()
    db.refresh(db_user_course)
    user_course = db_user_course.__dict__
    user_course['course_name'] = student_course.course_name
    return user_course

def update_student_course_old(db:Session,student_id:int, school_id:int,course_id:str, credits: int, grade: str, difficulty: str, feedback: str):
    db_user_course = db.query(models.StudentCourse).filter(
                                                    and_(
                                                        models.StudentCourse.student_id==student_id,
                                                        and_(models.StudentCourse.school_id==school_id,
                                                        models.StudentCourse.course_id==course_id))).first()
    if credits and credits!=db_user_course.credits:
        db_user_course.credits = credits
    if grade and grade!=db_user_course.grade:
        db_user_course.grade = grade
    if school_id and school_id!=db_user_course.school_id:
        db_user_course.school_id = school_id
    if difficulty and difficulty!=db_user_course.difficulty:
        db_user_course.difficulty = difficulty
    if feedback and feedback!=db_user_course.feedback:
        db_user_course.feedback = feedback
    db.add(db_user_course)
    db.commit()
    db.refresh(db_user_course)

    user_course = db_user_course.__dict__
    course = get_course(db, course=user_course['course_id'])
    user_course['course_name'] = course.course_name
    return user_course

def update_student_course_by_student_school_id(db:Session,
                                               student_school_id:int,
                                               course_id:str,
                                               course_credits: int,
                                               grade: str,
                                               difficulty: str,
                                               feedback: str):
    db_user_course = db.query(models.StudentCourse).filter(
                                                    and_(
                                                        models.StudentCourse.student_school_id==student_school_id,
                                                        models.StudentCourse.course_id==course_id)).first()
    if course_credits and course_credits!=db_user_course.credits:
        db_user_course.credits = course_credits
    if grade and grade!=db_user_course.grade:
        db_user_course.grade = grade
    # if school_id and school_id!=db_user_course.school_id:
    #     db_user_course.school_id = school_id
    if difficulty and difficulty!=db_user_course.difficulty:
        db_user_course.difficulty = difficulty
    if feedback and feedback!=db_user_course.feedback:
        db_user_course.feedback = feedback
    db.add(db_user_course)
    db.commit()
    db.refresh(db_user_course)

    user_course = db_user_course.__dict__
    course = get_course(db, course=user_course['course_id'])
    user_course['course_name'] = course.course_name
    return user_course


def delete_student_course(db:Session,student_course_id:int):
    db_student_course =  db.query(models.StudentCourse).filter(models.StudentCourse.id==student_course_id).first()
    if not db_student_course:
        log_trace(logging.INFO, f"Could not find student course id {student_course_id}")
        return False
    db.delete(db_student_course)
    db.commit()
    return True

##########################################################################################
################################ Student-Activity Ops ####################################
##########################################################################################

def add_student_activity(db:Session,student_id:int, activity: schemas.StudentActivityCreate):
    db_activity = get_activity(db, activity = activity.activity_name)
    if not db_activity:
        db_activity = create_activity(db, activity_name=activity.activity_name)
    
    db_user_activity = models.StudentActivity(student_id=student_id, 
                                            activity_id=db_activity.id,
                                            activity_description=activity.activity_description,
                                            type=activity.type,)

    db.add(db_user_activity)
    db.commit()
    db.refresh(db_user_activity)

    user_activity = db_user_activity.__dict__
    user_activity['activity_name'] = activity.activity_name

    return user_activity


def add_student_activity2(db:Session,student_id:str, 
                         activity_name:str,
                         activity_description: str,
                         hours_committed_per_week: float,
                         achievements: str):
    activity = get_activity(db, activity = activity_name)
    # log_trace(logging.INFO, "activity: ",activity.id)
    if not activity:
        activity = create_activity(db, activity_name=activity_name)
    db_user_activity = models.StudentActivity(student_id=student_id, 
                                              activity_id=activity.id,
                                              activity_description=activity_description,
                                              hours_committed_per_week=hours_committed_per_week,
                                              achievements=achievements)
    db.add(db_user_activity)
    db.commit()
    db.refresh(db_user_activity)
    user_activity = db_user_activity.__dict__
    user_activity['activity_name'] = activity.activity_name
    return user_activity

def get_student_activity_by_id(db:Session,student_activity_id:int):
    db_user_activity = db.query(models.StudentActivity).filter(models.StudentActivity.id==student_activity_id).first()
    if not db_user_activity:
        return None
    
    user_activity = db_user_activity.__dict__
    activity = get_activity(db, user_activity['activity_id'])
    user_activity['activity_name'] = activity.activity_name
    return user_activity

def get_activities_of_student(db: Session, student_id: int):
    activities = db.query(models.StudentActivity).filter(models.StudentActivity.student_id==student_id).all()
    if not activities:
        return []
    
    #log_trace(logging.INFO, activities)
    user_activities = []
    for a in activities:
        user_activity = {}
        for k in a.__dict__.keys():
            user_activity[k] = a.__dict__[k]
            if k=='activity_id':
                activity = get_activity(db,a.__dict__[k])
                user_activity['activity_name'] = activity.activity_name
        user_activities.append(user_activity)
    return user_activities

def update_student_activity(db:Session,student_activity: schemas.StudentActivityCreate, student_activity_id: int, activity_id: int):
    db_user_activity = db.query(models.StudentActivity).filter(models.StudentActivity.id==student_activity_id).first()
    if db_user_activity:
        update_data = student_activity.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_user_activity, key, value)
        db_user_activity.activity_id = activity_id
        db.commit()
        db.refresh(db_user_activity)
    
    user_activity = db_user_activity.__dict__
    # activity = get_activity(db, user_activity['activity_id'])
    user_activity['activity_name'] = student_activity.activity_name
    
    return user_activity

def delete_student_activity_by_id(db:Session,student_activity_id:int):
    db_student_activity = db.query(models.StudentActivity).filter(models.StudentActivity.id==student_activity_id).first()
    if not db_student_activity:
        return False
    db.delete(db_student_activity)
    db.commit()
    return True

def delete_student_activities(db:Session, student_id:int):
    db_student_activity = db.query(models.StudentActivity).filter(models.StudentActivity.student_id==student_id).all()
    if not db_student_activity:
        return True
    for activity in db_student_activity:
        db.delete(activity)
    db.commit()
    return True

def delete_student_activity(db:Session,student_id:int, activity_id:int):
    log_trace(logging.INFO, f"student_id: {student_id} and activity_id: {activity_id}")
    db_student_activity = db.query(models.StudentActivity).filter(
                                                        and_(
                                                            models.StudentActivity.student_id==student_id,
                                                            models.StudentActivity.activity_id==activity_id)).first()
    if not db_student_activity:
        return False
    db.delete(db_student_activity)
    db.commit()
    return True

##########################################################################################
################################# Career Ops #############################################
##########################################################################################

def create_career(db: Session, career: schemas.CareersCreate):
    log_trace(logging.INFO, career)
    db_career = models.Careers(career_name = career.career_name,
                               career_description = career.career_description,
                               skills = career.skills,
                               job_duties = career.job_duties,
                               median_salary = career.median_salary,
                               career_outlook = career.career_outlook,
                               majors = career.majors)
    
    db.add(db_career)
    db.commit()
    db.refresh(db_career)
    return db_career

def update_career(db: Session, 
                  career: schemas.CareersCreate):
    db_career = db.query(models.Careers).filter(models.Careers.career_name == career.career_name).first()
    if db_career:
        update_data = career.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_career, key, value)
        db.commit()
        db.refresh(db_career)
    return db_career

def delete_career(db: Session, career_id: int):
    db_career = models.Careers(id=career_id)
    if not db_career:
        return False
    db.delete(db_career)
    db.commit()
    # db.refresh(db_course)
    return True

def get_careers(db: Session, skip: int = 0, limit: int = 100):
    return db.query(models.Careers).offset(skip).limit(limit).all()

def get_career(db: Session, career: [int,str]):
    # log_trace(logging.INFO, f"get career: {career}")
    if isinstance(career,int):
        db_career = db.query(models.Careers).filter(models.Careers.id==career).first()
        return db_career
    if isinstance(career,str):
        # log_trace(logging.INFO, f"is string: {career}")
        db_career = db.query(models.Careers).filter(models.Careers.career_name==career).first()
        # log_trace(logging.INFO, db_career)
        return db_career
    return None

##########################################################################################
################################ Student-Career Ops ######################################
##########################################################################################

def get_user_from_student_id(db: Session, student_id: int):
    # Get the student record
    student_record = get_student(db, student_id=student_id)
    if student_record is None:
        # Should not happen ever
        log_trace(logging.ERROR, f"Unexpected error finding student record for {student_id}")
        return
    user_id = student_record.user_id
    user = get_user(db, user_id=user_id)
    return user

def get_user_following(db: Session, user: models.User):
    if user:
        return user.following
    return None

def update_student_career_intersections(db: Session, student_career: models.StudentCareers):
    # Get the user_id for the student
    student = db.query(models.Student).filter(models.Student.id == student_career.student_id).first()
    if not student:
        print(f"No student found with id {student_career.student_id}")
        return
    user_id = student.user_id

    # Find all friends who have saved this career
    friends_with_same_career = db.query(models.StudentCareers.student_id).\
        join(models.Student, models.Student.id == models.StudentCareers.student_id).\
        join(models.User, models.User.id == models.Student.user_id).\
        join(models.Follows, models.Follows.following_id == models.User.id).\
        filter(models.Follows.user_id == user_id).\
        filter(models.StudentCareers.career_id == student_career.career_id).\
        all()
    
    # Add intersections for the student
    for friend in friends_with_same_career:
        friend_user = db.query(models.User).join(models.Student).filter(models.Student.id == friend.student_id).first()
        if friend_user:
            intersection = models.StudentCareerIntersections(
                student_career_id=student_career.id,
                friend_user_id=friend_user.id
            )
            db.merge(intersection)

            # Add reciprocal intersection
            friend_student_career = db.query(models.StudentCareers).filter(
                models.StudentCareers.student_id == friend.student_id,
                models.StudentCareers.career_id == student_career.career_id
            ).first()
            if friend_student_career:
                reciprocal_intersection = models.StudentCareerIntersections(
                    student_career_id=friend_student_career.id,
                    friend_user_id=user_id
                )
                db.merge(reciprocal_intersection)
    db.commit()
    return

def remove_career_intersections(db: Session, student_career: models.StudentCareers):
    # Get the user_id for the student
    student = db.query(models.Student).filter(models.Student.id == student_career.student_id).first()
    if not student:
        print(f"No student found with id {student_career.student_id}")
        return
    user_id = student.user_id

    # Remove intersections where this student_career is the main entry
    db.query(models.StudentCareerIntersections).filter(
        models.StudentCareerIntersections.student_career_id == student_career.id
    ).delete()
    # Remove intersections where this user is the friend
    db.query(models.StudentCareerIntersections).filter(
        models.StudentCareerIntersections.friend_user_id == user_id
    ).delete()
    db.commit()

def add_student_career(student_career:schemas.StudentCareerCreate,
                       db:Session):
    # student_careers = []
    # for sc in student_career:
    career = get_career(db, career=student_career.career_id)
    log_trace(logging.INFO, f"career: {career.id}")

    # Get the user corresponding to the student id
    user = get_user_from_student_id(db, student_career.student_id)
    if not user:
        log_trace(logging.ERROR, f"User not found for student_id: {student_career.student_id}")
        raise HTTPException(status_code=404, detail="User not found!")
    
    # if not career:
    #     # career = create_career(db, activity_name=activity_name)
    db_student_career = models.StudentCareers(student_id=student_career.student_id, 
                                              career_id=career.id,
                                              rank = student_career.rank)
    db.add(db_student_career)
    db.commit()
    db.refresh(db_student_career)

    # Add the student userid to the student career Users table
    db_student_career_user = models.StudentCareerUsers(student_career_id=db_student_career.id,
                                                        user_id=user.id)
    db.add(db_student_career_user)
    db.commit()
    db.refresh(db_student_career_user)

    # Find commonality with friends the user is following, update student_career_intersections
    update_student_career_intersections(db, db_student_career)
    return db_student_career

def update_student_career(db:Session, student_career:schemas.StudentCareerCreate):
    # student_careers =[]
    entry = db.query(models.StudentCareers).options(joinedload(models.StudentCareers.career)).filter(
        and_(models.StudentCareers.student_id==student_career.student_id,
                models.StudentCareers.career_id==student_career.career_id
             )).first()

    if not entry:
        return False

    if student_career.rank != entry.rank:
        entry.rank = student_career.rank

    db.add(entry)
    db.commit()
    db.refresh(entry)
    # student_careers.append(entry)
    return entry

def delete_student_career(db:Session,student_career:schemas.StudentCareerDelete):
    db_student_career = db.query(models.StudentCareers).filter(
        and_(student_career.career_id==models.StudentCareers.career_id,
             student_career.student_id==models.StudentCareers.student_id)
    ).first()
    if not db_student_career:
        return False
    log_trace(logging.INFO, db_student_career)
    # Remove any career intersections for this saved career
    remove_career_intersections(db=db, student_career=db_student_career)
    
    # Remove any entries for this student_career in student career users table
    remove_student_career_users(db, db_student_career.id)

    # Now delete this saved career
    db.delete(db_student_career)
    db.commit()
    return True

def get_student_career_by_id(db: Session, student_career_id: int):
    db_student_career = db.query(models.StudentCareers).filter(models.StudentCareers.id == student_career_id).first()
    return db_student_career

def get_student_career(db:Session, student_career: schemas.StudentCareerCreate):
    db_student_career = db.query(models.StudentCareers).options(joinedload(models.StudentCareers.career)).filter(
        and_(models.StudentCareers.career_id==student_career.career_id,
             models.StudentCareers.student_id==student_career.student_id)
    ).first()
    return db_student_career

def get_student_careers(db:Session, student_id: int):
    db_student_careers = (db.query(models.StudentCareers). \
                          options(joinedload(models.StudentCareers.career)). \
                          filter(models.StudentCareers.student_id==student_id). \
                          all())
    print(db_student_careers)
    return db_student_careers

def get_username_and_profile_pic(db: Session, user_id: int):
    user = get_user(db, user_id)
    if not user:
        # Question: Should we skip the post if the user is not found? Or throw an error?
        log_trace(logging.ERROR, f"User not found! user_id: {user_id}")
        raise HTTPException(status_code=404, detail=f"User not found!")
    
    return user.username, user.profile_pic_url

def get_student_career_intersections(db: Session, student_career_id: int):
    student_career_intersections = db.query(models.StudentCareerIntersections)\
                                        .filter(models.StudentCareerIntersections.student_career_id == student_career_id).all()
    if student_career_intersections is None:
        return []
    intersections = []
    for intersection in student_career_intersections:
        user_id = intersection.friend_user_id
        new_intersection = intersection.__dict__
        # Augment intersection with username, profile pic url
        new_intersection['username'], new_intersection['profile_pic_url'] = get_username_and_profile_pic(db=db, user_id=user_id)
        intersections.append(new_intersection)
    return intersections

def get_student_career_intersections_paginated(db: Session, student_career_id: int,
                                               page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    offset = (page_num - 1) * limit

    query = db.query(models.StudentCareerIntersections)\
                    .filter(models.StudentCareerIntersections.student_career_id == student_career_id)
    total_count = query.count()  # Obtain the total count without fetching all records

    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()
    # Update results with username
    career_intersections = []
    for entry in results:
        user_id = entry.friend_user_id
        new_intersection = entry.__dict__
        # Augment intersection with username, profile pic url
        new_intersection['username'], new_intersection['profile_pic_url'] = get_username_and_profile_pic(db=db, user_id=user_id)
        career_intersections.append(new_intersection)

    return [total_count, career_intersections]

##########################################################################################
################################ Target-School Ops ######################################
##########################################################################################

# Add a college we dont have in our DB.
# TBD: We need to find the supplementary info about the college.
def add_target_school(db: Session, college_name: str):
    log_trace(logging.INFO, f"Adding new college {college_name}")
    db_target_school = models.TargetSchools(college_name = college_name)
    db.add(db_target_school)
    db.commit()
    db.refresh(db_target_school)
    return db_target_school

def get_target_school(db: Session, target_school_id: int):
    db_target_school = db.query(models.TargetSchools).filter(models.TargetSchools.id==target_school_id).first()
    return db_target_school

##########################################################################################
################################ Student-Target-School Ops ######################################
##########################################################################################

def augment_student_target_school_with_intersections(db, student_target_school):
    friends_info = None
    if student_target_school:
        id = student_target_school["college_id"]
        log_trace(logging.INFO, f"Get friends also interested in this college {id}")
        # Get friends who have saved these colleges
        friends_info = get_student_target_school_intersections(db=db,
                                                               student_target_school_id=student_target_school["id"])                         
    if friends_info and len(friends_info) > 0:
        student_target_school['friends_info_count'] = len(friends_info)
        student_target_school['friends_info'] = friends_info
    else:
        student_target_school['friends_info_count'] = 0
        student_target_school['friends_info'] = None
    return student_target_school

def augment_student_target_school_with_school_info(db, student_target_school: schemas.StudentTargetSchool):
    result_target_school = student_target_school.__dict__
    # We need to add these two keys to the dict
    result_target_school["college_url"] = ""
    result_target_school["college_pic_url"] = ""

    db_target_school = db.query(models.TargetSchools).filter(models.TargetSchools.id == student_target_school.college_id).first()
    if not db_target_school:
        #raise HTTPException(status_code=404, detail="Invalid college: College not found")
        return result_target_school

    result_target_school["college_url"] = db_target_school.college_pic_url
    result_target_school["college_pic_url"] = db_target_school.college_pic_url
    return result_target_school

def add_student_target_school(student_target_school:schemas.StudentTargetSchoolCreate,
                       db:Session):
    # Get college info
    similarity_threshold = 0.9
    c_name = clean_college_name(student_target_school.college_name)
    db_target_school = db.query(models.TargetSchools).filter(
        or_(
            models.TargetSchools.college_name.ilike(c_name),
            func.similarity(models.TargetSchools.college_name, c_name) > similarity_threshold)
        ).first()
    
    if not db_target_school:
        # Add the college
        db_target_school = add_target_school(db, college_name=c_name)
        if not db_target_school:
            raise HTTPException(status_code=404, detail="Error adding college!")

    # Get the user corresponding to the student id
    user = get_user_from_student_id(db, student_target_school.student_id)
    if not user:
        log_trace(logging.ERROR, f"User not found for student_id: {student_target_school.student_id}")
        raise HTTPException(status_code=404, detail="User not found!")
    
    college_id = db_target_school.id
    log_trace(logging.INFO, f"College id is {college_id}")
    db_student_target_school = models.StudentTargetSchools(student_id=student_target_school.student_id, 
                                            career_id=student_target_school.career_id,
                                            rank = student_target_school.rank,
                                            college_name = student_target_school.college_name,
                                            college_id = college_id,
                                            tution_fees = student_target_school.tution_fees,
                                            probability_of_admission=student_target_school.probability_of_admission,
                                            positives = student_target_school.positives,
                                            negatives = student_target_school.negatives,
                                            classification = student_target_school.classification,
                                            acceptance_rate = student_target_school.acceptance_rate,
                                            why_this_recommendation = student_target_school.why_this_recommendation)
    db.add(db_student_target_school)
    db.commit()
    db.refresh(db_student_target_school)

    # Add the student userid to the student target school Users table
    db_student_target_school_user = models.StudentTargetSchoolsUsers(student_target_school_id=db_student_target_school.id,
                                                                        user_id=user.id)
    db.add(db_student_target_school_user)
    db.commit()
    db.refresh(db_student_target_school_user)
    # Update target school intersections
    update_school_intersections_on_new_target_school(db, db_student_target_school)
    
    # Track the  saved student recommendation data to analytic
    student = get_student(db, student_target_school.student_id)
    analytic_data.track_college_recommendations(student.user_id, student_target_school.dict())

    # Augment the student target school record with the college url and other info
    student_target_school_result = augment_student_target_school_with_school_info(db,
                                                                                  student_target_school=db_student_target_school)
    student_target_school_result = augment_student_target_school_with_intersections(db,
                                                                                    student_target_school_result)
    return student_target_school_result

def update_student_target_school(db:Session, student_target_school:schemas.StudentTargetSchoolCreate):    
    entry = db.query(models.StudentTargetSchools).filter(
        and_(and_(models.StudentTargetSchools.student_id==student_target_school.student_id,
                models.StudentTargetSchools.career_id==student_target_school.career_id)
            ),models.StudentTargetSchools.college_name==student_target_school.college_name).first()
    log_trace(logging.INFO, entry)
    if not entry:
        return False
    if student_target_school.rank!=entry.rank:
        entry.rank = student_target_school.rank 
    db.add(entry)
    db.commit()
    db.refresh(entry)
    # Augment the student target school record with the college url and other info
    student_target_school_result = augment_student_target_school_with_school_info(db,
                                                                                  student_target_school=entry)
    student_target_school_result = augment_student_target_school_with_intersections(db,
                                                                                    student_target_school_result)
    # Track the  saved student recommendation data to analytic
    student = get_student(db, student_target_school.student_id)
    analytic_data.track_college_recommendations(student.user_id, student_target_school_result)
    return student_target_school_result

def delete_student_target_school(db:Session,student_target_school:schemas.StudentTargetSchoolDelete):
    db_student_target_school = db.query(models.StudentTargetSchools).filter(
        and_(and_(student_target_school.career_id==models.StudentTargetSchools.career_id,
             student_target_school.student_id==models.StudentTargetSchools.student_id),
             student_target_school.college_name==models.StudentTargetSchools.college_name)
    ).first()
    if not db_student_target_school:
        return False
    log_trace(logging.INFO, db_student_target_school)
    # Remove any target school intersections
    remove_target_school_intersections(db, db_student_target_school)

    # Remove any entries for this student_target_school in student target school users table
    remove_student_target_school_users(db, db_student_target_school.id)

    db.delete(db_student_target_school)
    db.commit()
    # Track the delete student recommendation data to analytic
    student = get_student(db, student_target_school.student_id)
    analytic_data.track_college_recommendations(student.user_id, student_target_school.dict(), delete=True)
    return True

def get_student_target_school_by_id(db: Session, student_target_school_id: int):
    db_student_target_school = db.query(models.StudentTargetSchools)\
                                 .filter(models.StudentTargetSchools.id == student_target_school_id).first()
    return db_student_target_school

def get_student_target_schools_by_career(db:Session, student_id: int, career_id: int, college_name: str):
    c_name = clean_college_name(college_name)
    similarity_threshold = 0.9
    db_student_target_schools_by_career = db.query(models.StudentTargetSchools).filter(
        and_(
            and_(models.StudentTargetSchools.career_id==career_id,
                models.StudentTargetSchools.student_id==student_id),
            or_(models.StudentTargetSchools.college_name.ilike(c_name),
                func.similarity(models.StudentTargetSchools.college_name, c_name) > similarity_threshold))
    ).first()

    if not db_student_target_schools_by_career:
        return None
    
    res_record = augment_student_target_school_with_school_info(db,
                                                                student_target_school=db_student_target_schools_by_career)
    res_record = augment_student_target_school_with_intersections(db, res_record)
    return res_record

def get_student_target_schools(db:Session, student_id: int):
    db_student_target_schools = db.query(models.StudentTargetSchools).filter(
        models.StudentTargetSchools.student_id==student_id
    ).all()
    # db_student.careers
    # log_trace(logging.INFO, db_student_careers)
    valid_records = []
    for record in db_student_target_schools:
        res_record = augment_student_target_school_with_school_info(db, record)
        res_record = augment_student_target_school_with_intersections(db, res_record)
        valid_records.append(res_record)
    return valid_records


##########################################################################################
################################ Post Ops #############################################
##########################################################################################

def create_post(db: Session, post: schemas.PostCreate):
    db_user = db.query(models.User).filter(models.User.id==post.user_id).first()
    if not db_user:
        return None
    db_post = models.Post(**post.model_dump())
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    return db_post

def delete_post(db: Session, post_id: int):
    db_post = db.query(models.Post).filter(models.Post.id==post_id).first()
    if not db_post:
        return False
    db.delete(db_post)
    db.commit()
    return True

def update_post(db: Session, post_id: int, post:schemas.PostCreate):
    db_post = db.query(models.Post).filter(models.Post.id==post_id).first()
    if not db_post:
        return False

    db_post.post_title = post.post_title
    db_post.post_content = post.post_content
    db_post.post_content_url = post.post_content_url
    db_post.likes = post.likes
    # if (like_student_id!=0) and (like_student_id not in db_post.likes):
    #     db_post.likes.append(like_student_id)
    db.add(db_post)
    db.commit()
    db.refresh(db_post)
    return db_post

def augment_post_with_user_and_comment_count(db: Session, post: models.Post):
    new_post = post.__dict__
    # Augment post user_id with username, profile pic url
    user = get_user(db, post.user_id)
    if not user:
        # Question: Should we skip the post if the user is not found? Or throw an error?
        raise HTTPException(status_code=404, detail="Invalid Post: User not found")
    new_post = {}
    new_post = post.__dict__
    new_post['username'] = user.username
    new_post['profile_pic_url'] = user.profile_pic_url
    new_post['user_type'] = user.type

    # Get # comments on the post and add to new_post
    comment_count = get_num_comments_of_post(db, post.id)
    new_post['comment_count'] = comment_count
    return new_post

# Filter out posts by users marked for delete
def get_posts(db: Session, skip: int = 0, limit: int = 100):
    # Define an alias for the User table to avoid naming conflicts
    user_alias = alias(models.User)

    # Skips posts by users marked for delete
    posts = db.query(models.Post) \
               .join(user_alias, models.Post.user_id == user_alias.c.id) \
               .filter(user_alias.c.is_active == True) \
               .offset(skip) \
               .limit(limit) \
               .all() 
    
    if posts is None:
        return []
    
    log_trace(logging.INFO, posts)
    user_posts = []
    for entry in posts:        
        user_post = augment_post_with_user_and_comment_count(db, entry)
        user_posts.append(user_post)
    return user_posts

# Get records by page # and limit
# Filter out posts by users marked for delete
def get_posts_paginated(db: Session, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    offset = (page_num - 1) * limit

    # Define an alias for the User table to avoid naming conflicts
    user_alias = alias(models.User)

    # Skips posts by users marked for delete
    query = db.query(models.Post) \
                .join(user_alias, models.Post.user_id == user_alias.c.id) \
                .filter(user_alias.c.is_active == True)
    total_count = query.count()  # Obtain the total count without fetching all records
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()

    # Update results with username
    user_posts = []
    for entry in results:
        user_post = augment_post_with_user_and_comment_count(db, entry)
        user_posts.append(user_post)

    return [total_count, user_posts]

# If the post's owner is a user marked for delete, return None
def get_post(db: Session, post: [int,str]):
    if isinstance(post,int):
        post = db.query(models.Post).filter(models.Post.id==post).first()
    elif isinstance(post,str):
        post = db.query(models.Post).filter(models.Post.post_title==post).first()
    else:
        return None
    if not post:
        return None
    
    # If the user who created the post is marked for delete, return None
    if not is_user_active(db, post.user_id):
        return None
    
    # Augment post with username, profile_pic_url and comment count
    post_result = augment_post_with_user_and_comment_count(db, post)
    return post_result

# If the post's owner is a user marked for delete, return None
def get_post_by_uid(db: Session, user_id: int):
    if not is_user_active(db, user_id):
        return None
    
    posts = db.query(models.Post).filter(models.Post.user_id==user_id).all()
    user_posts = []
    for entry in posts:
        user_post = augment_post_with_user_and_comment_count(db, entry)
        user_posts.append(user_post)
    return user_posts

# If the post's owner is a user marked for delete, return None
def get_post_by_uid_paginated(db: Session, user_id: int, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20), sorted: bool = False):
    if not is_user_active(db, user_id):
        return None
    
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    
    offset = (page_num - 1) * limit

    # Define the query
    query = db.query(models.Post).filter(models.Post.user_id==user_id)
    if sorted:
        log_trace(logging.INFO, "Sorting by date_published")
        query = query.order_by(models.Post.date_published.desc())
    total_count = query.count()  # Obtain the total count without fetching all records
    
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()

    # Update results with username
    user_posts = []
    for entry in results:
        user_post = augment_post_with_user_and_comment_count(db, entry)
        user_posts.append(user_post)

    return [total_count, user_posts]

# Filter out posts by users marked for delete
def get_all_posts_sorted_by_date_published(db: Session, skip: int = 0, limit: int = 100):
    # Define an alias for the User table to avoid naming conflicts
    user_alias = alias(models.User)

    posts = db.query(models.Post) \
                    .join(user_alias, models.Post.user_id == user_alias.c.id) \
                    .filter(user_alias.c.is_active == True) \
                    .order_by(models.Post.date_published.desc()).offset(skip).limit(limit).all()
    
    user_posts = []
    for entry in posts:
        user_post = augment_post_with_user_and_comment_count(db, entry)
        user_posts.append(user_post)
    return user_posts

# Filter out posts by users marked for delete
def get_all_posts_paginated_and_sorted_by_date_published(db, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    
    offset = (page_num - 1) * limit

    # Define an alias for the User table to avoid naming conflicts
    user_alias = alias(models.User)

    # Define the query
    query = db.query(models.Post) \
                    .join(user_alias, models.Post.user_id == user_alias.c.id) \
                    .filter(user_alias.c.is_active == True) \
                    .order_by(models.Post.date_published.desc())
    total_count = query.count()  # Obtain the total count without fetching all records
    
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()

    # Update results with username
    user_posts = []
    for entry in results:
        user_post = augment_post_with_user_and_comment_count(db, entry)
        user_posts.append(user_post)
    return [total_count, user_posts]

##########################################################################################
################################ Comment Ops #############################################
##########################################################################################

def create_comment(db: Session, comment: schemas.CommentCreate):
    db_comment = models.Comment(**comment.model_dump())
    db.add(db_comment)
    db.commit()
    db.refresh(db_comment)
    return db_comment

def delete_comment(db: Session, comment_id: int):
    db_comment = db.query(models.Comment).filter(models.Comment.id==comment_id).first()
    if not db_comment:
        return False
    db.delete(db_comment)
    db.commit()
    return True

def update_comment(db: Session, comment_id: int, comment:schemas.CommentCreate):
    db_comment = db.query(models.Comment).filter(models.Comment.id==comment_id).first()
    if not db_comment:
        return False
    db_comment.content = comment.content
    db_comment.content_url = comment.content_url
    db_comment.likes = comment.likes
    # if (like_student_id!=0) and (like_student_id not in db_post.likes):
    #     db_post.likes.append(like_student_id)
    db.add(db_comment)
    db.commit()
    db.refresh(db_comment)
    return db_comment

def augment_comment_with_user(db: Session, comment: models.Comment):
    new_comment = comment.__dict__
    # Augment comment user_id with username, profile pic url
    user = get_user(db, comment.user_id)
    if not user:
        # Question: Should we skip the post if the user is not found? Or throw an error?
        raise HTTPException(status_code=404, detail="Invalid Comment: User not found")
    
    new_comment['username'] = user.username
    new_comment['profile_pic_url'] = user.profile_pic_url
    new_comment['user_type'] = user.type
    return new_comment

# Filter out comments by users marked for delete
def get_comments(db: Session, skip: int = 0, limit: int = 100):
    # Define an alias for the User table to avoid naming conflicts
    user_alias = alias(models.User)

    # Augment comments with username, profile_pic_url
    comments = db.query(models.Comment) \
        .join(user_alias, models.Comment.user_id == user_alias.c.id) \
        .filter(user_alias.c.is_active == True) \
        .offset(skip).limit(limit).all()
    
    user_comments = []
    for entry in comments:
        user_comment = augment_comment_with_user(db, entry)
        user_comments.append(user_comment)
    return db.query(models.Comment).offset(skip).limit(limit).all()

# If the comment's owner is a user marked for delete, return None
def get_comment(db: Session, comment: [int,str]):
    if isinstance(comment,int):
        comment = db.query(models.Comment).filter(models.Comment.id==comment).first()
        if not is_user_active(db, comment.user_id):
            return None
        
        return augment_comment_with_user(db, comment)
    else:
        return None

# Don't count comments by users marked for delete
def get_num_comments_of_post(db: Session, post_id: int):
    # Define an alias for the User table to avoid naming conflicts
    user_alias = alias(models.User)

    return db.query(models.Comment) \
        .filter(models.Comment.post_id==post_id) \
        .join(user_alias, models.Comment.user_id == user_alias.c.id) \
        .filter(user_alias.c.is_active == True) \
        .count()

# Filter out comments by users marked for delete
def get_comments_of_post(db: Session, post_id: int):
    # Define an alias for the User table to avoid naming conflicts
    user_alias = alias(models.User)

    comments = db.query(models.Comment) \
            .filter(models.Comment.post_id==post_id) \
            .join(user_alias, models.Comment.user_id == user_alias.c.id) \
            .filter(user_alias.c.is_active == True) \
            .all()
    
    # Update results with username
    user_comments = []
    for entry in comments:
        user_comment = augment_comment_with_user(db, entry)
        user_comments.append(user_comment)

    return user_comments

# Filter out comments by users marked for delete
def get_comments_of_post_paginated(db: Session, post_id: int, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    
    offset = (page_num - 1) * limit
    
    # Define an alias for the User table to avoid naming conflicts
    user_alias = alias(models.User)

    # Define the query
    query = db.query(models.Comment) \
        .filter(models.Comment.post_id==post_id) \
        .join(user_alias, models.Comment.user_id == user_alias.c.id) \
        .filter(user_alias.c.is_active == True)
    
    total_count = query.count()  # Obtain the total count without fetching all records
    
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()

    # Update results with username
    user_comments = []
    for entry in results:
        user_comment = augment_comment_with_user(db, entry)
        user_comments.append(user_comment)

    return [total_count, user_comments]

def get_comments_of_user(db: Session, user_id: int):
    comments = db.query(models.Comment).filter(models.Comment.user_id==user_id).all()
    # Update results with username
    user_comments = []
    for entry in comments:
        user_comment = augment_comment_with_user(db, entry)
        user_comments.append(user_comment)

    return user_comments

def get_comments_of_user_paginated(db: Session, user_id: int, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    
    offset = (page_num - 1) * limit

    # Define the query
    query = db.query(models.Comment).filter(models.Comment.user_id==user_id)
    total_count = query.count()  # Obtain the total count without fetching all records
    
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()

    # Update results with username
    user_comments = []
    for entry in results:
        user_comment = augment_comment_with_user(db, entry)
        user_comments.append(user_comment)

    return [total_count, user_comments]

##########################################################################################
################################ News Ops #############################################

def create_news_post(db: Session, news: schemas.NewsCreate):
    #Check if the news exists
    db_news = db.query(models.NewsPost).filter(models.NewsPost.news_title==news.news_title).first()
    if db_news:
        # if it exists, return the existing news
        return db_news

    db_news = models.NewsPost(**news.model_dump())
    db.add(db_news)
    db.commit()
    db.refresh(db_news)
    return db_news

def get_news_post(db: Session, news: [int,str]):
    if isinstance(news,int):
        db_news = db.query(models.NewsPost).filter(models.NewsPost.id==news).first()
    elif isinstance(news,str):
        db_news = db.query(models.NewsPost).filter(models.NewsPost.news_title==news).first()
    else:
        return None
    if not db_news:
        return None
    return db_news

def get_news_post_by_id(db: Session, news_id: int):
    db_news = db.query(models.NewsPost).filter(models.NewsPost.id==news_id).first()
    if not db_news:
        return None
    return db_news

def delete_news_post_id(db: Session, news_id: int):
    db_news = db.query(models.NewsPost).filter(models.NewsPost.id==news_id).first()
    if db_news:
        db.delete(db_news)
        db.commit()
    return True

def delete_news_post(db: Session, news_title: str):       
    db_news = db.query(models.NewsPost).filter(models.NewsPost.news_title==news_title).first()
    if db_news:
        db.delete(db_news)
        db.commit()
    return True

def get_news_comment(db: Session, news_comment_id: int):
    db_news_comment = db.query(models.NewsComment).options(joinedload(models.NewsComment.likes)).filter(models.NewsComment.id==news_comment_id).first()
    if not db_news_comment:
        return None
    return db_news_comment

def get_news_comments(db: Session, news_id: int):
    db_news_comments = db.query(models.NewsComment). \
                        options(joinedload(models.NewsComment.likes)). \
                        order_by(models.NewsComment.date_published.desc()). \
                        filter(models.NewsComment.news_id==news_id). \
                        all()
    if not db_news_comments:
        return []
    return db_news_comments

def delete_news_comment(db: Session, news_comment_id: int):
    db_news_comment = db.query(models.NewsComment).filter(models.NewsComment.id==news_comment_id).first()
    if db_news_comment:
        db.delete(db_news_comment)
        db.commit()
    return True

def get_num_news_comments(db: Session, news_id: int):
    user_alias = alias(models.User)
    return db.query(models.NewsComment) \
        .filter(models.NewsComment.news_id==news_id) \
        .join(user_alias, models.NewsComment.user_id == user_alias.c.id) \
        .filter(user_alias.c.is_active == True) \
        .count()

def get_news_augmented_with_comment_count(db: Session, news: models.NewsPost):
    new_news = news.__dict__
    # Get num of comments on the news and add to new_news
    comment_count = get_num_news_comments(db, news.id)
    new_news['comment_count'] = comment_count
    return new_news


def get_news_paginated(db: Session, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    
    offset = (page_num - 1) * limit
    query = db.query(models.NewsPost).options(joinedload(models.NewsPost.likes)).order_by(models.NewsPost.news_published_date.desc())
    total_count = query.count()  # Obtain the total count without fetching all records
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()
    # extract the results into dict and add to list
    articles = []

    for entry in results:
        article = get_news_augmented_with_comment_count(db, entry)
        articles.append(article)
    return [total_count, articles]

def delete_news_comments(db: Session, news_id: int):
    db_news_comments = db.query(models.NewsComment).filter(models.NewsComment.news_id==news_id).all()
    if db_news_comments:
        for comment in db_news_comments:
            db.delete(comment)
        db.commit()
    return True

def delete_outdated_news(db: Session, threshold_date: datetime):
    # find the outdated entries
    db_news = db.query(models.NewsPost).filter(models.NewsPost.news_published_date < threshold_date).all()
    if db_news:
        for news in db_news:
            #delete the comments
            delete_news_comments(db, news.id)
            #delete the news
            db.delete(news)
        db.commit()
    return True

# Go through a list of user ids, and return a list of user_ids that are still active
def get_active_uids(db: Session, uids: list[int]):
    valid_uids = []
    for id in uids:
        # Check if user is active
        if is_user_active(db=db, user_id=id):
            # User is active
            valid_uids.append(id)
    return valid_uids

def validate_and_update_user_ids(db: Session, user: models.User):
    followers_new = get_active_uids(db, user.followers)
    following_new = get_active_uids(db, user.following)
    connections_new = get_active_uids(db, user.connections)
    counselor_connections_new = get_active_uids(db, user.counselor_connections)
    
    user.following = following_new
    user.followers = followers_new
    user.connections = connections_new
    user.counselor_connections = counselor_connections_new
    
    return user

def get_num_news_posts(db: Session):
    return db.query(models.NewsPost).count()

def process_snippet(snippet):
    nlp = spacy.load("en_core_web_sm")
    # Process the snippet using spaCy
    doc = nlp(snippet)
    # Extract named entities and their labels
    entities = [(ent.text, ent.label_) for ent in doc.ents]
    # Identify key themes (keywords) and sentiments
    keywords = []
    # Analyze the tokens in the snippet
    for token in doc:
        # Extract relevant keywords (nouns, verbs, adjectives)
        if token.pos_ in ['NOUN', 'VERB', 'ADJ'] and not token.is_stop:
            keywords.append(token.text.lower())
    main_focus = (lambda lst: [x[0] for x in lst])(entities) + keywords[:5]
    return main_focus

def get_validated_posts(db: Session, page_num: int, limit: int):
    error = None
    valid_posts = []
    invalid_records = 0
    total_count = 0
    try:
        [total_count, db_posts] = get_all_posts_paginated_and_sorted_by_date_published(db,
                                                                                       page_num=page_num,
                                                                                       limit=limit)
        log_trace(logging.INFO, f"Total posts: {total_count} num posts: {len(db_posts)}")
        for db_post in db_posts:
            try:
                # Validate each post entry with the Pydantic model
                post = schemas.PostResult(
                    id = db_post['id'],
                    type = Constants.POST_TYPE_REGULAR.value,
                    post_title = db_post['post_title'],
                    post_content = db_post['post_content'],
                    date_published = db_post['date_published'],
                    user_id = db_post['user_id'],
                    profile_pic_url=db_post['profile_pic_url'],
                    likes=db_post['likes'],
                    post_content_url=db_post['post_content_url'],
                    username=db_post['username'],
                    comment_count=db_post['comment_count']
                )
                valid_posts.append(post)
            except ValidationError as e:
                log_trace(logging.ERROR, f"validation error for id {db_post['id']} error is {str(e)}")
                # Handle entries that do not pass validation
                invalid_records = invalid_records + 1
                continue  # Skip invalid entries or log them as needed
    except Exception as e:
        error = e
    total_count = total_count - invalid_records
    log_trace(logging.INFO, f"Total posts: {total_count}")
    log_trace(logging.INFO, valid_posts)
    log_trace(logging.INFO, "Done posts")
    return valid_posts, total_count, error

def get_validated_news(db: Session, page_num: int, limit: int):
    error = None
    valid_posts = []
    invalid_records = 0
    total_count = 0
    try:
        [total_count, db_news] = get_news_paginated(db, page_num=page_num, limit=limit)
        for db_news_item in db_news:
            try:
                # Validate each post entry with the Pydantic model
                news_item = schemas.PostResult(
                    id = db_news_item['id'],
                    type = Constants.POST_TYPE_NEWS.value,
                    post_title = db_news_item['news_title'],
                    post_content = "", # No need to send anything - flutter will do url preview
                    user_id = Constants.DABBL_ADMIN.value,
                    profile_pic_url=Constants.DABBL_LOGO_NEW.value,
                    username = "dabbL Bot",
                    date_published = db_news_item['news_published_date'],
                    likes = [like.user_id for like in db_news_item['likes']],
                    post_content_url=db_news_item['news_content_url'],
                    comment_count=db_news_item['comment_count']
                )
                valid_posts.append(news_item)
            except ValidationError as e:
                # Handle entries that do not pass validation
                log_trace(logging.ERROR, f"Validation error for new {str(e)}")
                invalid_records = invalid_records + 1
                continue  # Skip invalid entries or log them as needed
    except Exception as e:
        error = e

    total_count = total_count - invalid_records
    return valid_posts, total_count, error

###########################################################################################
# Counselor APIs
###########################################################################################

def get_counselor_by_uid(db: Session,uid: int):
    counselor = db.query(models.Counselor).filter(models.Counselor.user_id==uid).first()
    if not counselor:
        return None
    # get user corresponding to this counselor
    log_trace(logging.INFO, f"User id for counselor {counselor.user_id}")
    if not is_user_active(db, uid):
        log_trace(logging.INFO, f"User not found or inactive for counselor {counselor}")
        return None
    return counselor

# Return paginated also may be needed? Return only students that are not deleted
def get_all_students_with_counselor(db: Session, counselor_id: int):
    student_counselors = db.query(models.StudentCounselor).filter(models.StudentCounselor.counselor_id == counselor_id).all()
    for rec in student_counselors:
        student = get_student(db, student_id=rec.student_id)
        if not student:
            student_counselors.remove(rec)
    return student_counselors

def get_counselor_by_id(db: Session, counselor_id: int):
    db_counselor = db.query(models.Counselor).filter(models.Counselor.id == counselor_id).first()
    if not db_counselor:
        return None
    
    if not is_user_active(db, user_id=db_counselor.user_id):
        return None
    
    # Get a list of students this counselor is guiding
    db_student_counselor = db.query(models.CounselorStudentsConnection).filter(
                                    models.CounselorStudentsConnection.counselor_id == counselor_id).all()    
    counselor = db_counselor.__dict__
    counselor['students'] = []
    db_student_counselor = get_all_students_with_counselor(db, counselor_id=counselor_id)
    for rec in db_student_counselor:
        user_id = get_student(db, student_id=rec.student_id).user_id
        if is_user_active(db, user_id=user_id):
            counselor['students'].append(rec.student_id)

    return counselor

def create_counselor(db: Session, counselor: schemas.CounselorCreate):
    db_counselor = models.Counselor(**counselor.model_dump()) 
    db.add(db_counselor)
    db.commit()
    db.refresh(db_counselor)
    return db_counselor


###########################################################################################
# JOBS API
###########################################################################################

def get_total_jobs(db: Session):
    return db.query(models.Job).count()

def get_jobs(db: Session, page_num: int, limit: int):
    offset = page_num * limit
    total_count = db.query(models.Job).count()
    jobs = db.query(models.Job).offset(offset).limit(limit).all()
    return jobs, total_count

def get_job_by_id(db: Session, job_id: int):
    return db.query(models.Job).filter(models.Job.id == job_id).first()

def get_job_by_title_and_org(db: Session, title: str, organization: str):
    return db.query(models.Job).filter(models.Job.title.ilike(title), models.Job.organization.ilike(organization)).first()

def create_job(db: Session, job: schemas.JobCreate):
    db_job = models.Job(**job.dict())
    db.add(db_job)
    db.commit()
    db.refresh(db_job)
    return db_job

def update_job(db: Session, job_id: int, updates: schemas.JobUpdate):
    db_job = get_job_by_id(db, job_id)
    if db_job:
        update_data = updates.model_dump(exclude_unset=True)
        for key, value in update_data.items():
            setattr(db_job, key, value)
        db.commit()
        db.refresh(db_job)
    return db_job

def delete_job(db: Session, job_id: int):
    db_job = get_job_by_id(db, job_id)
    if db_job:
        db.delete(db_job)
        db.commit()
    return db_job

# paginated
def search_jobs(db: Session, filter_by: str, query: str, page_num: int = 1, limit: int = 10, is_priority: Optional[bool] = None):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    
    offset = (page_num - 1) * limit
    search_query = f"%{query}%"
    filters = {
        'title': models.Job.title.ilike(search_query),
        'organization': models.Job.organization.ilike(search_query),
        'deadline': models.Job.deadline.ilike(search_query),
        'area': models.Job.area.any(query),
        'age': models.Job.age.any(query),
        'season': models.Job.season.any(query),
        'eligibility': models.Job.eligibility.any(query),
        'mode': models.Job.mode.any(query),
        'location': models.Job.location.any(query),
        'address': models.Job.address.ilike(search_query),
        'salary': models.Job.salary.ilike(search_query),
        'program_fee': models.Job.program_fee.ilike(search_query),
        'keywords': models.Job.keywords.any(query),
        'listing_type': models.Job.listing_type.any(query),
        'description': models.Job.description.ilike(search_query),
        'requirements': models.Job.requirements.ilike(search_query)
    }
    if filter_by not in filters:
        raise ValueError(f"Invalid filter field: {filter_by}")

    filter_condition = filters[filter_by]
    query = db.query(models.Job).filter(filter_condition)
    if is_priority is not None:
        query = query.filter(models.Job.is_priority == is_priority)
    
    return query.order_by(desc(models.Job.is_priority)).offset(offset).limit(limit).all()

def create_bookmark(db: Session, bookmark: schemas.BookmarkCreate):
    is_db_bookmark = db.query(models.Bookmark).filter(
        models.Bookmark.user_id == bookmark.user_id, models.Bookmark.job_id == bookmark.job_id
    ).first()

    if is_db_bookmark:
        raise HTTPException(status_code=400, detail="Job is already bookmarked by user")

    db_bookmark = models.Bookmark(**bookmark.model_dump())
    db.add(db_bookmark)
    db.commit()
    db.refresh(db_bookmark)
    return db_bookmark

# paginated
def get_bookmarked_jobs(db: Session, user_id: int, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    offset = (page_num - 1) * limit
    query = db.query(models.Bookmark).filter(models.Bookmark.user_id == user_id)
    total_count = query.count()
    return [total_count, query.offset(offset).limit(limit).all()]

def delete_bookmark(db: Session, user_id: int, job_id: int):
    db_bookmark = db.query(models.Bookmark).filter(models.Bookmark.user_id == user_id, models.Bookmark.job_id == job_id).first()
    if db_bookmark:
        db.delete(db_bookmark)
        db.commit()
    return db_bookmark

def delete_outdated_jobs(db: Session):
    current_time = datetime.now()
    jobs_to_delete = []

    all_jobs = db.query(models.Job).all()
    for job in all_jobs:
        try:
            job_deadline = dparser.parse(job.deadline, fuzzy=True)
            if job_deadline < current_time:
                jobs_to_delete.append(job)
                print(f"Deleting job: {job.title} with deadline {job.deadline}")
        except ValueError:
            continue

    deleted_count = 0
    for job in jobs_to_delete:
        db.delete(job)
        deleted_count += 1
    
    db.commit()
    return deleted_count

def update_job_priority(db: Session, job_id: int, is_priority: bool):
    job = db.query(models.Job).filter(models.Job.id == job_id).first()
    if not job:
        return None
    job.is_priority = is_priority
    db.commit()
    db.refresh(job)
    return job


def create_counselor_student_connect_record(db: Session, counselor_id: int, counselor_name: str, counselor_email: str,
                                            student: schemas.StudentDetails, token: str):
    try:
        # Create a record for CounselorStudentsConnection
        current_time = datetime.now(ZoneInfo("UTC"))
        current_date = current_time.date()
        counselor_student = models.CounselorStudentsConnection(counselor_id = counselor_id,
                                                            counselor_name = counselor_name,
                                                            counselor_email = counselor_email,
                                                            student_name = student.student_name,
                                                            student_email = student.student_email,
                                                            parent_email = student.parent_email,
                                                            token = token,
                                                            expiration = current_time + timedelta(days=1),  # Token expires in 1 day
                                                            connect_request_date =  current_date,
                                                            connect_approve_date = None,
                                                            status = Constants.CONN_STATUS_NOT_INITIATED.value)
        db.add(counselor_student)
        db.flush()  # This will allow us to see any database-level errors before committing
        db.commit()
        db.refresh(counselor_student)
        log_trace(logging.INFO, f"Record inserted successfully. ID: {counselor_student.id} {counselor_student.token}")
        return counselor_student
    except SQLAlchemyError as e:
        db.rollback()
        log_trace(logging.ERROR, f"An error occurred: {str(e)}")
        return None


def is_student_minor(birthdate: datetime):
    today = date.today()
    age = today.year - birthdate.year - (
                (today.month, today.day) < (birthdate.month, birthdate.day))
    if age < 18:
        return True

    return False

def send_connection_to_a_student(db: Session,
                                 connect_req: schemas.CounselorStudentConnectRequest,
                                 student: schemas.StudentDetails,
                                 counselor_user_info: schemas.User,
                                 host: str,
                                 request_id: str):
    try:
        log_trace(logging.INFO, f"Processing connection for student {student.student_name}")
        
        counselor_id = connect_req.counselor_id
        counselor_name = counselor_user_info.first_name + " " + counselor_user_info.last_name
        counselor_email = counselor_user_info.email
        student_name = student.student_name
        student_email = student.student_email
        parent_email = student.parent_email
        log_trace(
            logging.INFO,
            f"{counselor_id} {counselor_name} {counselor_email} {student_name} {student_email} {parent_email}")
        
        existing_connection_req = get_counselor_connect_with_student_request_status(
            db, connect_req.counselor_id, student.student_email)

        if (existing_connection_req):
            log_trace(logging.INFO, f"There is an existing connection request")
            # Check if the existing request is still pending
            if (existing_connection_req.status == Constants.CONN_STATUS_CONNECTED.value):
                message = f"You're already connected with {student.student_name}"
                log_trace(logging.INFO, message)
                return None, message
            elif (existing_connection_req.status == Constants.CONN_STATUS_PENDING.value):
                message = f"You have already sent connection request to {student.student_name}"
                log_trace(logging.INFO, message)
                return None, message

        # Check if the student exists. Do not send any response if the student is not recognized
        student_info = get_student_by_username_or_email(db, email=student.student_email, username=None)
        if not student_info:
            message = f"No student record found for email: {student.student_email}"
            log_trace(logging.ERROR, message)
            return None, message
        
        student_user_info = get_user_by_username_or_email(db, email=student.student_email, username=None)
        # student_is_minor = is_student_minor(student_user_info.birthdate)
        student_is_minor = student_user_info.is_minor
        if student_is_minor and normalize_email(student_user_info.parent_email) != normalize_email(student.parent_email):
            log_trace(logging.ERROR, f"Mismatch in the student parent email")
            message = f"Mismatch in the student parent email for student: {student.student_name}"                
            return None, message

        # Call the webhook API
        encoded_str = ses_utils.create_encoded_string(
            counselor_id,
            counselor_name,
            counselor_email,
            student_name,
            student_email,
            parent_email,
            request_id,
        )
        token = secrets.token_urlsafe(32)  # Generate a secure token
        webhook_url = f"{host}/{Constants.COUNSELOR_APPROVAL_URL.value}?token={token}&val={encoded_str}"
        log_trace(logging.INFO, f"webhook url is {webhook_url}")
        log_trace(logging.INFO, f"Token is {token}")

        if existing_connection_req:
            # Update Connect Request Date
            current_time = datetime.now(ZoneInfo("UTC"))
            current_date = current_time.date()
            existing_connection_req.connect_request_date = current_date

            # Update token & expiration time
            existing_connection_req.token = token
            existing_connection_req.expiration = current_time + timedelta(days=1)
            existing_connection_req.connect_reject_date = None

            counselor_student_connect_record = existing_connection_req
        else:
            counselor_student_connect_record = (
                create_counselor_student_connect_record(
                    db,
                    counselor_id=counselor_id,
                    counselor_name=counselor_name,
                    counselor_email=counselor_email,
                    student=student,
                    token=token))

        try:
            if student_is_minor:
                # Send Email
                services.send_approval_request_email(
                    url=webhook_url,
                    recipient_email=student.parent_email)
            else:
                NotificationHandler().create_notification(
                    db=db,
                    notification=schemas.NotificationCreate(
                        user_id=student_user_info.id,
                        title="New Connection Request",
                        message=f"You have a connect request from {counselor_name}",
                        type="connection_request",
                        send_time = datetime.now(timezone.utc),
                        data={
                            "token": token,
                            "val": encoded_str
                        }
                        )
                )
        except Exception as e:
            message = "Connect request failed for student {student.student_name}: {str(e)}"
            log_trace(logging.ERROR, f"Unexpected error notifying the student of the connection request: {str(e)}")
            db.rollback()
            return None, message
        
        # Successfully initiated a connection request, change status to pending
        counselor_student_connect_record.status = (
            Constants.CONN_STATUS_PENDING.value
        )
        db.add(counselor_student_connect_record)
        db.commit()
        db.refresh(counselor_student_connect_record)

        message = f"Connection request sent successfully for student: {student.student_name}"
        log_trace(
            logging.INFO,
            f"Connect request sent successfully. ID: {counselor_student_connect_record.id}")
        return counselor_student_connect_record, message

    except HTTPException as error:
        message = f"Connect request failed for student {student.student_name}: {error.detail}"
        return None, message
    
    except Exception as e:
        message = f"Unknown error sending connection request to student {student.student_name}: {e}"
        # return wrap_response(data=None, message=message, code=404, error=str(e))
        return None, message
    
def send_counselor_connect_requests(
    db: Session,
    host: str,
    request_id: str,
    connect_req: schemas.CounselorStudentConnectRequest):
    try:
        successful_connection_requests = 0
        connection_requests_sent = []
        counselor = get_counselor_by_id(db, connect_req.counselor_id)
        if not counselor:
            message = "Counselor not found"
            log_trace(logging.ERROR, f"Counselor with id: {connect_req.counselor_id} not found")
            return wrap_response(message=message, data=connection_requests_sent, code=404,
                                 error={"exception": "InternalServerError",
                                        "message": "Unknown error"})
        counselor_user_info = get_user(db, counselor["user_id"])
        if counselor_user_info is None:
            # Internal server error: something that wasnt expected to be none is.
            message = f"Unexpected error getting counselor information for user_id: {counselor['user_id']}"
            log_trace(logging.ERROR, message)
            return wrap_response(message=message, data=connection_requests_sent, code=500,
                                 error={"exception": "InternalServerError",
                                        "message": "Unknown error"})
        
        if len(connect_req.student_details) > 1:
        # Go through each student info and send connection approval request
            for student in connect_req.student_details:
                connection_record, message = send_connection_to_a_student(db, connect_req=connect_req,
                                                                          student=student,
                                                                          counselor_user_info=counselor_user_info,
                                                                          host=host,
                                                                          request_id=request_id)
                if connection_record:
                    successful_connection_requests = successful_connection_requests + 1
                connection_requests_sent.append(connection_record)
            return JSONResponse(
                status_code=200,
                content={
                    "message": f"Connection requests sent successfully: {successful_connection_requests}",
                    "data": connection_requests_sent,
                    "statusCode": 200,
                    "error": {}
                }
            )
        else:
            # Single student connection request
            student = connect_req.student_details[0]
            connection_record, message = send_connection_to_a_student(db, connect_req=connect_req,
                                                                      student=student,
                                                                      counselor_user_info=counselor_user_info,
                                                                      host=host,
                                                                      request_id=request_id)
            if connection_record:
                return wrap_response(data=connection_record, message=message, code=200, error=None)
            else:
                if "Mismatch" in message:
                    # Dont report an external error.
                    return wrap_response(data=connection_record, message="", code=200, error=None)
                else:
                    err_message = f"Error sending connection request to student {student.student_name}"
                    return wrap_response(data=connection_record, message=err_message, code=404,
                                        error={"exception": "InternalServerError",
                                                "message": message})
            
    except HTTPException as error:
        message = f"Failed to send connection request: {error.detail}"
        return wrap_response(data=connection_requests_sent, message=message, code=404, error={
                                "exception": "InternalServerError",
                                "message": str(error)})

    except Exception as e:
        message = f"Unknown error sending connection request: {e}"
        return wrap_response(data=connection_requests_sent, message=message, code=404,
                             error={"exception": "InternalServerError", "message":str(e)})


def get_counselor_connect_with_student_request_status(
    db: Session, counselor_id: int, student_email: str):
    students = (
        db.query(models.CounselorStudentsConnection).filter(and_(
            models.CounselorStudentsConnection.counselor_id == counselor_id,
            models.CounselorStudentsConnection.student_email == student_email)
        )
        .first()
    )
    return students


def get_counselor_connect_with_students_all_request_status(db: Session, counselor_id: int):
    # First, get all relevant CounselorStudentsConnection records
    connections = db.query(models.CounselorStudentsConnection).filter(
        models.CounselorStudentsConnection.counselor_id == counselor_id
    ).all()

    student_connections = []
    for conn in connections:
        conn_dict = conn.__dict__
        conn_dict['student_email'] = normalize_email(conn.student_email)

        student = (db.query(models.User.id.label('user_id'),
                            models.Student.id.label('student_id'))
                            .join(models.Student, models.Student.user_id == models.User.id)
                            .filter(models.User.normalized_email == conn_dict['student_email'])).first()
        if student:
            conn_dict['user_id'] = student.user_id
            conn_dict['student_id'] = student.student_id
            student_connections.append(conn_dict)

    result = []
    for connection in student_connections:
        school_info = db.query(models.StudentSchool).filter(and_(
                                models.StudentSchool.student_id == connection['student_id'],
                                models.StudentSchool.is_primary == True
                                )).first()
        current_grade = ''
        if school_info:
            current_grade = school_info.current_grade
        connection['current_grade'] = current_grade
        result.append(connection)

    return result

    # students = (db.query(models.CounselorStudentsConnection,
    #                      models.User.id.label('user_id'),
    #                      models.Student.id.label('student_id'))
    #     .join(models.User, models.User.normalized_email == func.normalize_email(models.CounselorStudentsConnection.student_email))
    #     .join(models.Student, models.Student.user_id == models.User.id)
    #     .filter(models.CounselorStudentsConnection.counselor_id == counselor_id)
    #     .all()
    # )
    
    # Format the results
    # result = []
    # for connection, user_id, student_id in students:
    #     connection_dict = connection.__dict__
    #     school_info = db.query(models.StudentSchool).filter(and_(
    #         models.StudentSchool.student_id == student_id,
    #         models.StudentSchool.is_primary == True
    #     )).first()
    #     current_grade = ''
    #     if school_info:
    #         current_grade = school_info.current_grade
    #     connection_dict['user_id'] = user_id
    #     connection_dict['student_id'] = student_id
    #     connection_dict['current_grade'] = current_grade
    #     result.append(connection_dict)

def get_counselor_connect_request(db: Session, counselor_id: int, token: str):
    conn_req = db.query(models.CounselorStudentsConnection) \
                        .filter(and_(models.CounselorStudentsConnection.token == token,
                                     models.CounselorStudentsConnection.counselor_id == counselor_id)).first()
    if not conn_req:
        return None

    return conn_req

def get_counselor_connection_request_by_id(db: Session, counselor_connection_request_id: int):
    return db.query(models.CounselorStudentsConnection) \
                    .filter(models.CounselorStudentsConnection.id == counselor_connection_request_id).first()

def update_counselor_connection_request(db: Session, counselor_id: int, token: str, approved: bool):
    counselor_info = get_counselor_by_id(db, counselor_id)
    if not counselor_info:
        return

    user_info = get_user(db, counselor_info["user_id"])
    if not user_info:
        return

    log_trace(
        logging.INFO,
        f"Getting the connection req for {counselor_id} with token {token}")
    conn_req = get_counselor_connect_request(db, counselor_id, token)

    if not conn_req:
        raise HTTPException(
            status_code=400, detail="Error finding the counselor connection request")
    # Reject connection request
    if not approved:
        conn_req.connect_reject_date = datetime.now(ZoneInfo("UTC"))
        conn_req.status = Constants.CONN_STATUS_REJECTED.value
        db.add(conn_req)
        db.commit()
        expire_counselor_connect_with_student_request_token(db, conn_req)
        return "Success"

    # Accept connection request
    conn_req.connect_approve_date = datetime.now(ZoneInfo("UTC"))
    conn_req.status = Constants.CONN_STATUS_CONNECTED.value
    db.add(conn_req)
    db.commit()

    # Update student record and counselor records
    student_user = get_user_by_username_or_email(
        db, email=conn_req.student_email, username=None
    )
    if not student_user:
        raise HTTPException(
            status_code=400, detail="Error processing the counselor connection approval"
        )
    
    counselors = []
    for counselor in student_user.counselor_connections:
        counselors.append(counselor)
    counselors.append(counselor_info["user_id"])
    
    log_trace(logging.INFO, f"Appended counselor_id {counselor_id}. Counselors is now {counselors}")
    student_user.counselor_connections = counselors
    db.add(student_user)
    db.commit()
    db.refresh(student_user)

    db_student = get_student_by_uid(db, uid=student_user.id)
    if not db_student:
        raise HTTPException(
            status_code=400, detail="Error processing the counselor connection approval"
        )
    # Add a student counselor record
    student_counselor = models.StudentCounselor(
        student_id=db_student.id, counselor_id=counselor_id
    )
    db.add(student_counselor)
    db.commit()
    expire_counselor_connect_with_student_request_token(db, conn_req)
    return "Success"


def get_all_counselors(db):
    counselors = db.query(models.User).filter(
                        and_(models.User.type==Constants.DB_USER_TYPE_COUNSELOR.value),
                            (models.User.is_active == True)).all()
    return counselors

def get_all_counselors_paginated(db: Session, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    offset = (page_num - 1) * limit

    query = db.query(models.User).filter(and_(models.User.type == Constants.DB_USER_TYPE_COUNSELOR.value),
                                             (models.User.is_active == True))
    total_count = query.count()  # Obtain the total count without fetching all records
    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()
    return [total_count, results]

def validate_approval_response_token(db: Session, token: str):
    conn_req = db.query(models.CounselorStudentsConnection).filter(models.CounselorStudentsConnection.token == token).first()
    if conn_req:
        # request exists for the given token
        # Make current_time timezone-aware
        current_time = datetime.now(ZoneInfo("UTC"))
        log_trace(logging.INFO, f"expiration: {conn_req.expiration}, current time: {current_time}")

        # Ensure conn_req.expiration is also timezone-aware
        if conn_req.expiration.tzinfo is None:
            conn_req.expiration = conn_req.expiration.replace(tzinfo=ZoneInfo("UTC"))

        if conn_req.expiration > current_time:
            # Request is still valid
            return True
    
    return False


def expire_counselor_connect_with_student_request_token(db: Session, conn_req: models.CounselorStudentsConnection):
    current_time = datetime.now(ZoneInfo("UTC")).replace(tzinfo=None)
    conn_req.expiration = current_time
    db.commit()
    db.refresh(conn_req)
    return conn_req

# Add delete to remove a student from the counselor's list
def remove_student_from_counselor(db: Session, counselor_id: int, student_id: int):
    # Get the student counselor record
    student_counselor = db.query(models.StudentCounselor).filter(
        models.StudentCounselor.counselor_id == counselor_id,
        models.StudentCounselor.student_id == student_id
    ).first()
    if not student_counselor:
        log_trace(logging.ERROR, f"Student {student_id} not found in counselor's {counselor_id} list")
        return None

    # Delete the student counselor record
    db.delete(student_counselor)
    db.commit()
    log_trace(logging.INFO, f"Student {student_id} removed from counselor's {counselor_id} list")
    return student_counselor

def send_support_email(db: Session, post_id: int, user_id: int, message: str):
    user = get_user(db, user_id=user_id)
    if not user:
        raise HTTPException(status_code=400, detail="Unknown user.")

    name = user.first_name + " " + user.last_name
    email = user.email

    post_username = ""
    post_user_email = ""
    if post_id:
        # This is called to report a post - get the user info
        post = get_post(db, post=post_id)
        if not post:
            raise HTTPException(status_code=400, detail="Unknown post.")
        # Get post's details
        post_user = get_user(db, user_id=post["user_id"])
        if not post_user:
            raise HTTPException(status_code=400, detail="Unable to find user for the post {post_id}")
        post_user_email = post_user.email
        post_username = post["username"]
        email_data = f"New Support Request: Post = {post_id}, " + \
                     f"Post by user: Name = {post_username}, Email = {post_user_email}, " + \
                     f"Reported by user: Id = {user_id}, Name = {name}, Email = {email}, Reason = {message}"
    elif message:
        email_data = f"New Support Request by user: Id = {user_id}, Name = {name}, Email = {email}, Message = {message}"
    else:
        raise HTTPException(status_code=400, detail="Invalid support request.")

    # Send email using AWS SES. post_id is optional, and included when reporting a post.
    response = ""
    try:
        response = ses_client.send_email(
            Source="hello@go-dabbl.ai",
            Destination={
                'ToAddresses': [Constants.DABBL_SUPPORT_EMAIL.value],
                'CcAddresses': [],
                'BccAddresses': []
            },
            Message={
                'Body': {
                    'Text': {
                        'Data': email_data
                    }
                },
                'Subject': {
                    'Data': "Support Request"
                }
            }
        )
    except ClientError as e:
        log_trace(logging.ERROR, f"Error raising an email to support: {e.response['Error']['Message']}")
        return JSONResponse(status_code=500, content={"message": "Error sending email"})

    log_trace(logging.INFO, f"Response is {response}")
    return response


class NewsHandler:
    def get_post(self, db, news_id):
        news = db.query(models.NewsPost).filter(models.NewsPost.id == news_id).first()

        if news is None:
            raise HTTPException(status_code=404, detail="News post not found")

        return news

    def get_news_like(self, db, news_id, user_id):
        like = (
            db.query(NewsPostLike)
            .filter(NewsPostLike.post_id == news_id, NewsPostLike.user_id == user_id)
            .first()
        )
        return like

    def create_news_comment(self, db: Session, news_comment: schemas.NewsCommentCreate):
        try:
            db_news_comment = models.NewsComment(**news_comment.model_dump())
            db.add(db_news_comment)
            db.commit()
            db.refresh(db_news_comment)
            return db_news_comment
        except Exception as e:
            print(str(e))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Error creating a comment on a news post",
            )

    def get_news_comment(self, db, comment_id):
        comment = (
            db.query(models.NewsComment)
            .filter(models.NewsComment.id == comment_id)
            .first()
        )

        if comment is None:
            raise HTTPException(status_code=404, detail="News post comment not found")

        return comment

    def get_news_comments(self, db: Session, news_id: int):
        db_news_comments = (
            db.query(models.NewsComment)
            .order_by(models.NewsComment.date_published.desc())
            .filter(models.NewsComment.news_id == news_id)
            .all()
        )
        return db_news_comments

    def get_news_comment_like(self, db, comment_id, user_id):
        like = (
            db.query(models.NewsCommentLike)
            .filter(
                models.NewsCommentLike.comment_id == comment_id,
                models.NewsCommentLike.user_id == user_id,
            )
            .first()
        )

        return like


class StudentCareerHandler:
    def check_student_career_exists(self, db: Session, career_id: int):
        career = db.query(models.StudentCareers).filter(models.StudentCareers.id == career_id).first()
        if not career:
            raise HTTPException(status_code=404, detail="Selected career not found in saved careers")
        return career

    def create_comment(self, db: Session, comment: schemas.StudentCareerComment):
        try:
            # Check if the student user is alread in student users table, if not, add it
            db_student_career = db.query(models.StudentCareers).filter(models.StudentCareers.id == comment.student_career_id).first()
            if not db_student_career:
                log_trace(logging.ERROR, f"Student career not found for comment {comment.student_career_id}")
                raise HTTPException(status_code=404, detail="Invalid Comment: Student career not found")
            
            log_trace(logging.INFO, f"Got student career {db_student_career.id}")
            # Get the user id corr to the student id and use that to look in StudentCareerUsers table
            student_user = get_user_from_student_id(db, db_student_career.student_id)
            if not student_user:
                log_trace(logging.ERROR, f"Student user {db_student_career.student_id} not found for student career {comment.student_career_id}")
                raise HTTPException(status_code=404, detail="Invalid Comment: User not found")
            
            log_trace(logging.INFO, f"Got student user {student_user.id}")
            db_student_career_users = db.query(models.StudentCareerUsers).filter(
                and_(models.StudentCareerUsers.student_career_id == comment.student_career_id,
                     models.StudentCareerUsers.user_id == student_user.id)).first()
            if not db_student_career_users:
                log_trace(logging.INFO, f"Adding user {student_user.id} to student career {comment.student_career_id} users")
                db_student_career_users = models.StudentCareerUsers(
                    student_career_id = comment.student_career_id,
                    user_id = student_user.id
                )
                db.add(db_student_career_users)
                db.commit()
            else:
                log_trace(logging.INFO, f"User {student_user.id} already in student career {comment.student_career_id} users")

            try:
                with db.begin_nested():
                    log_trace(logging.INFO, f"Creating comment on saved career {comment.student_career_id}")
                    db_comment = models.StudentCareerComment(
                        user_id = comment.user_id,
                        student_career_id = comment.student_career_id,
                        content = comment.content,
                        date_published = comment.date_published,
                        content_url = comment.content_url
                    )
                    db.add(db_comment)

                    # Add to the student career users table too
                    db_student_career_users = db.query(models.StudentCareerUsers).filter(
                        and_(models.StudentCareerUsers.student_career_id == comment.student_career_id,
                            models.StudentCareerUsers.user_id == comment.user_id)).first()
                    if not db_student_career_users:
                        log_trace(logging.INFO, f"Adding user {comment.user_id} to student career {comment.student_career_id} users")
                        db_student_career_users = models.StudentCareerUsers(
                            student_career_id = comment.student_career_id,
                            user_id = comment.user_id
                        )
                        db.add(db_student_career_users)
            except Exception as e:
                log_trace(logging.ERROR, str(e))
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Error creating comment on saved career"
                )
            
            db.commit()
            db.refresh(db_comment)
            
            log_trace(logging.INFO, f"Comment created successfully. ID: {db_comment.id}")

            # Get career name from career_id
            career = db.query(models.Careers).filter(models.Careers.id == db_student_career.career_id).first()
            if not career:
                log_trace(logging.ERROR, f"Career {db_student_career.career_id} not found for student career {comment.student_career_id}")
                raise HTTPException(status_code=404, detail="Invalid Comment: Career not found")
            
            log_trace(logging.INFO, f"Got career {career.career_name}")
            # Get the user corr to the comment user id
            comment_user = get_user(db, comment.user_id)
            if not comment_user:
                log_trace(logging.ERROR, f"Comment user {comment.user_id} not found for comment {comment.id}")
                raise HTTPException(status_code=404, detail="Invalid Comment: User not found")
            
            log_trace(logging.INFO, f"Got comment user {comment_user.id}")
            # Notify all users on this student career about the new comment
            users = db.query(models.StudentCareerUsers).filter(
                models.StudentCareerUsers.student_career_id == comment.student_career_id).all()
            for user in users:
                if user.user_id != comment.user_id and is_user_active(db, user.user_id):
                    log_trace(logging.INFO, f"Creating notification for user {user.user_id} on saved career {comment.student_career_id}")
                    NotificationHandler().create_notification(
                        db=db,
                        notification=schemas.NotificationCreate(
                            user_id=user.user_id,
                            title="New Comment",
                            message=f"{comment_user.username} added a comment on a saved career {career.career_name}",
                            type="comment",
                            send_time = datetime.now(timezone.utc),
                            data={
                                "career": career.career_name,
                                # Trim career description to 80 characters
                                "comment": db_comment.content[:80],
                                "comment_user_id": db_comment.user_id,
                                "comment_id": db_comment.id,
                                "saved_career_id": db_comment.student_career_id,
                                "user_type": comment_user.type
                            }
                        )
                    )
            log_trace(logging.INFO, f"Notification created successfully for all users on saved career {comment.student_career_id}")
            return augment_comment_with_user(db, db_comment)
        except Exception as e:
            log_trace(logging.ERROR, str(e))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Error creating comment on saved career"
            )

    def augment_comment_with_user(self, db: Session, comment: models.StudentCareerComment):
        new_comment = comment.__dict__
        # Augment comment user_id with username, profile pic url
        user = get_user(db, comment.user_id)
        if not user:
            # Question: Should we skip the post if the user is not found? Or throw an error?
            raise HTTPException(status_code=404, detail="Invalid Comment: User not found")

        new_comment['username'] = user.username
        new_comment['profile_pic_url'] = user.profile_pic_url
        new_comment['user_type'] = user.type
        return new_comment

    def get_comments(self, db: Session, career_id: int):
        db_comments = (db.query(models.StudentCareerComment).
                       filter(models.StudentCareerComment.student_career_id == career_id).
                       all())

        # Update results with username
        comments = []
        for comment in db_comments:
            user_comment = self.augment_comment_with_user(db, comment)
            comments.append(user_comment)

        return comments

    def get_comments_paginated(self, db: Session,
                               career_id: int, page_num: int = Query(1, ge=1),
                               limit: int = Query(10, le=20)
                               ):
        if page_num < 1:
            raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
        if limit < 1 or limit > 20:
            raise HTTPException(status_code=400, detail="limit must be between 1 and 20")

        offset = (page_num - 1) * limit

        # Define the query
        query = (db.query(models.StudentCareerComment).
                 filter(models.StudentCareerComment.student_career_id == career_id))

        total_count = query.count()  # Obtain the total count without fetching all records

        # Now, you can proceed with the offset and limit to fetch a subset of the results
        results = query.offset(offset).limit(limit).all()

        # Update results with username
        comments = []
        for entry in results:
            comment = self.augment_comment_with_user(db, entry)
            comments.append(comment)

        return [total_count, comments]


class StudentTargetSchoolHandler:
    def check_target_school_exists(self, db: Session, target_school_id: int):
        target_school = db.query(models.StudentTargetSchools).filter(models.StudentTargetSchools.id == target_school_id).first()
        if not target_school:
            raise HTTPException(status_code=404, detail="College not found in saved colleges")
        return target_school

    def create_comment(self, db: Session, comment: schemas.StudentTargetSchoolComment):
        try:
            # Check if the student user is alread in student users table, if not, add it
            db_student_target_school = db.query(models.StudentTargetSchools).filter(models.StudentTargetSchools.id == comment.target_school_id).first()
            if not db_student_target_school:
                log_trace(logging.ERROR, f"Student target school not found for comment {comment.target_school_id}")
                raise HTTPException(status_code=404, detail="Invalid Comment: College not found for the student")
            
            # Get the user id corr to the student id and use that to look in StudentTargetSchoolsUsers table
            student_user = get_user_from_student_id(db, db_student_target_school.student_id)
            if not student_user:
                log_trace(logging.ERROR, f"Student user not found for student target school {comment.target_school_id}")
                raise HTTPException(status_code=404, detail="Invalid Comment: User not found")
            
            db_student_target_school_users = db.query(models.StudentTargetSchoolsUsers).filter(
                and_(models.StudentTargetSchoolsUsers.student_target_school_id == comment.target_school_id,
                     models.StudentTargetSchoolsUsers.user_id == student_user.id)).first()
            if not db_student_target_school_users:
                log_trace(logging.INFO, f"Adding user {student_user.id} to student target school {comment.target_school_id} users")
                db_student_target_school_users = models.StudentTargetSchoolsUsers(
                    student_target_school_id = comment.target_school_id,
                    user_id = student_user.id
                )
                db.add(db_student_target_school_users)
                db.commit()

            try:
                with db.begin_nested():
                    db_comment = models.StudentTargetSchoolsComment(
                        user_id = comment.user_id,
                        target_school_id = comment.target_school_id,
                        content = comment.content,
                        date_published = comment.date_published,
                        content_url = comment.content_url
                    )
                    db.add(db_comment)
                    
                    # Add to the student target school users table too
                    db_student_target_school_users = db.query(models.StudentTargetSchoolsUsers).filter(
                        and_(models.StudentTargetSchoolsUsers.student_target_school_id == comment.target_school_id,
                            models.StudentTargetSchoolsUsers.user_id == comment.user_id)).first()
                    if not db_student_target_school_users:
                        db_student_target_school_users = models.StudentTargetSchoolsUsers(
                            student_target_school_id = comment.target_school_id,
                            user_id = comment.user_id
                        )
                        db.add(db_student_target_school_users)
            except Exception as e:
                log_trace(logging.ERROR, str(e))
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail="Error creating a comment on a saved college"
                )
            
            db.commit()
            db.refresh(db_comment)
 
            # Get college name from college_id
            college = db.query(models.TargetSchools).filter(models.TargetSchools.id == db_student_target_school.college_id).first()
            if not college:
                log_trace(logging.ERROR, f"College {db_student_target_school.college_id} not found for student target school {comment.target_school_id}")
                raise HTTPException(status_code=404, detail="Invalid Comment: College not found")
            
            # Get the user corr to the comment user id
            comment_user = get_user(db, comment.user_id)
            if not comment_user:
                log_trace(logging.ERROR, f"Comment user {comment.user_id} not found for comment {comment.id}")
                raise HTTPException(status_code=404, detail="Invalid Comment: User not found")
            
            # Notify all users on this student target school about the new comment
            users = db.query(models.StudentTargetSchoolsUsers).filter(
                             models.StudentTargetSchoolsUsers.student_target_school_id == comment.target_school_id).all()
            for user in users:
                if user.user_id != comment.user_id and is_user_active(db, user.user_id):
                    log_trace(logging.INFO, f"Creating notification for user {user.user_id} on saved college {comment.target_school_id}")
                    NotificationHandler().create_notification(
                        db=db,
                        notification=schemas.NotificationCreate(
                            user_id=user.user_id,
                            title="New Comment",
                            message=f"{comment_user.username} added a comment on a saved college {college.college_name}",
                            type="comment",
                            send_time = datetime.now(timezone.utc),
                            data={
                                "college": college.college_name,
                                # Trim college description to 80 characters
                                "comment": db_comment.content[:80],
                                "comment_user_id": db_comment.user_id,
                                "comment_id": db_comment.id,
                                "saved_college_id": db_comment.target_school_id,
                                "user_type": comment_user.type
                            }
                        )
                    )
            return augment_comment_with_user(db, db_comment)
        except Exception as e:
            print(str(e))
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail="Error creating a comment on a saved college"
            )

    def augment_comment_with_user(self, db: Session, comment: models.StudentTargetSchoolsComment):
        new_comment = comment.__dict__
        # Augment comment user_id with username, profile pic url
        user = get_user(db, comment.user_id)
        if not user:
            # Question: Should we skip the post if the user is not found? Or throw an error?
            raise HTTPException(status_code=404, detail="Invalid Comment: User not found")

        new_comment['username'] = user.username
        new_comment['profile_pic_url'] = user.profile_pic_url
        new_comment['user_type'] = user.type
        return new_comment

    def get_comments(self, db: Session, targetschool_id: int):
        db_comments = (db.query(models.StudentTargetSchoolsComment).
                           filter(models.StudentTargetSchoolsComment.target_school_id == targetschool_id).
                           all())

        # Update results with username
        comments = []
        for comment in db_comments:
            user_comment = self.augment_comment_with_user(db, comment)
            comments.append(user_comment)

        return comments

    def get_comments_paginated(self, db: Session,
                               targetschool_id: int, page_num: int = Query(1, ge=1),
                               limit: int = Query(10, le=20)
    ):
        if page_num < 1:
            raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
        if limit < 1 or limit > 20:
            raise HTTPException(status_code=400, detail="limit must be between 1 and 20")

        offset = (page_num - 1) * limit

        # Define the query
        query = (db.query(models.StudentTargetSchoolsComment).
                 filter(models.StudentTargetSchoolsComment.target_school_id == targetschool_id))

        total_count = query.count()  # Obtain the total count without fetching all records

        # Now, you can proceed with the offset and limit to fetch a subset of the results
        results = query.offset(offset).limit(limit).all()

        # Update results with username
        comments = []
        for entry in results:
            comment = self.augment_comment_with_user(db, entry)
            comments.append(comment)

        return [total_count, comments]

#
# When a user follows another, update the career intersections and target_school intersections for both users
#
def update_intersections_on_follow(db: Session, user_id: int, following_id: int):
    # Get the students associated with the users
    student = db.query(models.Student).join(models.User).filter(models.User.id == user_id).first()
    following_student = db.query(models.Student).join(models.User).filter(models.User.id == following_id).first()

    if not student or not following_student:
        log_trace(logging.ERROR, "One or both users are not students")
        return

    # Get all careers of the followed student
    student_careers = db.query(models.StudentCareers).filter(models.StudentCareers.student_id == student.id).all()
    # Get all careers of the follower student
    following_student_careers = db.query(models.StudentCareers).filter(models.StudentCareers.student_id == following_student.id).all()

    # Create career intersections
    for student_career in student_careers:
        for following_student_career in following_student_careers:
            if student_career.career_id == following_student_career.career_id:
                # Create intersection for followed user
                intersection1 = models.StudentCareerIntersections(
                    student_career_id=student_career.id,
                    friend_user_id=following_id
                )
                db.merge(intersection1)

    # Get all target_schools of the followed student
    student_target_schools = db.query(models.StudentTargetSchools)\
                                .filter(models.StudentTargetSchools.student_id == student.id).all()
    # Get all target_schools of the follower student
    following_student_target_schools = db.query(models.StudentTargetSchools)\
                                         .filter(models.StudentTargetSchools.student_id == following_student.id).all()
    # Create target_school intersections
    for student_target_school in student_target_schools:
        for following_student_target_school in following_student_target_schools:
            if student_target_school.college_id == following_student_target_school.college_id:
                # Create target_school intersection for followed user
                intersection3 = models.StudentTargetSchoolIntersections(
                    student_target_school_id=student_target_school.id,
                    friend_user_id=following_id
                )
                db.merge(intersection3)

    # Commit all the intersections
    db.commit()

#
# When a user unfollows another, update the career intersections and target_school intersections for both users
#
def remove_intersections_on_unfollow(db: Session, user_id: int, unfollowing_id: int):
    # Get the students associated with the users
    student = db.query(models.Student).join(models.User).filter(models.User.id == user_id).first()
    unfollowing_student = db.query(models.Student).join(models.User).filter(models.User.id == unfollowing_id).first()

    if not student or not unfollowing_student:
        print("One or both users are not students")
        return

    # Remove career intersections where unfollower is the friend of unfollowed
    db.query(models.StudentCareerIntersections).filter(
        and_(
            models.StudentCareerIntersections.student_career_id == models.StudentCareers.id,
            models.StudentCareers.student_id == student.id,
            models.StudentCareerIntersections.friend_user_id == unfollowing_id
        )
    ).delete(synchronize_session=False)

    # Remove target_school intersections where unfollower is the friend of unfollowed
    db.query(models.StudentTargetSchoolIntersections).filter(
        and_(
            models.StudentTargetSchoolIntersections.student_target_school_id == models.StudentTargetSchools.id,
            models.StudentTargetSchools.student_id == student.id,
            models.StudentTargetSchoolIntersections.friend_user_id == unfollowing_id
        )
    ).delete(synchronize_session=False)

    db.commit()

#
# When a new target school is saved by a user, update the target school intersections for that school
#
def update_school_intersections_on_new_target_school(db: Session, student_target_school: models.StudentTargetSchools):
    # Get the user_id for the student
    student = db.query(models.Student).filter(models.Student.id == student_target_school.student_id).first()
    if not student:
        print(f"No student found with id {student_target_school.student_id}")
        return
    user_id = student.user_id

    # Find all friends who have saved this school
    # First, get the college_ids for this user
    user_college_ids = db.query(models.StudentTargetSchools.college_id).\
        join(models.Student, models.Student.id == models.StudentTargetSchools.student_id).\
        join(models.User, models.User.id == models.Student.user_id).\
        filter(models.User.id == user_id).\
        subquery()

    # Now, get the friends' target schools that match these college_ids
    friends_with_same_target_school = db.query(models.StudentTargetSchools).\
        join(models.Student, models.Student.id == models.StudentTargetSchools.student_id).\
        join(models.User, models.User.id == models.Student.user_id).\
        join(models.Follows, and_(models.Follows.following_id == models.User.id, models.Follows.user_id == user_id)).\
        filter(models.StudentTargetSchools.college_id.in_(user_college_ids)).\
        all()
    
    # Add intersections for the student
    for friend in friends_with_same_target_school:
        friend_user = db.query(models.User).\
            join(models.Student, models.Student.user_id == models.User.id).\
            filter(models.Student.id == friend.student_id).first()
        if friend_user:
            intersection = models.StudentTargetSchoolIntersections(
                student_target_school_id=student_target_school.id,
                friend_user_id=friend_user.id
            )
            db.merge(intersection)

    db.commit()
    return

#
# When a user unsaves a saved target school, remove any target school intersections for that saved school and also
# remove other entries in friend user's target school intersections.
#
def remove_target_school_intersections(db: Session, student_target_school: models.StudentTargetSchools):
    # Get the user_id for the student
    student = db.query(models.Student).filter(models.Student.id == student_target_school.student_id).first()
    if not student:
        print(f"No student found with id {student_target_school.student_id}")
        return
    user_id = student.user_id

    # Remove intersections where this student_target_school is the main entry
    db.query(models.StudentTargetSchoolIntersections).filter(
        models.StudentTargetSchoolIntersections.student_target_school_id == student_target_school.id
    ).delete()

    # Remove intersections where this user is the friend
    db.query(models.StudentTargetSchoolIntersections).filter(
        models.StudentTargetSchoolIntersections.friend_user_id == user_id
    ).delete()
    db.commit()
    return

def get_student_target_school_intersections(db: Session, student_target_school_id: int):
    student_target_school_intersections = db.query(models.StudentTargetSchoolIntersections)\
                                            .filter(models.StudentTargetSchoolIntersections.student_target_school_id \
                                                    == student_target_school_id).all()
    if student_target_school_intersections is None:
        return []
    intersections = []
    for intersection in student_target_school_intersections:
        user_id = intersection.friend_user_id
        new_intersection = intersection.__dict__
        # Augment intersection with username, profile pic url
        new_intersection['username'], new_intersection['profile_pic_url'] = get_username_and_profile_pic(db=db, user_id=user_id)
        intersections.append(new_intersection)
    return intersections

def get_student_target_school_intersections_paginated(db: Session, student_target_school_id: int,
                                                      page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    offset = (page_num - 1) * limit

    query = db.query(models.StudentTargetSchoolIntersections)\
                    .filter(models.StudentTargetSchoolIntersections.student_target_school_id == student_target_school_id)
    total_count = query.count()  # Obtain the total count without fetching all records

    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()
    # Update results with username
    target_school_intersections = []
    for entry in results:
        user_id = entry.friend_user_id
        new_intersection = entry.__dict__
        # Augment intersection with username, profile pic url
        new_intersection['username'], new_intersection['profile_pic_url'] = get_username_and_profile_pic(db=db, user_id=user_id)
        target_school_intersections.append(new_intersection)

    return [total_count, target_school_intersections]

# Get student target school intersections of given user_id
def get_student_target_school_intersections_by_user_id(db: Session, user_id: int):
    # Step 1: Get the student ID for the given user ID
    student = db.query(models.Student).filter(models.Student.user_id == user_id).first()
    if not student:
        return []  # No student found for this user
    
    # Step 2: Get all student_target_school records for that student
    target_schools = db.query(models.StudentTargetSchools).filter(models.StudentTargetSchools.student_id == student.id).all()
    if not target_schools:
        return []  # No target schools found for this student
    
    # Get the IDs of the target schools
    target_school_ids = [ts.id for ts in target_schools]
    # Step 3: Find all intersections in student_target_school_intersections
    student_target_school_intersections = db.query(models.StudentTargetSchoolIntersections).\
        filter(models.StudentTargetSchoolIntersections.student_target_school_id.in_(target_school_ids))
    
    if student_target_school_intersections is None:
        return []
    intersections = []
    for intersection in student_target_school_intersections:
        user_id = intersection.friend_user_id
        new_intersection = intersection.__dict__
        # Augment intersection with username, profile pic url
        new_intersection['username'], new_intersection['profile_pic_url'] = get_username_and_profile_pic(db=db, user_id=user_id)
        intersections.append(new_intersection)
    return intersections

def get_student_target_school_intersections_by_user_id_paginated(db: Session, user_id: int,
                                                                page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
    if page_num < 1:
        raise HTTPException(status_code=400, detail="page_num must be greater than or equal to 1")
    if limit < 1 or limit > 20:
        raise HTTPException(status_code=400, detail="limit must be between 1 and 20")
    offset = (page_num - 1) * limit

    query = db.query(models.StudentTargetSchoolIntersections)\
                    .filter(models.StudentTargetSchoolIntersections.friend_user_id == user_id)
    total_count = query.count()  # Obtain the total count without fetching all records

    # Now, you can proceed with the offset and limit to fetch a subset of the results
    results = query.offset(offset).limit(limit).all()
    # Update results with username
    target_school_intersections = []
    for entry in results:
        user_id = entry.friend_user_id
        new_intersection = entry.__dict__
        # Augment intersection with username, profile pic url
        new_intersection['username'], new_intersection['profile_pic_url'] = get_username_and_profile_pic(db=db, user_id=user_id)
        target_school_intersections.append(new_intersection)

    return [total_count, target_school_intersections]

# Get student target school intersections of given college_id for the current user
def get_student_target_school_intersections_by_college_id(db: Session, college_id: int, user_id: int):
    log_trace(logging.INFO, f"Find intersections for college: {college_id} and user {user_id}")
    # student_target_school_intersections = db.query(models.StudentTargetSchools)\
    #                                         .join(models.Follows, models.Follows.following_id == user_id)\
    #                                         .join(models.Student, models.Student.user_id == models.Follows.user_id)\
    #                                         .filter(models.Student.id == models.StudentTargetSchools.student_id)\
    #                                         .filter(models.StudentTargetSchools.college_id == college_id).all()
    
    student_target_school_intersections = db.query(models.User)\
                                            .join(models.Follows, models.Follows.user_id == user_id)\
                                            .join(models.Student, models.Student.user_id == models.Follows.following_id)\
                                            .join(models.StudentTargetSchools, models.StudentTargetSchools.student_id == models.Student.id)\
                                            .filter(models.StudentTargetSchools.college_id == college_id)\
                                            .filter(models.User.id == models.Student.user_id)

    if student_target_school_intersections is None:
        return []

    intersections = []
    for intersection in student_target_school_intersections:
        new_intersection = {
            "user_id": intersection.id,
            "username": intersection.username,
            "profile_pic_url": intersection.profile_pic_url
        }
        intersections.append(new_intersection)

    return intersections

def add_user_follows(db: Session, user_id:int, following_id: int):
    db_follows = models.Follows(user_id = user_id,
                                following_id = following_id)
    db.add(db_follows)
    db.commit()

def remove_user_follows(db: Session, user_id:int, following_id: int):
    db_follows = db.query(models.Follows).filter(and_(models.Follows.user_id == user_id,
                                                      models.Follows.following_id == following_id)).first()
    if db_follows:
        db.delete(db_follows)
    return

# Given a student_career_id, remove any student_career_users entries for this student_career_id
def remove_student_career_users(db: Session, student_career_id: int):
    # Remove any entries from StudentCareerComment for this student_career_id
    db_student_career_comments = db.query(models.StudentCareerComment) \
                                .filter(models.StudentCareerComment.student_career_id == student_career_id)
    if db_student_career_comments:
        db_student_career_comments.delete()
        db.commit()
        
    # Remove any student_career_users entries for this student_career_id
    db_student_career_users = db.query(models.StudentCareerUsers) \
                                .filter(models.StudentCareerUsers.student_career_id == student_career_id)
    if db_student_career_users:
        db_student_career_users.delete()
        db.commit()
    return

# Given a user, remove any student_career_users entries for this user
def remove_student_career_users_by_user_id(db: Session, user_id: int):
    # Remove any entries from StudentCareerComment for this user_id
    db_student_career_comments = db.query(models.StudentCareerComment) \
                                .filter(models.StudentCareerComment.user_id == user_id)
    if db_student_career_comments:
        db_student_career_comments.delete()
        db.commit()

    # Remove any student_career_users entries for this user_id
    db_student_career_users = db.query(models.StudentCareerUsers) \
                                .filter(models.StudentCareerUsers.user_id == user_id)
    if db_student_career_users:
        db_student_career_users.delete()
        db.commit()
    return

# Given a student_target_school_id, remove any student_target_school_users entries for this student_target_school_id
def remove_student_target_school_users(db: Session, student_target_school_id: int):
    # Remove any entries in StudentTargetSchoolsComment for this target school id
    db_student_target_school_comments = db.query(models.StudentTargetSchoolsComment) \
                                        .filter(models.StudentTargetSchoolsComment.target_school_id == student_target_school_id)
    if db_student_target_school_comments:
        db_student_target_school_comments.delete()
        db.commit()

    # Remove any student_target_school_users entries for this student_target_school_id
    db_student_target_school_users = db.query(models.StudentTargetSchoolsUsers) \
                                        .filter(models.StudentTargetSchoolsUsers.student_target_school_id == student_target_school_id)
    if db_student_target_school_users:
        db_student_target_school_users.delete()
        db.commit()
    return

# Given a user, remove any student_target_school_users entries for this user
def remove_student_target_school_users_by_user_id(db: Session, user_id: int):
    # Remove any entries from StudentTargetSchoolsComment for this user_id
    db_student_target_school_comments = db.query(models.StudentTargetSchoolsComment) \
                                        .filter(models.StudentTargetSchoolsComment.user_id == user_id)
    if db_student_target_school_comments:
        db_student_target_school_comments.delete()
        db.commit()

    # Remove any student_target_school_users entries for this user_id
    db_student_target_school_users = db.query(models.StudentTargetSchoolsUsers) \
                                        .filter(models.StudentTargetSchoolsUsers.user_id == user_id)
    if db_student_target_school_users:
        db_student_target_school_users.delete()
        db.commit()
    return    