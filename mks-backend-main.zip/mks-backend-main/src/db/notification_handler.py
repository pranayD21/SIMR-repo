import os
from pyfcm import FCMNotification
from sqlalchemy.orm import Session
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import and_
from logger import log_trace, logging
from . import models, schemas
from fastapi import Query
from dotenv import load_dotenv, find_dotenv
import json
import requests
import random
import google.auth.transport.requests
from google.oauth2 import service_account
from datetime import datetime, timedelta, timezone


_ = load_dotenv(find_dotenv())

def load_notifications():
    with open(os.path.join(os.getenv("DABBL_HOME"), 'notifications.json'), 'r') as file:
        notifications = json.load(file)
    return notifications

class NotificationHandler:
    def __init__(self):
        # Initialize FCMNotification with your FCM server key
        self.service_account_file = os.getenv("FCM_SERVICE_ACCOUNT_FILE_PATH")
        self.project_id = os.getenv("FCM_PROJECT_ID")
        # Initialize FCMNotification with your FCM server key
        self.push_notification_service = FCMNotification(
            service_account_file=self.service_account_file,
            project_id=self.project_id
        )
        # Define the scope for FCM
        SCOPES = ['https://www.googleapis.com/auth/firebase.messaging']

        # Create credentials using the service account file
        self.credentials = service_account.Credentials.from_service_account_file(
            self.service_account_file, scopes=SCOPES)

        # Refresh the access token
        self.request = google.auth.transport.requests.Request()
        self.credentials.refresh(self.request)
        self.url = f"https://fcm.googleapis.com/v1/projects/{self.project_id}/messages:send"

        # Load any existing notifications and categorize them
        notifications = load_notifications()
        self.general_notifications = notifications["general_notifications"]
        self.fun_fact_notifications = notifications["fun_fact_notifications"]

    def create_notification(self, db: Session, notification: schemas.NotificationCreate):
        try:
            db_notification = models.Notification(**notification.model_dump())
            db.add(db_notification)
            db.commit()
            db.refresh(db_notification)
        except SQLAlchemyError as e:
            db.rollback()
            logging.error(f"Error occurred while creating notification: {str(e)}")
            return None #{"message": "Failed to create notification", "status_code": 400}
        except Exception as e:
            db.rollback()
            logging.error(f"Unexpected error: {str(e)}")
            return None #{"message": "An unexpected error occurred", "status_code": 500}

        if db_notification.data:
            notification = self.send_notification_to_user(
                db=db,
                user_id=notification.user_id,
                title=notification.title,
                body=notification.message,
                data={
                    "notification_id": str(db_notification.id),
                    "type": notification.type,
                    **db_notification.data,
                }
            )
        else:
            notification = self.send_notification_to_user(
                db=db,
                user_id=notification.user_id,
                title=notification.title,
                body=notification.message,
                data={
                    "notification_id": str(db_notification.id),
                    "type": notification.type,
                }
            )

        if not notification.get("name"):
            log_trace(logging.ERROR, f"Error sending notification {db_notification.id} to user {db_notification.user_id}")
            db.rollback()

        return db_notification

    def get_notifications(self, db: Session, user_id: int, page_num: int = Query(1, ge=1), limit: int = Query(10, le=20)):
        offset = (page_num - 1) * limit
        num_unread = db.query(models.Notification).filter(and_(
                                                            models.Notification.user_id == user_id,
                                                            models.Notification.is_read == False
                                                        )
                                                    ).count()
        query = db.query(models.Notification) \
                    .filter(models.Notification.user_id == user_id) \
                    .order_by(models.Notification.created_at.desc())
        total_count = query.count()
        return total_count, num_unread, query.offset(offset).limit(limit).all()

    def get_notification(self, db: Session, notification_id: int):
        return db.query(models.Notification).filter(models.Notification.id == notification_id).first()

    def update_notification(self, db: Session, notification_id: int, update_data: schemas.NotificationCreate):
        db_notification = self.get_notification(db, notification_id)
        if db_notification:
            for key, value in update_data.model_dump().items():
                setattr(db_notification, key, value)
            db.commit()
            db.refresh(db_notification)
        return db_notification

    def delete_notification(self, db: Session, notification_id: int):
        db_notification = self.get_notification(db, notification_id)
        if db_notification:
            db.delete(db_notification)
            db.commit()
        return db_notification

    def send_notification_to_user(self, db: Session, user_id: int, title: str, body: str, data: dict = None):
        from. import crud
        user = crud.get_user(db, user_id)
        if user and user.fcm_token:
            return self._send_fcm_notification(token=user.fcm_token, title=title, body=body, data=data)
        else:
            return {"message": "User not found or FCM token missing", "status_code": 400}

    def _send_fcm_notification(self, token: str, title: str, body: str, data: dict = None):
        result = {}
        try:
            self.request = google.auth.transport.requests.Request()
            self.credentials.refresh(self.request)
            # Get the access token
            access_token = self.credentials.token
            log_trace(logging.INFO, f"Access Token: {access_token}")
            
            # Headers
            headers = {
                'Authorization': f'Bearer {access_token}',
                'Content-Type': 'application/json; UTF-8',
            }

            if data:
                data_payload = {key: str(value) for key, value in data.items()}
            else:
                data_payload = None
            payload = {
                "message": {
                    "token": token,
                    "notification": {
                        "title": title,
                        "body": body
                    },
                    "apns": {
                        "payload": {
                            "aps": {
                                "sound": "default",
                                "content_available": "true"
                            }
                        }
                    },
                    "android": {
                        "priority": "HIGH",
                        "notification": {
                            "sound": "default"
                        }
                    },
                    "data": data_payload
                }
            }
            log_trace(logging.INFO, f"Headers are {headers}")
            log_trace(logging.INFO, f"Payload is {json.dumps(payload)}")
            
            result = requests.post(self.url, headers=headers, data=json.dumps(payload))
            log_trace(logging.INFO, f"Response is {result.json()}")

            return result.json()

        except Exception as e:
            log_trace(logging.ERROR, f"Unexpected error: {e} sending notification for token {token}")
        return result



    def schedule_notifications(self, db: Session, type: str):
        """
        Schedule notifications based on available templates
        """
        # Fetch the available active templates based on type
        available_templates = db.query(models.NotificationTemplate).filter(
            models.NotificationTemplate.type == type,
            models.NotificationTemplate.active == True
        ).all()

        if not available_templates:
            return {"error": f"No active templates available for type '{type}'."}

        # Fetch users
        users = db.query(models.User).filter(models.User.type == 'student').all() 
        notifications_scheduled = 0

        for user in users:
            # Check which templates this user has already received
            sent_notifications = db.query(models.Notification).filter(
                models.Notification.user_id == user.id,
                models.Notification.type == type,
                models.Notification.sent == True
            ).all()

            sent_template_ids = {notif.template_id for notif in sent_notifications}

            # Filter out templates that the user already received
            unsent_templates = [
                template for template in available_templates
                if template.id not in sent_template_ids
            ]

            # if everything in the db has been sent, use 'repeatable' flag - general can be cycled thru again (repeatable = true) but fun_facts should not be 
            if not unsent_templates:
                repeatable_templates = [template for template in available_templates if template.repeatable]
                if repeatable_templates:
                    # Use repeatable templates if available
                    unsent_templates = repeatable_templates
                else:
                    # No repeatable templates found, so skip this user
                    continue

            # Randomly select a template
            selected_template = random.choice(unsent_templates)

            random_hour = random.choice([1,2,3,4,5])
            send_time = datetime.now(timezone.utc) + timedelta(hours=random_hour)

            new_notification = models.Notification(
                user_id=user.id,
                template_id=selected_template.id,
                type=selected_template.type,
                title=selected_template.title,
                message=selected_template.message,
                scheduled=True,
                sent=False,
                send_time=send_time,
                data={}
            )
            db.add(new_notification)
            notifications_scheduled += 1

        db.commit()
        return {"message": f"Scheduled {notifications_scheduled} notifications for type '{type}'."}


    def send_scheduled_notifications(self, db: Session):
        # Fetch unsent scheduled notifications for all users
        unsent_notifications = db.query(models.Notification).filter(
            models.Notification.scheduled == True, 
            models.Notification.sent == False
        ).all()

        # Send notifications to all users
        for notification in unsent_notifications:
            user = db.query(models.User).filter(models.User.id == notification.user_id).first()
            if user and user.fcm_token:
                self._send_fcm_notification(
                    token=user.fcm_token,
                    title=notification.title, 
                    body=notification.message 
                )
                notification.sent = True
        
        db.commit()
        return {"message": f"Sent {len(unsent_notifications)} notifications"}
    

###NOTIFICATION TEMPLATES CRUD

    def create_notification_template(self, db: Session, template: schemas.NotificationTemplateCreate):
        """
        Create a new notification template.
        """
        try:
            db_template = models.NotificationTemplate(**template.model_dump())
            db.add(db_template)
            db.commit()
            db.refresh(db_template)
        except SQLAlchemyError as e:
            db.rollback()
            logging.error(f"Error occurred while creating notification template: {str(e)}")
            return None 
        return db_template

    def get_notification_template(self, db: Session, template_id: int):
        """
        Get a specific notification template by ID.
        """
        return db.query(models.NotificationTemplate).filter(models.NotificationTemplate.id == template_id).first()
    
    def get_all_notification_templates(self, db: Session):
        """
        Fetch all notification templates, both active and inactive.
        """
        return db.query(models.NotificationTemplate).all()

    def get_active_notification_templates(self, db: Session, type: str):
        """
        Fetch all active notification templates of a given type (e.g., 'general', 'fun_fact').
        """
        return db.query(models.NotificationTemplate).filter(
            models.NotificationTemplate.type == type,
            models.NotificationTemplate.active == True
        ).all()

    def update_notification_template(self, db: Session, template_id: int, update_data: schemas.NotificationTemplateUpdate):
        """
        Update an existing notification template.
        """
        db_template = self.get_notification_template(db, template_id)
        if db_template:
            try:
                for key, value in update_data.model_dump(exclude_unset=True).items():
                    setattr(db_template, key, value)
                db.commit()
                db.refresh(db_template)
            except SQLAlchemyError as e:
                db.rollback()
                logging.error(f"Error occurred while updating notification template: {str(e)}")
                return None
        return db_template

    def delete_notification_template(self, db: Session, template_id: int):
        """
        Delete a notification template by ID.
        """
        db_template = self.get_notification_template(db, template_id)
        if db_template:
            try:
                db.delete(db_template)
                db.commit()
            except SQLAlchemyError as e:
                db.rollback()
                logging.error(f"Error occurred while deleting notification template: {str(e)}")
                return None
        return db_template

