"""
This File contains functions to preprocess analytic data before sending it to the collector. Preprocessing involves
removing any private information, filtering or transforming the data appropriately and then sending it to the collector.

Events tracked 
1) User Login - USER_LOGIN, data collected is only user_id
2) User delete - USER_DELETE, data collected is only user_id
3) User school update -  USER_PROFILE_UPDATE, Data collected should help in determining the Geo and academic profile of the student.
                          Highschool name, city, state, student GPA 
4) Saved College recommendations -  Data collected  college name

"""
from analytics.analytics_constants import EventType, AnalyticsEvent, generate_auth_header, timeout, BASE_URL
from feature_flags import is_feature_enabled
import requests
from typing import Dict, Any
from datetime import datetime
from logger import log_trace, logging


def track_school_update_data(student_info: Dict[str,Any], school_info:Dict[str, Any]):
     """
     Track school update event data.

     Args:
         student_info (Dict[str,Any]): Information about the student.
         school_info (Dict[str,Any]): Information about the school.

     This function preprocesses the data received from the school update event and tracks it using the analytics collector.
     The data collected includes the name of the school, the city and state of the school, the GPA of the student, and the grade of the student.

     """
     data_processed = {}
     try:
       # Extract relevant data from the received information
       log_trace(logging.INFO, "School update event data received")
       log_trace(logging.INFO, f"DB Analytics: Student Info {student_info}")
       log_trace(logging.INFO, f"DB Analytics: School info {school_info}")

       # Preprocessed data that is applicable for Aanalytics to understand the student's high school, academic profile like GPA
       data_processed["school_name"] = school_info["name"]
       data_processed["school_city"] = school_info["city"]
       data_processed["school_state"] = school_info["state"]
       data_processed["gpa"] = student_info["gpa"] 
       data_processed["grade"] = student_info["current_grade"]

       # Track the data using the analytics collector
       log_trace(logging.INFO, f" DB Analytics: School update event posted  with Attributes {data_processed}")
       track_user_activity_data(EventType.USER_PROFILE_UPDATE, student_info["user_id"], attributes=data_processed)

     except Exception as e:
        # Log any errors that occur during the tracking process
        log_trace(logging.ERROR, f"Error tracking analytics: {e}")

def track_college_recommendations(user_id: int, college_info: Dict[str,Any], delete=False):
    """
    User saved college recommendations - Data collected  college name, state
    """
    log_trace(logging.INFO, "===== track college recommendations =====")
    log_trace(logging.INFO, f"User ID: {user_id}")
    log_trace(logging.INFO, f"College Info: {college_info}")
    log_trace(logging.INFO, f"Delete: {delete}")

    event_type = EventType.RECOMMENDATION_SAVED_COLLEGE if not delete else EventType.RECOMMENDATION_DELETE_COLLEGE
    data_preprocessed = {"college_name": college_info["college_name"]}
    log_trace(logging.INFO, f"Event Type: {event_type}")
    log_trace(logging.INFO, f"Data Processed: {data_preprocessed}")

    track_user_activity_data(event_type, user_id, attributes=data_preprocessed)

def track_user_activity_data(event: EventType , user_id: int, attributes: Dict[str, Any]):
    """
    # User Activity Events
    USER_SIGNUP = auto()
    USER_LOGIN = auto()
    USER_LOGOUT = auto()
    ACCOUNT_UPDATE = auto()
    
    """
    if not is_feature_enabled("Analytics"):
        log_trace(logging.INFO, "Analytics feature is disabled!")
        return
    headers = generate_auth_header()
    event_data = AnalyticsEvent(
                event_type = event,
                unique_id = str(user_id),
                timestamp = datetime.now(),
                attributes=attributes
               )
    payload = event_data.to_json()
    log_trace(logging.INFO, f"DB Analytics: Posting the event,  Payload : [{payload}]")
    try:
        response = requests.post(f"{BASE_URL}/analytics/event",data=payload, headers=headers, timeout=timeout)
        log_trace(logging.INFO, f" Post Analytical Data Response: [{response}]")
    except Exception as e:
        log_trace(logging.ERROR, f"Error: {e}")
    else:
        if response.status_code != 200:
            log_trace(logging.ERROR, f"Error: {response.status_code} - {response.text}")
        

