import os
import json
from fastapi import Depends, File, UploadFile
import requests
from db import schemas
from logger import log_trace, logging
from dotenv import load_dotenv, find_dotenv
from auth_jwt.jwt_token import JWKS, JWTAuthorizationCredentials, JWTBearer, fetch_jwks
from utils import get_identity_token

# Load environment variables
_ = load_dotenv(find_dotenv())

# Get base server url from env
base_url = os.getenv("DB_SERVER_URL")
# Replace db with auth in base_url
auth_url = base_url.replace("db", "auth")
timeout = int(os.getenv("REQUEST_TIMEOUT"))

# Needed for parsing the auth token in the request headers
jwks = JWKS.model_validate(fetch_jwks())
auth = JWTBearer(jwks)

def create_request_headers(credentials: JWTAuthorizationCredentials):
    headers = {
                "Authorization": f"Bearer {credentials.jwt_token}"
            }
    return headers

def create_request_headers_with_identity(credentials: JWTAuthorizationCredentials, identity_token: str):
    headers = {
                "Authorization": f"Bearer {credentials.jwt_token}",
                "X-Identity-Token": identity_token
            }
    return headers

# User operations
def create_user(user:schemas.UserCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/create", data=json.dumps(user), headers=headers, timeout=timeout)
    return response.json()

def get_users(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get", headers=headers, timeout=timeout)
    return response.json()

def get_other_users(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get_other_users/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def get_user_by_id(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def get_user_by_search(string: str, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/search/{string}", headers=headers, timeout=timeout)
    return response.json()

def get_user_by_search_paginated(string:str, page: int, limit: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/paginated/search/{string}/{page}/{limit}", headers=headers, timeout=timeout)
    return response.json()

def get_user_by_username(username: str, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/username/{username}", headers=headers, timeout=timeout)
    return response.json()

def get_user_by_email(email:str, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/email/{email}", headers=headers, timeout=timeout)
    return response.json()

def get_user_show_sensitive_info(user_id:int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/show_sensitive_info/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def get_user_profile(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/profile/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def update_user(user_id: int, user:schemas.UserCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/users/update/id/{user_id}/", data=json.dumps(user), headers=headers, timeout=timeout)
    return response.json()

def update_user_status(user_id: int, status:schemas.UserStatus, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/users/update/status/user_id/{user_id}/",
                            data=json.dumps(status), headers=headers, timeout=timeout)
    return response.json()

def update_user_profile(user_id: int, profile:schemas.UserProfile, credentials: JWTAuthorizationCredentials):  
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/users/update/profile/user_id/{user_id}/",
                            data=json.dumps(profile), headers=headers, timeout=timeout)
    return response.json()

def update_user_show_sensitive_info(user_id: int, show_sensitive_info:bool, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/users/update/show_sensitive_info/user_id/{user_id}/",
                            data=json.dumps(show_sensitive_info), headers=headers, timeout=timeout)
    return response.json()

def get_user_followers(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/followers/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def get_user_following(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/get/following/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def follow_user(user_id: int, user:schemas.UserFollowUnfollow, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/follow/user_id/{user_id}",
                             data=json.dumps(user), headers=headers, timeout=timeout)
    return response.json()

def delete_user(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/delete/id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

# Student operations
def create_student(student:schemas.StudentCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/create",
                             data=json.dumps(student), headers=headers, timeout=timeout)
    return response.json()

def get_students(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/get", headers=headers, timeout=timeout)
    return response.json()

def get_student_by_id(student_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/get/id/{student_id}", headers=headers, timeout=timeout)
    return response.json()

def get_student_by_uid(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/get/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def delete_student(student_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/delete/id/{student_id}", headers=headers, timeout=timeout)
    return response.json()

# School operations
def create_school(school: schemas.SchoolCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/schools/create/",
                             data=json.dumps(school), headers=headers, timeout=timeout)
    return response.json()

def get_schools(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/schools/get/", headers=headers, timeout=timeout)
    return response.json()

def get_school_by_id(school_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/schools/get/id/{school_id}", headers=headers, timeout=timeout)
    return response.json()

def delete_school(school_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/schools/delete/id/{school_id}", headers=headers, timeout=timeout)
    return response.json()

# Course operations
def create_course(course: schemas.CourseCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/courses/create/", data=json.dumps(course), headers=headers, timeout=timeout)
    return response.json()

def get_courses(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/courses/get/", headers=headers, timeout=timeout)
    return response.json()

def get_course_by_id(course_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/courses/get/id/{course_id}", headers=headers, timeout=timeout)
    return response.json()

def delete_course(course_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/courses/delete/id/{course_id}", headers=headers, timeout=timeout)
    return response.json()

# Activity operations
def create_activity(activity: schemas.ActivityCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/activities/create/",
                             data=json.dumps(activity), headers=headers, timeout=timeout)
    return response.json()

def get_activities(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/activities/get/", headers=headers, timeout=timeout)
    return response.json()

def get_activity_by_id(activity_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/activities/get/id/{activity_id}", headers=headers, timeout=timeout)
    return response.json()

def delete_activity(activity_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/activities/delete/id/{activity_id}", headers=headers, timeout=timeout)
    return response.json()

# Career operations
def create_career(career:schemas.CareersCreate,
                  refresh: bool=False, credentials: JWTAuthorizationCredentials=None):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/careers/get_create_or_update/",
                             data=json.dumps(career), headers=headers, timeout=timeout)
    return response.json()

def get_careers(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/careers/get", headers=headers, timeout=timeout)
    return response.json()

def get_career_by_id(career_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/careers/get/id/{career_id}", headers=headers, timeout=timeout)
    return response.json()

def delete_career(career_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/careers/deleteid/{career_id}", headers=headers, timeout=timeout)
    return response.json()

# Student-Course operations
def create_student_course(student_course: schemas.StudentCourseCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/courses/add/", json=student_course, headers=headers, timeout=timeout)
    return response.json()

def add_student_courses(user_id: int, student_course: schemas.StudentCourseCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/courses/addlist/", json=student_course, headers=headers, timeout=timeout)
    return response.json()

def delete_student_course(student_course_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/courses/delete/", json=student_course_id, headers=headers, timeout=timeout)
    return response.json()

def update_student_course(student_course_id: int, student_course: schemas.StudentCourseCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/courses/update/{student_course_id}",
                             data=json.dumps(student_course), headers=headers, timeout=timeout)
    return response.json()

def get_student_courses(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/courses/get/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

# Student-Activity operations
def create_student_activity_list(user_id: int, student_activity: list[schemas.StudentActivityCreate], credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/activities/addlist/{user_id}",
                             data=json.dumps(student_activity), headers=headers, timeout=timeout)
    return response.json()

def create_student_activity(user_id: int, student_activity: schemas.StudentActivityCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/activities/add/{user_id}",
                             data=json.dumps(student_activity), headers=headers, timeout=timeout)
    return response.json()

def delete_student_activity(student_activity_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/activities/delete/",
                               data=json.dumps(student_activity_id), headers=headers, timeout=timeout)
    return response.json()

def update_student_activity(student_activity: schemas.StudentActivityUpdate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/activities/update/",
                             data=json.dumps(student_activity), headers=headers, timeout=timeout)
    return response.json()

def get_student_activities(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/activities/get/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

# Student-Career operations
def create_student_career(student_career:schemas.StudentCareerCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    # log_trace(logging.INFO, student_career)
    response = requests.post(f"{base_url}/users/students/careers/add/", data=json.dumps(student_career), headers=headers, timeout=timeout)
    # log_trace(logging.INFO, response)
    return response.json()

def delete_student_career(student_career:schemas.StudentCareerDelete, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/careers/delete/", data=json.dumps(student_career), headers=headers, timeout=timeout)
    return response.json()

def update_student_career(student_career:schemas.StudentCareerCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/careers/update/", data=json.dumps(student_career), headers=headers, timeout=timeout)
    return response.json()

def get_student_careers(student_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/careers/student_id/{student_id}", headers=headers, timeout=timeout)
    log_trace(logging.INFO, response)
    return response.json()


# Student-Target-School operations
def create_student_target_school(student_target_school:schemas.StudentTargetSchoolCreate, credentials: JWTAuthorizationCredentials):
    # log_trace(logging.INFO, student_career)
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/targetschools/add/", 
                             data=json.dumps(student_target_school), headers=headers, timeout=timeout)
    # log_trace(logging.INFO, response)
    return response.json()

def delete_student_target_school(student_target_school:schemas.StudentTargetSchoolCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/targetschools/delete/", 
                               data=json.dumps(student_target_school), headers=headers, timeout=timeout)
    return response.json()

def update_student_target_school(student_target_school:schemas.StudentTargetSchoolCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/targetschools/update/",
                              data=json.dumps(student_target_school), headers=headers, timeout=timeout)
    return response.json()

def get_student_target_schools(student_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/targetschools/student_id/{student_id}", headers=headers, timeout=timeout)
    log_trace(logging.INFO, response)
    return response.json()

def get_student_target_school(student_target_school_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/targetschools/student_target_school_id/{student_target_school_id}", headers=headers, timeout=timeout)
    log_trace(logging.INFO, response)
    return response.json()

# For the given name, find the college pic url
def get_target_school_pic_url(college_name: str, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/targetschools/picture_url/{college_name}", headers=headers, timeout=timeout)
    log_trace(logging.INFO, response)
    return response.json()

def get_target_school(college_name: str, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/targetschools/search/{college_name}", headers=headers, timeout=timeout)
    log_trace(logging.INFO, response)
    return response.json()

def get_target_school_by_id(college_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/targetschools/get/id/{college_id}", headers=headers, timeout=timeout)
    log_trace(logging.INFO, response)
    return response.json()

# StudentSchool operations
def create_student_school(student_school: schemas.StudentSchoolCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/schools/add",
                             data=json.dumps(student_school), headers=headers, timeout=timeout)
    return response.json()

def get_student_schools(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/schools/get", headers=headers, timeout=timeout)
    return response.json()

# Get all school records for a user
def get_student_school_by_user_id(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/schools/get/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

# Get a specific school record for a user
def get_student_school_by_id(user_id: int, school_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/schools/get/id/{user_id}/{school_id}", headers=headers, timeout=timeout)
    return response.json()

# Get the primary school record for a user
def get_student_primary_school(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/schools/get/primary/user_id/{user_id}/", headers=headers, timeout=timeout)
    return response.json()

# Used by UI today
def delete_student_school(student_school_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/schools/delete/id/{student_school_id}", headers=headers, timeout=timeout)
    return response.json()

def update_student_school(student_school_id: int, student_school: schemas.StudentSchoolUpdate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/users/students/schools/update/id/{student_school_id}",
                            data=json.dumps(student_school.dict()), headers=headers, timeout=timeout)
    return response.json()

# Used by UI today
def update_student_school_by_id(user_id: int, school_id: int, student_school: schemas.StudentSchoolUpdate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/users/students/schools/update/id/{user_id}/{school_id}",
                            data=json.dumps(student_school.dict()), headers=headers, timeout=timeout)
    return response.json()

def delete_student_school_by_id(user_id: int, school_id:int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/schools/delete/id/{user_id}/{school_id}", headers=headers, timeout=timeout)
    return response.json()

# StudentStandardizedTests operations
def create_student_standardized_test(student_standardized_test: schemas.StudentStandardizedTestCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/standardizedtests/add",
                             data=json.dumps(student_standardized_test.model_dump()), headers=headers, timeout=timeout)
    return response.json()

def get_student_standardized_tests(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/standardizedtests/get", headers=headers, timeout=timeout)
    return response.json()

def get_student_standardized_test_by_id(student_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/standardizedtests/get/id/{student_id}", headers=headers, timeout=timeout)
    return response.json()

def delete_student_standardized_test(student_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/standardizedtests/delete/id/{student_id}", headers=headers, timeout=timeout)
    return response.json()

def update_student_standardized_test(student_standardized_test: schemas.StudentStandardizedTestUpdate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/studentstandardizedtests/update/",
                            data=json.dumps(student_standardized_test.model_dump()), headers=headers, timeout=timeout)
    return response.json()

# StudentStrengthsWeakness operations
def create_student_strengths_weakness(
        student_sw: schemas.StudentStrengthsWeaknessCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(
        f"{base_url}/users/students/strengthsweakness/add", 
        data=json.dumps(student_sw.model_dump()), headers=headers, timeout=timeout)
    return response.json()

def get_student_strengths_weakness(credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(
        f"{base_url}/users/students/strengthsweakness/get", headers=headers, timeout=timeout)
    return response.json()

def get_student_strengths_weakness_by_id(student_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(
        f"{base_url}/users/students/strengthsweakness/get/id/{student_id}", headers=headers, timeout=timeout)
    return response.json()

def delete_student_strengths_weakness(student_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(
        f"{base_url}/users/students/strengthsweakness/delete/id/{student_id}", headers=headers, timeout=timeout)
    return response.json()

def update_student_strengths_weakness(
        student_sw: schemas.StudentStrengthsWeaknessUpdate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(
        f"{base_url}/strengthsweakness/update/", 
        data=json.dumps(student_sw.model_dump()), headers=headers, timeout=timeout)
    return response.json()


# StudentWorkExperience operations
def create_student_work_experience(user_id: int, student_work_experience: schemas.StudentWorkExperienceCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/workexperience/add/user_id/{user_id}",
                             data=json.dumps(student_work_experience), headers=headers, timeout=timeout)
    return response.json()

def get_student_work_experiences(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/workexperience/get/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def update_student_work_experience(work_experience_id: int, student_work_experience: schemas.StudentWorkExperienceCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/users/students/workexperience/{work_experience_id}",
                            data=json.dumps(student_work_experience), headers=headers, timeout=timeout)
    return response.json()

def delete_student_work_experience(work_experience_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/workexperience/{work_experience_id}", headers=headers, timeout=timeout)
    return response.json()

# StudentProjects operations
def create_student_project(user_id: int, student_project: schemas.StudentProjectsCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.post(f"{base_url}/users/students/projects/add/user_id/{user_id}", data=json.dumps(student_project), headers=headers, timeout=timeout)
    return response.json()

def get_student_projects(user_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.get(f"{base_url}/users/students/projects/get/user_id/{user_id}", headers=headers, timeout=timeout)
    return response.json()

def update_student_project(project_id: int, student_project: schemas.StudentProjectsCreate, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.put(f"{base_url}/users/students/projects/{project_id}", data=json.dumps(student_project), headers=headers, timeout=timeout)
    return response.json()

def delete_student_project(project_id: int, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    response = requests.delete(f"{base_url}/users/students/projects/{project_id}", headers=headers, timeout=timeout)
    return response.json()

def get_student_college_intersections(college_id: int,
                                      user_id: int, 
                                      credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials=credentials)
    response = requests.get(f"{base_url}/users/students/target_school_intersections/college_id/{college_id}/{user_id}",
                            headers=headers, timeout=timeout)
    return response.json()

# Add an api to upload a file to S3 using the /auth endpoint
# upload_essay_review(user_id=user_id, college=college, major=major, prompt=prompt, essay=buffer, essay_review=result, credentials=credentials)
# This is a file buffer we need to save to S3 using the upload_file api
def upload_pdf_file(object_type: str,
                    file: UploadFile = File(...), 
                    credentials: JWTAuthorizationCredentials = Depends(auth),
                    identity_token: str = Depends(get_identity_token)):
    headers = create_request_headers_with_identity(credentials, identity_token)
    log_trace(logging.INFO, f"{auth_url}/upload_pdf_file")
    files = {"file": (file.filename, file.file, file.content_type), "object_type": object_type}
    response = requests.post(f"{auth_url}/upload_pdf_file/", files=files, headers=headers, timeout=timeout)
    return response.json()

def save_essay_review(essay_review: schemas.EssayReviewBase, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    log_trace(logging.INFO, f"Saving essay review: {essay_review}")
    response = requests.post(f"{base_url}/users/students/essay_review/add/",
                             data=json.dumps(essay_review), headers=headers, timeout=timeout)
    return response.json()

def save_letter_of_recommendation(lor: schemas.LorBase, credentials: JWTAuthorizationCredentials):
    headers = create_request_headers(credentials)
    counselor_id = lor['counselor_id']
    log_trace(logging.INFO, f"Saving letter of recommendation: {lor} counselor_id {counselor_id}")
    response = requests.post(f"{base_url}/users/counselors/letter_of_recommendation/add/{counselor_id}",
                             data=json.dumps(lor), headers=headers, timeout=timeout)
    return response.json()