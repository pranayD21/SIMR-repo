from sqlalchemy import ARRAY, Boolean, Column, ForeignKey, Integer, Text, String, Float, DATE, DateTime, TIMESTAMP, func, UniqueConstraint, Enum as SQLAlchemyEnum, JSON
from sqlalchemy.orm import relationship, validates
from typing import Dict, Any, List
from datetime import datetime, timezone
from enum import Enum
from .database import Base

# To Do add data validations


# class CounselorConnectStudentStatusEnum(str, Enum):
#      # Pending/connected/Not-initiated/. When the email is sent to
#      # invite connection that's when this changes to Pending, and
#      # connect-request-date is initialized.
#      REJECTED = "Rejected"
#      PENDING = "Pending"
#      CONNECTED = "Connected"
#      NOT_INITIATED = "Not-Initiated"



class BaseModel(Base):
    # List of fields to exclude from the dictionary (personal data)
    __abstract__ = True
    private_data: List[str] = ["private_data",'id','password','token','token_expiry', 'email','first_name', 'last_name',
                                'birthdate','parent_name','parent_email','consentdate','website','personal_statement',
                                'profile_pic_url','show_sensitive_info','fcm_token', 'username', 'uid', 'is_online', 'student_id']    


    def to_dict(self, hide_private_data: bool = True) -> Dict[str, Any]:
        """
        Convert the object to a dictionary, excluding personal dataif hide_private_data is True.
        """
        return {
            key: value for key, value in self.__dict__.items()
            if not key.startswith('_') and (not hide_private_data or key not in self.private_data)
        }


class Counselor(Base):
    __tablename__ = "counselors_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    # name = Column(String, index=True)
    is_school_counselor = Column(Boolean, default=False)
    school_id = Column(Integer,ForeignKey('schools_main.id',ondelete='CASCADE'))
    lor = relationship("LetterOfRecommendation", back_populates="counselor")


class CounselorStudentsConnection(Base):
    __tablename__ = "counselors_students_connection_main"
    __table_args__ = {"extend_existing": True}
    id = Column(Integer, primary_key=True, index=True)
    counselor_id = Column(Integer, ForeignKey("counselors_main.id", ondelete="CASCADE"))
    counselor_name = Column(String)
    counselor_email = Column(String)
    student_name = Column(String)
    student_email = Column(String)
    parent_email = Column(String)
    token = Column(String)
    expiration = Column(DateTime)  # Request expiration
    connect_approve_date = Column(DATE)
    connect_reject_date = Column(DATE)
    connect_request_date = Column(DATE)
    status = Column(String)


class StudentCounselor(Base):
    __tablename__ = "student_counselor_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    counselor_id = Column(Integer,ForeignKey('counselors_main.id',ondelete='CASCADE'))

class CounselorStudentCareer(Base):
    __tablename__ = "csc_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    student_counselor_id = Column(Integer, ForeignKey('student_counselor_main.id',
                                                      ondelete='CASCADE'))
    
    career_id = Column(Integer, ForeignKey('careers_main.id', ondelete='CASCADE'))
    status = Column(String, index=True) # status can be Exploring/Considering
    tasks = relationship("CSC_Task")

# Next 2 tables are for counselor-student-communication-for-careers.
class CounselorStudentCareersPost(Base):
    __tablename__ = "csc_post_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    csc_id = Column(Integer, ForeignKey('csc_main.id', ondelete='CASCADE'))
    description = Column(String) # Initial comments about career
    date_published = Column(DATE)
    profile_pic_url = Column(String) # Need to join to get this data. For now, redundancy is ok
    likes = Column(ARRAY(Integer))
    comments = relationship("CSC_Post_Comment")

class CSC_Post_Comment(Base):
    __tablename__ = "csc_post_comments_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True,index=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    csc_post_id = Column(Integer,ForeignKey('csc_post_main.id',ondelete='CASCADE'))
    content = Column(String)
    likes = Column(ARRAY(Integer))
    date_published = Column(DateTime)
    profile_pic_url = Column(String)

class CounselorStudentCollege(Base):
    __tablename__ = "csco_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    student_counselor_id = Column(Integer, ForeignKey('student_counselor_main.id',
                                                      ondelete='CASCADE'))
    
    college_id = Column(Integer, ForeignKey('target_schools_main.id', ondelete='CASCADE'))
    status = Column(String, index=True) # status can be Exploring/Considering/Applying/Applied/Accepted/Denied/Waitlisted
    tasks = relationship("CSCO_Task")

# Next 2 tables are for counselor-student-communication-for-colleges
class CounselorStudentCollegesPost(Base):
    __tablename__ = "csco_post_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    csco_id = Column(Integer, ForeignKey('csco_main.id', ondelete='CASCADE'))
    description = Column(String) # Initial comments about college
    date_published = Column(DATE)
    profile_pic_url = Column(String) # Need to join to get this data. For now, redundancy is ok
    likes = Column(ARRAY(Integer))
    comments = relationship("CSCO_Post_Comment")

class CSCO_Post_Comment(Base):
    __tablename__ = "csco_post_comments_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True,index=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    csco_post_id = Column(Integer,ForeignKey('csco_post_main.id',ondelete='CASCADE'))
    content = Column(String)
    likes = Column(ARRAY(Integer))
    date_published = Column(DateTime)
    profile_pic_url = Column(String)

class Tasks(Base):
    __tablename__ = "tasks_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    desc = Column(String)
    priority = Column(Integer) # Priority of tasks: 0, 1, 2, etc
    assign_date = Column(DATE)
    done_date = Column(DATE)
    due_date = Column(DATE, index=True)
    status = Column(String) # Can be assigned/started/inreview/reviewdone/inrevision/completed/discarded
    comments = relationship("Task_Comments")

class Task_Comments(Base):
    __tablename__ = "task_comments_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True,index=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    task_id = Column(Integer,ForeignKey('tasks_main.id',ondelete='CASCADE'))
    content = Column(String)
    likes = Column(ARRAY(Integer))
    date_published = Column(DateTime)
    profile_pic_url = Column(String)

class CSC_Task(Base):
    __tablename__ = "csc_tasks_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True,index=True)
    csc_id = Column(Integer, ForeignKey('csc_main.id', ondelete='CASCADE'))
    task_id = Column(Integer, ForeignKey('tasks_main.id', ondelete='CASCADE'))

class CSCO_Task(Base):
    __tablename__ = "csco_tasks_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True,index=True)
    csco_id = Column(Integer, ForeignKey('csco_main.id', ondelete='CASCADE'))
    task_id = Column(Integer, ForeignKey('tasks_main.id', ondelete='CASCADE'))

class School(BaseModel):
    __tablename__ = "schools_main"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True,index=True)
    name = Column(String,index=True)
    city = Column(String)
    state = Column(String)
    # phone = Column(String)
    zip = Column(String)
    type = Column(String, default="High School")
    country = Column(String)
    # students = relationship("Student",back_populates="schools")

## TO DO - School metadata table.

class User(BaseModel):
    __tablename__ = "users_main"
    __table_args__ = {'extend_existing': True}
   
    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, index=True)
    uid = Column(String, unique=True,index=True)
    email = Column(String, unique=True, index=True)
    normalized_email = Column(String, unique=True, index=True)
    first_name = Column(String)
    last_name = Column(String)
    type = Column(String, index=True)
    birthdate = Column(DATE)
    parent_name = Column(String)
    parent_email = Column(String)
    consentdate = Column(DATE)
    followers = Column(ARRAY(Integer))
    following = Column(ARRAY(Integer))
    website = Column(String)
    personal_statement = Column(String)
    connections = Column(ARRAY(Integer))
    profile_pic_url = Column(String)
    is_online = Column(Boolean, default=False)
    fcm_token = Column(String)
    show_sensitive_info = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    is_minor = Column(Boolean, default=True)
    delete_date = Column(DATE, default=None)
    counselor_connections = Column(ARRAY(Integer), default=[])  # List of counselor ids for counselors the user is connected to
    mentor_connections = Column(ARRAY(Integer), default=[]) # List of mentor ids for mentors the user is connected to
    posts = relationship("Post")
    comments = relationship("Comment")
    bookmarks = relationship("Bookmark", back_populates="user")
    news_post_likes = relationship("NewsPostLike", backref="user")
    notifications = relationship("Notification", back_populates="user")
    my_follows = relationship("Follows", back_populates="user", foreign_keys="[Follows.user_id]")
    my_connections = relationship("Connections", back_populates="user", foreign_keys="[Connections.user_id]")
    my_connected_users = relationship("Connections", back_populates="connected_user", foreign_keys="[Connections.connected_user_id]")
    student = relationship("Student", back_populates="user", uselist=False)
    my_followers = relationship("Follows", back_populates="follower", foreign_keys="[Follows.following_id]")
    career_intersections = relationship("StudentCareerIntersections", back_populates="user",
                                        foreign_keys="[StudentCareerIntersections.friend_user_id]")
    target_school_intersections = relationship("StudentTargetSchoolIntersections", back_populates="user",
                                               foreign_keys="[StudentTargetSchoolIntersections.friend_user_id]")
    student_career_comments = relationship("StudentCareerComment", back_populates="student_career_comments_user")
    student_career_users = relationship("StudentCareerUsers", back_populates="career_users")
    student_target_school_commenters = relationship("StudentTargetSchoolsComment", back_populates="student_target_school_commenters")
    student_target_school_users = relationship("StudentTargetSchoolsUsers", back_populates="target_school_users")
    essay_reviews = relationship("EssayReview", back_populates="user")
    lor = relationship("LetterOfRecommendation", back_populates="user")

class Follows(Base):
    __tablename__ = "follows"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    following_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    user = relationship("User", back_populates="my_follows", foreign_keys=[user_id])
    follower = relationship("User", back_populates="my_followers", foreign_keys=[following_id])

class Connections(Base):
    __tablename__ = "connections"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    connected_user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    user = relationship("User", back_populates="my_connections", foreign_keys=[user_id])
    connected_user = relationship("User", back_populates="my_connected_users", foreign_keys=[connected_user_id])

class Student(Base):
    __tablename__ = "students_main"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    courses = relationship("StudentCourse",back_populates="student")
    activities = relationship("StudentActivity",back_populates="student")
    careers = relationship("StudentCareers",back_populates='students')
    standardized_scores = relationship("StudentStandardizedTests",
                                       back_populates="students")
    strengths_weakness = relationship("StudentStrengthsWeakness")
    # schools = relationship("StudentSchool",back_populates="students")
    user = relationship("User", back_populates="student")

class StudentStrengthsWeakness(Base):
    __tablename__="students_strength_weakness"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer,primary_key=True, index=True)
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    strengths = Column(String)
    weakness = Column(String)

class StudentSchool(Base):
    __tablename__ = "student_schools"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    school_id = Column(Integer,ForeignKey('schools_main.id',ondelete='CASCADE'))
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    start_date = Column(DATE)
    end_date = Column(DATE)
    currently_enrolled = Column(Boolean,default=True)
    gpa = Column(Float)
    w_gpa = Column(Float)
    current_grade = Column(String, default='Freshman')
    is_primary = Column(Boolean,default=True)
    graduation_year = Column(DATE)
    # student = relationship("Student",back_populates="school")

class StudentStandardizedTests(Base):
    __tablename__ = "student_standardized_tests"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer, ForeignKey('students_main.id',ondelete='CASCADE'))
    date_taken = Column(DATE)
    test_type = Column(String)
    total_score = Column(Integer)
    english_score = Column(Float)
    math_score = Column(Float) 
    reading_score = Column(Float)
    science_score = Column(Float)
    students = relationship("Student",back_populates="standardized_scores")

class StudentWorkExperience(Base):
    __tablename__="students_work_experience"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer,primary_key=True, index=True)
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    job_title = Column(String)
    company_name = Column(String)
    job_description = Column(String)
    start_date = Column(DATE)
    end_date = Column(DATE)
    employment_type = Column(String,default='Internship')
    active = Column(Boolean,default=True)

class StudentProjects(Base):
    __tablename__="students_projects"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer,primary_key=True, index=True)
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    project_title = Column(String)
    project_description = Column(String)
    rewards_recognition = Column(String)
    start_date = Column(DATE)
    end_date = Column(DATE)
    is_complete = Column(Boolean,default=True)
    skills = Column(String, default='')

class Course(Base):
    __tablename__ = "courses_main"

    id = Column(Integer,primary_key=True, index=True)
    course_name = Column(String, unique=True, index=True)
    # student = relationship("User", back_populates="courses")#

class Activity(Base):
    __tablename__ = "activities_main"

    id = Column(Integer,primary_key=True, index=True)
    activity_name = Column(String, unique=True, index=True)
    # student = relationship("User", back_populates="courses")


class StudentCourse(Base):
    __tablename__ = "student_courses"
    id = Column(Integer, primary_key=True,index=True)
    # student_school_id = Column(Integer,ForeignKey('student_schools.id',ondelete='CASCADE'))
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    course_id = Column(Integer,ForeignKey('courses_main.id',ondelete='CASCADE'))
    school_id = Column(Integer, ForeignKey('schools_main.id',ondelete='CASCADE'))
    credits = Column(Integer)
    grade = Column(String)
    grade_year = Column(String)
    term = Column(String, default="")
    difficulty_level = Column(String)
    feedback = Column(String)
    student = relationship("Student",back_populates="courses")


class StudentActivity(Base):
    __tablename__="student_activities"
    id = Column(Integer, primary_key=True,index=True)
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    activity_id = Column(Integer,ForeignKey('activities_main.id',ondelete='CASCADE'))
    hours_committed_per_week = Column(Float)
    type = Column(String)
    activity_description = Column(String)
    achievements = Column(String) 
    student = relationship("Student",back_populates="activities")

class Careers(Base):
    __tablename__="careers_main"
    id = Column(Integer, primary_key=True,index=True)
    career_name = Column(String)
    career_description = Column(String)
    career_outlook = Column(String)
    job_duties = Column(String)
    skills = Column(String)
    median_salary = Column(String)
    majors = Column(String)

class StudentCareers(Base):
    __tablename__="student_careers"
    id = Column(Integer, primary_key=True,index=True)
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    career_id = Column(Integer,ForeignKey('careers_main.id',ondelete='CASCADE'))
    rank = Column(Integer,default=0)
    students = relationship("Student",back_populates='careers')
    comments = relationship("StudentCareerComment")
    career = relationship("Careers")
    friend_intersections = relationship("StudentCareerIntersections", back_populates="student_career")
    student_career_users = relationship("StudentCareerUsers", back_populates="student_career")

class StudentCareerComment(Base):
    __tablename__ = "student_career_comments"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users_main.id', ondelete='CASCADE'))
    student_career_id = Column(Integer, ForeignKey('student_careers.id', ondelete='CASCADE'))
    content = Column(String)
    date_published = Column(DateTime)
    content_url = Column(String)
    # Add constraints for unique user_id and student_career_id
    student_career = relationship("StudentCareers", back_populates="comments")
    student_career_comments_user = relationship("User", back_populates="student_career_comments")

class StudentCareerUsers(Base):
    __tablename__ = "student_career_users"
    id = Column(Integer, primary_key=True, index=True)
    student_career_id = Column(Integer, ForeignKey('student_careers.id', ondelete='CASCADE'))
    user_id = Column(Integer, ForeignKey('users_main.id', ondelete='CASCADE'))
    student_career = relationship("StudentCareers", back_populates="student_career_users")
    career_users = relationship("User", back_populates="student_career_users")

class StudentTargetSchools(BaseModel):
    __tablename__ = "student_target_schools"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    student_id = Column(Integer,ForeignKey('students_main.id',ondelete='CASCADE'))
    career_id = Column(Integer, ForeignKey('careers_main.id',ondelete='CASCADE'))
    college_id = Column(Integer, ForeignKey('target_schools_main.id', ondelete='CASCADE'))
    college_name = Column(String)
    tution_fees = Column(String)
    probability_of_admission = Column(String)
    positives = Column(ARRAY(String))
    negatives = Column(ARRAY(String))
    why_this_recommendation = Column(String)
    rank = Column(Integer,default=0)
    classification = Column(String)
    acceptance_rate = Column(String)
    comments = relationship("StudentTargetSchoolsComment", back_populates="student_target_school")
    friend_intersections = relationship("StudentTargetSchoolIntersections", back_populates="student_target_school")
    student_target_school_users = relationship("StudentTargetSchoolsUsers", back_populates="student_target_school")
    essay_reviews = relationship("EssayReview", back_populates="student_target_school")
    lor = relationship("LetterOfRecommendation", back_populates="student_target_school")

class StudentTargetSchoolsComment(Base):
    __tablename__ = "student_target_schools_comments"
    id = Column(Integer, primary_key=True,index=True)
    user_id = Column(Integer, ForeignKey('users_main.id', ondelete='CASCADE'))
    target_school_id = Column(Integer, ForeignKey('student_target_schools.id', ondelete='CASCADE'))
    content = Column(String)
    date_published = Column(DateTime)
    content_url = Column(String)
    student_target_school = relationship("StudentTargetSchools", back_populates="comments")
    student_target_school_commenters = relationship("User", back_populates="student_target_school_commenters")

class StudentTargetSchoolsUsers(Base):
    __tablename__ = "student_target_schools_users"
    id = Column(Integer, primary_key=True, index=True)
    student_target_school_id = Column(Integer, ForeignKey('student_target_schools.id', ondelete='CASCADE'))
    user_id = Column(Integer, ForeignKey('users_main.id', ondelete='CASCADE'))
    student_target_school = relationship("StudentTargetSchools", back_populates="student_target_school_users")
    target_school_users = relationship("User", back_populates="student_target_school_users")

# Auto ppopulated table but good to have schema here
class TargetSchools(Base):
    __tablename__ = "target_schools_main"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    college_name = Column(String, index=True)
    college_url = Column(String)
    campus = Column(String)
    college_pic_url = Column(String)
    college_control = Column(String) # Pvt/Public/for-profit/etc
    college_type = Column(String) # 4 year/2 year/trade school/community college/etc
    college_size = Column(String) # small/med/large
    is_hbcu = Column(Boolean) # HBCU institution?
    is_mstc = Column(Boolean) # Minority serving institution?

class Post(Base):
   __tablename__ = "posts_main"
   id = Column(Integer, primary_key=True,index=True)
   user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
   post_title = Column(String)
   post_content = Column(String)
   profile_pic_url = Column(String)
   likes = Column(ARRAY(Integer))
   date_published = Column(DateTime)
   post_content_url = Column(String)
   comments = relationship("Comment")

class Comment(Base):
    __tablename__ = "comments_main"
    id = Column(Integer, primary_key=True,index=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    post_id = Column(Integer,ForeignKey('posts_main.id',ondelete='CASCADE'))
    content = Column(String)
    likes = Column(ARRAY(Integer))
    date_published = Column(DateTime)
    content_url = Column(String)
    profile_pic_url = Column(String)

class UserProfileAIUpdates(Base):
    __tablename__= "student_profile_ai_update_status"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer,ForeignKey('users_main.id',ondelete='CASCADE'))
    profile_last_update = Column(DateTime)
    ai_last_update = Column(DateTime)


# Class for News Posts comments
class NewsComment(Base):
    __tablename__ = "news_comments"
    id = Column(Integer, primary_key=True,index=True)
    user_id = Column(Integer, ForeignKey('users_main.id', ondelete='CASCADE'))
    news_id = Column(Integer, ForeignKey('news_main.id', ondelete='CASCADE'))
    content = Column(String)
    content_url = Column(String)
    date_published = Column(DateTime)
    likes = relationship("NewsCommentLike")
    user = relationship("User")


class NewsCommentLike(Base):
    __tablename__ = "news_comment_like"
    id = Column(Integer, primary_key=True, index=True)
    comment_id = Column(Integer, ForeignKey("news_comments.id", ondelete='CASCADE'), index=True)
    user_id = Column(Integer, ForeignKey("users_main.id", ondelete='CASCADE'), index=True)


# This is the schema for ephemeral news posts
class NewsPost(Base):
    __tablename__ = "news_main"
    id = Column(Integer, primary_key=True, index=True)
    news_title = Column(String)
    news_content_url = Column(String)
    news_published_date = Column(DateTime)
    news_keywords = Column(ARRAY(String))
    likes = relationship("NewsPostLike", backref="news_post", cascade="all, delete-orphan")
    comments = relationship("NewsComment")

class NewsPostLike(Base):
    __tablename__ = "news_likes"
    id = Column(Integer, primary_key=True, index=True)
    post_id = Column(Integer, ForeignKey("news_main.id"), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users_main.id"), nullable=False, index=True)


class Job(Base):
    __tablename__ = "jobs"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, index=True)
    organization = Column(String, index=True)
    deadline = Column(String, index=True)
    area = Column(ARRAY(String), index=True)  
    age = Column(ARRAY(String), index=True) 
    season = Column(ARRAY(String), index=True) 
    eligibility = Column(ARRAY(String), index=True)
    description = Column(String, index=True)
    requirements = Column(String, index=True)
    mode = Column(ARRAY(String), index=True) 
    location = Column(ARRAY(String), index=True) 
    address = Column(String, index=True)
    salary = Column(String, index=True)
    program_fee = Column(String, index=True)
    keywords = Column(ARRAY(String), index=True)
    link = Column(String, index=True)
    listing_type = Column(ARRAY(String), index=True)  # Updated to ARRAY
    is_priority = Column(Boolean, default=False)  # New field for priority
    created_at = Column(TIMESTAMP, server_default=func.current_timestamp())
    bookmarked_by = relationship("Bookmark", back_populates="job")

class MatchedJob(Base):
    __tablename__ = 'matched_jobs'
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey('users_main.id'))
    job_id = Column(Integer, ForeignKey('jobs.id'))

    user = relationship("User")
    job = relationship("Job")

class Bookmark(Base):
    __tablename__ = "bookmarks"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users_main.id"))
    job_id = Column(Integer, ForeignKey("jobs.id"))

    user = relationship("User", back_populates="bookmarks")
    job = relationship("Job", back_populates="bookmarked_by")

    __table_args__ = (UniqueConstraint('user_id', 'job_id', name='uq_user_job'), )


class Notification(Base):
    __tablename__ = "notifications"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users_main.id", ondelete='CASCADE'), nullable=False, index=True)
    template_id = Column(Integer, ForeignKey("notification_templates.id"), nullable=True, index=True)  # Linking to NotificationTemplate
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    type = Column(String(255))
    is_read = Column(Boolean, default=False) 
    scheduled = Column(Boolean, default=False)
    sent = Column(Boolean, default=False) 
    send_time = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))
    updated_at = Column(DateTime, default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
    data = Column(JSON)  

    user = relationship("User", back_populates="notifications")
    template = relationship("NotificationTemplate")  


    def __repr__(self):
        return f"<Notification(id={self.id}, user_id={self.user_id}, title={self.title})>"
    
class NotificationTemplate(Base):
    __tablename__ = "notification_templates"

    id = Column(Integer, primary_key=True, index=True)
    type = Column(String(255), nullable=False)  # 'general', 'fun_fact', 'streaks', etc
    title = Column(String(255), nullable=False)
    message = Column(Text, nullable=False)
    repeatable = Column(Boolean, default=True)  # can be sent again 
    active = Column(Boolean, default=True) # if active, currently in the cycle of notifications users recieve
    created_at = Column(DateTime, default=lambda: datetime.now(timezone.utc))

    def __repr__(self):
        return f"<NotificationTemplate(id={self.id}, title={self.title})>"

class StudentCareerIntersections(Base):
    __tablename__ = "student_career_intersections"

    id = Column(Integer, primary_key=True, index=True)
    student_career_id = Column(Integer, ForeignKey("student_careers.id", ondelete='CASCADE'), nullable=False, index=True)
    friend_user_id = Column(Integer, ForeignKey("users_main.id", ondelete='CASCADE'), nullable=False, index=True)
    # Relationships
    user = relationship("User", back_populates="career_intersections")
    student_career = relationship("StudentCareers", back_populates="friend_intersections")

class StudentTargetSchoolIntersections(Base):
    __tablename__ = "student_target_schools_intersections"

    id = Column(Integer, primary_key=True, index=True)
    student_target_school_id = Column(Integer, ForeignKey("student_target_schools.id", ondelete='CASCADE'), nullable=False, index=True)
    friend_user_id = Column(Integer, ForeignKey("users_main.id", ondelete='CASCADE'), nullable=False, index=True)
    # Relationships
    user = relationship("User", back_populates="target_school_intersections")
    student_target_school = relationship("StudentTargetSchools", back_populates="friend_intersections")

class EssayReview(Base):
    __tablename__ = "essay_reviews"

    id = Column(Integer, primary_key=True, index=True)
    student_target_school_id = Column(Integer, ForeignKey("student_target_schools.id", ondelete='CASCADE'), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users_main.id", ondelete='CASCADE'), nullable=False, index=True)
    essay_review_s3_url = Column(String, nullable=False)
    date_reviewed = Column(DateTime, nullable=True)
    student_target_school = relationship("StudentTargetSchools", back_populates="essay_reviews")
    user = relationship("User", back_populates="essay_reviews")

class LetterOfRecommendation(Base):
    __tablename__ = "letter_of_recommendations"

    id = Column(Integer, primary_key=True, index=True)
    student_target_school_id = Column(Integer, ForeignKey("student_target_schools.id", ondelete='CASCADE'), nullable=False, index=True)
    user_id = Column(Integer, ForeignKey("users_main.id", ondelete='CASCADE'), nullable=False, index=True)
    letter_of_recommendation_s3_url = Column(String, nullable=False)
    counselor_id = Column(Integer, ForeignKey("counselors_main.id", ondelete='CASCADE'), nullable=False, index=True)
    date_created = Column(DateTime, nullable=True)
    student_target_school = relationship("StudentTargetSchools", back_populates="lor")
    user = relationship("User", back_populates="lor")
    counselor = relationship("Counselor", back_populates="lor")