
from datetime import date
from enum import Enum

# Constants
class Constants(Enum):
    DB_USER_TYPE_STUDENT="student"
    DB_USER_TYPE_COUNSELOR="counselor"
    DABBL_ADMIN=1
    DABBL_LOGO="https://dabbl-mvp-storage.s3.amazonaws.com/private-resources/us-east-2:24a162db-8b67-cfcc-d383-de24ab9d6eea/profilePics/a7151418-9ad2-4c96-af95-11791ff90f60.png"
    COUNSELOR_APPROVAL_URL="counselor/request"
    DABBL_SUPPORT_EMAIL="support@go-dabbl.ai"
    DABBL_LOGO_NEW="https://dabbl-mvp-storage.s3.us-east-2.amazonaws.com/private-resources/defaults/dabbl+transparent+logo.PNG"
    POST_TYPE_REGULAR="post"
    POST_TYPE_NEWS="news"
    CONN_STATUS_REJECTED = "Rejected"
    CONN_STATUS_PENDING = "Pending"
    CONN_STATUS_CONNECTED = "Connected"
    CONN_STATUS_NOT_INITIATED = "Not-Initiated"
    STD_TEST_TYPE_SAT="sat"
    STD_TEST_TYPE_ACT="act"
    DUMMY_BIRTHDATE=date(1900, 1, 1)
    DUMMY_BIRTHDATE_STR="01-01-1900"
    PARENT_APPROVAL_TEXT_CONTENT="""
        Parental Approval Request

        Dear Parent,

        We are reaching out to request your approval for your child to connect with a counselor through our platform. This connection is intended to provide your child with additional support and guidance.

        If you recognize the counselor, please click here to approve this request: {url}

        If you do not recognize the counselor or have any concerns, please report it immediately to support@go-dabbl.ai.

        Thank you for your attention and cooperation.

        Best regards,
        The dabbL Team
    """

    PARENT_APPROVAL_HTML_CONTENT="""
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Parental Approval Request</title>
            <style>
                body {{
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f9;
                    margin: 0;
                    padding: 0;
                }}
                .container {{
                    max-width: 600px;
                    margin: 20px auto;
                    background-color: #ffffff;
                    padding: 20px;
                    border-radius: 5px;
                    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                }}
                .header {{
                    background-color: #000000;
                    color: #ffffff;
                    padding: 10px;
                    text-align: center;
                    border-radius: 5px 5px 0 0;
                }}
                .logo {{
                    max-width: 50px;
                    margin-bottom: 1px;
                }}
                .content {{
                    margin: 20px 0;
                }}
                .footer {{
                    text-align: center;
                    font-size: 12px;
                    color: #777;
                }}
                .button {{
                    display: inline-block;
                    padding: 10px 20px;
                    margin: 10px 0;
                    background-color: #4CAF50;
                    color: #ffffff;
                    text-decoration: none;
                    border-radius: 5px;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <img src="{logo_url}" alt="Logo" class="logo"/>
                    <h1>Parental Approval Request</h1>
                </div>
                <div class="content">
                    <p>Dear Parent,</p>
                    <p>We are reaching out to request your approval for your child to connect with a counselor through our platform. This connection is intended to provide your child with additional support and guidance.</p>
                    <p>If you recognize the counselor, please click here to approve or deny the connect request: <a href="{url}"> Approve/Deny Request </a></p>
                    <p>If you do not recognize the counselor or have any concerns, please report it immediately to <a href="mailto:support@go-dabbl.ai">support@go-dabbl.ai</a>.</p>
                    <p>Thank you for your attention and cooperation.</p>
                    <p>Best regards,</p>
                    <p>The dabbL Team</p>
                </div>
                <div class="footer">
                    <p>&copy; 2024 dabbL Corp. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>
    """